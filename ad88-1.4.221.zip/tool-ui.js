// AD88 XNK TOOL — UI shell. Core order-processing remains in content.js.
(() => {
  'use strict';
  const S={running:false,processed:0,skipped:0,manual:0,lastOrder:'—',speedHistory:[]};
  const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const q=(sel,root=document)=>root.querySelector(sel);
  const formatAmountInput=(v,currency='VND')=>{
    if(currency==='USDT'){
      let s=String(v??'').replace(/,/g,'.').replace(/[^0-9.]/g,'');
      const parts=s.split('.');
      if(parts.length>2)s=parts[0]+'.'+parts.slice(1).join('');
      return s;
    }
    const d=String(v??'').replace(/[^0-9]/g,'');
    return d?d.replace(/\B(?=(\d{3})+(?!\d))/g,'.'):'';
  };
  const parseAmountInput=(v,currency='VND')=>{
    if(currency==='USDT'){
      const s=String(v??'').replace(/,/g,'.').trim();
      if(s==='')return null;
      const n=Number(s);
      return Number.isFinite(n)?n:null;
    }
    const d=String(v??'').replace(/[^0-9]/g,'');
    return d===''?null:Number(d);
  };
  function getProviderConfigState(){
    let saved={};
    try{saved=JSON.parse(localStorage.getItem('AD88_XNK_PROVIDER_CONFIG')||'{}')||{};}catch{saved={};}
    const out={};
    for(const key of PROVIDERS){
      const def=PROVIDER_CONFIG_DEFAULTS[key]||{};
      let item=saved[key];
      if(!item && typeof AD88_providerCanonical==='function'){
        for(const [savedKey,v] of Object.entries(saved)){
          const canonical=AD88_providerCanonical(savedKey);
          if(canonical===key){item=v;break;}
          if(v && AD88_providerCanonical(v.name||'')===key){item=v;break;}
        }
      }
      out[key]={
        name:def.name||key,
        currency:def.currency||'VND',
        min:item && item.min!==undefined && item.min!==null && item.min!=='' ? item.min : (def.min??null),
        max:item && item.max!==undefined && item.max!==null && item.max!=='' ? item.max : (def.max??null)
      };
    }
    return out;
  }
  function setProviderConfigState(state){
    const out={};
    for(const key of PROVIDERS){
      const def=PROVIDER_CONFIG_DEFAULTS[key]||{};
      const x=state?.[key]||{};
      out[key]={
        name:def.name||key,
        currency:def.currency||'VND',
        min:x.min===undefined?null:x.min,
        max:x.max===undefined?null:x.max
      };
    }
    localStorage.setItem('AD88_XNK_PROVIDER_CONFIG',JSON.stringify(out));
    window.dispatchEvent(new CustomEvent('AD88_PROVIDER_CONFIG_CHANGED',{detail:out}));
  }
  // Provider Registry: toàn bộ tên/currency/MIN/MAX/alias lấy từ provider-registry.js.
  const PROVIDERS = typeof AD88_providerNames === 'function' ? AD88_providerNames() : [];
  const PROVIDER_CONFIG_DEFAULTS = typeof AD88_providerDefinition === 'function'
    ? Object.fromEntries(PROVIDERS.map(k => { const p=AD88_providerDefinition(k)||{}; return [k,{name:p.name||k,currency:p.currency||'VND',min:p.min??null,max:p.max??null}]; }))
    : {};

  const LED_COLORS=[
    {name:'Xanh AD88',value:'#2DB38D'},
    {name:'Cyan',value:'#00E5FF'},
    {name:'Xanh dương',value:'#2196FF'},
    {name:'Tím',value:'#9C5CFF'},
    {name:'Hồng',value:'#FF4FA3'},
    {name:'Đỏ',value:'#FF4D6D'},
    {name:'Cam',value:'#FF9D3D'},
    {name:'Vàng',value:'#FFD43B'},
    {name:'Xanh lá',value:'#35E07F'},
    {name:'Trắng',value:'#F4FAFF'},
    {name:'Xanh băng',value:'#7DD3FC'},
    {name:'Tím hồng',value:'#D946EF'}
  ];
  function getProviderState(){
    try{return JSON.parse(localStorage.getItem('AD88_XNK_PROVIDER_TOGGLES')||'{}')}catch{return {}}
  }
  function setProviderState(s){localStorage.setItem('AD88_XNK_PROVIDER_TOGGLES',JSON.stringify(s));window.dispatchEvent(new CustomEvent('AD88_PROVIDER_TOGGLES_CHANGED',{detail:s}));}
  function getLedColor(){return localStorage.getItem('AD88_XNK_LED_COLOR')||'#2DB38D'}
  function setLedColor(c){localStorage.setItem('AD88_XNK_LED_COLOR',c);document.documentElement.style.setProperty('--ad88-led',c);window.dispatchEvent(new CustomEvent('AD88_LED_COLOR_CHANGED',{detail:c}));}
  function getLedSettings(){
    const num=(k,d)=>{const v=Number(localStorage.getItem(k));return Number.isFinite(v)?v:d};
    return {brightness:num('AD88_XNK_LED_BRIGHTNESS',90),speed:num('AD88_XNK_LED_SPEED',50),effect:localStorage.getItem('AD88_XNK_LED_EFFECT')||'single',enabled:localStorage.getItem('AD88_XNK_LED_ENABLED')!=='0',thick:num('AD88_XNK_LED_THICK',60)};
  }
  function setLedSetting(k,v){localStorage.setItem(k,String(v));window.dispatchEvent(new CustomEvent('AD88_LED_SETTINGS_CHANGED',{detail:{key:k,value:v}}));}
  /* ===== Giao diện banner (chỉ đổi hình nền tiêu đề; logo, chữ, giờ, font, màu giữ nguyên) ===== */
  const BANNER_THEMES=[
    {id:'christmas',name:'Giáng sinh',desc:'Giao diện hiện tại (mặc định)',file:'assets/ad88-header-christmas.svg'},
    {id:'circuit',name:'Mạch điện tử',desc:'Mạch xanh ngọc, xung điện chạy',file:'assets/ad88-header-circuit.svg'},
    {id:'city',name:'Thành phố pháo hoa',desc:'Thành phố neon, pháo hoa bắn liên tục',file:'assets/ad88-header-city.svg'}
  ];
  function getBannerThemeId(){let v='';try{v=localStorage.getItem('AD88_XNK_BANNER_THEME')||'';}catch(e){}return BANNER_THEMES.some(t=>t.id===v)?v:'christmas';}
  function setBannerThemeId(id){try{localStorage.setItem('AD88_XNK_BANNER_THEME',id);}catch(e){}window.dispatchEvent(new CustomEvent('AD88_BANNER_THEME_CHANGED',{detail:{id}}));}
  function applyBannerTheme(root){
    const hd=(root||document).querySelector('.ad88-head.new-head');if(!hd)return;
    const t=BANNER_THEMES.find(x=>x.id===getBannerThemeId())||BANNER_THEMES[0];
    hd.style.setProperty('--ad88-head-art',`url('${chrome.runtime.getURL(t.file)}')`);
    hd.dataset.banner=t.id;
  }
  const TOOL_SETTINGS_DEFAULTS={auto:true,bank:true,unlock:true,returnUnlock:true,lockWatchdog:true,balanceRefresh:true,balanceScan:false,bankBadSkip:true,usdt:true,scanTop:true,scanBottom:false,noticeClose:true,autoReload:false,sound:true,returnReasonLog:true,lite:false};
  function getToolSettings(){
    const out={};
    for(const [k,d] of Object.entries(TOOL_SETTINGS_DEFAULTS)){
      const raw=localStorage.getItem('AD88_XNK_SETTING_'+k);
      out[k]=raw===null?d:raw==='true';
    }
    return out;
  }
  function getToolPanelOpen(){
    const raw=localStorage.getItem('AD88_XNK_TOOL_PANEL_OPEN');
    return raw===null ? true : raw==='true';
  }
  // 1.4.207: giao diện thu nhỏ thành biểu tượng tròn → ngừng vẽ lại bảng/thống kê/số dư (mở lại thì vẽ ngay).
  function panelHidden(){try{const p=document.getElementById('ad88-tool-panel');return !!p&&p.classList.contains('ad88-hidden');}catch(_){return false;}}
  function setToolPanelOpen(v){
    localStorage.setItem('AD88_XNK_TOOL_PANEL_OPEN',String(!!v));
  }
  // 1.4.163: CHẾ ĐỘ NHẸ (mặc định TẮT). Chỉ tắt hiệu ứng giao diện và giảm tần suất vẽ lại; KHÔNG đụng tới xử lý đơn.
  function applyLiteMode(){try{
    const on=!!getToolSettings().lite;document.documentElement.classList.toggle('ad88-lite',on);
    if(on){const root=document.getElementById('ad88-xnk-tool-root');const sv=root&&root.querySelector('#ad88-stats-view');
      if(sv&&!sv.classList.contains('ad88-hidden')){sv.classList.add('ad88-hidden');root.querySelector('#ad88-home-content')?.classList.remove('ad88-hidden');root.querySelector('#ad88-tool-main')?.classList.remove('stats-mode');}}
    else if(typeof renderStatus==='function'){setTimeout(()=>{try{renderStatus();}catch(_){}},0);}
  }catch(_){}}
  try{applyLiteMode();window.addEventListener('AD88_TOOL_SETTING_CHANGED',e=>{if(!e.detail||e.detail.key==='lite')applyLiteMode();});}catch(_){}
  // 1.4.210: THEME SÁNG / TỐI / TỰ ĐỘNG (mặc định TỐI như cũ). Chỉ đổi màu giao diện của Tool, không đụng xử lý đơn.
  const THEME_LABELS={dark:'Tối',light:'Sáng',auto:'Tự động (6h–18h sáng)'};
  function getThemeMode(){try{const v=localStorage.getItem('AD88_XNK_THEME_MODE');return (v==='light'||v==='auto')?v:'dark';}catch(_){return 'dark';}}
  function themeIsLight(mode){if(mode==='light')return true;if(mode==='auto'){const h=new Date().getHours();return h>=6&&h<18;}return false;}
  function applyTheme(){try{document.documentElement.classList.toggle('ad88-theme-light',themeIsLight(getThemeMode()));}catch(_){}}
  function setThemeMode(m){try{localStorage.setItem('AD88_XNK_THEME_MODE',m);}catch(_){}applyTheme();}
  try{applyTheme();setInterval(()=>{if(getThemeMode()==='auto')applyTheme();},300000);}catch(_){}
  function setToolSetting(k,v){
    localStorage.setItem('AD88_XNK_SETTING_'+k,String(!!v));
    window.dispatchEvent(new CustomEvent('AD88_TOOL_SETTING_CHANGED',{detail:{key:k,value:!!v}}));
  }
  function playNotice(){
    try{
      if(!getToolSettings().sound)return;
      const Ctx=window.AudioContext||window.webkitAudioContext;
      if(!Ctx)return;
      const ctx=new Ctx(); const osc=ctx.createOscillator(); const gain=ctx.createGain();
      osc.type='sine'; osc.frequency.value=880; gain.gain.setValueAtTime(.045,ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(.001,ctx.currentTime+.16); osc.connect(gain);gain.connect(ctx.destination);
      osc.start();osc.stop(ctx.currentTime+.16);
    }catch{}
  }

  function healthStatus(){
    try{return window.AD88_XNK_BOT?.status?.()?.health||{};}catch{return {}}
  }
  function fmtMs(v){
    const n=Number(v);
    if(!Number.isFinite(n)) return '—';
    if(n<1000) return Math.round(n)+'ms';
    return (n/1000).toFixed(n>=10000?0:1)+'s';
  }
  function fmtUptime(v){
    const n=Math.max(0,Math.floor(Number(v)||0)/1000);
    const s=Math.floor(n%60), m=Math.floor(n/60)%60, h=Math.floor(n/3600);
    return [h,m,s].map((x,i)=>i===0?String(x).padStart(2,'0'):String(x).padStart(2,'0')).join(':');
  }
  function healthTone(h){
    if(h.state==='ERROR') return ['bad','LỖI'];
    if(h.state==='WARNING') return ['warn','CẢNH BÁO'];
    if(h.state==='IDLE') return ['idle','ĐANG CHỜ'];
    return ['good','TỐT'];
  }
  function renderHealthPage(el){
    const h=healthStatus(), [tone,label]=healthTone(h), avg=fmtMs(h.avgProcessMs), p95=fmtMs(h.p95Ms), p99=fmtMs(h.p99Ms);
    el.innerHTML=head('Sức khỏe & tốc độ')+`<div class="ad88-health-page ad88-detail-page"><div class="health-hero ${tone}"><span class="health-pulse"></span><div><b>${label}</b><small>${h.auto?'Tool đang tự động xử lý':'Tool chưa chạy tự động'}</small></div><strong>${h.queue||0}<small>đơn chờ</small></strong></div><div class="health-grid ad88-detail-grid"><div><span>Heartbeat</span><b>${fmtMs(h.heartbeatMs)}</b></div><div><span>Last action</span><b>${fmtMs(h.lastActionMs)}</b></div><div><span>Website / DOM</span><b>${h.currentStep||'Ready'}</b></div><div><span>API TB</span><b>${fmtMs(h.avgApiMs)}</b></div><div><span>Lỗi</span><b class="${h.errors?'bad-t':''}">${h.errors||0}</b></div><div><span>Timeout</span><b class="${h.timeouts?'bad-t':''}">${h.timeouts||0}</b></div></div><div class="health-section-title ad88-detail-section-title">TỐC ĐỘ XỬ LÝ</div><div class="speed-grid ad88-detail-grid"><div><span>Trung bình</span><b>${avg}</b></div><div><span>P50</span><b>${fmtMs(h.p50Ms)}</b></div><div><span>P95</span><b>${p95}</b></div><div><span>P99</span><b>${p99}</b></div><div><span>Nhanh nhất</span><b>${fmtMs(h.fastestMs)}</b></div><div><span>Chậm nhất</span><b>${fmtMs(h.slowestMs)}</b></div></div><div class="health-current ad88-detail-current"><div><span>Đơn hiện tại</span><b>${esc(h.currentOrder||'—')}</b></div><div><span>Bước hiện tại</span><b>${esc(h.currentStep||'Sẵn sàng')}</b></div><div><span>Thời gian đơn</span><b>${fmtMs(h.currentElapsedMs)}</b></div><div><span>Uptime</span><b>${fmtUptime(h.uptimeMs)}</b></div></div>${h.lastError?`<div class="health-error">⚠ ${esc(h.lastError)}</div>`:''}<div class="health-note ad88-detail-note">Đánh giá dựa trên tiến trình thực tế, thời gian xử lý, heartbeat, API, timeout và trạng thái DOM.</div></div>`;
    q('[data-back]',el).onclick=back;
  }

  function create(){
    if(q('#ad88-xnk-tool-root')) return;
    const savedAction=Number(localStorage.getItem('AD88_XNK_CFG_ACTION_TIMEOUT'));
    const savedBank=Number(localStorage.getItem('AD88_XNK_CFG_BANK_TIMEOUT'));
    const savedDelay=Number(localStorage.getItem('AD88_XNK_CFG_NEXT_DELAY'));
    if(window.XNK_CONFIG){
      if(Number.isFinite(savedAction)&&savedAction>0) window.XNK_CONFIG.actionTimeoutMs=savedAction;
      if(Number.isFinite(savedBank)&&savedBank>0) window.XNK_CONFIG.bankCheckTimeoutMs=savedBank;
      if(Number.isFinite(savedDelay)&&savedDelay>0) window.XNK_CONFIG.nextOrderDelayMs=savedDelay;
      const bool=(k,d)=>{const v=localStorage.getItem(k);return v===null?d:v==='true'};
      const num=(k,d)=>{const v=Number(localStorage.getItem(k));return Number.isFinite(v)?v:d};
      window.XNK_CONFIG.autoSync=bool('AD88_XNK_AUTO_SYNC',window.XNK_CONFIG.autoSync!==false);
      window.XNK_CONFIG.pollMinMs=num('AD88_XNK_POLL_MIN',window.XNK_CONFIG.pollMinMs||100);
      window.XNK_CONFIG.pollMaxMs=num('AD88_XNK_POLL_MAX',window.XNK_CONFIG.pollMaxMs||650);
      window.XNK_CONFIG.nextOrderDelayMinMs=num('AD88_XNK_DELAY_MIN',window.XNK_CONFIG.nextOrderDelayMinMs||350);
      window.XNK_CONFIG.nextOrderDelayMaxMs=num('AD88_XNK_DELAY_MAX',window.XNK_CONFIG.nextOrderDelayMaxMs||3000);
    }
    document.documentElement.style.setProperty('--ad88-led',getLedColor());
    const root=document.createElement('div');root.id='ad88-xnk-tool-root';root.dataset.ui='new';
    root.innerHTML=`
      <button id="ad88-tool-fab" title="AD88 XNK TOOL"><em class="fab-led"></em><span class="fab-name">AD88</span><small class="fab-state" id="ad88-fab-state">Đang chạy</small></button>
      <section id="ad88-tool-panel" class="${getToolPanelOpen()?'':'ad88-hidden'}">
        <div class="ad88-resize-handle ad88-resize-br" id="ad88-resize-handle"></div><div class="ad88-resize-handle ad88-resize-tl" id="ad88-resize-handle-tl"></div>
        <header class="ad88-head new-head" style="--ad88-head-art:url('${chrome.runtime.getURL('assets/ad88-header-christmas.svg')}');--ad88-logo:url('${chrome.runtime.getURL('assets/ad88-logo.png')}')">
          <div class="ad88-brand new-brand"><strong class="ad88-logo-text"><i>AD</i><b>88</b></strong><span><b>XNK TOOL</b><small>v${AD88_VERSION}</small></span></div>
          <div class="new-head-status"><span class="status-dot"></span><div><b id="tool-run-status">Đang chạy</b><small id="tool-runtime">00:00:00</small></div></div>
          <div class="ad88-head-actions"><button data-act="min" title="Thu gọn">−</button><button data-act="close" title="Đóng">×</button></div>
        <div class="ad88-snow" aria-hidden="true"><i></i><i></i><i></i></div></header>
        <div id="ad88-led-palette" class="ad88-led-palette ad88-hidden"><div class="ad88-led-palette-title">MÀU ĐÈN LED</div><div class="ad88-led-swatches">${LED_COLORS.map(c=>`<button type="button" data-led="${c.value}" title="${c.name}" aria-label="${c.name}" style="--c:${c.value}"><span></span></button>`).join('')}</div></div>
        <main id="ad88-tool-main" class="new-main">
          <div class="new-actions"><button class="run" data-act="run" type="button"><span>▶</span><b>CHẠY</b></button><button class="stop" data-act="stop" type="button"><span>■</span><b>DỪNG</b></button><button data-page="settings" title="Cài đặt"><svg class="na-ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 6h10M18 6h2M4 12h4M12 12h8M4 18h12"/><circle cx="16" cy="6" r="2"/><circle cx="10" cy="12" r="2"/><circle cx="18" cy="18" r="2"/></svg><small>Cài đặt</small></button><button data-page="log" title="Check thông tin"><svg class="na-ic" viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4M8 11l2 2 4-4"/></svg><small>Check thông tin</small></button><button data-act="stats" title="Thống kê"><svg class="na-ic" viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="12" width="4" height="8" rx="1"/><rect x="10" y="4" width="4" height="16" rx="1"/><rect x="17" y="9" width="4" height="11" rx="1"/></svg><small>THỐNG KÊ</small></button><button data-act="balance" title="Số dư nhà thứ 3"><svg class="na-ic" viewBox="0 0 24 24" aria-hidden="true"><rect x="2.5" y="6" width="19" height="14" rx="3"/><path d="M2.5 10h19M7 15h3"/></svg><small>SỐ DƯ</small></button></div>
          <div class="new-home-content" id="ad88-home-content">
          <div class="new-dashboard">
            <section class="new-card health-card"><div class="new-card-title"><span>❤</span><b>BẢNG SỨC KHỎE</b><i>?</i><strong id="tool-health-label">TỐT</strong></div>
              <div class="health-list">
                <div><span>▣</span><label>Tool</label><b id="new-health-tool">Đang chạy</b></div>
                <div><span>◎</span><label>Kết nối website</label><b id="new-health-web">Ổn định</b></div>
                <div><span>▣</span><label>API</label><b id="new-health-api">—</b></div>
                <div><span>▣</span><label>DOM</label><b id="new-health-dom">Ready</b></div>
                <div><span>◉</span><label>Queue</label><b id="new-health-queue">0 đơn</b></div>
                <div><span>↻</span><label>Đang xử lý</label><b id="new-health-order">—</b></div>
                <div><span>»</span><label>Bước hiện tại</label><b id="new-health-step">Sẵn sàng</b></div>
                <div><span>◷</span><label>Last action</label><b id="new-health-last">—</b></div>
                <div><span>△</span><label>Lỗi / Timeout</label><b id="new-health-errors">0 / 0</b></div>
              </div>
            </section>
            <section class="new-card speed-card"><div class="new-card-title"><span>◔</span><b>TỐC ĐỘ XỬ LÝ</b><i>?</i><select id="new-speed-window"><option>10 phút gần nhất</option><option>30 phút gần nhất</option><option>Hôm nay</option></select></div>
              <div class="speed-chart-wrap"><div class="speed-axis">Đơn/phút</div><svg id="tool-speed-chart" viewBox="0 0 220 92" preserveAspectRatio="none" aria-label="Biểu đồ tốc độ"><defs><linearGradient id="speedFill" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stop-color="#2DB38D" stop-opacity=".42"/><stop offset="1" stop-color="#2DB38D" stop-opacity="0"/></linearGradient></defs><path id="speed-area" fill="url(#speedFill)" d="M0 80 L0 80 L220 80 Z"></path><polyline id="speed-line" fill="none" stroke="#2DB38D" stroke-width="2" points="0,80 220,80"></polyline><g id="speed-dots"></g></svg><div class="speed-times"><span>10:40</span><span>10:42</span><span>10:44</span><span>10:46</span><span>10:48</span><span>10:50</span></div></div>
              <div class="speed-metrics"><div><span>⚡</span><b id="tool-speed">—</b><small>đơn/phút</small></div><div><span>◷</span><b id="tool-avg">—</b><small>TB mỗi đơn</small></div><div><span>▶</span><b id="tool-fastest">—</b><small>Nhanh nhất</small></div><div><span>⌛</span><b id="tool-slowest">—</b><small>Chậm nhất</small></div></div>
            </section>
          </div>
          <section class="new-card current-card"><div class="new-card-title"><span>◌</span><b>ĐƠN HIỆN TẠI</b><button data-page="health">Chi tiết <em>›</em></button></div><div class="current-grid"><div><small>Mã đơn</small><b id="new-order-id">—</b></div><div><small>Số tiền</small><b id="new-order-amount">—</b><em id="new-order-currency">VNĐ</em></div><div><small>Nhà thứ ba</small><b id="new-order-provider">—</b></div><div><small>Thời gian</small><b id="new-order-time">00:00</b></div><div><small>Trạng thái</small><b class="current-status" id="new-order-status">Đang kiểm tra</b></div></div></section>
          <div class="new-hidden-stats" aria-hidden="true"><span id="tool-order">—</span><span id="tool-done">0</span><span id="tool-skip">0</span><span id="tool-manual">0</span></div>
          </div>
          <section id="ad88-stats-view" class="ad88-stats-view ad88-hidden" aria-label="Thống kê xử lý"></section>
          <div class="new-mini-footer"><button data-page="providers">Nhà thứ 3</button><button data-page="about">Thông tin Tool</button><span>v${AD88_VERSION}</span></div>
        </main>
        <section id="ad88-tool-sub" class="ad88-hidden"></section>
      </section>`;
    document.body.appendChild(root);
    ensureLedFrame(q('#ad88-tool-panel',root));
    restorePosition(root);bind(root);setupFabReveal(root);refreshCore();
    applyBannerTheme(root);window.addEventListener('AD88_BANNER_THEME_CHANGED',()=>applyBannerTheme(root));
    renderBalanceBoard();let balDeb=null;window.addEventListener('AD88_PROVIDER_BALANCES_CHANGED',()=>{clearTimeout(balDeb);balDeb=setTimeout(()=>{if(!panelHidden())renderBalanceBoard();},250);});setInterval(()=>{if(!document.hidden&&!panelHidden()&&!document.documentElement.classList.contains('ad88-lite')&&!document.documentElement.classList.contains('ad88-nobal'))renderBalanceBoard();},30000);
    const panel=q('#ad88-tool-panel',root);
    if(panel && 'ResizeObserver' in window){const ro=new ResizeObserver(()=>{updateNewUiScale(panel);updateLedFrame(panel);});ro.observe(panel);}
    window.addEventListener('AD88_LED_COLOR_CHANGED',()=>updateLedFrame(panel));
    window.addEventListener('AD88_LED_SETTINGS_CHANGED',()=>updateLedFrame(panel));
    window.addEventListener('resize',()=>{updateNewLayout(panel);updateLedFrame(panel);clampRootToViewport(root,true);savePosition(root);});
  }
  function ensureLedFrame(panel){
    if(!panel || panel.querySelector('.ad88-led-frame')) return;
    const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');
    svg.classList.add('ad88-led-frame');
    svg.setAttribute('aria-hidden','true');
    panel.appendChild(svg);
    updateLedFrame(panel);
  }
  // LED viền v2: nét sắc (không dùng blur filter nên không bị lem), đuôi sao chổi chuyển mờ dần,
  // vầng sáng bằng lớp nét rộng trong suốt. Mỗi hiệu ứng được dựng riêng.
  function buildLedMarkup(w,h,r,ls){
    const bright=Math.max(.1,Math.min(5,ls.brightness/100));
    const clip=v=>Math.max(0,Math.min(1,v));
    const D=Math.max(1.2,5.5-(Math.max(10,Math.min(100,ls.speed))/100)*4.5);
    const sw=(2.6+Math.min(bright,2)*.4).toFixed(2);
    const geo=`x="1.5" y="1.5" width="${Math.max(1,w-3)}" height="${Math.max(1,h-3)}" rx="${Math.max(1,r-1)}" ry="${Math.max(1,r-1)}" pathLength="1000" fill="none" vector-effect="non-scaling-stroke"`;
    const rect=(cls,extra,style)=>`<rect class="led-seg ${cls}" ${geo} ${extra} style="${style}"/>`;
    let out='';
    const track=op=>rect('led-track',`stroke-width="1"`,`stroke:currentColor;opacity:${clip(op*bright).toFixed(2)}`);
    const comet=(scale,dur,delay,rev,pieces,glow,col)=>{const C=col||'currentColor';
      const L=[260,190,130,85,50,24].slice(6-pieces).map(v=>Math.round(v*scale));
      const O=[.16,.26,.4,.58,.8,1].slice(6-pieces);
      let m='';
      L.forEach((len,i)=>{
        const o=rev?0:len, anim=rev?'led-run-rev':'led-run';
        const st=`stroke:${C};stroke-dasharray:${len} ${1000-len};--o:${o}px;animation:${anim} ${dur}s linear ${-delay}s infinite`;
        if(glow) m+=rect('led-glow',`stroke-width="9" stroke-linecap="round"`,st+`;opacity:${clip(O[i]*.22*bright).toFixed(2)}`);
        m+=rect('led-core',`stroke-width="${sw}" stroke-linecap="round"`,st+`;opacity:${clip(O[i]*(.55+.45*bright)).toFixed(2)}`);
      });
      const hl=Math.max(4,Math.round(12*scale));
      m+=rect('led-head',`stroke-width="1.6" stroke-linecap="round"`,`stroke:#fff;stroke-dasharray:${hl} ${1000-hl};--o:${hl}px;animation:led-run ${dur}s linear ${-delay}s infinite;opacity:${clip(.9*Math.min(1,bright)).toFixed(2)}`);
      return m;
    };
    switch(ls.effect==='two'?'two-way':ls.effect){
      case 'two-way': out=track(.16)+comet(.8,D,0,false,6,true)+comet(.8,D,D/2,true,6,true);break;
      case 'multi': out=track(.16)+[0,1,2,3].map(i=>comet(.42,D*1.15,D*1.15*i/4,false,4,false)).join('');break;
      case 'comet': out=track(.14)+comet(1.9,D*1.25,0,false,6,true);break;
      case 'pulse': out=rect('led-glow',`stroke-width="7"`,`stroke:currentColor;opacity:${clip(.2*bright)};animation:led-breathe ${Math.max(1.2,D*.6)}s ease-in-out infinite`)+rect('led-core',`stroke-width="${sw}"`,`stroke:currentColor;animation:led-breathe ${Math.max(1.2,D*.6)}s ease-in-out infinite`);break;
      case 'rainbow': {
        const N=12,len=1000/N;
        out=Array.from({length:N},(_,i)=>rect('led-core',`stroke-width="${sw}"`,`stroke:hsl(${i*360/N},95%,${Math.round(52+Math.min(bright,1.5)*6)}%);stroke-dasharray:${len+2} ${1000-len-2};--o:${-i*len}px;animation:led-run ${D*1.6}s linear infinite;opacity:${clip(.55+.45*bright)}`)).join('');
        out=track(.10)+out;break;}
      case 'wave': {
        const N=14,len=1000/N;
        out=track(.10)+Array.from({length:N},(_,i)=>rect('led-core',`stroke-width="${sw}"`,`stroke:currentColor;stroke-dasharray:${len-3} ${1000-len+3};stroke-dashoffset:${-i*len}px;animation:led-wave ${D*.9}s ease-in-out ${-(i/N)*D*.9}s infinite`)).join('');break;}
      case 'spark': {
        const cfg=[[1,0,false],[1.35,.4,true],[.8,.7,false]];
        out=track(.14)+cfg.map(([k,d,rev])=>{const len=14,dur=D*k*1.1;const st=`stroke:currentColor;stroke-dasharray:${len} ${1000-len};--o:${rev?0:len}px;animation:${rev?'led-run-rev':'led-run'} ${dur}s linear ${-d*dur}s infinite`;
          return rect('led-glow',`stroke-width="8" stroke-linecap="round"`,st+`;opacity:${clip(.3*bright)}`)+rect('led-core',`stroke-width="${sw}" stroke-linecap="round"`,st)+rect('led-head',`stroke-width="1.2" stroke-linecap="round"`,`stroke:#fff;stroke-dasharray:5 995;--o:${rev?0:5}px;animation:${rev?'led-run-rev':'led-run'} ${dur}s linear ${-d*dur}s infinite`);}).join('');break;}
      case 'chase': out=track(.14)+['#ff4d6d','#ffd34a','#35c6ff'].map((c,i)=>comet(.7,D*1.2,D*1.2*i/3,false,5,true,c)).join('');break;
      case 'dual': out=track(.14)+comet(.9,D,0,false,6,true)+comet(.9,D,D/2,true,6,true,'#ff4d9a');break;
      case 'snake': out=track(.14)+comet(3.2,D*1.5,0,false,6,true);break;
      case 'fire': out=track(.12)+comet(1.3,D*.9,0,false,6,true,'#ff4a1c')+comet(.85,D*.9,D*.22,false,5,true,'#ffa526')+comet(.5,D*.9,D*.4,false,4,true,'#ffe27a');break;
      case 'marquee': {const g=`stroke-linecap="round" stroke-width="3.4"`;out=track(.12)+rect('led-glow',`stroke-linecap="round" stroke-width="8"`,`stroke:currentColor;stroke-dasharray:0.1 8.9;opacity:${clip(.25*bright)};animation:led-march ${D*.5}s linear infinite`)+rect('led-core',g,`stroke:currentColor;stroke-dasharray:0.1 8.9;animation:led-march ${D*.5}s linear infinite;opacity:${clip(.6+.4*bright)}`);break;}
      case 'xmas': {const cols=['#ff3b3b','#ffd34a','#3be07a','#35c6ff'];out=track(.12)+cols.map((c,i)=>rect('led-core',`stroke-linecap="round" stroke-width="4"`,`stroke:${c};stroke-dasharray:0.1 35.9;stroke-dashoffset:${-i*9}px;filter:none;animation:led-xblink ${D*.5}s ease-in-out ${-i*D*.125}s infinite`)+rect('led-glow',`stroke-linecap="round" stroke-width="9"`,`stroke:${c};stroke-dasharray:0.1 35.9;stroke-dashoffset:${-i*9}px;opacity:.28;animation:led-xblink ${D*.5}s ease-in-out ${-i*D*.125}s infinite`)).join('');break;}
      case 'heart': out=rect('led-glow',`stroke-width="8"`,`stroke:currentColor;opacity:${clip(.22*bright)};animation:led-beat ${D*.5}s ease-in-out infinite`)+rect('led-core',`stroke-width="${sw}"`,`stroke:currentColor;animation:led-beat ${D*.5}s ease-in-out infinite`);break;
      case 'corner': {const per=2*(w+h);const pos=[(w)/per,(w+h)/per,(2*w+h)/per,1];out=track(.14)+pos.map((q,i)=>{const len=90,off=-(q*1000-len/2);const st=`stroke:currentColor;stroke-dasharray:${len} ${1000-len};stroke-dashoffset:${off}px;animation:led-corner ${D*.9}s ease-in-out ${-i*D*.9/4}s infinite`;return rect('led-glow',`stroke-width="9" stroke-linecap="round"`,st+`;opacity:0`)+rect('led-core',`stroke-width="${sw}" stroke-linecap="round"`,st);}).join('');break;}
      case 'static': out=rect('led-glow',`stroke-width="7"`,`stroke:currentColor;opacity:${clip(.16*bright)}`)+rect('led-core',`stroke-width="${sw}"`,`stroke:currentColor;opacity:${clip(.55+.45*bright)}`);break;
      default: out=track(.16)+comet(1,D,0,false,6,true);
    }
    const T=Math.max(.3,Math.min(2,(ls.thick||60)/100));
    return out.replace(/stroke-width="([\d.]+)"/g,(m,v)=>`stroke-width="${Math.max(.5,v*T).toFixed(2)}"`);
  }
  function updateLedFrame(panel){
    if(!panel) return;
    const svg=panel.querySelector('.ad88-led-frame');
    if(!svg) return;
    const w=Math.max(20,panel.clientWidth),h=Math.max(20,panel.clientHeight);
    const radius=Math.min(14,Math.max(8,parseFloat(getComputedStyle(panel).borderRadius)||12));
    const ls=getLedSettings();
    const color=getComputedStyle(document.documentElement).getPropertyValue('--ad88-led').trim()||getLedColor();
    const key=[w,h,radius,ls.brightness,ls.speed,ls.effect,color,ls.enabled,ls.thick].join('|');
    svg.setAttribute('viewBox',`0 0 ${w} ${h}`);svg.setAttribute('width',w);svg.setAttribute('height',h);
    if(svg.dataset.key===key) return;
    svg.dataset.key=key;
    svg.style.color=color;
    { const b=Math.max(.1,Math.min(3,ls.brightness/100)); svg.style.filter=b>1?`brightness(${(1+(b-1)*.45).toFixed(2)}) saturate(${(1+(b-1)*.3).toFixed(2)}) drop-shadow(0 0 ${((b-1)*2.2).toFixed(1)}px ${color})`:''; }
    svg.style.display=ls.enabled?'':'none';
    svg.innerHTML=ls.enabled?buildLedMarkup(w,h,radius,ls):'';
  }

  // 1.4.214: viên thuốc hiện khi chuột lại gần (bán kính 150px) + tự hiện 4 giây sau khi tải trang
  // để người dùng biết nó đang nằm ở đâu. Không động tới xử lý đơn / Bank Check.
  function setupFabReveal(root){
    const fab=q('#ad88-tool-fab',root); if(!fab) return;
    let rect=null,rectAt=0,last=0,peekT=null;
    const invalidate=()=>{rect=null;};
    const getRect=()=>{const n=Date.now();if(!rect||n-rectAt>700){const r=fab.getBoundingClientRect();if(!r.width)return null;rect=r;rectAt=n;}return rect;};
    try{
      window.addEventListener('resize',invalidate,{passive:true});
      window.addEventListener('scroll',invalidate,{passive:true});
      document.addEventListener('mousemove',e=>{
        const n=Date.now(); if(n-last<90) return; last=n;
        const r=getRect(); if(!r) return;
        const dx=Math.max(r.left-e.clientX,0,e.clientX-r.right);
        const dy=Math.max(r.top-e.clientY,0,e.clientY-r.bottom);
        fab.classList.toggle('fab-near',(dx*dx+dy*dy)<=22500);
      },{passive:true});
    }catch(_){}
    const peek=(ms)=>{try{fab.classList.add('fab-peek');clearTimeout(peekT);peekT=setTimeout(()=>fab.classList.remove('fab-peek'),ms||4000);}catch(_){}};
    window.AD88_FAB_PEEK=peek; // chi dung khi go tay trong Console, khong tu chay
  }
  // 1.4.214: bảo đảm nút thu nhỏ LUÔN nằm trong màn hình. Trước đây vị trí cũ lưu theo
  // góc phải-dưới của chấm tròn 54px; viên thuốc rộng ~133px nên có máy bị đẩy ra ngoài mép
  // màn hình và không bao giờ thấy. Hàm này đo đúng nút rồi kéo cả khung vào trong.
  function ensureFabVisible(root){
    try{
      if(!panelHidden()) return;
      const fab=q('#ad88-tool-fab',root); if(!fab) return;
      const r=fab.getBoundingClientRect(); if(!r.width||!r.height) return;
      const m=6,vw=window.innerWidth,vh=window.innerHeight;
      let dx=0,dy=0;
      if(r.left<m) dx=m-r.left; else if(r.right>vw-m) dx=(vw-m)-r.right;
      if(r.top<m) dy=m-r.top; else if(r.bottom>vh-m) dy=(vh-m)-r.bottom;
      if(!dx&&!dy) return;
      const cur=root.getBoundingClientRect();
      root.style.left=Math.round(cur.left+dx)+'px';
      root.style.top=Math.round(cur.top+dy)+'px';
      root.style.right='auto';root.style.bottom='auto';
      saveFabAnchor(root);
      try{localStorage.setItem('AD88_XNK_TOOL_POSITION',JSON.stringify({x:Math.round(cur.left+dx),y:Math.round(cur.top+dy)}));}catch(_){}
    }catch(_){}
  }
  function clampRootToViewport(root, preferPanel=false){
    const panel=q('#ad88-tool-panel',root);
    const fab=q('#ad88-tool-fab',root);
    const target=preferPanel && panel && !panel.classList.contains('ad88-hidden') ? panel : (panel && !panel.classList.contains('ad88-hidden') ? panel : fab);
    if(!target)return;
    const rr=root.getBoundingClientRect();
    const tr=target.getBoundingClientRect();
    let dx=0,dy=0;
    const margin=6;
    if(tr.left < margin) dx=margin-tr.left;
    else if(tr.right > window.innerWidth-margin) dx=(window.innerWidth-margin)-tr.right;
    if(tr.top < margin) dy=margin-tr.top;
    else if(tr.bottom > window.innerHeight-margin) dy=(window.innerHeight-margin)-tr.bottom;
    if(dx||dy){
      const x=Math.max(0,Math.min(rr.left+dx,window.innerWidth-rr.width));
      const y=Math.max(0,Math.min(rr.top+dy,window.innerHeight-rr.height));
      root.style.left=x+'px';root.style.top=y+'px';root.style.right='auto';root.style.bottom='auto';
    }
  }
  function restorePosition(root){
    let saved=null;
    try{ saved=JSON.parse(localStorage.getItem('AD88_XNK_TOOL_POSITION')||'null'); }catch{}
    const apply=()=>{
      const panel=q('#ad88-tool-panel',root);
      const target=panel && !panel.classList.contains('ad88-hidden') ? panel : q('#ad88-tool-fab',root);
      const r=target?.getBoundingClientRect();
      const w=r?.width||54, h=r?.height||54;
      const sx=Number.isFinite(saved?.x)?saved.x:(window.innerWidth-w-10);
      const sy=Number.isFinite(saved?.y)?saved.y:(window.innerHeight-h-10);
      const x=Math.max(4,Math.min(sx,window.innerWidth-w-4));
      const y=Math.max(4,Math.min(sy,window.innerHeight-h-4));
      root.style.left=x+'px';root.style.top=y+'px';root.style.right='auto';root.style.bottom='auto';
      clampRootToViewport(root);
      if(panelHidden()) applyFabAnchor(root); else ensureFabVisible(root);
    };
    requestAnimationFrame(()=>requestAnimationFrame(apply));
    let rsT=null;try{window.addEventListener('resize',()=>{clearTimeout(rsT);rsT=setTimeout(()=>ensureFabVisible(root),250);},{passive:true});}catch(_){}
  }
  // 1.4.215: nhớ riêng chỗ đặt của viên thuốc. Mở bảng lớn ra có thể phải xê bảng cho vừa
  // màn hình, nhưng thu nhỏ lại thì viên thuốc phải quay về đúng chỗ người dùng đã kéo.
  function saveFabAnchor(root){
    try{const r=root.getBoundingClientRect();localStorage.setItem('AD88_XNK_FAB_ANCHOR',JSON.stringify({x:Math.round(r.left),y:Math.round(r.top)}));}catch(_){}
  }
  function applyFabAnchor(root){
    try{
      const a=JSON.parse(localStorage.getItem('AD88_XNK_FAB_ANCHOR')||'null');
      if(a&&Number.isFinite(a.x)&&Number.isFinite(a.y)){
        root.style.left=a.x+'px';root.style.top=a.y+'px';root.style.right='auto';root.style.bottom='auto';
      }
    }catch(_){}
    ensureFabVisible(root);
  }
  function savePosition(root,anchorToo){
    const r=root.getBoundingClientRect();
    try{localStorage.setItem('AD88_XNK_TOOL_POSITION',JSON.stringify({x:Math.round(r.left),y:Math.round(r.top)}));}catch{}
    if(anchorToo||panelHidden()) saveFabAnchor(root);
  }
  function makeDraggable(root){
    const handles=[q('#ad88-tool-fab',root),q('.ad88-head',root)].filter(Boolean);
    handles.forEach(handle=>{
      let drag=null;
      handle.addEventListener('pointerdown',e=>{
        // FAB itself is the drag handle; header buttons are excluded.
        // The previous guard rejected the FAB because the FAB is a <button>,
        // making it impossible to drag the collapsed Tool.
        if(e.button!==0) return;
        if(handle !== q('#ad88-tool-fab',root) && e.target.closest('button')) return;
        const r=root.getBoundingClientRect();
        drag={sx:e.clientX,sy:e.clientY,x:r.left,y:r.top,moved:false};
        handle.setPointerCapture?.(e.pointerId);
        e.preventDefault();
      });
      handle.addEventListener('pointermove',e=>{
        if(!drag)return;
        const dx=e.clientX-drag.sx,dy=e.clientY-drag.sy;
        if(Math.abs(dx)+Math.abs(dy)>4)drag.moved=true;
        if(!drag.moved)return;
        const r=root.getBoundingClientRect();
        const x=Math.max(4,Math.min(drag.x+dx,window.innerWidth-r.width-4));
        const y=Math.max(4,Math.min(drag.y+dy,window.innerHeight-r.height-4));
        root.style.left=x+'px';root.style.top=y+'px';root.style.right='auto';root.style.bottom='auto';
      });
      handle.addEventListener('pointerup',()=>{
        if(drag?.moved){savePosition(root,true);root.dataset.ad88Dragged='1';}
        drag=null;
      });
      handle.addEventListener('pointercancel',()=>{if(drag?.moved)savePosition(root,true);drag=null;});
    });
  }
  function bind(root){
    q('#ad88-tool-fab',root).onclick=()=>{
      if(root.dataset.ad88Dragged==='1'){delete root.dataset.ad88Dragged;return;}
      const panel=q('#ad88-tool-panel',root);const open=panel.classList.toggle('ad88-hidden')===false;setToolPanelOpen(open);requestAnimationFrame(()=>{if(!open)applyFabAnchor(root);else clampRootToViewport(root,true);savePosition(root);updateLedFrame(panel);if(open){try{renderStatus();renderBalanceBoard();}catch(_){}}});
    };
    makeDraggable(root);
    makeResizable(root);
    window.addEventListener('keydown',e=>{
      if(e.ctrlKey && e.shiftKey && e.code==='KeyA'){
        e.preventDefault();
        const panel=q('#ad88-tool-panel',root);
        const w=panel?.getBoundingClientRect().width||282, h=panel?.getBoundingClientRect().height||420;
        const x=Math.max(6,(window.innerWidth-w)/2), y=Math.max(6,(window.innerHeight-h)/2);
        root.style.left=x+'px';root.style.top=y+'px';root.style.right='auto';root.style.bottom='auto';
        savePosition(root);
        panel?.classList.remove('ad88-hidden');
        setToolPanelOpen(true);
        requestAnimationFrame(()=>{clampRootToViewport(root,true);savePosition(root);try{renderStatus();renderBalanceBoard();}catch(_){}});
      }
    });
    root.addEventListener('click',e=>{
      const b=e.target.closest('button');if(!b)return;const act=b.dataset.act,page=b.dataset.page;
      if(b.dataset.led){setLedColor(b.dataset.led);return;}
      if(act==='min'){q('#ad88-tool-panel',root).classList.add('ad88-hidden');setToolPanelOpen(false);applyFabAnchor(root);savePosition(root);return;}
      if(act==='stats'){toggleStatsView(root,'stats');return;}
      if(act==='balance'){toggleStatsView(root,'balance');return;}
      if(act==='home'){
        const home=q('#ad88-home-content',root), stats=q('#ad88-stats-view',root), main=q('#ad88-tool-main',root);
        if(stats&&home&&main){stats.classList.add('ad88-hidden');home.classList.remove('ad88-hidden');main.classList.remove('stats-mode');}
        root.querySelectorAll('[data-act="stats"],[data-act="balance"]').forEach(x=>x.classList.remove('is-active'));
        return;
      }
      if(act==='close'){q('#ad88-tool-panel',root).classList.add('ad88-hidden');setToolPanelOpen(false);applyFabAnchor(root);savePosition(root);return;}
      if(act==='run'){
        window.AD88_LICENSE?.getStatus?.().then(lic=>{
          if(!lic?.ok){ alert('🔒 ' + (lic?.message || 'Vui lòng kích hoạt License trong Cài đặt → Mở khóa Key.')); openPage('license'); return; }
          window.AD88_XNK_BOT?.start?.(); renderStatus();
        }); return;
      }
      if(act==='stop'){window.AD88_XNK_BOT?.stop?.();renderStatus();return;}
      if(page==='provider-amount'){openPage('provider-amount');return;}
      if(page)openPage(page);
    });
  }

  function getPanelSize(){
    const panel=q('#ad88-tool-panel');
    const r=panel?.getBoundingClientRect();
    return {w:r?.width||282,h:r?.height||420};
  }
  function saveSize(panel){
    const r=panel.getBoundingClientRect();
    const isNew=panel.closest('#ad88-xnk-tool-root')?.dataset.ui==='new';
    const key=isNew?'AD88_XNK_TOOL_SIZE_NEWUI':'AD88_XNK_TOOL_SIZE';
    try{localStorage.setItem(key,JSON.stringify({w:Math.round(r.width),h:Math.round(r.height)}));}catch{}
  }
  function restoreSize(panel){
    let saved=null;
    const isNew=panel.closest('#ad88-xnk-tool-root')?.dataset.ui==='new';
    const key=isNew?'AD88_XNK_TOOL_SIZE_NEWUI':'AD88_XNK_TOOL_SIZE';
    try{saved=JSON.parse(localStorage.getItem(key)||'null');}catch{}
    if(!saved)return;
    const defaultW=isNew?460:282, defaultH=isNew?375:420;
    const sw=(isNew && saved && saved.w<390)?defaultW:(saved?.w||defaultW);
    const sh=(isNew && saved && saved.h<330)?defaultH:(saved?.h||defaultH);
    const w=Math.max(isNew?460:240,Math.min(sw,isNew?1000:520));
    const h=Math.max(isNew?260:300,Math.min(sh,isNew?850:window.innerHeight-8));
    panel.style.width=w+'px';
    panel.style.height=h+'px';
  }
  function updateNewLayout(panel){
    if(!panel || panel.closest('#ad88-xnk-tool-root')?.dataset.ui!=='new') return;
    const main=q('#ad88-tool-main',panel.parentElement);
    const actions=q('.new-actions',main);
    const dash=q('.new-dashboard',main);
    const current=q('.current-card',main);
    if(!main||!actions||!dash||!current)return;
    const cs=getComputedStyle(main);
    const padY=(parseFloat(cs.paddingTop)||0)+(parseFloat(cs.paddingBottom)||0);
    const available=Math.max(0,main.clientHeight-padY);
    const actionH=actions.offsetHeight;
    const currentH=92;
    const gap=8;
    const minDash=300;
    const target=Math.max(minDash,available-actionH-currentH-gap);
    dash.style.height=Math.round(target)+'px';
    dash.style.minHeight=minDash+'px';
  }

  function updateNewUiScale(panel){
    /* 1.4.6: typography stays at a fixed readable size.
       Resizing changes the viewport only; short panels scroll vertically. */
    if(!panel)return;
    panel.style.setProperty('--new-ui-scale','1');
    /* 1.4.185: chỉ hàng nút CHẠY / DỪNG / Cài đặt / Check thông tin / Thống kê / Số dư: chữ và biểu tượng to dần theo bề rộng khung (665px trở xuống = 1, tối đa x1.35) */
    try{const w=panel.getBoundingClientRect().width||0;panel.style.setProperty('--na-s',Math.max(1,Math.min(1.3,w/665)).toFixed(3));}catch(_){}
  }
  function makeResizable(root){
    const panel=q('#ad88-tool-panel',root),br=q('#ad88-resize-handle',root),tl=q('#ad88-resize-handle-tl',root);
    if(!panel||!br)return;
    restoreSize(panel);
    updateNewUiScale(panel);updateNewLayout(panel);
    let resize=null;
    const start=(handle,e,corner)=>{
      if(e.button!==0)return;
      const r=panel.getBoundingClientRect(), rr=root.getBoundingClientRect();
      resize={sx:e.clientX,sy:e.clientY,w:r.width,h:r.height,rootX:rr.left,rootY:rr.top,moved:false,corner};
      handle.setPointerCapture?.(e.pointerId);
      e.preventDefault();e.stopPropagation();
    };
    const move=e=>{
      if(!resize)return;
      const dx=e.clientX-resize.sx,dy=e.clientY-resize.sy;
      const isNew=root.dataset.ui==='new';
      const minW=isNew?460:240,minH=isNew?260:300;
      const maxW=Math.min(isNew?1000:520,window.innerWidth-8);
      const maxH=Math.min(isNew?850:820,window.innerHeight-8);
      let w,h;
      if(resize.corner==='tl'){
        w=Math.max(minW,Math.min(maxW,resize.w-dx));
        h=Math.max(minH,Math.min(maxH,resize.h-dy));
        root.style.left=Math.max(4,resize.rootX+(resize.w-w))+'px';
        root.style.top=Math.max(4,resize.rootY+(resize.h-h))+'px';
      }else{
        w=Math.max(minW,Math.min(maxW,resize.w+dx));
        h=Math.max(minH,Math.min(maxH,resize.h+dy));
      }
      panel.style.width=w+'px';panel.style.height=h+'px';
      resize.moved=true;
      updateNewUiScale(panel);updateNewLayout(panel);updateLedFrame(panel);
    };
    const finish=()=>{if(!resize)return;if(resize.moved){saveSize(panel);savePosition(root);}resize=null;};
    br.addEventListener('pointerdown',e=>start(br,e,'br'));
    br.addEventListener('pointermove',move);br.addEventListener('pointerup',finish);br.addEventListener('pointercancel',finish);
    if(tl){tl.addEventListener('pointerdown',e=>start(tl,e,'tl'));tl.addEventListener('pointermove',move);tl.addEventListener('pointerup',finish);tl.addEventListener('pointercancel',finish);}
  }
  function renderStatus(){
    const st=window.AD88_XNK_BOT?.status?.()||{};S.running=!!st.auto;
    const h=st.health||healthStatus();
    const set=(id,v)=>{const e=q('#'+id);if(e)e.textContent=v};
    set('tool-run-status',S.running?'ĐANG CHẠY':'ĐÃ DỪNG');
    const now=new Date();
    set('tool-runtime',now.toLocaleTimeString('vi-VN',{hour12:false,hour:'2-digit',minute:'2-digit',second:'2-digit'}));
    const runBtn=q('.new-actions .run,.ad88-runrow .run'), stopBtn=q('.new-actions .stop,.ad88-runrow .stop');
    if(runBtn&&stopBtn){runBtn.classList.toggle('is-active',!S.running);runBtn.classList.toggle('is-inactive',S.running);stopBtn.classList.toggle('is-active',S.running);stopBtn.classList.toggle('is-inactive',!S.running);}
    set('tool-order',st.currentOrder||h.currentOrder||'—');
    set('tool-done',st.processed?.length||h.processed||0);
    set('tool-skip',st.skipped?.length||h.skipped||0);
    set('tool-manual',st.manual?.length||h.manual||0);
    // 1.4.165: CHẾ ĐỘ NHẸ — không cập nhật Bảng sức khỏe / Tốc độ xử lý (đã ẩn); chỉ giữ thẻ "Đơn hiện tại".
    if(document.documentElement.classList.contains('ad88-lite')){
      set('new-order-id',h.currentOrder||'—');
      set('new-order-amount', h.currentAmount!=null ? Number(h.currentAmount).toLocaleString('vi-VN') : '—');
      set('new-order-currency', h.currentCurrency || 'VNĐ');
      set('new-order-provider', h.currentProvider || 'Đang chọn...');
      set('new-order-time',h.currentElapsedMs?Math.floor(h.currentElapsedMs/1000).toString().padStart(2,'0')+'s':'00:00');
      set('new-order-status',S.running?(h.currentStep||'Đang kiểm tra'):'Đã dừng');
      return;
    }
    const [tone,label]=healthTone(h);
    set('tool-health-label',label);
    const speed=h.avgProcessMs ? ((60000/h.avgProcessMs).toFixed(1)+' đơn/phút') : '—';
    set('tool-speed',speed);
    set('tool-avg',fmtMs(h.avgProcessMs));
    set('new-health-tool',S.running?'Đang chạy':'Đã dừng');
    set('new-health-web',h.heartbeatMs!=null && h.heartbeatMs<5000?'Ổn định':(h.heartbeatMs<10000?'Chậm':'Mất kết nối'));
    set('new-health-api',h.avgApiMs!=null?fmtMs(h.avgApiMs):'—');
    set('new-health-dom',h.currentStep&&h.currentStep!=='Sẵn sàng'?'Ready':'Ready');
    set('new-health-queue',String(h.queue||0)+' đơn');
    set('new-health-order',h.currentOrder||'—');
    set('new-health-step',h.currentStep||'Sẵn sàng');
    set('new-health-last',fmtMs(h.lastActionMs));
    set('new-health-errors',String(h.errors||0)+' / '+String(h.timeouts||0));
    const setStatusTone=(id,cls)=>{const e=q('#'+id);if(e)e.className=cls};
    setStatusTone('new-health-tool',S.running?'status-green':'status-red');
    setStatusTone('new-health-web',h.heartbeatMs!=null&&h.heartbeatMs<5000?'status-green':(h.heartbeatMs<10000?'status-amber':'status-red'));
    setStatusTone('new-health-api','status-blue');
    setStatusTone('new-health-dom','status-green');
    setStatusTone('new-health-queue','status-blue');
    setStatusTone('new-health-order','status-blue');
    setStatusTone('new-health-step','status-amber');
    setStatusTone('new-health-last','status-blue');
    setStatusTone('new-health-errors',(Number(h.errors||0)+Number(h.timeouts||0))===0?'status-green':'status-red');
    set('new-order-id',h.currentOrder||'—');
    set('new-order-amount', h.currentAmount!=null ? Number(h.currentAmount).toLocaleString('vi-VN') : '—');
    set('new-order-currency', h.currentCurrency || 'VNĐ');
    set('new-order-provider', h.currentProvider || 'Đang chọn...');
    set('new-order-time',h.currentElapsedMs?Math.floor(h.currentElapsedMs/1000).toString().padStart(2,'0')+'s':'00:00');
    set('new-order-status',S.running?(h.currentStep||'Đang kiểm tra'):'Đã dừng');
    set('tool-fastest',fmtMs(h.fastestMs));
    set('tool-slowest',fmtMs(h.slowestMs));
    const avgSpeed=h.avgProcessMs ? 60000/h.avgProcessMs : null;
    if(Number.isFinite(avgSpeed)){S.speedHistory.push(avgSpeed);if(S.speedHistory.length>24)S.speedHistory.shift();}
    const svg=q('#tool-speed-chart');
    if(svg && S.speedHistory.length){
      const vals=S.speedHistory, max=Math.max(1,...vals), min=0, w=220, hgt=70, pad=3;
      const pts=vals.map((v,i)=>{const x=vals.length===1?w/2:pad+i*(w-2*pad)/(vals.length-1);const y=pad+(hgt-pad*2)*(1-v/max);return [x,y];});
      const points=pts.map(p=>p.join(',')).join(' ');
      const line=q('#speed-line');if(line)line.setAttribute('points',points);
      const area=q('#speed-area');if(area)area.setAttribute('d',`M${pts[0][0]} ${hgt} L${pts.map(p=>p.join(' ')).join(' L')} L${pts[-1]?.[0]||pts[pts.length-1][0]} ${hgt} Z`);
      const dots=q('#speed-dots');if(dots)dots.innerHTML=pts.map(([x,y])=>`<circle cx="${x}" cy="${y}" r="2.2" fill="#2DB38D"/>`).join('');
    }
    const bar=q('#tool-healthbar');
    if(bar){bar.classList.remove('good','warn','bad','idle');bar.classList.add(tone);}
    const dot=q('#tool-health-dot');if(dot){dot.className='health-dot '+tone;}
  }
  let lastNoticeKey='';
  function refreshCore(){
    renderStatus();
    let lastDone=0,lastSkipped=0,lastManual=0,liteTick=0;
    const timer=setInterval(()=>{
      if(!document.body.contains(q('#ad88-xnk-tool-root'))){clearInterval(timer);return;}
      const st=window.AD88_XNK_BOT?.status?.()||{};
      const doneCount=st.processed?.length||0, skippedCount=st.skipped?.length||0, manualCount=st.manual?.length||0;
      if((doneCount>lastDone||skippedCount>lastSkipped||manualCount>lastManual) && (lastDone||lastSkipped||lastManual)){playNotice();}
      lastDone=doneCount; lastSkipped=skippedCount; lastManual=manualCount;
      // 1.4.213: viên thuốc trạng thái (ẩn khi chuột rời). Chỉ đổi chữ khi thay đổi, rất nhẹ.
      try{ ensureFabVisible(document.getElementById('ad88-xnk-tool-root')); }catch(_){}
      try{
        const fab=document.getElementById('ad88-tool-fab');
        if(fab){
          const run=!!st.running;
          const txt=run?'Đang chạy':'Đã dừng';
          const el=document.getElementById('ad88-fab-state');
          if(el&&el.textContent!==txt)el.textContent=txt;
          if(fab.classList.contains('fab-stopped')===run)fab.classList.toggle('fab-stopped',!run);
        }
      }catch(_){}
      if(panelHidden()) return; // 1.4.207: đang thu nhỏ → không vẽ lại (âm báo ở trên vẫn chạy)
      // Chế độ nhẹ: vẽ lại trạng thái 3 giây/lần thay vì 1 giây/lần (âm báo vẫn kiểm tra mỗi giây).
      if(document.documentElement.classList.contains('ad88-lite') && (liteTick++%3)) return;
      renderStatus();
    },1000);
  }
  function getTodayKey(){ return new Date().toLocaleDateString('vi-VN'); }
  function localDateTimeValue(d){
    const x=new Date(d);
    const pad=n=>String(n).padStart(2,'0');
    return `${x.getFullYear()}-${pad(x.getMonth()+1)}-${pad(x.getDate())}T${pad(x.getHours())}:${pad(x.getMinutes())}`;
  }
  function parseLogTimestamp(x){
    const ts=Number(x?.timestamp);
    if(Number.isFinite(ts)&&ts>0) return ts;
    const m=String(x?.date||'').match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
    const t=String(x?.time||'').match(/^(\d{1,2}):(\d{2}):(\d{2})$/);
    if(!m||!t) return 0;
    const d=new Date(Number(m[3]),Number(m[2])-1,Number(m[1]),Number(t[1]),Number(t[2]),Number(t[3]));
    return Number.isFinite(d.getTime())?d.getTime():0;
  }
  function getSavedLogRange(){
    const start=new Date(); start.setHours(0,0,0,0);
    const now=new Date();
    return {
      from:localStorage.getItem('AD88_XNK_LOG_FROM')||localDateTimeValue(start),
      to:localStorage.getItem('AD88_XNK_LOG_TO')||localDateTimeValue(now)
    };
  }
  function saveLogRange(from,to){
    localStorage.setItem('AD88_XNK_LOG_FROM',from);
    localStorage.setItem('AD88_XNK_LOG_TO',to);
  }
  function filterLogsByRange(logs,from,to){
    const fromMs=new Date(from).getTime(), toMs=new Date(to).getTime();
    if(!Number.isFinite(fromMs)||!Number.isFinite(toMs)||fromMs>toMs) return [];
    return (Array.isArray(logs)?logs:[]).filter(x=>{const ts=parseLogTimestamp(x);return ts>=fromMs&&ts<=toMs;});
  }
  function setQuickLogRange(mode){
    const now=new Date();
    if(mode==='yesterday'){
      const start=new Date(now); start.setDate(start.getDate()-1); start.setHours(0,0,0,0);
      const end=new Date(start); end.setHours(23,59,59,999);
      saveLogRange(localDateTimeValue(start),localDateTimeValue(end));
      return;
    }
    const start=new Date(now); start.setHours(0,0,0,0);
    saveLogRange(localDateTimeValue(start),localDateTimeValue(now));
  }
  function money(v,c='VND'){
    const n=Number(v);
    if(!Number.isFinite(n)) return '—';
    return `${n.toLocaleString('vi-VN')} ${c==='USDT'?'USDT':'VND'}`;
  }
  function statsRows(){
    const st=window.AD88_XNK_BOT?.status?.()||{};
    const logs=Array.isArray(st.orderLogs)?st.orderLogs:[];
    const today=getTodayKey();
    const todayLogs=logs.filter(x=>!x.date||x.date===today);
    const done=todayLogs.filter(x=>x.state==='DONE');
    const returned=todayLogs.filter(x=>x.state==='RETURN');
    const sums=arr=>{const v=arr.filter(x=>(x.currency||'VND')!=='USDT').reduce((a,x)=>a+(Number(x.amount)||0),0);const u=arr.filter(x=>x.currency==='USDT').reduce((a,x)=>a+(Number(x.amount)||0),0);return {v,u};};
    return {todayLogs,done,returned,sumDone:sums(done),sumReturned:sums(returned)};
  }
  function statsTable(title,items,type){
    const rows=items.slice().reverse().slice(0,10);
    const timeHead=type==='done'?'Thời gian giao dịch thành công':'Thời gian trả lại đơn';
    const body=rows.length?rows.map(x=>`<tr><td>${esc(x.time||'')}</td><td class="order-cell">${esc(x.order||'—')}</td><td>${money(x.amount,x.currency)}</td><td>${esc(x.provider||'—')}</td><td class="${type==='done'?'ok':'bad'}">${type==='done'?'✓ Thành công':esc(x.reason||x.label||'Đơn trả lại')}</td></tr>`).join(''):`<tr><td colspan="5" class="empty-row">Chưa có dữ liệu</td></tr>`;
    return `<section class="stats-table-card ${type}"><div class="stats-table-head"><b>${title}</b><button type="button" data-stat-all="${type}">Xem tất cả ›</button></div><div class="stats-table-scroll"><table><thead><tr><th>${timeHead}</th><th>Mã đơn</th><th>Số tiền</th><th>Nhà thứ ba</th><th>${type==='done'?'Trạng thái':'Lý do trả lại'}</th></tr></thead><tbody>${body}</tbody></table></div></section>`;
  }

  function renderFilteredLog(el,type){
    const st=window.AD88_XNK_BOT?.status?.()||{};
    const logs=Array.isArray(st.orderLogs)?st.orderLogs:[];
    const today=getTodayKey();
    const items=logs.filter(x=>(!x.date||x.date===today) && x.state===(type==='done'?'DONE':'RETURN'));
    const title=type==='done'?'DANH SÁCH ĐƠN ĐÃ XỬ LÝ':'DANH SÁCH ĐƠN TRẢ LẠI';
    const timeHead=type==='done'?'Thời gian giao dịch thành công':'Thời gian trả lại đơn';
    const rows=items.length?items.map(x=>`<div class="ad88-order-log-item ${type==='done'?'success':'skip'}"><div class="ad88-order-log-top"><span class="ad88-order-log-status">${type==='done'?'✓ THÀNH CÔNG':'↷ ĐƠN TRẢ LẠI'}</span><time>${esc(x.time||'')}</time></div><div class="ad88-order-log-order">Đơn: <b>${esc(x.order||'—')}</b></div><div class="ad88-order-log-meta">Người thao tác: <b>${esc(x.operator||'—')}</b> &nbsp; Số tiền: <b>${esc(money(x.amount,x.currency))}</b> &nbsp; Nhà thứ 3: <b>${esc(x.provider||'—')}</b></div>${type!=='done'&&x.reason?`<div class="ad88-order-log-reason">Lý do: ${esc(x.reason)}</div>`:''}</div>`).join(''):`<div class="ad88-order-log-empty">Chưa có dữ liệu ${type==='done'?'đã xử lý':'trả lại'} trong ngày hôm nay.</div>`;
    el.innerHTML=head(title)+`<div class="ad88-log-live"><div class="ad88-log-live-head"><span>${timeHead.toUpperCase()}</span><div class="ad88-log-actions"><b>${items.length}</b></div></div><div class="ad88-order-log-list">${rows}</div></div>`;
    q('[data-back]',el).onclick=back;
  }
  function renderStats(el){
    const d=statsRows();
    const total=d.done.length+d.returned.length;
    const pct=n=>total?((n/total)*100).toFixed(1):'0.0';
    el.innerHTML=`<div class="stats-page">
      <div class="stats-page-head"><div><span>▥</span><b>THỐNG KÊ XỬ LÝ HÔM NAY</b></div><div class="stats-head-actions"><label>▣ Hôm nay (${new Date().toLocaleDateString('vi-VN')})</label><button type="button" id="stats-refresh">↻ Làm mới</button></div></div>
      <div class="stats-summary">
        <div class="stats-box done"><span>✓</span><small>ĐÃ XỬ LÝ</small><strong>${d.done.length} đơn</strong><em>Tổng: ${d.sumDone.v?money(d.sumDone.v,'VND'):''}${d.sumDone.u?`${d.sumDone.v?' · ':''}${money(d.sumDone.u,'USDT')}`:''}</em><i style="width:${pct(d.done.length)}%"></i></div>
        <div class="stats-box returned"><span>↷</span><small>ĐƠN TRẢ LẠI</small><strong>${d.returned.length} đơn</strong><em>Tổng: ${d.sumReturned.v?money(d.sumReturned.v,'VND'):''}${d.sumReturned.u?`${d.sumReturned.v?' · ':''}${money(d.sumReturned.u,'USDT')}`:''}</em><i style="width:${pct(d.returned.length)}%"></i></div>
      </div>
      <div class="stats-lists">${statsTable('DANH SÁCH ĐƠN ĐÃ XỬ LÝ',d.done,'done')}${statsTable('DANH SÁCH ĐƠN TRẢ LẠI',d.returned,'returned')}</div>
      <div class="stats-home-back"><button type="button" data-act="home">← &nbsp; QUAY LẠI GIAO DIỆN TRANG CHỦ</button></div>
    </div>`;
    q('#stats-refresh',el).onclick=()=>renderStats(el);
    el.querySelectorAll('[data-stat-all]').forEach(b=>b.onclick=()=>openPage(b.dataset.statAll==='done'?'log-done':'log-returned'));
  }
  function toggleStatsView(root,view){
    view=view||'stats';
    if(document.documentElement.classList.contains('ad88-lite')&&view!=='off')return; // 1.4.165: chế độ nhẹ tắt Thống kê / Số dư
    const home=q('#ad88-home-content',root), stats=q('#ad88-stats-view',root), main=q('#ad88-tool-main',root);
    if(!home||!stats||!main)return;
    const hidden=stats.classList.contains('ad88-hidden');
    const same=!hidden&&stats.dataset.view===view;
    const sb=q('[data-act="stats"]',root),bb=q('[data-act="balance"]',root);
    if(same){stats.classList.add('ad88-hidden');home.classList.remove('ad88-hidden');main.classList.remove('stats-mode');delete stats.dataset.view;if(sb)sb.classList.remove('is-active');if(bb)bb.classList.remove('is-active');return;}
    home.classList.add('ad88-hidden');stats.classList.remove('ad88-hidden');main.classList.add('stats-mode');stats.dataset.view=view;
    if(view==='balance')renderBalanceBoard();else renderStats(stats);
    if(sb)sb.classList.toggle('is-active',view==='stats');if(bb)bb.classList.toggle('is-active',view==='balance');
  }
  function openPage(page){const main=q('#ad88-tool-main'),sub=q('#ad88-tool-sub');if(!main||!sub)return;main.classList.add('ad88-hidden');sub.classList.remove('ad88-hidden');sub.classList.remove('provider-page-host');if(page==='health')renderHealthPage(sub);else if(page==='providers')renderProviders(sub);else if(page==='banks')renderBankToggles(sub);else if(page==='pet')renderPet(sub);else if(page==='balances')renderProviderBalances(sub);else if(page==='provider-amount')renderProviderAmountSettings(sub);else if(page==='settings')renderSettings(sub);else if(page==='license')renderLicenseSettings(sub);else if(page==='apikeys')renderApiKeys(sub);else if(page==='led')renderLedSettings(sub);else if(page==='banner')renderBannerSettings(sub);else if(page==='log')renderLog(sub);else if(page==='log-done')renderFilteredLog(sub,'done');else if(page==='log-returned')renderFilteredLog(sub,'returned');else renderAbout(sub);}
  function back(){q('#ad88-tool-main')?.classList.remove('ad88-hidden');q('#ad88-tool-sub')?.classList.add('ad88-hidden');}
  function head(title){return `<div class="ad88-subhead"><button data-back="1">‹</button><b>${title}</b><button data-back="1">×</button></div>`;}
  window.addEventListener('AD88_PROVIDER_BALANCES_CHANGED',()=>{const sub=q('#ad88-tool-sub');if(sub&&!sub.classList.contains('ad88-hidden')&&sub.querySelector('.ad88-bal-body'))renderProviderBalances(sub);});
  window.addEventListener('AD88_ORDER_LOG_CHANGED',()=>{const sub=q('#ad88-tool-sub');if(sub&&!sub.classList.contains('ad88-hidden')&&sub.querySelector('.ad88-log-live'))renderLog(sub);});
  // 1.4.216: bật/tắt từng ngân hàng. Ngân hàng TẮT thì Tool không bắt đơn của ngân hàng đó.
  function bankListAll(){ try{ return (window.AD88_XNK_BANK_LIST||[]).slice(); }catch(_){ return []; } }
  function getBankOff(){ try{ const a=JSON.parse(localStorage.getItem('AD88_XNK_BANK_OFF')||'[]'); return new Set(Array.isArray(a)?a.map(x=>String(x).toUpperCase()):[]); }catch(_){ return new Set(); } }
  function setBankOff(set){ try{ localStorage.setItem('AD88_XNK_BANK_OFF',JSON.stringify([...set])); }catch(_){} }
  function bankCountLabel(){ const all=bankListAll(); if(!all.length) return ''; const off=getBankOff(); const on=all.filter(b=>!off.has(b.key)).length; return on+'/'+all.length; }
  // 1.4.217: cài đặt robot đi lại
  function petGet(){ try{ return window.AD88_PET ? window.AD88_PET.get() : null; }catch(_){ return null; } }
  function renderPet(el){
    el.classList.add('provider-page-host');
    const st=petGet()||{on:true,skin:'blue',size:128,move:true};
    const SZ=[['Nhỏ',92],['Vừa',128],['To',170],['Rất to',215]];
    const SK=[['blue','Robot trắng'],['red','Robot đỏ']];
    el.innerHTML=head('Robot đi lại')+
      `<div class="ad88-settings">
        <button class="setting-row" id="pet-on" type="button">🤖 <span>Hiện robot thay nút thu nhỏ</span><b>${st.on?'BẬT':'TẮT'}</b></button>
        <button class="setting-row" id="pet-move" type="button">🚶 <span>Cho robot đi lại khắp trang</span><b>${st.move?'BẬT':'TẮT'}</b></button>
        <h4>Chọn robot</h4><div class="ad88-pet-pick">${SK.map(k=>`<button type="button" data-skin="${k[0]}" class="${st.skin===k[0]?'on':''}">${k[1]}</button>`).join('')}</div>
        <h4>Cỡ robot</h4><div class="ad88-pet-pick">${SZ.map(z=>`<button type="button" data-size="${z[1]}" class="${st.size===z[1]?'on':''}">${z[0]}</button>`).join('')}</div>
        <div class="ad88-balance-foot"><span>Bấm trái vào robot = mở bảng tool · Bấm phải = menu · Kéo = đặt lại chỗ.</span></div>
      </div>`;
    el.scrollTop=0; q('[data-back]',el).onclick=back;
    const re=()=>renderPet(el);
    q('#pet-on',el).onclick=()=>{ const p=petGet(); if(!window.AD88_PET)return; p.on?window.AD88_PET.off():window.AD88_PET.on(); re(); };
    q('#pet-move',el).onclick=()=>{ const p=petGet(); if(!window.AD88_PET)return; window.AD88_PET.setMove(!p.move); re(); };
    el.querySelectorAll('[data-skin]').forEach(b=>b.onclick=()=>{ window.AD88_PET&&window.AD88_PET.setSkin(b.dataset.skin); re(); });
    el.querySelectorAll('[data-size]').forEach(b=>b.onclick=()=>{ window.AD88_PET&&window.AD88_PET.setSize(Number(b.dataset.size)); re(); });
  }
  function renderBankToggles(el){
    el.classList.add('provider-page-host');
    const all=bankListAll();
    if(!all.length){ el.innerHTML=head('Bật/tắt ngân hàng')+'<div class="ad88-loading">Chưa đọc được danh sách ngân hàng. Hãy tải lại trang BO (F5) rồi mở lại.</div>'; q('[data-back]',el).onclick=back; return; }
    const draw=()=>{
      const off=getBankOff(), kw=(el.querySelector('#bank-search')?.value||'').trim().toUpperCase();
      const show=all.filter(b=>!kw||b.name.toUpperCase().includes(kw)||b.key.includes(kw.replace(/[^A-Z0-9]/g,'')));
      const on=all.filter(b=>!off.has(b.key)).length;
      el.innerHTML=head('Bật/tắt ngân hàng')+
        `<div class="ad88-bank-tools"><input id="bank-search" type="text" placeholder="Tìm ngân hàng..." value="${kw.replace(/"/g,'&quot;')}"><button type="button" id="bank-all-on">Bật tất cả</button><button type="button" id="bank-all-off">Tắt tất cả</button></div>`+
        `<div class="ad88-bank-sum">Đang bắt đơn của <b>${on}</b>/${all.length} ngân hàng${on<all.length?` · đang tắt <i>${all.length-on}</i>`:''}</div>`+
        `<div class="ad88-provider-list">${show.map(b=>{const o=!off.has(b.key);
          return `<label class="ad88-provider-row${o?'':' off'}"><span class="provider-dot"></span><b>${b.name}</b><input class="provider-toggle bank-toggle" data-bank="${b.key}" type="checkbox" ${o?'checked':''}><i class="provider-switch"><span></span><em>${o?'✓':'×'}</em></i></label>`;}).join('')
          || '<div class="ad88-loading">Không tìm thấy ngân hàng nào.</div>'}</div>`+
        `<div class="ad88-balance-foot"><span>Tắt ngân hàng nào thì Tool KHÔNG bắt đơn của ngân hàng đó (không khóa đơn).</span></div>`;
      q('[data-back]',el).onclick=back;
      const sb=el.querySelector('#bank-search');
      if(sb){ sb.oninput=()=>{const v=sb.value;draw();const n=el.querySelector('#bank-search');if(n){n.value=v;n.focus();n.setSelectionRange(v.length,v.length);} }; if(kw){sb.focus();sb.setSelectionRange(kw.length,kw.length);} }
      el.querySelector('#bank-all-on').onclick=()=>{setBankOff(new Set());draw();};
      el.querySelector('#bank-all-off').onclick=()=>{setBankOff(new Set(all.map(b=>b.key)));draw();};
      el.querySelectorAll('.bank-toggle').forEach(inp=>inp.onchange=()=>{
        const s2=getBankOff(); if(inp.checked)s2.delete(inp.dataset.bank); else s2.add(inp.dataset.bank);
        setBankOff(s2);
        const row=inp.closest('.ad88-provider-row'); row?.classList.toggle('off',!inp.checked);
        const em=row?.querySelector('.provider-switch em'); if(em)em.textContent=inp.checked?'✓':'×';
        const sum=el.querySelector('.ad88-bank-sum'); const on2=all.filter(b=>!s2.has(b.key)).length;
        if(sum)sum.innerHTML=`Đang bắt đơn của <b>${on2}</b>/${all.length} ngân hàng`+(on2<all.length?` · đang tắt <i>${all.length-on2}</i>`:'');
      });
    };
    draw(); el.scrollTop=0; requestAnimationFrame(()=>{el.scrollTop=0;});
  }
  function renderProviders(el){
    el.classList.add('provider-page-host');
    const st=getProviderState();
    el.innerHTML=head('Bật/tắt nhà thứ 3')+`<div class="ad88-provider-list">${PROVIDERS.map(name=>{
      const on=st[name]!==false;
      return `<label class="ad88-provider-row"><span class="provider-dot"></span><b>${name}</b><input class="provider-toggle" data-provider="${name}" type="checkbox" ${on?'checked':''}><i class="provider-switch"><span></span><em>${on?'✓':'×'}</em></i></label>`;
    }).join('')}</div><div class="ad88-balance-foot"><span>Chỉ bật nhà được phép tự động đẩy đơn</span></div>`;
    el.scrollTop=0;
    requestAnimationFrame(()=>{el.scrollTop=0;});
    q('[data-back]',el).onclick=back;
    el.querySelectorAll('.provider-toggle').forEach(inp=>inp.onchange=()=>{const s=getProviderState();s[inp.dataset.provider]=inp.checked;setProviderState(s);inp.closest('.ad88-provider-row')?.classList.toggle('off',!inp.checked);});
  }
  function getProviderBalances(){try{const _s=getToolSettings();if(!_s.balanceRefresh&&!_s.balanceScan)return [];const o=JSON.parse(localStorage.getItem('AD88_XNK_PROVIDER_BALANCES')||'{}');return Object.values(o||{}).filter(x=>x&&x.name&&typeof x.balance==='number'&&x.balance!==0);}catch{return [];}}
  function fmtMoney(n){return Math.round(Math.abs(n)).toLocaleString('en-US');}
  function fmtAgo(ts){if(!ts)return '';const s=Math.max(0,Math.round((Date.now()-ts)/1000));if(s<60)return s+' giây trước';const m=Math.round(s/60);if(m<60)return m+' phút trước';const h=Math.floor(m/60);return h<24?h+' giờ '+(m%60)+' phút trước':Math.floor(h/24)+' ngày trước';}
  function getPriority(){try{return JSON.parse(localStorage.getItem('AD88_XNK_PROVIDER_PRIORITY')||'{}')||{};}catch{return {};}}
  function setPriority(k,on){const o=getPriority();if(on)o[k]=true;else delete o[k];try{localStorage.setItem('AD88_XNK_PROVIDER_PRIORITY',JSON.stringify(o));}catch{}}
  function getBalRefreshSec(){const n=Number(localStorage.getItem('AD88_XNK_BALANCE_REFRESH_SEC'));return Number.isFinite(n)&&n>=0&&localStorage.getItem('AD88_XNK_BALANCE_REFRESH_SEC')!==null?n:60;}
  function getBalLimits(){let o={};try{o=JSON.parse(localStorage.getItem('AD88_XNK_BALANCE_THRESHOLDS')||'{}')||{};}catch{}const pick=(v,d)=>{const n=Number(v);return Number.isFinite(n)&&n>0?n:d;};return {warn:pick(o.warn,30000000),low:pick(o.low,20000000),warnU:pick(o.warnU,10000),lowU:pick(o.lowU,5000)};}
  // Ngưỡng TĂNG CAO theo từng nhà (số dư từ mức này trở lên → báo đỏ "TĂNG CAO"). [id, tên hiển thị, regex trên tên đã chuẩn hóa, mặc định]
  const BAL_HIGH_RULES=[['gopay','GO-PAY',/gopay/,1e8],['okpay','OKPay',/okpay/,2e9],['33pay','33Pay',/33pay/,7e7],['pppay','PPPay',/^pppay/,2e9],['196','VN196Pay',/196/,5e8],['v6pay','V6Pay',/^v6/,1e8],['vippay','VipPay',/^v[il1]ppay/,1e8],['888pay','888Pay',/888pay/,1e8],['bb168','BB168Pay',/bb168/,8e8],['fastpay','FastPay',/fastpay/,5e8],['a8pay','A8Pay',/a8pay/,5e7],['jypay','JYPay / JPay',/^jy?pay/,5e7],['payopay','PayoPay',/payopay/,7e7],['u2pay','U2PAY (USDT)',/u2pay/,4e4],['rcpay','RCPAY (USDT)',/rcpay/,4e4]];
  function balKey(n){return String(n||'').toLowerCase().replace(/[（(][^)）]*[)）]/g,'').replace(/[^a-z0-9]/g,'');}
  function getBalHigh(){try{return JSON.parse(localStorage.getItem('AD88_XNK_BALANCE_HIGH')||'{}')||{};}catch{return {};}}
  function highFor(x){const k=balKey(x.name),o=getBalHigh();for(const r of BAL_HIGH_RULES){if(r[2].test(k)){if(r[0] in o){const v=Number(o[r[0]]);if(v===0)return 0;if(Number.isFinite(v)&&v>0)return v;}return r[3];}}return 0;}
  function balLevel(x,lim){if(x&&x.off)return 'off';const h=highFor(x);if(h&&x.balance>=h)return 'high';const u=x.currency==='USDT';const w=u?lim.warnU:lim.warn,l=u?lim.lowU:lim.low;return x.balance<l?'low':x.balance<w?'warn':'ok';}
  function balTagHTML(lv,withOk){return lv==='off'?'<span class="bal-tag off">ĐANG TẮT</span>':lv==='high'?'<span class="bal-tag high">TĂNG CAO</span>':lv==='low'?'<span class="bal-tag low">SỐ DƯ THẤP</span>':lv==='warn'?'<span class="bal-tag warn">SẮP HẾT</span>':withOk?'<span class="bal-tag ok">ỔN ĐỊNH</span>':'';}
  // Kiểu hiển thị số dư: cổ điển (cũ) hoặc số điện tử. Nút ở đầu bảng đổi vòng tròn giữa các kiểu.
  const BAL_STYLES=[['classic','Cổ điển (cũ)'],['g1','Mẫu 01 · Rõ ràng'],['g2','Mẫu 02 · Cao gọn'],['g3','Mẫu 03 · Kính mờ'],['g4','Mẫu 04 · Dashboard'],['g5','Mẫu 05 · Biên tập'],['g6','Mẫu 06 · Terminal'],['led','LED 7 đoạn'],['dot','Chấm ma trận'],['flip','Đồng hồ lật'],['seg','7 đoạn gọn']];
  function getBalStyle(){try{const v=localStorage.getItem('AD88_XNK_BALANCE_STYLE');return BAL_STYLES.some(x=>x[0]===v)?v:'classic';}catch{return 'classic';}}
  function setBalStyle(v){try{localStorage.setItem('AD88_XNK_BALANCE_STYLE',v);}catch{}}
  const LED_SEG={'0':'abcdef','1':'bc','2':'abdeg','3':'abcdg','4':'bcfg','5':'acdfg','6':'acdefg','7':'abc','8':'abcdefg','9':'abcdfg'};
  const LED_P={a:'M10 4 L50 4 L44 12 L16 12Z',b:'M52 6 L52 46 L45 40 L45 14Z',c:'M52 54 L52 94 L45 86 L45 60Z',d:'M10 96 L50 96 L44 88 L16 88Z',e:'M8 54 L15 60 L15 86 L8 94Z',f:'M8 6 L15 14 L15 40 L8 46Z',g:'M10 50 L16 44 L44 44 L50 50 L44 56 L16 56Z'};
  const LED_DM={'0':['01110','10001','10011','10101','11001','10001','01110'],'1':['00100','01100','00100','00100','00100','00100','01110'],'2':['01110','10001','00001','00010','00100','01000','11111'],'3':['11110','00001','00001','01110','00001','00001','11110'],'4':['00010','00110','01010','10010','11111','00010','00010'],'5':['11111','10000','11110','00001','00001','10001','01110'],'6':['00110','01000','10000','11110','10001','10001','01110'],'7':['11111','00001','00010','00100','01000','01000','01000'],'8':['01110','10001','10001','01110','10001','10001','01110'],'9':['01110','10001','10001','01111','00001','00010','01100']};
  function ledSeven(t,on,off,glow){let x=0,o='';for(const ch of t){if(ch===','||ch==='.'){o+=`<circle cx="${x+5}" cy="94" r="5" fill="${on}"/>`;x+=14;continue;}if(!LED_SEG[ch]){x+=62;continue;}let g=`<g transform="translate(${x},0) skewX(-6)">`;for(const k of 'abcdefg')g+=`<path d="${LED_P[k]}" fill="${LED_SEG[ch].includes(k)?on:off}"/>`;o+=g+'</g>';x+=62;}return `<svg class="bd-svg bd-seven" viewBox="0 0 ${x} 100" aria-hidden="true"${glow?` style="filter:drop-shadow(0 0 3px ${on}88)"`:''}>${o}</svg>`;}
  function ledDot(t,on,off){let x=0,o='';const d=7,r=2.9;for(const ch of t){if(ch===','||ch==='.'){o+=`<circle cx="${x+d/2}" cy="${6*d+d/2}" r="${r}" fill="${on}"/>`;x+=d*1.5;continue;}const m=LED_DM[ch];if(!m){x+=6*d;continue;}for(let a=0;a<7;a++)for(let c=0;c<5;c++)o+=`<circle cx="${x+c*d+d/2}" cy="${a*d+d/2}" r="${r}" fill="${m[a][c]==='1'?on:off}"/>`;x+=6*d;}return `<svg class="bd-svg bd-dot" viewBox="0 0 ${x} ${7*d}" aria-hidden="true" style="filter:drop-shadow(0 0 3px ${on}99)">${o}</svg>`;}
  function ledFlip(t){let o='';for(const ch of t)o+=/[0-9]/.test(ch)?`<span class="bd-tile">${ch}</span>`:`<span class="bd-sep">${ch}</span>`;return `<span class="bd-flip">${o}</span>`;}
  function balDigits(txt,style,lv){const bad=lv==='low'||lv==='high';const on=bad?'#ee5555':lv==='warn'?'#f0cc36':'#3ee0ac';const off=on+'1c';if(style==='led')return ledSeven(txt,on,off,true);if(style==='seg')return ledSeven(txt,on,'rgba(0,0,0,0)',false);if(style==='dot')return ledDot(txt,on,off);if(style==='flip')return ledFlip(txt);return txt;}
  function fmtDelta(x,d){return x.currency==='USDT'?Math.abs(d).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2}):fmtMoney(d);}
  function fmtBal(x){return x.currency==='USDT'?Number(x.balance).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2}):fmtMoney(x.balance);}
  function renderProviderBalances(el){
    el.classList.add('provider-page-host');
    const draw=()=>{
      const lim=getBalLimits();const pri=getPriority();
      const list=getProviderBalances().sort((a,b)=>a.balance-b.balance);
      const vnd=list.filter(x=>x.currency!=='USDT');const total=vnd.reduce((s,x)=>s+x.balance,0);const usd=list.filter(x=>x.currency==='USDT');const totalU=usd.reduce((s,x)=>s+x.balance,0);
      const last=list.reduce((m,x)=>Math.max(m,x.ts||0),0);
      const nLow=list.filter(x=>balLevel(x,lim)==='low').length,nWarn=list.filter(x=>balLevel(x,lim)==='warn').length,nHigh=list.filter(x=>balLevel(x,lim)==='high').length;
      const rows=list.map(x=>{const lv=balLevel(x,lim);const stale=Date.now()-(x.ts||0)>30*60*1000;const d=x.delta||0;const dTxt=d?`<small class="bal-delta ${d>0?'up':'down'}">${d>0?'▲ +':'▼ −'}${fmtDelta(x,d)}${x.changedAt?' · '+fmtAgo(x.changedAt):''}</small>`:'';
        const tag=balTagHTML(lv,false);
        const isP=!!pri[x.name.toLowerCase()];return `<div class="ad88-bal-row lv-${lv} ${stale?'stale':''}"><span class="bal-light"></span><div class="bal-name"><b>${x.name.replace(/[<>&]/g,'')}</b><small>${fmtAgo(x.ts)}</small></div>${balLogoHTML(x)}<button type="button" class="bal-pri ${isP?'on':''}" data-pri="${x.name.toLowerCase().replace(/[<>&"]/g,'')}" title="Chỉ đẩy đơn vào các nhà được bấm Ưu tiên (nhiều nhà thì chia đều)">${isP?'★ Ưu tiên':'☆ Ưu tiên'}</button><div class="bal-val"><strong>${fmtBal(x)}</strong>${tag||'<em>'+(x.currency==='USDT'?'USDT':'VND')+'</em>'}${dTxt}</div></div>`;}).join('');
      const alert=nLow||nWarn||nHigh?`<small class="bal-alert">${nHigh?`🔴 ${nHigh} nhà tăng cao`:''}${nHigh&&(nLow||nWarn)?' · ':''}${nLow?`🔴 ${nLow} nhà thấp`:''}${nLow&&nWarn?' · ':''}${nWarn?`🟠 ${nWarn} nhà sắp hết`:''}</small>`:'';
      el.querySelector('.ad88-bal-body').innerHTML=list.length?`<div class="ad88-bal-total"><span>Tổng số dư tất cả nhà${alert}</span><strong>${fmtMoney(total)} <small>VND</small>${usd.length?` · ${totalU.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})} <small>USDT</small>`:''}</strong></div>${rows}`:`<div class="ad88-bal-empty">Chưa có dữ liệu.<br>Số dư sẽ tự cập nhật khi tool mở ô chọn nhà thứ 3 để đẩy đơn.</div>`;
      el.querySelectorAll('.bal-pri').forEach(b=>b.onclick=()=>{setPriority(b.dataset.pri,!b.classList.contains('on'));draw();renderBalanceBoard();});
      el.querySelector('.ad88-bal-foot').textContent=last?'Cập nhật lần cuối '+new Date(last).toLocaleTimeString('vi-VN')+' · tự quét mỗi lần đẩy đơn':'Tự quét mỗi lần tool đẩy đơn sang nhà thứ 3';
    };
    const lim0=getBalLimits();
    el.innerHTML=head('Số dư nhà thứ 3')+'<div class="ad88-bal-body"></div><div class="ad88-bal-limits"><h5>Ngưỡng cảnh báo (VND)</h5><label><i class="bal-light"></i><span>🟠 Sắp hết khi dưới</span><input id="bal-warn" inputmode="numeric" value="'+fmtMoney(lim0.warn)+'"></label><label><i class="bal-light red"></i><span>🔴 Số dư thấp khi dưới</span><input id="bal-low" inputmode="numeric" value="'+fmtMoney(lim0.low)+'"></label><h5 style="margin-top:9px">Ngưỡng cảnh báo nhà USDT</h5><label><i class="bal-light"></i><span>🟠 Sắp hết khi dưới (USDT)</span><input id="bal-warnU" inputmode="numeric" value="'+fmtMoney(lim0.warnU)+'"></label><label><i class="bal-light red"></i><span>🔴 Số dư thấp khi dưới (USDT)</span><input id="bal-lowU" inputmode="numeric" value="'+fmtMoney(lim0.lowU)+'"></label><h5 style="margin-top:9px">Ngưỡng TĂNG CAO theo từng nhà (từ mức này trở lên báo đỏ, 0 = tắt)</h5>'+BAL_HIGH_RULES.map(r=>'<label><i class="bal-light red"></i><span>'+r[1]+'</span><input id="bal-hi-'+r[0]+'" data-hi="'+r[0]+'" inputmode="numeric" value="'+fmtMoney(highFor({name:r[1].replace(/[^A-Za-z0-9]/g,'')})||0)+'"></label>').join('')+'</div><div class="ad88-balance-foot ad88-bal-foot"></div>';
    q('[data-back]',el).onclick=()=>openPage('settings');
    ['warn','low','warnU','lowU'].forEach(k=>{const inp=q('#bal-'+k,el);inp.onchange=()=>{const cur=getBalLimits();const v=Number(String(inp.value).replace(/[^0-9]/g,''))||cur[k];cur[k]=v;const U=k.endsWith('U');const w=U?'warnU':'warn',l=U?'lowU':'low';if(cur[l]>cur[w]){if(k===l)cur[w]=cur[l];else cur[l]=cur[w];}try{localStorage.setItem('AD88_XNK_BALANCE_THRESHOLDS',JSON.stringify(cur));}catch{}['warn','low','warnU','lowU'].forEach(z=>{const e=q('#bal-'+z,el);if(e)e.value=fmtMoney(cur[z]);});draw();renderBalanceBoard();};});
    el.querySelectorAll('[data-hi]').forEach(inp=>{inp.onchange=()=>{const o=getBalHigh();const v=Number(String(inp.value).replace(/[^0-9]/g,''))||0;o[inp.dataset.hi]=v;try{localStorage.setItem('AD88_XNK_BALANCE_HIGH',JSON.stringify(o));}catch{}inp.value=fmtMoney(v);draw();renderBalanceBoard();};});
    draw();el.scrollTop=0;
  }
  const BAL_LOGOS=[['196',/196/],['33pay',/^33pay/],['u2pay',/^u2pay/],['vippay',/^vippay|^vip/],['fastpay',/^fastpay/],['gopay',/^gopay/],['a8pay',/^a8pay/],['888pay',/^888pay/],['pppay',/^pppay/],['okpay',/^okpay/],['bb168',/^bb168/],['v6pay',/^v6/],['whpay',/^whpay/],['payopay',/^payopay|^payo/],['rcpay',/^rcpay/]];
  function balLogoHTML(x){
    const nm=String(x.name||'').replace(/\(.*$/,'').replace(/[^A-Za-z0-9]/g,'');const lk=nm.toLowerCase();
    if(/^jypay|^jpay/.test(lk))return '';
    const hit=BAL_LOGOS.find(z=>z[1].test(lk));
    if(hit){let u='';try{u=chrome.runtime.getURL('assets/logos/'+hit[0]+'.png');}catch(_){}
      if(u)return `<span class="bc-logo has-img" data-lg="${hit[0]}"><img src="${u}" alt="" onerror="this.parentNode.classList.remove('has-img');this.remove()"><i>${(nm.slice(0,2)||'?').toUpperCase()}</i></span>`;}
    const ini=(nm.slice(0,2)||'?').toUpperCase();
    let h=0;for(const ch of nm)h=(h*31+ch.charCodeAt(0))%360;
    const u=/^(https?:|data:image\/)/i.test(x.logo||'')?String(x.logo).replace(/["'<>\s]/g,''):'';
    return `<span class="bc-logo" style="--lh:${h}">${u?`<img src="${u}" alt="" loading="lazy" onerror="this.remove()">`:''}<i>${ini}</i></span>`;
  }
  function balCardHTML(x,lim,pri){
    const lv=balLevel(x,lim),stale=Date.now()-(x.ts||0)>30*60*1000,d=x.delta||0,isP=!!pri[x.name.toLowerCase()];
    const nm=x.name.replace(/[<>&"]/g,'');
    const dTxt=d?`<span class="bc-delta ${d>0?'up':'down'}">${d>0?'▲':'▼'} ${fmtDelta(x,d)}</span>`:'';
    const tag=balTagHTML(lv,true);
    return `<div class="bc lv-${lv} ${stale?'stale':''} ${isP?'is-pri':''}"><div class="bc-top"><span class="bal-light"></span>${balLogoHTML(x)}<b class="bc-name" title="${nm}">${nm}</b>${tag}</div><div class="bc-mid"><strong>${balDigits(fmtBal(x),getBalStyle(),lv)}</strong><em>${x.currency==='USDT'?'USDT':'VND'}</em></div><div class="bc-bot"><span class="bc-time">${fmtAgo(x.ts)}${dTxt?' · ':''}${dTxt}</span><button type="button" class="bal-pri ${isP?'on':''}" data-pri="${nm.toLowerCase()}" title="Chỉ đẩy đơn vào các nhà được bấm Ưu tiên (nhiều nhà thì chia đều)">${isP?'★ Ưu tiên':'☆ Ưu tiên'}</button></div></div>`;
  }
  let balFilter='';
  function renderBalanceBoard(){
    const host=document.getElementById('ad88-stats-view');if(!host||host.dataset.view!=='balance'||host.classList.contains('ad88-hidden'))return;
    if(!host.querySelector('#ad88-balance-board'))host.innerHTML='<section class="new-balance-board" id="ad88-balance-board" aria-label="Số dư nhà thứ 3"></section><div class="stats-home-back"><button type="button" data-act="home">← &nbsp; QUAY LẠI GIAO DIỆN TRANG CHỦ</button></div>';
    const box=host.querySelector('#ad88-balance-board');
    if(box.querySelector('.bb-style-menu'))return;
    const lim=getBalLimits(),pri=getPriority();
    const rank={high:0,low:0,warn:1,ok:2,off:3};
    const list=getProviderBalances().sort((a,b)=>rank[balLevel(a,lim)]-rank[balLevel(b,lim)]||(a.currency==='USDT')-(b.currency==='USDT')||a.name.localeCompare(b.name));
    const vnd=list.filter(x=>x.currency!=='USDT'),total=vnd.reduce((s,x)=>s+x.balance,0);const usd=list.filter(x=>x.currency==='USDT'),totalU=usd.reduce((s,x)=>s+x.balance,0);
    const nLow=list.filter(x=>balLevel(x,lim)==='low').length,nWarn=list.filter(x=>balLevel(x,lim)==='warn').length,nHigh=list.filter(x=>balLevel(x,lim)==='high').length;
    const last=list.reduce((m,x)=>Math.max(m,x.ts||0),0);
    if(balFilter&&!list.some(x=>balLevel(x,lim)===balFilter))balFilter='';
    const chip=(lv,cls,n,t)=>n?`<button type="button" class="al ${cls}${balFilter===lv?' on':''}" data-alf="${lv}" title="Bấm để xem các nhà ${t}">● ${n} ${t}</button>`:'';
    const alert=chip('high','low',nHigh,'tăng cao')+chip('low','low',nLow,'thấp')+chip('warn','warn',nWarn,'sắp hết');
    const shown=balFilter?list.filter(x=>balLevel(x,lim)===balFilter):list;
    const keep=box.querySelector('.bb-scroll')?.scrollTop||0;
    box.innerHTML=`<div class="bb-head"><span class="bb-title">💳 <b>SỐ DƯ NHÀ THỨ 3</b></span><span class="bb-total"><small>Tổng</small><strong>${fmtMoney(total)}</strong><em>VND</em></span>${usd.length?`<span class="bb-total usdt"><small>Tổng</small><strong>${totalU.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})}</strong><em>USDT</em></span>`:''}${alert}<button type="button" class="bb-style" data-bstyle title="Đổi kiểu hiển thị số dư">🎛 ${(()=>{const t=(BAL_STYLES.find(z=>z[0]===getBalStyle())||BAL_STYLES[0])[1].split(' · ');return t[0]+(t[1]?'<span class="bs-d"> · '+t[1]+'</span>':'');})()}</button><span class="bb-tail"><span class="bb-last">${last?'Quét lúc '+new Date(last).toLocaleTimeString('vi-VN'):'Chưa quét'}</span><button type="button" class="bb-gear" data-page="balances" title="Cài ngưỡng cảnh báo">⚙</button></span></div><div class="bb-scroll">${list.length?`${balFilter?`<div class="bb-filter">Đang xem: <b>${balFilter==='high'?'nhà tăng cao':balFilter==='low'?'nhà thấp':'nhà sắp hết'}</b> (${shown.length}) <button type="button" data-alf="">✕ Xem tất cả</button></div>`:''}<div class="bb-grid">${shown.map(x=>balCardHTML(x,lim,pri)).join('')}</div>`:'<div class="ad88-bal-empty">Chưa có dữ liệu số dư.<br>Tool sẽ tự quét khi mở ô chọn nhà thứ 3 để đẩy đơn.</div>'}</div>`;
    box.querySelector('.bb-scroll').scrollTop=keep;
    box.querySelectorAll('[data-alf]').forEach(b=>b.onclick=e=>{e.stopPropagation();const v=b.dataset.alf;balFilter=(balFilter===v)?'':v;renderBalanceBoard();});
    box.querySelectorAll('.bal-pri').forEach(b=>b.onclick=e=>{e.stopPropagation();setPriority(b.dataset.pri,!b.classList.contains('on'));renderBalanceBoard();});
    const g=box.querySelector('.bb-gear');if(g)g.onclick=()=>openPage('balances');
    const sb=box.querySelector('.bb-style');if(sb)sb.onclick=e=>{e.stopPropagation();const ex=box.querySelector('.bb-style-menu');if(ex){ex.remove();return;}const cur=getBalStyle();const m=document.createElement('div');m.className='bb-style-menu';m.innerHTML=BAL_STYLES.map(z=>'<button type="button" data-bsv="'+z[0]+'" class="'+(z[0]===cur?'on':'')+'">'+(z[0]===cur?'✓ ':'')+z[1]+'</button>').join('');box.appendChild(m);m.querySelectorAll('[data-bsv]').forEach(b=>b.onclick=ev=>{ev.stopPropagation();setBalStyle(b.dataset.bsv);m.remove();renderBalanceBoard();});const closeM=ev=>{if(!m.contains(ev.target)){m.remove();document.removeEventListener('click',closeM,true);}};setTimeout(()=>document.addEventListener('click',closeM,true),0);};
    box.dataset.bs=getBalStyle();
  }
  function renderSettings(el){
    const st=getToolSettings();
    el.innerHTML=head('Cài đặt')+`<div class="ad88-settings"><h4>Cài đặt chung</h4>${toggle('auto','Tự động xử lý đơn',st.auto)}${toggle('bank','Tự động kiểm tra Bank',st.bank)}${toggle('unlock','Tự động mở khóa',st.unlock)}${toggle('returnUnlock','Tự mở khóa đơn nhà thứ 3 trả về',st.returnUnlock)}${toggle('lockWatchdog','Chưa xử lý quá 2 phút tự mở khóa',st.lockWatchdog)}${toggle('balanceRefresh','Gọi số dư mới (bấm Làm mới từng nhà, đọc cả nhà tắt)',st.balanceRefresh)}${toggle('balanceScan','Gọi số dư cũ (quét số dư khi đẩy đơn)',st.balanceScan)}${toggle('bankBadSkip','Bỏ qua thành viên vừa bị trả sai ngân hàng (180 phút)',st.bankBadSkip)}${toggle('lite','Chế độ nhẹ (giao diện cơ bản, tắt hiệu ứng)',st.lite)}${toggle('usdt','Xử lý đơn USDT (TRC20 / ERC20)',st.usdt)}${toggle('scanTop','Bắt đơn từ trên xuống (đơn mới nhất trước)',st.scanTop)}${toggle('scanBottom','Bắt đơn từ dưới lên (đơn cũ nhất trước)',st.scanBottom)}${toggle('noticeClose','Tự đóng popup thông báo của BO',st.noticeClose)}${toggle('autoReload','Tự F5 trang BO khi rảnh (mỗi 45 phút) rồi tự chạy lại — chống trang Ối, hỏng',st.autoReload)}<button class="setting-row" id="provider-amount-settings" data-page="provider-amount" type="button">💰 <span>Cài đặt số tiền bên thứ 3</span><i>›</i></button><button class="setting-row provider-toggle-settings" id="provider-toggle-settings">🏦 <span>Bật/tắt nhà thứ 3</span><i>›</i></button><button class="setting-row" id="bank-toggle-settings" type="button">🏛 <span>Bật/tắt ngân hàng</span><b>${bankCountLabel()}</b><i>›</i></button><button class="setting-row" id="pet-settings" type="button">🤖 <span>Robot đi lại</span><i>›</i></button><button class="setting-row" id="provider-balances-settings" type="button">💳 <span>Số dư nhà thứ 3</span><i>›</i></button><h4>Nhật ký</h4><button class="setting-row" id="return-reason-log-settings" type="button">▤ <span>Log lý do đơn trả lại</span><b>${st.returnReasonLog?'BẬT':'TẮT'}</b><i>›</i></button><h4>Giao diện</h4><button class="setting-row" id="theme-settings" type="button">🌓 <span>Chế độ sáng / tối</span><b id="theme-label">${THEME_LABELS[getThemeMode()]}</b><i>⟳</i></button><button class="setting-row" id="banner-settings" type="button">🖼 <span>Giao diện banner</span><b>${(BANNER_THEMES.find(t=>t.id===getBannerThemeId())||BANNER_THEMES[0]).name}</b><i>›</i></button><h4>Cấu hình LED</h4><button class="setting-row" id="led-settings">💡 <span>Điều chỉnh đèn LED</span><i>›</i></button><h4>Cấu hình xử lý</h4><button class="setting-row" id="process-time">⏱ <span>Thời gian xử lý</span><i>›</i></button><button class="setting-row" id="reset-session">↻ <span>Đặt lại phiên xử lý</span><i>›</i></button><h4>License</h4><button class="setting-row" id="license-settings">🔑 <span>Mở khóa Key</span><i>›</i></button><button class="setting-row" id="apikey-settings" type="button">🔑 <span>Khóa API Bank Check</span><i>›</i></button><h4>Bảo mật &amp; cập nhật</h4><button class="setting-row" id="check-update" type="button">↻ <span>Cập nhật Tool</span><b id="update-badge">v${AD88_VERSION}</b><i>›</i></button><h4>Khác</h4><button class="setting-row" id="clear-log">♲ <span>Xóa nhật ký phiên</span><i>›</i></button><div class="setting-row">🌐 <span>Ngôn ngữ</span><b>Tiếng Việt</b></div></div>`;
    q('[data-back]',el).onclick=back;
    ['auto','bank','unlock','returnUnlock','lockWatchdog','balanceRefresh','balanceScan','bankBadSkip','lite','usdt','scanTop','scanBottom','noticeClose','autoReload'].forEach(id=>{
      const input=q('#'+id,el);
      input.onchange=e=>{
        setToolSetting(id,e.target.checked);
        // 1.4.173: 2 cách gọi số dư loại trừ nhau — bật cách này thì cách kia tự tắt.
        if(e.target.checked&&(id==='balanceRefresh'||id==='balanceScan')){const other=id==='balanceRefresh'?'balanceScan':'balanceRefresh';setToolSetting(other,false);const oi=q('#'+other,el);if(oi)oi.checked=false;}
        // 1.4.204: hướng bắt đơn — luôn có đúng 1 hướng bật (bật hướng này thì hướng kia tắt; tắt hướng đang bật thì hướng kia tự bật).
        if(id==='scanTop'||id==='scanBottom'){const other=id==='scanTop'?'scanBottom':'scanTop';const on=e.target.checked;setToolSetting(other,!on);const oi=q('#'+other,el);if(oi)oi.checked=!on;}
        if(id==='balanceRefresh'||id==='balanceScan'){try{window.dispatchEvent(new CustomEvent('AD88_PROVIDER_BALANCES_CHANGED'));}catch(_){}}
        if(id==='auto'){
          if(e.target.checked) window.AD88_XNK_BOT?.start?.(); else window.AD88_XNK_BOT?.stop?.();
          renderStatus();
        }
      };
    });
    q('#provider-amount-settings',el).onclick=e=>{e.preventDefault();e.stopPropagation();openPage('provider-amount');};
    q('#provider-toggle-settings',el).onclick=()=>openPage('providers');
    q('#bank-toggle-settings',el).onclick=()=>openPage('banks');
    q('#pet-settings',el).onclick=()=>openPage('pet');
    q('#provider-balances-settings',el).onclick=()=>openPage('balances');
    q('#return-reason-log-settings',el).onclick=()=>renderReturnReasonLogSettings(el);
    q('#license-settings',el).onclick=()=>openPage('license');
    {const ak=q('#apikey-settings',el);if(ak)ak.onclick=()=>openPage('apikeys');}
    q('#led-settings',el).onclick=()=>openPage('led');
    q('#theme-settings',el).onclick=()=>{const order=['dark','light','auto'];const nx=order[(order.indexOf(getThemeMode())+1)%3];setThemeMode(nx);const lb=q('#theme-label',el);if(lb)lb.textContent=THEME_LABELS[nx];};
    q('#banner-settings',el).onclick=()=>openPage('banner');
    q('#reset-session',el).onclick=()=>{
      window.AD88_XNK_BOT?.reset?.();
      renderStatus();
      alert('Đã đặt lại phiên xử lý. Lịch sử đơn của phiên hiện tại đã được xóa.');
    };
    q('#clear-log',el).onclick=()=>{
      window.AD88_XNK_BOT?.reset?.();
      renderStatus();
      alert('Đã xóa nhật ký phiên xử lý.');
    };
    q('#process-time',el).onclick=()=>renderProcessTiming(el);
    q('#check-update',el).onclick=async()=>{
      const r=await ad88SendToBackground({type:'AD88_OPEN_UPDATE',auto:true},5000);
      if(!r||!r.ok)alert('Không mở được trang cập nhật: '+((r&&r.message)||'thử F5 trang BO.'));
    };
    ad88SendToBackground({type:'AD88_CHECK_UPDATE'},8000).then(r=>{const b=q('#update-badge',el);if(!b)return;b.textContent=(r&&r.ok&&r.available)?('CÓ BẢN MỚI '+r.version):('v'+AD88_VERSION);if(r&&r.ok&&r.available)b.style.color='#ffb454';});
  }
  // showToast được gọi ở nhiều nơi (tải CSV, kích hoạt…) nhưng trước đây chưa được định nghĩa.
  function showToast(message,error=false){try{showToolToast(q('#ad88-tool-sub')||document.body,message,error);}catch(e){}}
  function renderApiKeys(el){
    el.innerHTML=head('Khóa API Bank Check')+`<div class="ad88-timing ad88-sync-page"><div class="sync-intro"><div class="sync-intro-icon">🔑</div><div><b>Khóa API Bank Check</b><small>Khóa chỉ lưu trong bộ nhớ extension, không nằm trong mã nguồn. Không chia sẻ khóa này cho người khác.</small></div></div><div class="sync-section-title">TRẠNG THÁI</div><div class="setting-row"><span>Khóa hiện tại</span><b id="key-state">…</b></div><div class="sync-section-title">NHẬP KHÓA</div><div class="sync-grid"><label class="sync-field"><span>License Key</span><div><input id="key-license" type="password" autocomplete="off" spellcheck="false" placeholder="ak_…"></div></label><label class="sync-field"><span>Secret Key</span><div><input id="key-secret" type="password" autocomplete="off" spellcheck="false" placeholder="sk_…"></div></label></div><button class="setting-row sync-save" id="key-save">✓ <span>Lưu khóa</span><i>›</i></button><button class="setting-row" id="key-clear">♲ <span>Xóa khóa đã lưu</span><i>›</i></button></div>`;
    q('[data-back]',el).onclick=()=>openPage('settings');
    const refresh=async()=>{const st=await window.AD88_apiKeys.status();const t=q('#key-state',el);if(!t)return;if(st.hasLicense&&st.hasSecret){t.textContent='ĐÃ NHẬP (…'+esc(st.licenseTail)+')';return;}let b=null;try{b=await ad88SendToBackground({type:'AD88_API_KEY_STATE'},5000);}catch(_){}t.textContent=(b&&b.builtin)?'ĐÃ CÓ SẴN TRONG TOOL — không cần nhập':(b&&b.ok?'CHƯA CÓ KHÓA — cài bản FULL hoặc nhập khóa':'Không đọc được trạng thái');t.style.color=(b&&b.builtin)?'#3ddc97':'#ff6b6b';};
    refresh();
    q('#key-save',el).onclick=async()=>{
      const l=q('#key-license',el).value.trim(),sk=q('#key-secret',el).value.trim();
      if(!l||!sk||/\s/.test(l+sk)){showToolToast(el,'Cần nhập đủ License Key và Secret Key (không chứa khoảng trắng)',true);return;}
      const ok=await window.AD88_apiKeys.save(l,sk);
      q('#key-license',el).value='';q('#key-secret',el).value='';
      await refresh();
      showToolToast(el,ok?'✓ Đã lưu khóa':'Không lưu được khóa',!ok);
    };
    q('#key-clear',el).onclick=async()=>{
      if(!confirm('Xóa License Key và Secret Key đã lưu? Bank Check sẽ không chạy cho đến khi nhập lại.'))return;
      await window.AD88_apiKeys.clear();
      await refresh();
      showToolToast(el,'Đã xóa khóa');
    };
  }
  async function renderLicenseSettings(el){
    const escLocal=v=>String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
    const icon=(name,cls='')=>{
      const a={
        key:`<svg class="${cls}" viewBox="0 0 48 48" aria-hidden="true"><path d="M19.5 27.5a9.5 9.5 0 1 1 6.1-16.8l5.3 5.3h10.4v6.1h-4v4h-4v4h-5.8l-3.5-3.5a9.5 9.5 0 0 1-4.5.9Z"/><circle cx="19" cy="18" r="3.1" fill="#07191a" stroke="none"/></svg>`,
        shield:`<svg class="${cls}" viewBox="0 0 48 48" aria-hidden="true"><path d="M24 4 40 10v11c0 10.5-6.6 18.7-16 23-9.4-4.3-16-12.5-16-23V10L24 4Z"/><path d="m16.5 24 5 5 10-11" fill="none" stroke="#07191a" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
        database:`<svg class="${cls}" viewBox="0 0 48 48" aria-hidden="true"><ellipse cx="24" cy="9" rx="14" ry="6"/><path d="M10 9v15c0 3.3 6.3 6 14 6s14-2.7 14-6V9" fill="none"/><path d="M10 24v15c0 3.3 6.3 6 14 6s14-2.7 14-6V24" fill="none"/></svg>`,
        gear:`<svg class="${cls}" viewBox="0 0 48 48" aria-hidden="true"><path d="m29.5 5 1.3 5.2a15 15 0 0 1 4.2 2.4l5.1-1.6 3.5 6-4 3.6a15 15 0 0 1 0 4.8l4 3.6-3.5 6-5.1-1.6a15 15 0 0 1-4.2 2.4L29.5 41h-7l-1.3-5.2a15 15 0 0 1-4.2-2.4l-5.1 1.6-3.5-6 4-3.6a15 15 0 0 1 0-4.8l-4-3.6 3.5-6 5.1 1.6a15 15 0 0 1 4.2-2.4L22.5 5h7Z"/><circle cx="26" cy="22" r="6" fill="#07191a" stroke="none"/></svg>`,
        lock:`<svg class="${cls}" viewBox="0 0 48 48" aria-hidden="true"><rect x="9" y="20" width="30" height="22" rx="4"/><path d="M15 20v-6c0-5 4-9 9-9s9 4 9 9v6" fill="none" stroke="currentColor" stroke-width="5"/><circle cx="24" cy="30" r="3" fill="#07191a" stroke="none"/></svg>`,
        check:`<svg class="${cls}" viewBox="0 0 48 48" aria-hidden="true"><circle cx="24" cy="24" r="20"/><path d="m14 24 7 7 14-15" fill="none" stroke="#06201c" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
        copy:`<svg class="${cls}" viewBox="0 0 48 48" aria-hidden="true"><rect x="15" y="13" width="23" height="27" rx="3" fill="none" stroke="currentColor" stroke-width="3"/><path d="M10 33V10c0-2 1.5-3 3-3h18" fill="none" stroke="currentColor" stroke-width="3"/></svg>`,
        trash:`<svg class="${cls}" viewBox="0 0 48 48" aria-hidden="true"><path d="M11 13h26M19 13V8h10v5M15 13l2 29h14l2-29" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M20 19v17M28 19v17" fill="none" stroke="currentColor" stroke-width="3"/></svg>`
      }; return a[name]||'';
    };
    el.innerHTML=head('Mở khóa Key')+`<div class="ad88-license-page christmas-license">
      <div class="ad88-license-card christmas-license-card">
        <div class="ad88-license-icon">${icon('key')}</div>
        <div class="license-card-copy"><h3>LICENSE AD88 XNK TOOL</h3><p>Kích hoạt License Key được cấp riêng cho máy này.</p></div>
        <div class="license-card-brand">AD<span>88</span><i>♛</i></div>
      </div>
      <div class="ad88-license-device christmas-device"><small>MÃ MÁY</small><b id="ad88-license-device">Đang lấy mã máy…</b><button type="button" id="ad88-copy-device">${icon('copy')}<span>Sao chép</span></button></div>
      <label class="ad88-license-label">LICENSE KEY</label>
      <textarea id="ad88-license-input" class="ad88-license-input christmas-license-input" rows="4" placeholder="Dán License Key AD88.… vào đây"></textarea>
      <div class="ad88-license-actions christmas-actions"><button type="button" id="ad88-license-activate">${icon('key')}<span>KÍCH HOẠT</span></button><button type="button" id="ad88-license-clear" class="danger">${icon('trash')} XÓA KEY</button></div>
      <div id="ad88-license-status" class="ad88-license-status christmas-status">Đang kiểm tra…</div>
      <div class="ad88-license-note">License được xác minh bằng chữ ký ECDSA P-256. Tool không chứa private key.</div>

      <section class="ad88-license-info artwork-license-info" aria-label="Thông tin và bản quyền">
        <img src="${chrome.runtime.getURL('assets/ad88-license-info-christmas.png')}" alt="AD88 XNK TOOL - Thông tin và bản quyền" draggable="false">
      </section>
    </div>`;
    q('[data-back]',el).onclick=back;
    const deviceEl=q('#ad88-license-device',el), input=q('#ad88-license-input',el), status=q('#ad88-license-status',el);
    const render=lic=>{
      deviceEl.textContent=lic.device||'—';
      status.textContent=(lic.ok?'✓ ':'✕ ')+(lic.message||'License không hợp lệ');
      status.className='ad88-license-status christmas-status '+(lic.ok?'ok':'bad');
      if(lic.ok && lic.payload) status.textContent='✓ '+lic.message+(lic.payload.n?` · ${lic.payload.n}`:'');
    };
    try{
      const token=await window.AD88_LICENSE.getToken();
      if(token) input.value=token;
      render(await window.AD88_LICENSE.getStatus());
    }catch{ status.textContent='✕ Không thể đọc trạng thái License'; status.className='ad88-license-status christmas-status bad'; }
    q('#ad88-copy-device',el).onclick=async()=>{
      try{await navigator.clipboard.writeText(deviceEl.textContent);showToast('Đã sao chép Mã máy');}
      catch{alert('Mã máy: '+deviceEl.textContent);}
    };
    q('#ad88-license-activate',el).onclick=async()=>{
      const token=input.value.trim();
      if(!token){alert('Vui lòng nhập License Key.');return;}
      const btn=q('#ad88-license-activate',el);btn.disabled=true;btn.textContent='ĐANG KIỂM TRA…';
      try{
        const lic=await window.AD88_LICENSE.activate(token);
        render(lic);
        if(lic.ok){showToast('✓ Kích hoạt License thành công');}
        else{alert('Không thể kích hoạt: '+lic.message);}
      }finally{btn.disabled=false;btn.innerHTML=icon('key')+'<span>KÍCH HOẠT</span>';}
    };
    q('#ad88-license-clear',el).onclick=async()=>{
      if(!confirm('Xóa License Key đang lưu trên máy này?'))return;
      await window.AD88_LICENSE.clearToken(); input.value=''; render(await window.AD88_LICENSE.getStatus());
      try{window.AD88_XNK_BOT?.stop?.();}catch{}
    };
  }

  function renderReturnReasonLogSettings(el){
    const on=!!getToolSettings().returnReasonLog;
    el.innerHTML=head('Log lý do đơn trả lại')+`<div class="ad88-return-reason-settings"><div class="return-reason-intro"><div class="return-reason-icon">▤</div><div><b>CHI TIẾT LÝ DO ĐƠN TRẢ LẠI</b><small>Khi Bank Check kết luận sai thông tin, nhật ký sẽ lưu nguyên nhân cụ thể để dễ đối chiếu.</small></div></div><label class="setting-row"><span>Hiển thị lý do chi tiết trong nhật ký</span><input id="cfg-return-reason-log" type="checkbox" ${on?'checked':''}><i class="switch"></i></label><div class="return-reason-example"><b>Ví dụ log</b><div>HỌ TÊN KHÔNG KHỚP · Tên trên đơn: NGUYEN VAN MINH · Tên từ API: NGUYEN TRAN THU HAI · Chi tiết: Tên chủ tài khoản không khớp...</div></div><div class="return-reason-note">Tắt mục này không xóa nhật ký cũ. Các đơn trả lại mới sẽ chỉ lưu lý do ngắn.</div></div>`;
    q('[data-back]',el).onclick=()=>openPage('settings');
    q('#cfg-return-reason-log',el).onchange=e=>setToolSetting('returnReasonLog',e.target.checked);
  }

  function renderProviderAmountSettings(el){
    const cfg=getProviderConfigState();
    el.innerHTML=head('Cài đặt số tiền bên thứ 3')+`<div class="ad88-provider-config"><div class="provider-config-note">Cài đặt khoảng tiền xử lý cho từng nhà thứ 3. <b>VND: nhập trực tiếp số tiền</b> · <b>USDT: nhập đúng số USDT</b>. Số tiền sẽ tự thêm dấu chấm để dễ đọc, ví dụ <b>5.000.000</b> hoặc <b>10.000.000</b>.</div><div class="provider-config-list">${PROVIDERS.map(key=>{const x=cfg[key];const cur=x.currency||'VND';return `<div class="provider-config-card" data-key="${esc(key)}"><div class="provider-config-title"><span class="provider-dot"></span><b>${esc(x.name)}</b><em class="provider-currency ${cur==='USDT'?'usdt':'vnd'}">${cur}</em></div><div class="provider-config-fields"><label><span>MIN</span><input class="provider-min-input" type="text" inputmode="decimal" autocomplete="off" value="${x.min==null?'':formatAmountInput(x.min,cur)}" placeholder="Không giới hạn"></label><label><span>MAX</span><input class="provider-max-input" type="text" inputmode="decimal" autocomplete="off" value="${x.max==null?'':formatAmountInput(x.max,cur)}" placeholder="Không giới hạn"></label></div><div class="provider-unit-hint">${cur==='USDT'?'Đơn vị: USDT (10 = 10 USDT)':'Đơn vị: VND trực tiếp (100.000 = 100.000 VNĐ)'}</div></div>`}).join('')}<div class="provider-config-save-wrap"><button class="setting-row provider-config-save" id="save-provider-config">✓ <span>Lưu cấu hình</span><i>›</i></button></div></div></div>`;
    el.querySelectorAll('.provider-min-input,.provider-max-input').forEach(input=>{
      input.addEventListener('input',()=>{
        const card=input.closest('.provider-config-card');
        const key=card?.dataset.key;
        const cur=PROVIDER_CONFIG_DEFAULTS[key]?.currency||'VND';
        const before=input.value.slice(0,input.selectionStart??input.value.length);
        const digitsBefore=before.replace(/[^0-9]/g,'').length;
        input.value=formatAmountInput(input.value,cur);
        let pos=0,seen=0;
        while(pos<input.value.length && seen<digitsBefore){if(/[0-9]/.test(input.value[pos]))seen++;pos++;}
        try{input.setSelectionRange(pos,pos)}catch{}
      });
    });
    q('[data-back]',el).onclick=()=>openPage('settings');
    requestAnimationFrame(()=>{
      const panel=q('#ad88-tool-panel');
      const list=q('.provider-config-list',el);
      if(panel&&list){
        const available=Math.max(180,Math.min(window.innerHeight-220,panel.clientHeight-150));
        list.style.maxHeight=available+'px';
      }
    });
    q('#save-provider-config',el).onclick=()=>{
      const out={};
      let invalid='';
      el.querySelectorAll('.provider-config-card').forEach(card=>{
        const key=card.dataset.key;
        const minRaw=card.querySelector('.provider-min-input').value.trim();
        const maxRaw=card.querySelector('.provider-max-input').value.trim();
        const currency=(PROVIDER_CONFIG_DEFAULTS[key]?.currency==='USDT')?'USDT':'VND';
        const min=parseAmountInput(minRaw,currency), max=parseAmountInput(maxRaw,currency);
        const name=PROVIDER_CONFIG_DEFAULTS[key]?.name||key;
        if(min!==null && (!Number.isFinite(min)||min<0)){invalid=`MIN của ${name} không hợp lệ.`;return;}
        if(max!==null && (!Number.isFinite(max)||max<0)){invalid=`MAX của ${name} không hợp lệ.`;return;}
        if(min!==null && max!==null && min>max){invalid=`MIN không được lớn hơn MAX của ${name}.`;return;}
        out[key]={name,currency,min,max};
      });
      if(invalid){showToolToast(el,invalid,true);return;}
      out.__vndDirectUnitMigrated=true;
      setProviderConfigState(out);
      showToolToast(el,'✓ Đã áp dụng');
    };
  }
  function showToolToast(el,message,error=false){
    let toast=q('.ad88-tool-toast',el);
    if(!toast){toast=document.createElement('div');toast.className='ad88-tool-toast';const host=q('#ad88-tool-panel')||el;host.appendChild(toast);}
    toast.textContent=message;
    toast.classList.toggle('error',!!error);
    toast.classList.remove('show');
    requestAnimationFrame(()=>toast.classList.add('show'));
    clearTimeout(toast._timer);
    toast._timer=setTimeout(()=>toast.classList.remove('show'),1600);
  }
  function renderProcessTiming(el){
    const cfg=window.XNK_CONFIG||{},auto=cfg.autoSync!==false,pollMin=Number(cfg.pollMinMs)||100,pollMax=Number(cfg.pollMaxMs)||650,dmin=Number(cfg.nextOrderDelayMinMs)||350,dmax=Number(cfg.nextOrderDelayMaxMs)||3000;
    el.innerHTML=head('Tốc độ & đồng bộ')+`<div class="ad88-timing ad88-sync-page"><div class="sync-intro"><div class="sync-intro-icon">⚡</div><div><b>Tốc độ & đồng bộ</b><small>AUTO SYNC ưu tiên trạng thái DOM/API thực tế, giúp Tool không chạy nhanh hơn khi website chưa cập nhật.</small></div></div><label class="setting-row sync-master"><span>⚡ Đồng bộ tốc độ tự động</span><input id="cfg-auto-sync" type="checkbox" ${auto?'checked':''}><i class="switch"></i></label><div class="sync-section-title">THỜI GIAN CHỜ</div><div class="sync-grid"><label class="sync-field"><span>Chờ thao tác</span><div><input id="cfg-action" type="number" min="1000" max="30000" step="500" value="${Number(cfg.actionTimeoutMs)||8000}"><b>ms</b></div></label><label class="sync-field"><span>Bank Check timeout</span><div><input id="cfg-bank" type="number" min="3000" max="60000" step="500" value="${Number(cfg.bankCheckTimeoutMs)||15000}"><b>ms</b></div></label><label class="sync-field"><span>Cooldown cơ sở</span><div><input id="cfg-delay" type="number" min="100" max="30000" step="100" value="${Number(cfg.nextOrderDelayMs)||2200}"><b>ms</b></div></label></div><div class="sync-section-title">POLLING & COOLDOWN</div><div class="sync-grid"><label class="sync-field"><span>Polling MIN</span><div><input id="cfg-poll-min" type="number" min="50" max="1000" step="10" value="${pollMin}"><b>ms</b></div></label><label class="sync-field"><span>Polling MAX</span><div><input id="cfg-poll-max" type="number" min="100" max="2000" step="10" value="${pollMax}"><b>ms</b></div></label><label class="sync-field"><span>Cooldown MIN</span><div><input id="cfg-delay-min" type="number" min="100" max="10000" step="50" value="${dmin}"><b>ms</b></div></label><label class="sync-field"><span>Cooldown MAX</span><div><input id="cfg-delay-max" type="number" min="200" max="30000" step="100" value="${dmax}"><b>ms</b></div></label></div><button class="setting-row sync-save" id="save-timing">✓ <span>Lưu cấu hình tốc độ & đồng bộ</span><i>›</i></button></div>`;
    q('[data-back]',el).onclick=()=>openPage('settings');
    q('#save-timing',el).onclick=()=>{const a=Math.max(1000,Math.min(30000,Number(q('#cfg-action',el).value)||8000)),b=Math.max(3000,Math.min(60000,Number(q('#cfg-bank',el).value)||15000)),d=Math.max(100,Math.min(30000,Number(q('#cfg-delay',el).value)||2200)),pmin=Math.max(50,Math.min(1000,Number(q('#cfg-poll-min',el).value)||100)),pmax=Math.max(pmin,Math.min(2000,Number(q('#cfg-poll-max',el).value)||650)),dmin2=Math.max(100,Math.min(10000,Number(q('#cfg-delay-min',el).value)||350)),dmax2=Math.max(dmin2,Math.min(30000,Number(q('#cfg-delay-max',el).value)||3000));localStorage.setItem('AD88_XNK_CFG_ACTION_TIMEOUT',String(a));localStorage.setItem('AD88_XNK_CFG_BANK_TIMEOUT',String(b));localStorage.setItem('AD88_XNK_CFG_NEXT_DELAY',String(d));if(window.XNK_CONFIG){window.XNK_CONFIG.actionTimeoutMs=a;window.XNK_CONFIG.bankCheckTimeoutMs=b;window.XNK_CONFIG.nextOrderDelayMs=d;window.XNK_CONFIG.autoSync=!!q('#cfg-auto-sync',el).checked;window.XNK_CONFIG.pollMinMs=pmin;window.XNK_CONFIG.pollMaxMs=pmax;window.XNK_CONFIG.nextOrderDelayMinMs=dmin2;window.XNK_CONFIG.nextOrderDelayMaxMs=dmax2;}localStorage.setItem('AD88_XNK_AUTO_SYNC',String(!!q('#cfg-auto-sync',el).checked));localStorage.setItem('AD88_XNK_POLL_MIN',String(pmin));localStorage.setItem('AD88_XNK_POLL_MAX',String(pmax));localStorage.setItem('AD88_XNK_DELAY_MIN',String(dmin2));localStorage.setItem('AD88_XNK_DELAY_MAX',String(dmax2));showToolToast(el,'✓ Đã lưu cấu hình tốc độ & đồng bộ');};
  }

  function renderLedSettings(el){
    const ls=getLedSettings();
    el.innerHTML=head('Điều chỉnh đèn LED')+`<div class="ad88-led-settings ${ls.enabled?'':'led-off'}"><label class="led-onoff"><input id="led-enabled" type="checkbox" ${ls.enabled?'checked':''}><span class="led-onoff-sw"></span><b id="led-enabled-text">${ls.enabled?'Đèn LED: ĐANG BẬT':'Đèn LED: ĐÃ TẮT'}</b></label><div class="led-setting-title">🎨 Màu LED</div><div class="ad88-led-swatches led-settings-swatches">${LED_COLORS.map(c=>`<button type="button" data-led="${c.value}" title="${c.name}" style="--c:${c.value}"><span></span></button>`).join('')}</div><label class="led-range-row"><span>Độ sáng</span><output id="led-bright-out">${ls.brightness}%</output><input id="led-bright" type="range" min="10" max="300" value="${ls.brightness}"></label><label class="led-range-row"><span>Độ dày</span><output id="led-thick-out">${ls.thick}%</output><input id="led-thick" type="range" min="30" max="200" value="${ls.thick}"></label><label class="led-range-row"><span>Tốc độ</span><output id="led-speed-out">${ls.speed}%</output><input id="led-speed" type="range" min="10" max="100" value="${ls.speed}"></label><div class="led-setting-title">Hiệu ứng</div><div class="led-effects">${[['single','Chạy đơn'],['two','Hai chiều'],['multi','Nhiều điểm'],['comet','Comet Tail'],['pulse','Pulse toàn viền'],['rainbow','Rainbow Flow'],['wave','Wave'],['spark','Spark'],['chase','Đuổi 3 màu'],['dual','Hai màu đối nghịch'],['snake','Rắn dài'],['fire','Lửa'],['marquee','Bóng đèn chạy'],['xmas','Đèn Giáng sinh nhấp nháy'],['heart','Nhịp tim'],['corner','Chớp 4 góc'],['static','Tĩnh']].map(([v,n])=>`<label><input type="radio" name="led-effect" value="${v}" ${ls.effect===v?'checked':''}><span>○</span>${n}</label>`).join('')}</div></div>`;
    q('[data-back]',el).onclick=()=>openPage('settings');
    el.querySelectorAll('[data-led]').forEach(b=>b.onclick=()=>setLedColor(b.dataset.led));
    const br=q('#led-bright',el),bo=q('#led-bright-out',el); br.oninput=()=>{bo.value=br.value+'%';setLedSetting('AD88_XNK_LED_BRIGHTNESS',br.value)};
    const th=q('#led-thick',el),tho=q('#led-thick-out',el); th.oninput=()=>{tho.value=th.value+'%';setLedSetting('AD88_XNK_LED_THICK',th.value)};
    const sp=q('#led-speed',el),so=q('#led-speed-out',el); sp.oninput=()=>{so.value=sp.value+'%';setLedSetting('AD88_XNK_LED_SPEED',sp.value)};
    const en=q('#led-enabled',el);if(en)en.onchange=()=>{setLedSetting('AD88_XNK_LED_ENABLED',en.checked?'1':'0');q('#led-enabled-text',el).textContent=en.checked?'Đèn LED: ĐANG BẬT':'Đèn LED: ĐÃ TẮT';el.querySelector('.ad88-led-settings').classList.toggle('led-off',!en.checked)};
    el.querySelectorAll('input[name=led-effect]').forEach(r=>r.onchange=()=>setLedSetting('AD88_XNK_LED_EFFECT',r.value));
  }
  function renderBannerSettings(el){
    const cur=getBannerThemeId();
    el.innerHTML=head('Giao diện banner')+`<div class="ad88-banner-settings"><p class="banner-note">Chọn hình nền cho phần tiêu đề. Logo, chữ và giờ chạy giữ nguyên.</p>${BANNER_THEMES.map(t=>`<button type="button" class="banner-card ${t.id===cur?'selected':''}" data-banner="${t.id}" aria-pressed="${t.id===cur}"><span class="banner-preview" style="--prev:url('${chrome.runtime.getURL(t.file)}')"></span><span class="banner-info"><b>${t.name}</b><small>${t.desc}</small></span><i class="banner-check">${t.id===cur?'✓ Đang dùng':'Chọn'}</i></button>`).join('')}</div>`;
    q('[data-back]',el).onclick=()=>openPage('settings');
    el.querySelectorAll('.banner-card').forEach(b=>b.onclick=()=>{
      setBannerThemeId(b.dataset.banner);
      el.querySelectorAll('.banner-card').forEach(x=>{const on=x===b;x.classList.toggle('selected',on);x.setAttribute('aria-pressed',on);x.querySelector('.banner-check').textContent=on?'✓ Đang dùng':'Chọn';});
    });
  }
  function toggle(id,label,on){return `<label class="setting-row"><span>⚙ ${label}</span><input id="${id}" type="checkbox" ${on?'checked':''}><i class="switch"></i></label>`;}
  function downloadOrderLogCsv(logs){
    const rows=(Array.isArray(logs)?logs:[]).filter(x=>x.state==='DONE'||x.state==='RETURN');
    if(!rows.length){
      showToast('Chưa có nhật ký để tải');
      return;
    }
    const escCsv=v=>{const s=String(v??'');return /[\",\n]/.test(s)?'\"'+s.replace(/\"/g,'\"\"')+'\"':s};
    const done=rows.filter(x=>x.state==='DONE').length;
    const returned=rows.filter(x=>x.state==='RETURN').length;
    const lines=[];
    lines.push(['BÁO CÁO NHẬT KÝ XỬ LÝ ĐƠN AD88 XNK TOOL']);
    lines.push(['Ngày xuất',new Date().toLocaleDateString('vi-VN')]);
    lines.push(['Tổng số đơn',rows.length]);
    lines.push(['Thành công',done]);
    lines.push(['Đơn trả lại',returned]);
    lines.push([]);
    lines.push(['Ngày','Thời gian','Người thao tác','Mã đơn','Kết quả','Nhà thứ 3','Số tiền VND','USDT','Lý do']);
    rows.slice().reverse().forEach(x=>lines.push([
      x.date||'',x.time||'',x.operator||'',x.order||'',x.label||x.state||'',x.provider||'',
      x.currency==='USDT'?'':(x.amount!=null?Number(x.amount).toLocaleString('vi-VN'):''),
      x.currency==='USDT'?(x.amount!=null?Number(x.amount).toLocaleString('en-US',{maximumFractionDigits:8}):''):'',
      x.reason||''
    ]));
    const csv='\uFEFF'+lines.map(r=>r.map(escCsv).join(',')).join('\r\n');
    const blob=new Blob([csv],{type:'text/csv;charset=utf-8;'});
    const url=URL.createObjectURL(blob);
    const a=document.createElement('a');
    const stamp=new Date().toISOString().slice(0,10);
    a.href=url;a.download=`AD88_XNK_NHAT_KY_${stamp}.csv`;
    document.body.appendChild(a);a.click();a.remove();
    setTimeout(()=>URL.revokeObjectURL(url),1000);
    showToast('Đã tải file nhật ký');
  }
  // ===== 1.4.180: Nhật ký → tab "Kiểm tra đơn" (chỉ đọc; gọi window.AD88_XNK_BOT.checkOrder) =====
  // 1.4.202: ô nhập ở các trang Check luôn dán/gõ được dù trang BO có chặn phím tắt/chuột phải;
  // nếu Ctrl+V bị chặn thì tự đọc clipboard điền vào ô.
  function ckHardenInput(input){
    if(!input||input.dataset.ckHard)return;input.dataset.ckHard='1';
    ['keydown','keyup','keypress','paste','input','beforeinput','contextmenu','copy','cut'].forEach(t=>input.addEventListener(t,e=>e.stopPropagation()));
    input.addEventListener('keydown',e=>{
      if((e.ctrlKey||e.metaKey)&&String(e.key).toLowerCase()==='v'){
        const before=input.value;
        setTimeout(()=>{
          if(input.value!==before)return;
          try{navigator.clipboard&&navigator.clipboard.readText&&navigator.clipboard.readText().then(t=>{t=String(t||'').trim();if(t&&input.value===before){input.value=t;input.dispatchEvent(new Event('input',{bubbles:true}));}}).catch(()=>{});}catch(_){}
        },60);
      }
    });
  }
  function ckTabsHTML(active){return `<div class="ck-tabs"><button type="button" data-ck-tab="log" class="${active==='log'?'on':''}">NHẬT KÝ</button><button type="button" data-ck-tab="check" class="${active==='check'?'on':''}">CHECK ĐƠN XUẤT</button><button type="button" data-ck-tab="dep" class="${active==='dep'?'on':''}">CHECK ĐƠN NHẬP</button><button type="button" data-ck-tab="acct" class="${active==='acct'?'on':''}">CHECK TÊN TK</button></div>`;}
  function wireCkTabs(el){
    el.querySelectorAll('[data-ck-tab]').forEach(b=>b.onclick=()=>{const t=b.dataset.ckTab;if(t==='check')renderOrderCheck(el);else if(t==='dep')renderDepositCheck(el);else if(t==='acct')renderAccountCheck(el);else renderLog(el);});
  }
  // 1.4.185: các mục Nhật ký / Check: từ khung ~700px trở xuống giữ cỡ chữ hiện tại; kéo khung to hơn thì chữ, số, nút, biểu tượng to dần (tối đa x1.3 ở 1000px)
  function wireCkScale(el){
    const page=q('.ad88-log-page',el);
    if(!page)return;
    try{el._ckRO&&el._ckRO.disconnect();}catch(_){}
    const apply=()=>{
      const w=page.getBoundingClientRect().width||0;
      const z=Math.max(1,Math.min(1.3,1+(w-700)/300*0.3));
      page.style.setProperty('--ck-zoom',z.toFixed(3));
    };
    apply();
    if(typeof ResizeObserver==='function'){el._ckRO=new ResizeObserver(apply);el._ckRO.observe(page);}
  }
  function wireLogHeadDrag(el){
    const root=q('#ad88-xnk-tool-root');
    const head=q('.ad88-log-page-head',el);
    if(!root||!head)return;
    let drag=null;
    const moveDrag=e=>{
      if(!drag)return;
      const dx=e.clientX-drag.sx,dy=e.clientY-drag.sy;
      if(Math.abs(dx)+Math.abs(dy)>3)drag.moved=true;
      if(!drag.moved)return;
      const r=root.getBoundingClientRect();
      const x=Math.max(4,Math.min(drag.x+dx,window.innerWidth-r.width-4));
      const y=Math.max(4,Math.min(drag.y+dy,window.innerHeight-r.height-4));
      root.style.left=x+'px';root.style.top=y+'px';root.style.right='auto';root.style.bottom='auto';
      e.preventDefault();
    };
    const stopDrag=()=>{
      if(!drag)return;
      if(drag.moved)savePosition(root,true);
      drag=null;
      document.removeEventListener('mousemove',moveDrag);
      document.removeEventListener('mouseup',stopDrag);
    };
    head.addEventListener('mousedown',e=>{
      if(e.button!==0||e.target.closest('button'))return;
      const r=root.getBoundingClientRect();
      drag={sx:e.clientX,sy:e.clientY,x:r.left,y:r.top,moved:false};
      document.addEventListener('mousemove',moveDrag);
      document.addEventListener('mouseup',stopDrag);
      e.preventDefault();
    });
  }
  function renderCheckLock(el){
    const bot=window.AD88_XNK_BOT;
    el.innerHTML=head('Check thông tin')+`<div class="ad88-settings ck-lock"><div class="ck-lock-ic"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="4.5" y="10.5" width="15" height="10" rx="2.5"/><path d="M8 10.5V8a4 4 0 0 1 8 0v2.5"/><circle cx="12" cy="15.5" r="1.3"/></svg></div><div class="ck-lock-msg">Vì vấn đề bảo mật, khi không có key không thể kiểm tra thông tin.</div><input id="ck-key" type="password" autocomplete="off" spellcheck="false" placeholder="Nhập key để mở"><button type="button" id="ck-unlock">MỞ KHÓA</button><div class="ck-lock-err" id="ck-lock-err"></div></div>`;
    q('[data-back]',el).onclick=back;
    el.querySelectorAll('[data-back]').forEach(b=>b.onclick=back);
    const inp=q('#ck-key',el),btn=q('#ck-unlock',el),err=q('#ck-lock-err',el);
    let busy=false;
    const go=async()=>{
      if(busy)return;
      busy=true;btn.disabled=true;err.textContent='';
      try{
        const r=await bot.checkLock.unlock(inp.value);
        if(r&&r.ok){inp.value='';renderLog(el);return;}
        err.textContent=(r&&r.message)||'Key không đúng.';
      }catch(_){err.textContent='Không kiểm tra được key.';}
      busy=false;btn.disabled=false;inp.select();
    };
    btn.onclick=go;
    inp.onkeydown=e=>{if(e.key==='Enter')go();};
    setTimeout(()=>{try{inp.focus();}catch(_){}},50);
  }
  function checkLockedGate(el){
    const lk=window.AD88_XNK_BOT&&window.AD88_XNK_BOT.checkLock;
    if(lk&&!lk.isOpen()){renderCheckLock(el);return true;}
    return false;
  }
  function renderOrderCheck(el){
    if(checkLockedGate(el))return;
    const rowsHTML=(arr)=>(arr||[]).map(r=>`<div class="ck-row"><span>${esc(r[0])}</span><b class="${r[2]==='warn'?'ck-warn':r[2]==='ok'?'ck-ok':r[2]==='bad'?'ck-bad':''}">${esc(r[1])}</b></div>`).join('');
    el.innerHTML=`<div class="ad88-log-page ck-page"><div class="ad88-log-page-head"><div class="ad88-log-title"><span>▣</span><div><b>NHẬT KÝ XỬ LÝ ĐƠN</b><small>Kiểm tra lại thông tin một đơn theo số lệnh</small></div></div><button class="ad88-log-home" type="button" data-back="1">← QUAY LẠI GIAO DIỆN TRANG CHỦ</button></div>${ckTabsHTML('check')}
      <div class="ck-search"><input id="ck-input" type="text" inputmode="numeric" autocomplete="off" placeholder="Dán số lệnh đơn cần kiểm tra"><button type="button" id="ck-go">KIỂM TRA</button></div>
      <div id="ck-out"><div class="ck-hint">Dán số lệnh đầy đủ (có thể kèm tiền tố 01–09 ở đầu) rồi bấm KIỂM TRA. Tool tra đơn trên BO (đơn cũ cũng được, tìm tới 6 tháng gần nhất), gọi Bank Check, và cho biết khách có bao nhiêu tài khoản, tài khoản trên đơn là cũ hay mới. Chỉ xem, không khóa/đổi đơn.</div></div></div>`;
    q('[data-back]',el).onclick=back;wireCkTabs(el);wireLogHeadDrag(el);wireCkScale(el);
    const input=q('#ck-input',el),go=q('#ck-go',el),out=q('#ck-out',el);ckHardenInput(input);
    const histHTML=(h)=>h&&h.length?`<div class="ck-card"><h5>LỊCH SỬ XỬ LÝ CỦA ĐƠN NÀY <em>${h.length} dòng</em></h5>${h.map(x=>`<div class="ck-row ck-hist"><span>${esc(x.time)}</span><b class="${x.state==='DONE'?'ck-ok':x.state==='RETURN'||x.state==='STOP'?'ck-bad':''}">${esc(x.label)}${x.provider?' · '+esc(x.provider):''}${x.reason?' — '+esc(x.reason):''}</b></div>`).join('')}</div>`:'';
    const acctHTML=(ac,av)=>{
      if(!ac)return '';
      if(ac.error)return `<div class="ck-card"><h5>TÀI KHOẢN CỦA KHÁCH <em>không lấy được</em></h5><div class="ck-note">${esc(ac.error)}</div></div>`;
      const tag=(t,c)=>`<i class="ck-tag ${c}">${t}</i>`;
      const rowsA=(ac.items||[]).map(x=>`<div class="ck-acct ${x.match?'hit':''}"><div class="ck-acct-main"><b>${esc(x.bank)}</b><span>${esc(x.masked)}</span></div><div class="ck-acct-meta"><span>${esc(x.type)} · tạo ${esc(x.created)}</span><div>${x.match?tag('TÀI KHOẢN TRÊN ĐƠN','hit'):''}${x.newest?tag('MỚI NHẤT','new'):''}${x.def?tag('MẶC ĐỊNH','def'):''}${x.active?'':tag('ĐÃ HỦY','off')}</div></div></div>`).join('');
      return `<div class="ck-card"><h5>TÀI KHOẢN CỦA KHÁCH <em>${esc(ac.summary||'')}</em></h5>${rowsA||'<div class="ck-note">Khách chưa có tài khoản rút nào.</div>'}</div>`;
    };
    const render=(r)=>{
      if(!r||r.ok===false){out.innerHTML=`<div class="ck-verdict warn"><i>!</i><div>${esc(r&&r.message||'Không kiểm tra được.')}</div></div>${histHTML(r&&r.history)}`;return;}
      const v=r.verdict||{tone:'warn',title:'',detail:''};
      const ico=v.tone==='ok'?'✓':v.tone==='bad'?'✕':'!';
      const av=r.acctVerdict;
      const avPill=av&&av.tone!=='ok'?`<u title="${esc(av.detail||'')}">${esc(String(av.title||'').replace(/\(theo BO\)/i,'').trim())}${av.detail?' · '+esc((String(av.detail).match(/\(([^)]*trước[^)]*)\)/)||[])[1]||''):''}</u>`:'';
      const api=r.api;
      const cmpHTML=api=>{const ic={ok:'✓',bad:'✕',na:'?'};
        let h=api.compare.map(c=>`<div class="ck-ab"><small>${esc(c.label.replace('Họ tên chủ tài khoản','Họ tên'))}</small><div class="${esc(c.state)}">${ic[c.state]} ${esc(c.api)}</div></div>`).join('');
        if(api.where&&api.where.tone!=='ok')h+=`<div class="ck-cmp-w ${esc(api.where.tone)}">${esc(api.where.text)}</div>`;
        h+=`<div class="ck-ab-at">Gọi lúc ${esc(api.at||'—')}</div>`;
        if(api.fields&&api.fields.length)h+='<details class="ck-cmp-d"><summary>Chi tiết API trả về</summary>'+api.fields.map(f=>`<div><b>${esc(f[0])}</b>: ${esc(f[1])}</div>`).join('')+'</details>';
        return h;};
      const apiRows=api&&api.usdt?[['Mạng',api.bank||'—'],['Địa chỉ ví',api.account||'—'],['Xác minh',api.status==='VALID'?'✓ Hợp lệ':api.status==='INVALID'?'✕ Không hợp lệ':'Chưa kết luận',api.status==='VALID'?'ok':api.status==='INVALID'?'bad':'warn'],['Gọi lúc',api.at||'—']]:api?[['Ngân hàng (API)',api.bank||'—'],['Số tài khoản (API)',api.account||'—'],['Tên chủ TK (API)',api.fullname||(api.nameNotReturned?'API không trả tên':'—')],['Xác minh',api.status==='VALID'?'✓ Khớp':api.status==='INVALID'?'✕ Không khớp':'Chưa kết luận',api.status==='VALID'?'ok':api.status==='INVALID'?'bad':'warn'],['Gọi lúc',api.at||'—']]:[];
      const srcTxt=r.source==='API'?'tra từ BO':'đọc từ dòng đơn';
      out.innerHTML=`${r.note?`<div class="ck-note ck-prefix">${esc(r.note)}</div>`:''}<div class="ck-verdict ck-vc ${esc(v.tone)}"><i>${ico}</i><b>${esc(v.title)}</b><span>${esc(v.detail)}</span>${avPill}</div><div class="ck-grid2"><div class="ck-card"><h5>THÔNG TIN TRÊN BO <em>${srcTxt}</em></h5>${rowsHTML(r.bo)}</div><div class="ck-card"><h5>${api&&api.usdt?'KIỂM TRA VÍ USDT':'KẾT QUẢ API NGÂN HÀNG'} <em>${api&&api.usdt?'qua mạng blockchain':'gọi trực tiếp'}</em></h5>${api?(api.compare&&!api.usdt?cmpHTML(api):rowsHTML(apiRows))+(api.message?`<div class="ck-note">${esc(api.message)}</div>`:'')+'<div class="ck-note">Chỉ xem, không khóa/không đổi đơn</div>':'<div class="ck-note">Chưa gọi API.</div>'}</div></div>${acctHTML(r.accounts,av)}${histHTML(r.history)}`;
    };
    let busy=false;
    const run=async()=>{
      if(busy)return;
      const bot=window.AD88_XNK_BOT;
      if(!bot||typeof bot.checkOrder!=='function'){render({ok:false,message:'Tool chưa sẵn sàng, hãy tải lại trang BO rồi thử lại.'});return;}
      busy=true;go.disabled=true;go.textContent='ĐANG KIỂM TRA…';out.innerHTML='<div class="ck-hint">Đang đọc đơn và gọi Bank Check…</div>';
      try{render(await bot.checkOrder(input.value));}catch(e){render({ok:false,message:String(e&&e.message||e)});}
      busy=false;go.disabled=false;go.textContent='KIỂM TRA';
    };
    go.onclick=run;input.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();run();}};
    setTimeout(()=>{try{input.focus();}catch(_){}} ,50);
  }
  // ===== 1.4.183: tab "CHECK ĐƠN NHẬP" (đơn nạp, chỉ đọc; gọi window.AD88_XNK_BOT.checkDeposit) =====
  function renderDepositCheck(el){
    if(checkLockedGate(el))return;
    const rowsHTML=(arr)=>(arr||[]).map(r=>`<div class="ck-row"><span>${esc(r[0])}</span><b class="${r[2]==='warn'?'ck-warn':r[2]==='ok'?'ck-ok':r[2]==='bad'?'ck-bad':''}">${esc(r[1])}</b></div>`).join('');
    el.innerHTML=`<div class="ad88-log-page ck-page"><div class="ad88-log-page-head"><div class="ad88-log-title"><span>▣</span><div><b>NHẬT KÝ XỬ LÝ ĐƠN</b><small>Kiểm tra đơn NẠP theo số lệnh</small></div></div><button class="ad88-log-home" type="button" data-back="1">← QUAY LẠI GIAO DIỆN TRANG CHỦ</button></div>${ckTabsHTML('dep')}
      <div class="ck-search"><input id="ck-input" type="text" inputmode="numeric" autocomplete="off" placeholder="Dán số lệnh đơn nạp cần kiểm tra"><button type="button" id="ck-go">KIỂM TRA</button></div>
      <div id="ck-out"><div class="ck-hint">Dán số lệnh đơn nạp rồi bấm KIỂM TRA. Tool tra đơn ở cả “Tổng nạp tiền” và “Tổng nạp nhanh” trên BO (tìm tới 6 tháng gần nhất) và hiện đủ: tài khoản, thời gian tạo/thành công, cấp độ, tiền tệ, số tiền, hạng mục, nhà thứ 3, tỷ lệ phí, người thao tác, tình trạng đơn. Chỉ xem, không bấm/khóa/đổi đơn.</div></div></div>`;
    q('[data-back]',el).onclick=back;wireCkTabs(el);wireLogHeadDrag(el);wireCkScale(el);
    const input=q('#ck-input',el),go=q('#ck-go',el),out=q('#ck-out',el);ckHardenInput(input);
    const render=(r)=>{
      if(!r||r.ok===false){out.innerHTML=`<div class="ck-verdict warn"><i>!</i><div>${esc(r&&r.message||'Không kiểm tra được.')}</div></div>`;return;}
      const v=r.verdict||{tone:'warn',title:'',detail:''};
      const ico=v.tone==='ok'?'✓':v.tone==='bad'?'✕':'!';
      out.innerHTML=`<div class="ck-verdict ${esc(v.tone)}"><i>${ico}</i><div>${esc(v.title)}<br><span>${esc(v.detail)}</span></div></div><div class="ck-grid2"><div class="ck-card"><h5>THÔNG TIN ĐƠN NẠP <em>tra từ BO</em></h5>${rowsHTML(r.left)}</div><div class="ck-card"><h5>KÊNH NẠP</h5>${rowsHTML(r.right)}</div></div><div class="ck-card"><h5>TIỀN &amp; PHÍ NHÀ THỨ 3 <em>phí lấy từ BO</em></h5>${rowsHTML(r.money)}</div><div class="ck-card"><h5>THÔNG TIN KHÁCH</h5>${rowsHTML(r.extra)}</div>`;
    };
    let busy=false;
    const run=async()=>{
      if(busy)return;
      const bot=window.AD88_XNK_BOT;
      if(!bot||typeof bot.checkDeposit!=='function'){render({ok:false,message:'Tool chưa sẵn sàng, hãy tải lại trang BO rồi thử lại.'});return;}
      busy=true;go.disabled=true;go.textContent='ĐANG KIỂM TRA…';out.innerHTML='<div class="ck-hint">Đang tra đơn nạp trên BO…</div>';
      try{render(await bot.checkDeposit(input.value));}catch(e){render({ok:false,message:String(e&&e.message||e)});}
      busy=false;go.disabled=false;go.textContent='KIỂM TRA';
    };
    go.onclick=run;input.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();run();}};
    setTimeout(()=>{try{input.focus();}catch(_){}} ,50);
  }
  // ===== 1.4.184: tab "CHECK TÊN TK" (lịch sử nạp của một tài khoản thành viên; chỉ đọc; gọi window.AD88_XNK_BOT.checkAccount) =====
  function renderAccountCheck(el){
    if(checkLockedGate(el))return;
    const rowsHTML=(arr)=>(arr||[]).map(r=>`<div class="ck-row"><span>${esc(r[0])}</span><b class="${r[2]==='warn'?'ck-warn':r[2]==='ok'?'ck-ok':r[2]==='bad'?'ck-bad':''}">${esc(r[1])}</b></div>`).join('');
    el.innerHTML=`<div class="ad88-log-page ck-page"><div class="ad88-log-page-head"><div class="ad88-log-title"><span>▣</span><div><b>NHẬT KÝ XỬ LÝ ĐƠN</b><small>Kiểm tra lịch sử nạp theo tên tài khoản</small></div></div><button class="ad88-log-home" type="button" data-back="1">← QUAY LẠI GIAO DIỆN TRANG CHỦ</button></div>${ckTabsHTML('acct')}
      <div class="ck-search"><input id="ck-input" type="text" autocomplete="off" placeholder="Nhập tên tài khoản thành viên"><button type="button" id="ck-go">KIỂM TRA</button></div>
      <div class="ck-range"><span>Lịch sử:</span><button type="button" data-days="31" class="on">1 tháng</button><button type="button" data-days="90">3 tháng</button><button type="button" data-days="180">6 tháng</button></div>
      <div id="ck-out"><div class="ck-hint">Nhập tên tài khoản thành viên rồi bấm KIỂM TRA. Tool lấy lịch sử nạp 1 tháng gần nhất (chọn 3 hoặc 6 tháng nếu muốn xem lâu hơn): khách đã nạp thành công bao nhiêu lần, tổng tiền, và từng lần nạp: giờ tạo, giờ thành công, số tiền, hạng mục, nhà thứ 3, tình trạng. Chỉ xem, không bấm/khóa/đổi đơn.</div></div></div>`;
    q('[data-back]',el).onclick=back;wireCkTabs(el);wireLogHeadDrag(el);wireCkScale(el);
    const input=q('#ck-input',el),go=q('#ck-go',el),out=q('#ck-out',el);ckHardenInput(input);
    let days=31;
    el.querySelectorAll('.ck-range [data-days]').forEach(b=>b.onclick=()=>{days=Number(b.dataset.days);el.querySelectorAll('.ck-range [data-days]').forEach(x=>x.classList.toggle('on',x===b));if(input.value.trim())run();});
    const dt=(v)=>{const m=String(v||'').match(/^(\d{4}-\d\d-\d\d) (\d\d:\d\d:\d\d)$/);return m?`${esc(m[1])}<span class="ck-sp"> </span><br>${esc(m[2])}`:esc(v||'—');};
    const tbl=(rows)=>`<div class="ck-trow ck-thead"><span>#</span><span>Tạo lúc</span><span>Thành công lúc</span><span class="r">Số tiền</span><span>Hạng mục · nhà</span><span>Tình trạng</span></div>`+(rows||[]).map(r=>`<div class="ck-trow"><span>${r.no}</span><span>${dt(r.created)}</span><span>${dt(r.done)}</span><span class="r"><b>${r.vnd?esc(Number(r.vnd).toLocaleString('en-US')):esc(String(r.amount))}</b>${r.first?'<i class="ck-tag def">NẠP ĐẦU</i>':''}</span><span>${esc(r.cat)} · ${esc(r.prov)}</span><span class="${r.tone==='ok'?'ck-ok':r.tone==='bad'?'ck-bad':r.tone==='warn'?'ck-warn':''}">${esc(r.status)}</span></div>`).join('');
    const render=(r)=>{
      if(!r||r.ok===false){out.innerHTML=`<div class="ck-verdict warn"><i>!</i><div>${esc(r&&r.message||'Không kiểm tra được.')}</div></div>`;return;}
      const v=r.verdict||{tone:'warn',title:'',detail:''};
      const ico=v.tone==='ok'?'✓':v.tone==='bad'?'✕':'!';
      const warns=(r.warns||[]).map(w=>`<div class="ck-verdict warn"><i>!</i><div>${esc(w)}</div></div>`).join('');
      out.innerHTML=`<div class="ck-verdict ${esc(v.tone)}"><i>${ico}</i><div>${esc(v.title)}<br><span>${esc(v.detail)}</span></div></div>${warns}${r.summary&&r.summary.length?`<div class="ck-card"><h5>THÔNG TIN KHÁCH <em>${esc(r.account)}</em></h5>${rowsHTML(r.summary)}</div><div class="ck-card"><h5>CÁC LẦN NẠP <em>${r.count} đơn · mới nhất ở trên</em></h5><div class="ck-tbl">${tbl(r.rows)}</div></div>`:''}`;
    };
    let busy=false;
    const run=async()=>{
      if(busy)return;
      const bot=window.AD88_XNK_BOT;
      if(!bot||typeof bot.checkAccount!=='function'){render({ok:false,message:'Tool chưa sẵn sàng, hãy tải lại trang BO rồi thử lại.'});return;}
      busy=true;go.disabled=true;go.textContent='ĐANG KIỂM TRA…';out.innerHTML='<div class="ck-hint">Đang đọc lịch sử nạp trên BO…</div>';
      try{render(await bot.checkAccount(input.value,{days}));}catch(e){render({ok:false,message:String(e&&e.message||e)});}
      busy=false;go.disabled=false;go.textContent='KIỂM TRA';
    };
    go.onclick=run;input.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();run();}};
    setTimeout(()=>{try{input.focus();}catch(_){}} ,50);
  }
  function renderLog(el){
    if(checkLockedGate(el))return;
    const root=q('#ad88-xnk-tool-root');
    if(!root) return;
    const st=window.AD88_XNK_BOT?.status?.()||{};
    const logs=Array.isArray(st.orderLogs)?st.orderLogs:[];
    const range=getSavedLogRange();
    const filtered=filterLogsByRange(logs,range.from,range.to).filter(x=>x.state==='DONE'||x.state==='RETURN').slice().sort((a,b)=>(Number(b.timestamp)||0)-(Number(a.timestamp)||0));
    const fmtDateTime=x=>`${esc(x.date||'—')} ${esc(x.time||'—')}`;
    const amountText=x=>x.amount!=null?`${Number(x.amount).toLocaleString('vi-VN')} ${esc(x.currency||'')}`:'—';
    const statusMeta=x=>{
      if(x.state==='DONE') return ['success','✓','Thành công'];
      if(x.state==='RETURN') return ['return','↶','Trả lại'];
      return ['return','↶','Trả lại'];
    };
    const pageSize=10;
    let page=1;
    const totalPages=Math.max(1,Math.ceil(filtered.length/pageSize));

    el.innerHTML=`<div class="ad88-log-page">
      <div class="ad88-log-page-head"><div class="ad88-log-title"><span>▣</span><div><b>NHẬT KÝ XỬ LÝ ĐƠN</b><small>Theo dõi toàn bộ hoạt động xử lý đơn của tool</small></div></div><button class="ad88-log-home" type="button" data-back="1">← QUAY LẠI GIAO DIỆN TRANG CHỦ</button></div>
      <div class="ad88-log-filter ad88-log-filter-pro"><div class="ad88-log-quick"><button type="button" id="log-today">Hôm nay</button><button type="button" id="log-yesterday">Hôm qua</button><button type="button" id="log-7days">7 ngày</button><button type="button" id="log-30days">30 ngày</button><button type="button" id="log-custom">Chọn thời gian</button></div><div class="ad88-log-date-row"><label><span>TỪ NGÀY</span><input id="log-from" type="datetime-local" value="${esc(range.from)}"></label><label><span>ĐẾN NGÀY</span><input id="log-to" type="datetime-local" value="${esc(range.to)}"></label><button type="button" id="log-apply" class="primary">⌕ ÁP DỤNG</button><button type="button" id="download-order-log" class="excel" ${filtered.length?'':'disabled'}>▣ XUẤT EXCEL</button></div></div>
      <section class="ad88-log-table-card ad88-log-table-card-full"><div class="ad88-log-table-head"><div><b>▣ DANH SÁCH NHẬT KÝ XỬ LÝ ĐƠN</b><span>Hiển thị ${filtered.length.toLocaleString('vi-VN')} dòng</span></div><span>${esc(range.from.replace('T',' '))} → ${esc(range.to.replace('T',' '))}</span></div><div class="ad88-log-table-scroll"><table class="ad88-log-table"><thead><tr><th>STT</th><th>THỜI GIAN</th><th>MÃ ĐƠN</th><th>SỐ TIỀN VND</th><th>USDT</th><th>NHÀ THỨ 3</th><th>NGƯỜI THAO TÁC</th><th>TRẠNG THÁI</th><th>LÝ DO</th></tr></thead><tbody id="ad88-log-tbody"></tbody></table></div><div class="ad88-log-pagination" id="ad88-log-pagination"></div></section>
    </div>`;

    const tbody=q('#ad88-log-tbody',el), pager=q('#ad88-log-pagination',el);
    const renderTable=()=>{
      const start=(page-1)*pageSize, rows=filtered.slice(start,start+pageSize);
      tbody.innerHTML=rows.length?rows.map((x,i)=>{const [tone,icon,label]=statusMeta(x);const isUsdt=x.currency==='USDT';const vndText=!isUsdt&&x.amount!=null?`${Number(x.amount).toLocaleString('vi-VN')} VND`:'—';const usdtText=isUsdt&&x.amount!=null?`${Number(x.amount).toLocaleString('en-US',{maximumFractionDigits:8})} USDT`:'—';return `<tr data-log-index="${start+i}"><td>${start+i+1}</td><td>${fmtDateTime(x)}</td><td class="order-no">${esc(x.order||'—')}</td><td class="amount">${vndText}</td><td class="amount ${isUsdt?'usdt':''}">${usdtText}</td><td>${esc(x.provider||'—')}</td><td>${esc(x.operator||'—')}</td><td><b class="log-status ${tone}">${icon} ${label}</b></td><td class="log-reason-cell">${x.state==='RETURN'?esc(x.reason||'—'):'—'}</td></tr>`}).join(''):`<tr><td colspan="9"><div class="ad88-log-empty">Không có đơn trong khoảng thời gian đã chọn.</div></td></tr>`;
      const nums=Array.from({length:Math.min(totalPages,7)},(_,i)=>i+1).map(p=>`<button type="button" class="${page===p?'active':''}" data-journal-page="${p}">${p}</button>`).join('');
      pager.innerHTML=`<span>Hiển thị <b>${pageSize}</b> dòng/trang</span><div><button type="button" data-journal-page="prev" aria-label="Trang trước">‹</button>${nums}${totalPages>7?`<i>…</i><button type="button" data-journal-page="${totalPages}">${totalPages}</button>`:''}<button type="button" data-journal-page="next" aria-label="Trang sau">›</button></div><span>Trang ${page} / ${totalPages} (Tổng: ${filtered.length.toLocaleString('vi-VN')} dòng)</span>`;
      pager.querySelectorAll('[data-journal-page]').forEach(b=>b.onclick=e=>{
        e.preventDefault();
        e.stopPropagation();
        const action=b.dataset.journalPage;
        const p=action==='next'?Math.min(totalPages,page+1):action==='prev'?Math.max(1,page-1):Number(action);
        if(p>=1&&p<=totalPages&&p!==page){page=p;renderTable();}
      });
    };
    renderTable();
    q('[data-back]',el).onclick=back;
    try{const hd=q('.ad88-log-page-head',el);if(hd&&!q('.ck-tabs',el)){hd.insertAdjacentHTML('afterend',ckTabsHTML('log'));wireCkTabs(el);}wireCkScale(el);}catch(_){}
    const from=q('#log-from',el),to=q('#log-to',el);
    const apply=()=>{if(!from?.value||!to?.value)return;const a=new Date(from.value).getTime(),b=new Date(to.value).getTime();if(!Number.isFinite(a)||!Number.isFinite(b)||a>b){showToast('Khoảng thời gian không hợp lệ');return;}saveLogRange(from.value,to.value);renderLog(el);};
    q('#log-apply',el).onclick=apply;
    q('#log-today',el).onclick=()=>{setQuickLogRange('today');renderLog(el);};
    q('#log-yesterday',el).onclick=()=>{setQuickLogRange('yesterday');renderLog(el);};
    q('#log-7days',el).onclick=()=>{const now=new Date(),start=new Date(now);start.setDate(start.getDate()-6);start.setHours(0,0,0,0);saveLogRange(localDateTimeValue(start),localDateTimeValue(now));renderLog(el);};
    q('#log-30days',el).onclick=()=>{const now=new Date(),start=new Date(now);start.setDate(start.getDate()-29);start.setHours(0,0,0,0);saveLogRange(localDateTimeValue(start),localDateTimeValue(now));renderLog(el);};
    q('#log-custom',el).onclick=()=>from?.focus();
    const dl=q('#download-order-log',el);if(dl)dl.onclick=()=>downloadOrderLogCsv(filtered);

    // Journal-only drag: use the desktop mouse events on the actual journal header.
    // This intentionally does NOT touch the global Tool/root drag handlers.
    const logHead=q('.ad88-log-page-head',el);
    if(logHead){
      let drag=null;
      const moveDrag=e=>{
        if(!drag)return;
        const dx=e.clientX-drag.sx,dy=e.clientY-drag.sy;
        if(Math.abs(dx)+Math.abs(dy)>3)drag.moved=true;
        if(!drag.moved)return;
        const r=root.getBoundingClientRect();
        const x=Math.max(4,Math.min(drag.x+dx,window.innerWidth-r.width-4));
        const y=Math.max(4,Math.min(drag.y+dy,window.innerHeight-r.height-4));
        root.style.left=x+'px';root.style.top=y+'px';root.style.right='auto';root.style.bottom='auto';
        e.preventDefault();
      };
      const stopDrag=()=>{
        if(!drag)return;
        if(drag.moved) savePosition(root,true);
        drag=null;
        document.removeEventListener('mousemove',moveDrag);
        document.removeEventListener('mouseup',stopDrag);
      };
      logHead.addEventListener('mousedown',e=>{
        if(e.button!==0 || e.target.closest('button'))return;
        const r=root.getBoundingClientRect();
        drag={sx:e.clientX,sy:e.clientY,x:r.left,y:r.top,moved:false};
        document.addEventListener('mousemove',moveDrag);
        document.addEventListener('mouseup',stopDrag);
        e.preventDefault();
      });
    }
  }
  function renderAbout(el){el.innerHTML=head('Thông tin Tool')+`<div class="ad88-about"><b>AD88 XNK TOOL</b><p>Phát triển Tool kiểm tra đơn, số tài khoản ngân hàng và xử lý đơn trên bộ WG.</p><p>Phát triển bởi <b>Awei</b> dành riêng cho <b>AD88</b>.</p><p><b>Cấm sao chép, sao lưu, phân phối, chỉnh sửa hoặc sử dụng Tool dưới bất cứ hình thức nào ngoài AD88 khi chưa được Awei cho phép.</b></p><p>Cấu hình nhà thứ 3 cho phép bật/tắt từng cổng tự động. Tắt cổng nào thì Tool không tự chọn cổng đó.</p><small>Version ${AD88_VERSION}</small></div>`;q('[data-back]',el).onclick=back;}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',create);else create();
})();