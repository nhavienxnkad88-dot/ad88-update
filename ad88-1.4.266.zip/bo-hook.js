// AD88 XNK TOOL 1.4.265 — chạy trong trang BO (world MAIN, trước khi BO tải mã).
// CHỈ nghe lệnh thanh toán "auditPayout" mà CHÍNH TRANG gửi khi bấm "Xác nhận việc thanh toán": báo cho Tool biết
// BO ĐÃ GỬI lệnh chưa và BO trả lời gì (mã + câu ngắn). Không đọc gì khác, không gửi đi đâu ngoài chính trang.
(() => {
  if (window.__ad88BoHook) return;
  window.__ad88BoHook = true;
  const WANT = /\/withdrawCheck\/auditPayout/i;
  const post = o => { try { window.postMessage(Object.assign({ source: "ad88-bo" }, o), location.origin); } catch (_) {} };
  function parse(b) { let j = null; try { j = typeof b === "string" ? JSON.parse(b) : b; } catch (_) {} return j && typeof j === "object" ? j : null; }
  function res(status, body) {
    const j = parse(body);
    post({ kind: "payout-res", http: Number(status) || 0, code: j && j.code != null ? String(j.code) : "", msg: j ? String(j.msg || j.message || "").slice(0, 160) : "", at: Date.now() });
  }
  try {
    const XO = XMLHttpRequest.prototype.open, XS = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.open = function (m, url) { try { this.__ad88bu = String(url || ""); } catch (_) {} return XO.apply(this, arguments); };
    XMLHttpRequest.prototype.send = function () {
      try {
        if (WANT.test(this.__ad88bu || "")) {
          post({ kind: "payout-sent", at: Date.now() });
          this.addEventListener("loadend", () => {
            try { const rt = this.responseType; res(this.status, (rt === "" || rt === "text") ? this.responseText : (rt === "json" ? this.response : null)); } catch (_) { res(this.status, null); }
          });
        }
      } catch (_) {}
      return XS.apply(this, arguments);
    };
  } catch (_) {}
  try {
    const F = window.fetch;
    if (typeof F === "function") window.fetch = function (input) {
      const u = typeof input === "string" ? input : (input && (input.url || String(input))) || "";
      const hit = WANT.test(u);
      if (hit) post({ kind: "payout-sent", at: Date.now() });
      const p = F.apply(this, arguments);
      if (hit) p.then(r => { try { r.clone().text().then(t => res(r.status, t), () => res(r.status, null)); } catch (_) {} }, () => res(0, null));
      return p;
    };
  } catch (_) {}
  try { document.documentElement.setAttribute("data-ad88-bo-hook", "1"); } catch (_) {}
})();
