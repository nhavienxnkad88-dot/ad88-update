// AWEI AD88 XNK TOOL — background service worker
//  1) Gọi API Bank Check: ký HMAC + gọi mạng ở đây; chỉ chạy khi máy có License hợp lệ.
//     Khóa API lấy từ chrome.storage.local (Cài đặt → Khóa API Bank Check), không nằm trong mã nguồn.
//  2) Cập nhật: mở trang update.html và kiểm tra có bản mới (đọc version.json, kiểm tra chữ ký).
//  3) Bridge kiểm tra địa chỉ TRON (USDT TRC20).
self.window = self; // các tệp khóa công khai gán vào window.*
importScripts('src/api-constants.js', 'src/hmac.js', 'src/license-verify.js', 'license-public-key.js', 'license-revoked.js',
              'src/update-core.js', 'update-config.js', 'update-public-key.js');
try { importScripts('api-keys.js'); } catch (e) { /* máy cài từ bản cũ chưa có api-keys.js: vẫn chạy, dùng khóa trong storage */ }

function ad88NewNonce() {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) return crypto.randomUUID();
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
    const r = Math.random() * 16 | 0;
    return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
  });
}

// ---------- License theo máy ----------
async function ad88DeviceCode() {
  const d = await chrome.storage.local.get([AD88_STORAGE_DEVICE]);
  const cur = ad88NormalizeDeviceCode(d[AD88_STORAGE_DEVICE]);
  if (cur) return cur;
  const fresh = ad88GenerateDeviceCode();
  await chrome.storage.local.set({ [AD88_STORAGE_DEVICE]: fresh });
  return fresh;
}
async function ad88LicenseCheck() {
  const deviceCode = await ad88DeviceCode();
  const st = await chrome.storage.local.get([AD88_STORAGE_LICENSE_TOKEN]);
  const res = await ad88VerifyLicense({
    token: st[AD88_STORAGE_LICENSE_TOKEN], deviceCode, nowSec: Math.floor(Date.now() / 1000),
    publicKeyJwk: self.AD88_LICENSE_PUBLIC_KEY || null,
    revokedIds: Array.isArray(self.AD88_LICENSE_REVOKED) ? self.AD88_LICENSE_REVOKED.map(x => String(x).toLowerCase()) : []
  });
  return { ok: res.ok, code: res.code, message: res.message, deviceCode, info: res.info };
}

// ---------- Bank Check ----------
async function ad88BankApi(message) {
  const url = String(message && message.url || '');
  if (url !== AD88_API_BANKING_URL) return { ok: false, bridgeError: true, message: 'URL không được phép.' };
  const body = message.body;
  if (!body || typeof body !== 'object') return { ok: false, bridgeError: true, message: 'Body không hợp lệ.' };

  const lic = await ad88LicenseCheck();
  if (!lic.ok) {
    return { ok: false, licenseError: true, licenseRequired: true,
      message: (lic.message || 'Chưa có License hợp lệ.') + ' Vào Cài đặt → Mở khóa Key để kích hoạt.' };
  }
  const keys = await chrome.storage.local.get([AD88_STORAGE_LICENSE, AD88_STORAGE_SECRET]);
  const built = self.AD88_BUILTIN_API_KEYS || {};
  const licenseKey = String(keys[AD88_STORAGE_LICENSE] || built.license || '').trim();
  const secretKey = String(keys[AD88_STORAGE_SECRET] || built.secret || '').trim();
  if (!licenseKey || !secretKey) {
    return { ok: false, licenseError: true, keyMissing: true,
      message: 'Chưa nhập License Key / Secret Key của API Bank Check. Vào Cài đặt → Khóa API Bank Check để nhập.' };
  }

  let timeoutId = null, controller = null;
  try {
    const timestamp = Math.floor(Date.now() / 1000).toString();
    const nonce = ad88NewNonce();
    const rawBody = JSON.stringify(body);
    const signature = hmacSha256(secretKey, `${timestamp}.${nonce}.${rawBody}`);
    const timeoutMs = Number(message.timeoutMs);
    if (Number.isFinite(timeoutMs) && timeoutMs > 0) {
      controller = new AbortController();
      timeoutId = setTimeout(() => controller.abort(), timeoutMs);
    }
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-License-Key': licenseKey, 'X-Timestamp': timestamp, 'X-Nonce': nonce, 'X-Signature': signature },
      body: rawBody,
      signal: controller ? controller.signal : undefined
    });
    if (timeoutId) clearTimeout(timeoutId);
    const result = await response.json().catch(() => null);
    if (response.status === 401 || response.status === 409) {
      return { ok: false, licenseError: true, status: response.status, message: (result && result.message) || 'License Key hoặc Secret Key không hợp lệ.' };
    }
    if (!response.ok) {
      return { ok: false, licenseError: false, status: response.status, result, message: (result && result.message) || 'Không thể kết nối máy chủ.' };
    }
    return { ok: true, status: response.status, result };
  } catch (err) {
    if (timeoutId) clearTimeout(timeoutId);
    const timedOut = !!(err && err.name === 'AbortError');
    return { ok: false, timeout: timedOut, bridgeError: !timedOut, message: timedOut ? 'Bank Checker phản hồi quá chậm.' : 'Không thể kết nối máy chủ.' };
  }
}

// ---------- Cập nhật ----------
async function ad88CheckUpdate() {
  const running = chrome.runtime.getManifest().version;
  try {
    const r = await fetch(AD88_UPDATE_BASE_URL + 'version.json?t=' + Date.now(), { cache: 'no-store' });
    if (!r.ok) return { ok: false, running, message: 'Không tải được version.json (' + r.status + ').' };
    const info = await r.json();
    const v = await AD88UpdateCore.verifyInfo(info, self.AD88_UPDATE_PUBLIC_KEY);
    if (!v.ok) return { ok: false, running, message: v.message };
    const cmp = AD88UpdateCore.compareVersions(info.version, running);
    return { ok: true, running, available: cmp > 0, version: info.version, notes: String(info.notes || '').slice(0, 500) };
  } catch (e) { return { ok: false, running, message: 'Không kiểm tra được bản mới: ' + String(e && e.message || e) }; }
}

function ad88FromOurPage(sender) {
  return !!(sender && sender.id === chrome.runtime.id && typeof sender.url === 'string' &&
    sender.url.startsWith(AD88_ALLOWED_PAGE_ORIGIN + '/'));
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message) return;
  const type = message.type;

  // 1.4.232: TỰ CỨU KHI "Ối, hỏng" — nhịp tim từ tab BO.
  if (type === 'AD88_TAB_BEAT' || type === 'AD88_TAB_RESUME_Q') {
    if (!ad88FromOurPage(sender) || !sender.tab || sender.tab.id == null) { sendResponse({ ok: false }); return; }
    const tabId = sender.tab.id;
    if (type === 'AD88_TAB_BEAT') {
      ad88TabWatch.beat(tabId, !!message.running, !!message.page).then(() => sendResponse({ ok: true }), () => sendResponse({ ok: false }));
    } else {
      ad88TabWatch.takeResume(tabId).then(resume => sendResponse({ ok: true, resume }), () => sendResponse({ ok: true, resume: false }));
    }
    return true;
  }

  if (type === 'AD88_BANK_API' || type === 'AD88_CHECK_UPDATE' || type === 'AD88_OPEN_UPDATE') {
    if (!ad88FromOurPage(sender)) { sendResponse({ ok: false, bridgeError: true, message: 'Nguồn gọi không hợp lệ.' }); return; }
    if (type === 'AD88_OPEN_UPDATE') {
      chrome.tabs.create({ url: chrome.runtime.getURL('update.html' + (message.auto ? '?auto=1' : '')) })
        .then(() => sendResponse({ ok: true }), e => sendResponse({ ok: false, message: String(e && e.message || e) }));
      return true;
    }
    const job = type === 'AD88_BANK_API' ? ad88BankApi(message) : ad88CheckUpdate();
    job.then(sendResponse, e => sendResponse({ ok: false, bridgeError: true, message: String(e && e.message || e) }));
    return true;
  }

  if (type === 'AD88_API_KEY_STATE') {
    if (!ad88FromOurPage(sender)) { sendResponse({ ok: false }); return; }
    const b = self.AD88_BUILTIN_API_KEYS || {};
    const builtin = !!(String(b.license || '').trim() && String(b.secret || '').trim());
    chrome.storage.local.get([AD88_STORAGE_LICENSE, AD88_STORAGE_SECRET]).then(k => {
      const stored = !!(String(k[AD88_STORAGE_LICENSE] || '').trim() && String(k[AD88_STORAGE_SECRET] || '').trim());
      sendResponse({ ok: true, builtin, stored, ready: builtin || stored });
    }, () => sendResponse({ ok: true, builtin, stored: false, ready: builtin }));
    return true;
  }

  if (type === 'AD88_VALIDATE_TRON_ADDRESS') {
    (async () => {
      try {
        const headers = {'Content-Type':'application/json'};
        if (message.apiKey) headers['TRON-PRO-API-KEY'] = String(message.apiKey);
        const r = await fetch('https://api.trongrid.io/wallet/validateaddress', {
          method:'POST', headers,
          body:JSON.stringify({address:String(message.address||'').trim(),visible:true})
        });
        const data = await r.json().catch(() => null);
        sendResponse({ok:r.ok,httpStatus:r.status,data});
      } catch (e) {
        sendResponse({ok:false,networkError:true,error:String(e?.message||e)});
      }
    })();
    return true;
  }
});


// ===== 1.4.232: TỰ CỨU KHI TAB BO SẬP ("Ối, hỏng") HOẶC ĐỨNG HẲN =====
// Tab BO gửi nhịp tim 20 giây/lần. Tool đang ở chế độ CHẠY mà quá 3 phút không có nhịp → tab đã sập / treo / bị Chrome đóng
// → tự tải lại đúng tab đó và đánh dấu "tự chạy lại". Bấm Dừng thì không đụng. Tối đa 1 lần/3 phút, 6 lần/giờ cho mỗi tab.
const ad88TabWatch = (() => {
  const KEY = 'AD88_TAB_WATCH';
  const NO_BEAT_MS = 3 * 60 * 1000;
  const area = (chrome.storage && chrome.storage.session) ? chrome.storage.session : chrome.storage.local;
  async function read() { try { const o = await area.get(KEY); return (o && o[KEY]) || {}; } catch (_) { return {}; } }
  async function write(v) { try { await area.set({ [KEY]: v }); } catch (_) {} }
  async function beat(tabId, running, page) {
    const st = await read();
    const prev = st[tabId] || {};
    st[tabId] = { ...prev, t: Date.now(), running: !!(running && page) };
    await write(st);
    if (!prev.noDiscard) {
      try { await chrome.tabs.update(tabId, { autoDiscardable: false }); st[tabId].noDiscard = true; await write(st); } catch (_) {}
    }
  }
  async function takeResume(tabId) {
    const st = await read();
    const e = st[tabId];
    if (!e || !e.healAt || Date.now() - e.healAt > 5 * 60 * 1000) return false;
    e.healAt = 0; e.t = Date.now(); await write(st);
    return true;
  }
  async function tick() {
    const st = await read();
    let changed = false;
    const now = Date.now();
    for (const id of Object.keys(st)) {
      const e = st[id];
      const tabId = Number(id);
      let tab = null;
      try { tab = await chrome.tabs.get(tabId); } catch (_) { tab = null; }
      if (!tab) { delete st[id]; changed = true; continue; }                 // tab đã đóng
      if (!e.running) continue;                                               // Tool đang Dừng → không đụng
      if (typeof tab.url === 'string' && tab.url && !tab.url.startsWith(AD88_ALLOWED_PAGE_ORIGIN + '/')) { delete st[id]; changed = true; continue; }
      const silent = now - Number(e.t || 0);
      if (silent < NO_BEAT_MS && !tab.discarded) continue;
      const hist = (e.heals || []).filter(x => now - x < 3600 * 1000);
      if (hist.length && now - hist[hist.length - 1] < 3 * 60 * 1000) continue;
      if (hist.length >= 6) continue;
      try {
        await chrome.tabs.reload(tabId);
        e.heals = hist.concat([now]); e.healAt = now; e.t = now;
        changed = true;
        console.warn('[AD88] TỰ CỨU: tab BO không còn nhịp ' + Math.round(silent / 1000) + ' giây' + (tab.discarded ? ' (bị Chrome đóng tạm)' : '') + ' → đã tải lại tab');
      } catch (_) {}
    }
    if (changed) await write(st);
  }
  try {
    chrome.alarms.create('ad88-tab-watch', { periodInMinutes: 1 });
    chrome.alarms.onAlarm.addListener(a => { if (a && a.name === 'ad88-tab-watch') tick().catch(() => {}); });
  } catch (_) {}
  return { beat, takeResume, tick, NO_BEAT_MS };
})();


// ===== 1.4.252: GIỮ ĐĂNG NHẬP TAB NGÂN HÀNG =====
// Bật trong Cài đặt → Check Bank → "Giữ đăng nhập ngân hàng". Cứ 3 phút tải lại (F5) các tab web ngân hàng
// VietinBank / MB Bank / TPBank đang mở để không bị tự đăng xuất. Chỉ tải lại trang: không đọc, không điền gì trên trang ngân hàng.
// Nhân viên đang thao tác ngay trên tab ngân hàng (tab đang mở trước mặt + vừa dùng chuột/bàn phím) → bỏ qua lượt đó.
const ad88BankKeep = (() => {
  const ON_KEY = 'AD88_BANK_KEEP_ON';
  const LAST_KEY = 'AD88_BANK_KEEP_LAST';
  const ALARM = 'ad88-bank-keep';
  const EVERY_MIN = 3;
  const BANKS = [
    { name: 'VietinBank', pattern: 'https://*.vietinbank.vn/*', re: /(^|\.)vietinbank\.vn$/i },
    { name: 'MB Bank', pattern: 'https://*.mbbank.com.vn/*', re: /(^|\.)mbbank\.com\.vn$/i },
    { name: 'TPBank', pattern: 'https://*.tpb.vn/*', re: /(^|\.)tpb\.vn$/i }
  ];
  const area = (chrome.storage && chrome.storage.session) ? chrome.storage.session : chrome.storage.local;
  async function isOn() { try { const o = await chrome.storage.local.get(ON_KEY); return !!o[ON_KEY]; } catch (_) { return false; } }
  async function readLast() { try { const o = await area.get(LAST_KEY); return (o && o[LAST_KEY]) || {}; } catch (_) { return {}; } }
  async function writeLast(v) { try { await area.set({ [LAST_KEY]: v }); } catch (_) {} }
  function bankOf(url) { try { const h = new URL(url).hostname; const b = BANKS.find(x => x.re.test(h)); return b ? b.name : ''; } catch (_) { return ''; } }
  async function findTabs() {
    try { return (await chrome.tabs.query({ url: BANKS.map(b => b.pattern) })).filter(t => t && t.id != null && bankOf(t.url || '')); }
    catch (_) { return []; }
  }
  async function userOnTab(tab) {
    if (!tab.active) return false;
    let focused = false;
    try { const w = await chrome.windows.get(tab.windowId); focused = !!(w && w.focused); } catch (_) {}
    if (!focused) return false;
    try { return (await chrome.idle.queryState(60)) === 'active'; } catch (_) { return true; }
  }
  async function ensureAlarm(on) {
    try {
      const a = await chrome.alarms.get(ALARM);
      if (on && !a) chrome.alarms.create(ALARM, { periodInMinutes: EVERY_MIN });
      if (!on && a) await chrome.alarms.clear(ALARM);
    } catch (_) {}
  }
  async function tick(force) {
    if (!force && !(await isOn())) return { ok: true, skipped: true };
    const tabs = await findTabs();
    const last = await readLast();
    const now = Date.now();
    for (const t of tabs) {
      try { if (t.autoDiscardable !== false) await chrome.tabs.update(t.id, { autoDiscardable: false }); } catch (_) {}
      if (!force && await userOnTab(t)) { last[t.id] = { ...(last[t.id] || {}), wait: now }; continue; }
      if (typeof ad88BankWeb !== 'undefined' && ad88BankWeb.busy()) continue;   // 1.4.253: đang tra tên trên tab này → không F5 giữa chừng
      if (!force && t.status === 'loading' && !t.discarded) continue;
      try { await chrome.tabs.reload(t.id); last[t.id] = { at: now }; } catch (_) {}
    }
    for (const id of Object.keys(last)) if (!tabs.some(t => String(t.id) === id)) delete last[id];
    await writeLast(last);
    return { ok: true, count: tabs.length };
  }
  async function state() {
    const on = await isOn();
    const tabs = await findTabs();
    const last = await readLast();
    const bw = (typeof ad88BankWeb !== 'undefined') ? await ad88BankWeb.state(tabs) : null;
    return { ok: true, on, every: EVERY_MIN, bw, tabs: tabs.map(t => ({ bank: bankOf(t.url || ''), title: String(t.title || '').slice(0, 80), at: (last[t.id] || {}).at || 0, wait: (last[t.id] || {}).wait || 0 })) };
  }
  async function setOn(on) {
    try { await chrome.storage.local.set({ [ON_KEY]: !!on }); } catch (_) {}
    await ensureAlarm(!!on);
    return state();
  }
  try {
    chrome.alarms.onAlarm.addListener(a => { if (a && a.name === ALARM) tick(false).catch(() => {}); });
    isOn().then(on => ensureAlarm(on));
  } catch (_) {}
  return { tick, state, setOn };
})();

// ===== 1.4.253: TỰ TRA TÊN NGƯỜI NHẬN TRÊN WEB VIETINBANK =====
// Check không ra tên (ngân hàng không trả tên) → tab BO hỏi ở đây → gửi sang tab VietinBank iPay đang đăng nhập
// (bankweb/vtb.js điền STK + chọn ngân hàng, đọc tên VietinBank trả về). Mỗi lần 1 đơn; đang tra thì không F5 tab ngân hàng.
const ad88BankWeb = (() => {
  const ON_KEY = 'AD88_BANKWEB_ON';
  const LAST_KEY = 'AD88_BANKWEB_LAST';
  const COUNT_KEY = 'AD88_BANKWEB_COUNT';      // 1.4.255: đếm ngầm lượt tra trên ngân hàng theo ngày (giữ 31 ngày)
  const TAB_URL = 'https://ipay.vietinbank.vn/*';
  function dayKey(t) { const d = new Date(t || Date.now()); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
  async function countOne(r) {
    try {
      const o = (await chrome.storage.local.get(COUNT_KEY))[COUNT_KEY] || {};
      const k = dayKey();
      const e = o[k] || { total: 0, found: 0, notFound: 0, failed: 0 };
      if (r && r.ok) { e.total++; if (r.found) e.found++; else if (r.notFound) e.notFound++; }
      else e.failed++;
      o[k] = e;
      const keep = Object.keys(o).sort().slice(-31); const out = {}; keep.forEach(x => { out[x] = o[x]; });
      await chrome.storage.local.set({ [COUNT_KEY]: out });
    } catch (_) {}
  }
  async function counts() {
    let o = {}; try { o = (await chrome.storage.local.get(COUNT_KEY))[COUNT_KEY] || {}; } catch (_) {}
    const z = { total: 0, found: 0, notFound: 0, failed: 0 };
    const today = o[dayKey()] || z, yest = o[dayKey(Date.now() - 864e5)] || z;
    let week = 0, month = 0;
    for (let i = 0; i < 31; i++) { const e = o[dayKey(Date.now() - i * 864e5)]; if (!e) continue; month += e.total; if (i < 7) week += e.total; }
    return { today, yesterday: yest.total, week, month };
  }
  let chain = Promise.resolve();
  let busyUntil = 0;
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  async function isOn() { try { const o = await chrome.storage.local.get(ON_KEY); return !!o[ON_KEY]; } catch (_) { return false; } }
  async function findTab() {
    let tabs = [];
    try { tabs = await chrome.tabs.query({ url: TAB_URL }); } catch (_) {}
    return tabs.find(t => !t.discarded && t.status === 'complete') || tabs.find(t => !t.discarded) || tabs[0] || null;
  }
  function send(tabId, msg, ms) {
    return new Promise(res => {
      let done = false;
      const tm = setTimeout(() => { if (!done) { done = true; res({ ok: false, reason: 'TIMEOUT' }); } }, ms);
      try {
        chrome.tabs.sendMessage(tabId, msg, r => {
          const e = chrome.runtime.lastError;
          if (done) return; done = true; clearTimeout(tm);
          res(e ? { ok: false, reason: 'NO_SCRIPT' } : (r || { ok: false, reason: 'NO_REPLY' }));
        });
      } catch (_) { if (!done) { done = true; clearTimeout(tm); res({ ok: false, reason: 'NO_SCRIPT' }); } }
    });
  }
  async function waitComplete(tabId, ms) {
    const end = Date.now() + ms;
    while (Date.now() < end) {
      try { const t = await chrome.tabs.get(tabId); if (t.status === 'complete') return true; } catch (_) { return false; }
      await sleep(300);
    }
    return false;
  }
  async function doLookup(req) {
    if (!(await isOn())) return { ok: false, reason: 'OFF' };
    const tab = await findTab();
    if (!tab) return { ok: false, reason: 'NO_TAB' };
    try { if (tab.autoDiscardable !== false) await chrome.tabs.update(tab.id, { autoDiscardable: false }); } catch (_) {}
    if (tab.discarded) { try { await chrome.tabs.reload(tab.id); } catch (_) {} await waitComplete(tab.id, 15000); await sleep(2000); }
    else if (tab.status !== 'complete') { await waitComplete(tab.id, 12000); await sleep(1500); }
    const msg = { type: 'AD88_BW_LOOKUP', account: String(req.account || ''), bin: String(req.bin || '') };
    let r = await send(tab.id, msg, 30000);
    if (r.reason === 'NO_SCRIPT') {            // trang vừa F5 → chờ tải xong rồi hỏi lại
      await waitComplete(tab.id, 12000); await sleep(2000);
      r = await send(tab.id, msg, 30000);
    }
    if (r.reason === 'NO_SCRIPT') {            // tab mở từ trước khi cập nhật Tool → tải lại 1 lần để gắn phần tra cứu
      try { await chrome.tabs.reload(tab.id); } catch (_) {}
      await waitComplete(tab.id, 15000); await sleep(2500);
      r = await send(tab.id, msg, 30000);
    }
    if (r.reason === 'NOT_TRANSFER_PAGE' && String(req.bin || '') !== '970415') {   // còn ở trang chủ → mở thẳng màn liên ngân hàng
      try { await chrome.tabs.update(tab.id, { url: 'https://ipay.vietinbank.vn/transfer/external' }); } catch (_) {}
      await sleep(800); await waitComplete(tab.id, 15000); await sleep(2500);
      r = await send(tab.id, msg, 30000);
    }
    try { await chrome.storage.local.set({ [LAST_KEY]: { at: Date.now(), ok: !!r.ok, found: !!r.found, notFound: !!r.notFound, reason: String(r.reason || '') } }); } catch (_) {}
    if (r.ok || !['OFF', 'NO_TAB', 'LOGGED_OUT', 'BANK_NOT_IN_LIST', 'NO_ACCOUNT', 'BUSY'].includes(String(r.reason || ''))) await countOne(r);
    return r;
  }
  function lookup(req) {
    const job = chain.then(() => { busyUntil = Date.now() + 90000; return doLookup(req); })
      .catch(e => ({ ok: false, reason: 'BG_ERROR', msg: String(e && e.message || e) }))
      .finally(() => { busyUntil = 0; });
    chain = job.then(() => sleep(300), () => {});    // giãn cách ngắn giữa 2 lần tra
    return job;
  }
  async function state(keepTabs) {
    const on = await isOn();
    let last = null; try { last = (await chrome.storage.local.get(LAST_KEY))[LAST_KEY] || null; } catch (_) {}
    const tab = await findTab();
    let tabState = 'NO_TAB';
    if (tab) {
      const p = await send(tab.id, { type: 'AD88_BW_PING' }, 1500);
      tabState = p.ok ? (p.loggedOut ? 'LOGGED_OUT' : (p.ready ? 'READY' : 'OPEN')) : 'NO_SCRIPT';
    }
    return { on, tabState, last, counts: await counts() };
  }
  async function setOn(on) { try { await chrome.storage.local.set({ [ON_KEY]: !!on }); } catch (_) {} return true; }
  return { lookup, state, setOn, busy: () => Date.now() < busyUntil };
})();

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || message.type !== 'AD88_BANKWEB_LOOKUP') return;
  if (!ad88FromOurPage(sender)) { sendResponse({ ok: false, reason: 'BAD_SENDER' }); return; }
  ad88BankWeb.lookup(message).then(sendResponse, () => sendResponse({ ok: false, reason: 'BG_ERROR' }));
  return true;
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || !/^AD88_BANK_KEEP_(STATE|SET|NOW)$|^AD88_BANKWEB_SET$/.test(String(message.type || ''))) return;
  if (!ad88FromOurPage(sender)) { sendResponse({ ok: false }); return; }
  if (message.type === 'AD88_BANKWEB_SET') { ad88BankWeb.setOn(!!message.on).then(() => ad88BankKeep.state()).then(sendResponse, () => sendResponse({ ok: false })); return true; }
  const job = message.type === 'AD88_BANK_KEEP_SET' ? ad88BankKeep.setOn(!!message.on)
    : message.type === 'AD88_BANK_KEEP_NOW' ? ad88BankKeep.tick(true).then(() => ad88BankKeep.state())
    : ad88BankKeep.state();
  job.then(sendResponse, () => sendResponse({ ok: false }));
  return true;
});
