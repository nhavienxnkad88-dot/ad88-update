// AD88 XNK TOOL — Provider Registry
// SINGLE SOURCE OF TRUTH cho nhà thứ 3.
// Khi thêm provider mới về sau: thêm 1 object vào AD88_PROVIDER_REGISTRY.
// Settings / toggle / MIN-MAX / currency / Core selection đều đọc từ registry này.
// Provider VND mới xuất hiện trực tiếp trong BO vẫn được Core nhận diện động; Registry chỉ là nơi chuẩn hóa alias/cấu hình cho nhà đã biết.
// Thứ tự mảng = thứ tự chuẩn hiển thị và thứ tự fallback VND.
// usdtPriority chỉ dùng cho USDT: số nhỏ hơn được ưu tiên trước.

const AD88_PROVIDER_REGISTRY = Object.freeze([
  { name:"V6Pay(VND)(二)", currency:"VND", min:50000, max:15000000, aliases:["V6Pay(VND)(二)","V6Pay(VND)","V6Pay"], usdtPriority:null },
  { name:"33Pay",    currency:"VND",  min:50000,    max:15000000,    aliases:["33Pay"], usdtPriority:null },
  { name:"RCPAY",    currency:"USDT", min:5,     max:1000,     aliases:["RCPAY","RCPay"], usdtPriority:20 },
  { name:"U2PAY",    currency:"USDT", min:5,     max:1000,     aliases:["U2PAY","U2Pay","U2Pay2"], usdtPriority:10 },
  { name:"VN196Pay", currency:"VND",  min:50000,    max:15000000,   aliases:["VN196Pay","196"], usdtPriority:null },
  { name:"FastPay",  currency:"VND",  min:50000,   max:15000000, aliases:["FastPay"], usdtPriority:null },
  { name:"GO-PAY",   currency:"VND",  min:50000, max:15000000,aliases:["GO-PAY","GoPay"], usdtPriority:null },
  { name:"VipPay",   currency:"VND",  min:50000,  max:15000000,aliases:["VipPay","VIPPay"], usdtPriority:null },
  { name:"PPPAY",    currency:"VND",  min:50000,  max:15000000,aliases:["PPPAY"], usdtPriority:null },
  { name:"OkPay",    currency:"VND",  min:50000,   max:15000000, aliases:["OkPay","OKPAY"], usdtPriority:null },
  { name:"A8Pay",    currency:"VND",  min:50000,   max:15000000, aliases:["A8Pay"], usdtPriority:null },
  { name:"BB168Pay", currency:"VND",  min:50000,     max:15000000,     aliases:["BB168Pay","BB168PAY","BB168 Pay"], usdtPriority:null },
  { name:"JYPay(VND)(二)", currency:"VND", min:50000, max:15000000, aliases:["JYPay(VND)(二)","JYPay"], usdtPriority:null },
  { name:"PaYoPay(VND)(二)", currency:"VND", min:50000, max:15000000, aliases:["PaYoPay(VND)(二)","PaYoPay(VND)","PaYoPay"], usdtPriority:null },
  { name:"888Pay", currency:"VND", min:50000, max:15000000, aliases:["888Pay","888PAY"], usdtPriority:null },
  { name:"WHPAY",    currency:"USDT", min:5,     max:1000,     aliases:["WHPAY","WHPay"], usdtPriority:30 }
]);

// MẶC ĐỊNH 1.4.129: mọi nhà thứ 3 đều BẬT; VND tối đa 15.000.000, USDT tối đa 1.000 USDT.
// Migration chạy 1 LẦN trên mỗi máy: bật lại 888Pay (trước đây bị tự tắt) và hạ mức MAX đang để
// trống/vượt trần về mặc định. Giá trị nhỏ hơn trần mà người vận hành đã tự đặt được giữ nguyên.
// Sau lần chạy này mọi chỉnh sửa của người vận hành được giữ, không bị ghi đè nữa.
const AD88_DEFAULT_MAX_VND = 15000000;
const AD88_DEFAULT_MAX_USDT = 1000;
try {
  if (localStorage.getItem("AD88_XNK_PROVIDER_DEFAULTS_V129") !== "1") {
    const rawT = localStorage.getItem("AD88_XNK_PROVIDER_TOGGLES");
    const st = rawT ? (JSON.parse(rawT) || {}) : {};
    st["888Pay"] = true;
    localStorage.setItem("AD88_XNK_PROVIDER_TOGGLES", JSON.stringify(st));
    const rawC = localStorage.getItem("AD88_XNK_PROVIDER_CONFIG");
    if (rawC) {
      const cfg = JSON.parse(rawC) || {};
      for (const key of Object.keys(cfg)) {
        const it = cfg[key]; if (!it || typeof it !== "object") continue;
        const cap = (it.currency === "USDT") ? AD88_DEFAULT_MAX_USDT : AD88_DEFAULT_MAX_VND;
        const m = (it.max === null || it.max === undefined || it.max === "") ? null : Number(it.max);
        if (m === null || !Number.isFinite(m) || m > cap) it.max = cap;
      }
      localStorage.setItem("AD88_XNK_PROVIDER_CONFIG", JSON.stringify(cfg));
    }
    localStorage.setItem("AD88_XNK_PROVIDER_DEFAULTS_V129", "1");
  }
} catch {}

// MẶC ĐỊNH 1.4.154: mọi nhà VND MIN 50.000 / MAX 15.000.000; mọi nhà USDT MIN 5 / MAX 1.000.
// Migration chạy 1 LẦN trên mỗi máy: đưa MIN/MAX đang lưu về mặc định mới. Sau đó mọi chỉnh sửa
// của người vận hành trong "Cài đặt số tiền bên thứ 3" được giữ nguyên, không bị ghi đè nữa.
const AD88_DEFAULT_MIN_VND = 50000;
const AD88_DEFAULT_MIN_USDT = 5;
try {
  if (localStorage.getItem("AD88_XNK_PROVIDER_DEFAULTS_V154") !== "1") {
    const rawC = localStorage.getItem("AD88_XNK_PROVIDER_CONFIG");
    if (rawC) {
      const cfg = JSON.parse(rawC) || {};
      for (const key of Object.keys(cfg)) {
        const it = cfg[key]; if (!it || typeof it !== "object") continue;
        const def = AD88_PROVIDER_REGISTRY.find(p => p.name === key);
        const usdt = (def ? def.currency : it.currency) === "USDT";
        it.min = usdt ? AD88_DEFAULT_MIN_USDT : AD88_DEFAULT_MIN_VND;
        it.max = usdt ? AD88_DEFAULT_MAX_USDT : AD88_DEFAULT_MAX_VND;
      }
      localStorage.setItem("AD88_XNK_PROVIDER_CONFIG", JSON.stringify(cfg));
    }
    localStorage.setItem("AD88_XNK_PROVIDER_DEFAULTS_V154", "1");
  }
} catch {}

function AD88_getProviderRegistry(){
  return AD88_PROVIDER_REGISTRY.map(p => ({...p, aliases:[...(p.aliases||[])]}));
}
function AD88_providerCanonical(name){
  const raw=String(name??"").trim();
  // BO có thể hiển thị provider kèm hậu tố currency, ví dụ:
  // "BB168Pay(VND)", "U2Pay(USDT)". Hậu tố này chỉ là cách BO
  // hiển thị loại tiền, không phải tên provider. Chuẩn hóa để Toggle,
  // MIN/MAX, alias và thống kê dùng cùng một provider key.
  const n=raw.toUpperCase()
    .replace(/\s+/g,"")
    .replace(/\((?:VND|USDT)\)$/i,"");
  const hit=AD88_PROVIDER_REGISTRY.find(p =>
    [p.name,...(p.aliases||[])].some(a=>String(a).toUpperCase().replace(/\s+/g,"")===n)
  );
  return hit ? hit.name : raw;
}
function AD88_providerDefinition(name){
  const key=AD88_providerCanonical(name);
  return AD88_PROVIDER_REGISTRY.find(p=>p.name===key)||null;
}
function AD88_providerNames(){
  return AD88_PROVIDER_REGISTRY.map(p=>p.name);
}
function AD88_providerFallback(){
  return AD88_PROVIDER_REGISTRY.map(({name,currency,min,max})=>({name,currency,min,max}));
}
function AD88_usdtProviders(){
  return AD88_PROVIDER_REGISTRY
    .filter(p=>p.currency==="USDT")
    .slice()
    .sort((a,b)=>(a.usdtPriority??9999)-(b.usdtPriority??9999));
}
