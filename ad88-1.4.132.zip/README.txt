AD88 XNK TOOL 1.4.132

CÀI LẦN ĐẦU (mỗi máy 1 lần)
1. Giải nén zip vào 1 thư mục cố định (ví dụ D:\AD88_TOOL). Đừng xóa thư mục này.
2. Chrome → chrome://extensions → bật "Chế độ nhà phát triển" → "Tải tiện ích đã giải nén" → chọn thư mục.
3. Nhập License máy (Cài đặt → Mở khóa Key) như bản 1.4.115. Khóa API Bank Check đã dựng sẵn trong tệp api-keys.js.

CẬP NHẬT VỀ SAU
Cài đặt → "Cập nhật Tool" → "Kiểm tra" → "Cập nhật". Lần đầu chọn đúng thư mục tool ở bước 1.
Nếu lỗi: bấm "Khôi phục bản trước".
api-keys.js không bao giờ bị bản cập nhật ghi đè hay đưa lên GitHub.
