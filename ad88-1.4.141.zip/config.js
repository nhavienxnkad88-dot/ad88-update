// Phiên bản chỉ lấy từ manifest.json (nguồn duy nhất).
const AD88_VERSION = (() => { try { return chrome.runtime.getManifest().version; } catch (e) { return "dev"; } })();

const XNK_CONFIG = {
  version: AD88_VERSION,
  mode: "LIVE",

  // Không khóa hàng loạt.
  // Một đơn phải hoàn tất rồi mới bắt đầu đơn kế tiếp.
  processOnlyOneAtATime: true,
  nextOrderDelayMs: 2200,
  // Đồng bộ tốc độ: Tool ưu tiên chờ theo trạng thái website thay vì sleep cố định.
  autoSync: true,
  pollMinMs: 100,
  pollMaxMs: 650,
  nextOrderDelayMinMs: 350,
  nextOrderDelayMaxMs: 3000,

  actionTimeoutMs: 8000,
  bankCheckTimeoutMs: 15000,

  // Kiểm tra địa chỉ USDT TRC20 trên TRON Mainnet.
  // Có thể điền API key TronGrid nếu tài khoản của bạn yêu cầu/quản lý quota.
  tron: {
    enabled: true,
    validateUrl: "https://api.trongrid.io/wallet/validateaddress",
    apiKey: ""
  },

  invalidUsdtNote:
    "ĐỊA CHỈ VÍ USDT TRC20 KHÔNG CHÍNH XÁC HOẶC KHÔNG HỢP LỆ. QUÝ KHÁCH VUI LÒNG LIÊN HỆ CSKH 24/7 ĐỂ ĐƯỢC HỖ TRỢ Ạ!!!",

  invalidUsdtErc20Note:
    "ĐỊA CHỈ VÍ USDT ERC20 KHÔNG CHÍNH XÁC HOẶC KHÔNG HỢP LỆ. QUÝ KHÁCH VUI LÒNG LIÊN HỆ CSKH 24/7 ĐỂ ĐƯỢC HỖ TRỢ Ạ!!!",

  invalidBankNote:
    "THÔNG TIN NGÂN HÀNG QUÝ KHÁCH LIÊN KẾT KHÔNG CHÍNH XÁC. QUÝ KHÁCH VUI LÒNG LIÊN HỆ CSKH 24/7 ĐỂ ĐƯỢC HỖ TRỢ Ạ!!!",

  // Khoảng tiền mặc định của các cổng. VND dùng số tiền thực tế; USDT dùng đúng số USDT.
  // 888Pay có trong Registry để hiển thị ở Bật/tắt, Thống kê và Nhật ký; mặc định BẬT (từ 1.4.129).
  providerFallback: AD88_providerFallback(),

  allowPaymentConfirm: true
};
