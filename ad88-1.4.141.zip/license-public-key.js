// AD88 XNK TOOL — khóa CÔNG KHAI để kiểm tra License Key.
// KHÔNG chứa private key. Có thể phát hành cùng extension.
window.AD88_LICENSE_PUBLIC_KEY = {"kty":"EC","crv":"P-256","x":"6JBur5D1U97uCR38b-id3AvsoQ4R1KW-vft7cFsNTlo","y":"P4KbempXaDSpLLlae4H7g0GBe0MfQ6pkY2IAsdW0zlo"};
