// AD88 XNK TOOL — giấy phép theo máy (OFFLINE), chữ ký số ECDSA P-256 / SHA-256.
// Chạy trong background.js (importScripts). Người cấp phép ký License Key bằng KHÓA RIÊNG (không nằm trong gói này);
// extension chỉ giữ KHÓA CÔNG KHAI (src/license-pubkey.js) nên không thể tự tạo key mới.
//
// Định dạng License Key:  AD88.<payload base64url>.<chữ ký base64url>
// payload JSON: { v:1, i:"mã giấy phép", d:"MÃ-MÁY", e:hạn(giây UNIX, 0 = vĩnh viễn), t:thời điểm cấp, n:"ghi chú" }
// Chữ ký (64 byte, IEEE-P1363) ký trên đúng chuỗi payload base64url.
const AD88_LICENSE_PREFIX = "AD88.";
const AD88_DEVICE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // 32 ký tự, bỏ I O 0 1 cho dễ đọc
const AD88_CLOCK_TOLERANCE_SEC = 86400;                          // cho phép lệch đồng hồ 1 ngày

function ad88B64uEncode(bytes) {
  let s = "";
  for (let i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]);
  return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
function ad88B64uDecode(str) {
  const v = String(str || "");
  if (!/^[A-Za-z0-9_-]+$/.test(v)) throw new Error("base64url không hợp lệ");
  const s = v.replace(/-/g, "+").replace(/_/g, "/") + "=".repeat((4 - v.length % 4) % 4);
  const bin = atob(s);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

// "abcd efgh-jklm npqr" → "ABCD-EFGH-JKLM-NPQR"; sai định dạng → "".
function ad88NormalizeDeviceCode(input) {
  const s = String(input || "").toUpperCase().replace(/[^A-Z0-9]/g, "");
  if (s.length !== 16) return "";
  for (const ch of s) if (AD88_DEVICE_ALPHABET.indexOf(ch) < 0) return "";
  return `${s.slice(0, 4)}-${s.slice(4, 8)}-${s.slice(8, 12)}-${s.slice(12, 16)}`;
}
function ad88GenerateDeviceCode() {
  const bytes = crypto.getRandomValues(new Uint8Array(16));
  let s = "";
  for (let i = 0; i < 16; i++) s += AD88_DEVICE_ALPHABET[bytes[i] & 31];
  return ad88NormalizeDeviceCode(s);
}

function ad88LicenseResult(ok, code, message, info) {
  return { ok, code, message, info: info || null };
}

// Kiểm tra License Key. Tham số tách riêng (không đọc storage/đồng hồ trực tiếp) để dễ kiểm thử.
// lastSeen = { id, t } mốc thời gian lớn nhất đã thấy khi giấy phép CÓ HẠN mang mã `id` còn hiệu lực (hoặc null).
// Chỉ dùng để phát hiện chỉnh lùi đồng hồ cho đúng giấy phép đó; giấy phép vĩnh viễn hoặc mã khác không bị ảnh hưởng.
async function ad88VerifyLicense({ token, deviceCode, nowSec, publicKeyJwk, revokedIds }) {
  const R = ad88LicenseResult;
  if (!publicKeyJwk || !publicKeyJwk.x || !publicKeyJwk.y)
    return R(false, "NO_PUBKEY", "Gói tool chưa được cấu hình khóa công khai (src/license-pubkey.js).");
  if (typeof crypto === "undefined" || !crypto.subtle)
    return R(false, "NO_CRYPTO", "Trình duyệt không hỗ trợ WebCrypto để kiểm tra giấy phép.");
  const t = String(token || "").replace(/\s+/g, "");
  if (!t) return R(false, "NO_KEY", "Chưa kích hoạt giấy phép.");
  if (!t.startsWith(AD88_LICENSE_PREFIX)) return R(false, "BAD_FORMAT", "License Key không đúng định dạng.");
  const parts = t.slice(AD88_LICENSE_PREFIX.length).split(".");
  if (parts.length !== 2 || !parts[0] || !parts[1]) return R(false, "BAD_FORMAT", "License Key không đúng định dạng.");

  let sig;
  try { sig = ad88B64uDecode(parts[1]); } catch (e) { return R(false, "BAD_FORMAT", "License Key không đúng định dạng."); }
  if (sig.length !== 64) return R(false, "BAD_FORMAT", "License Key không đúng định dạng.");

  let valid = false;
  try {
    const key = await crypto.subtle.importKey("jwk",
      { kty: "EC", crv: "P-256", x: publicKeyJwk.x, y: publicKeyJwk.y },
      { name: "ECDSA", namedCurve: "P-256" }, false, ["verify"]);
    valid = await crypto.subtle.verify({ name: "ECDSA", hash: "SHA-256" }, key, sig, new TextEncoder().encode(parts[0]));
  } catch (e) { valid = false; }
  if (!valid) return R(false, "BAD_SIGNATURE", "License Key không hợp lệ (chữ ký không đúng).");

  let p;
  try { p = JSON.parse(new TextDecoder().decode(ad88B64uDecode(parts[0]))); } catch (e) { p = null; }
  if (!p || p.v !== 1 || typeof p.i !== "string" || typeof p.d !== "string" ||
      !Number.isInteger(p.e) || p.e < 0)
    return R(false, "BAD_FORMAT", "License Key không đúng định dạng.");
  const info = { id: p.i, name: String(p.n || ""), exp: p.e, issuedAt: Number(p.t) || 0, device: p.d };

  const dev = ad88NormalizeDeviceCode(deviceCode);
  if (!dev || ad88NormalizeDeviceCode(p.d) !== dev)
    return R(false, "WRONG_DEVICE", "License Key này được cấp cho máy khác.", info);
  if (Array.isArray(revokedIds) && revokedIds.indexOf(p.i) >= 0)
    return R(false, "REVOKED", "License Key đã bị thu hồi.", info);
  const now = Number(nowSec) || 0;
  if (p.e > 0 && now > p.e) return R(false, "EXPIRED", "License Key đã hết hạn.", info);
  return R(true, "OK", "Giấy phép hợp lệ.", info);
}
