// AD88 XNK TOOL — hằng số dùng cho background.js. KHÔNG đặt License/Secret Key ở đây.
const AD88_API_BASE_URL = "https://apibo.memberappu.com";
const AD88_API_BANKING_URL = AD88_API_BASE_URL + "/api/v4/banking-info";
const AD88_STORAGE_LICENSE = "AD88_API_LICENSE_KEY";   // khóa API Bank Check do người dùng nhập
const AD88_STORAGE_SECRET = "AD88_API_SECRET_KEY";
// Khóa lưu của cơ chế License theo máy (license.js) — giữ nguyên để key đã kích hoạt vẫn dùng được.
const AD88_STORAGE_DEVICE = "AD88_XNK_DEVICE_CODE_V1";
const AD88_STORAGE_LICENSE_TOKEN = "AD88_XNK_LICENSE_TOKEN_V1";
const AD88_ALLOWED_PAGE_ORIGIN = "https://8f75lftex8h.cg.ink";
