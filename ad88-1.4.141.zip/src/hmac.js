// AD88 XNK TOOL — HMAC-SHA256 thuần JS (chạy trong background service worker qua importScripts).
// Giữ nguyên thuật toán cũ để chữ ký request không đổi.
// ---- Thuật toán mã hóa HMAC-SHA256 thuần JS (chạy an toàn trên mọi context HTTP/HTTPS/iframe) ----
function sha256(ascii) {
  function rightRotate(value, amount) {
    return (value >>> amount) | (value << (32 - amount));
  }

  const words = [];
  const asciiBitLength = ascii.length * 8;

  const hash = [
    0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
    0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19
  ];
  const k = [
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
  ];

  for (let idx = 0; idx < ascii.length; idx++) {
    const ch = ascii.charCodeAt(idx);
    words[idx >> 2] = (words[idx >> 2] || 0) | (ch << ((3 - idx % 4) * 8));
  }

  words[asciiBitLength >> 5] = (words[asciiBitLength >> 5] || 0) | (0x80 << (24 - asciiBitLength % 32));
  words[(((asciiBitLength + 64) >> 9) << 4) + 15] = asciiBitLength;

  for (let b = 0; b < words.length; b += 16) {
    const w = [];
    for (let j = 0; j < 16; j++) w[j] = words[b + j] || 0;
    const oldHash = hash.slice(0);

    for (let j = 0; j < 64; j++) {
      if (j >= 16) {
        let w15 = w[j - 15], w2 = w[j - 2];
        const s0 = rightRotate(w15, 7) ^ rightRotate(w15, 18) ^ (w15 >>> 3);
        const s1 = rightRotate(w2, 17) ^ rightRotate(w2, 19) ^ (w2 >>> 10);
        w[j] = (w[j - 16] + s0 + w[j - 7] + s1) | 0;
      }

      const ch = (hash[4] & hash[5]) ^ (~hash[4] & hash[6]);
      const maj = (hash[0] & hash[1]) ^ (hash[0] & hash[2]) ^ (hash[1] & hash[2]);
      const sigma0 = rightRotate(hash[0], 2) ^ rightRotate(hash[0], 13) ^ rightRotate(hash[0], 22);
      const sigma1 = rightRotate(hash[4], 6) ^ rightRotate(hash[4], 11) ^ rightRotate(hash[4], 25);
      const temp1 = (hash[7] + sigma1 + ch + k[j] + w[j]) | 0;
      const temp2 = (sigma0 + maj) | 0;

      hash[7] = hash[6];
      hash[6] = hash[5];
      hash[5] = hash[4];
      hash[4] = (hash[3] + temp1) | 0;
      hash[3] = hash[2];
      hash[2] = hash[1];
      hash[1] = hash[0];
      hash[0] = (temp1 + temp2) | 0;
    }

    for (let h = 0; h < 8; h++) {
      hash[h] = (hash[h] + oldHash[h]) | 0;
    }
  }

  const bytes = [];
  for (let h = 0; h < 8; h++) {
    for (let j = 3; j >= 0; j--) {
      bytes.push((hash[h] >> (j * 8)) & 255);
    }
  }
  return bytes;
}

function hmacSha256(keyStr, msgStr) {
  const enc = (s) => unescape(encodeURIComponent(s));
  const keyAscii = enc(keyStr);
  const msgAscii = enc(msgStr);
  let keyBytes = [];
  for (let i = 0; i < keyAscii.length; i++) keyBytes.push(keyAscii.charCodeAt(i));
  if (keyBytes.length > 64) {
    keyBytes = sha256(keyAscii);
  }
  while (keyBytes.length < 64) keyBytes.push(0);
  const oKeyPad = [], iKeyPad = [];
  for (let i = 0; i < 64; i++) {
    oKeyPad.push(keyBytes[i] ^ 0x5c);
    iKeyPad.push(keyBytes[i] ^ 0x36);
  }
  let innerInput = "";
  for (let i = 0; i < 64; i++) innerInput += String.fromCharCode(iKeyPad[i]);
  innerInput += msgAscii;
  const innerHash = sha256(innerInput);
  let outerInput = "";
  for (let i = 0; i < 64; i++) outerInput += String.fromCharCode(oKeyPad[i]);
  for (let i = 0; i < innerHash.length; i++) outerInput += String.fromCharCode(innerHash[i]);
  const finalHash = sha256(outerInput);
  return finalHash.map(b => b.toString(16).padStart(2, "0")).join("");
}
