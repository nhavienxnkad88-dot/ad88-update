// AD88 XNK TOOL — ghi bản cập nhật vào thư mục extension (File System Access API) có sao lưu + khôi phục.
// Chỉ dùng các thao tác của FileSystemDirectoryHandle nên test được bằng thư mục giả lập.
(function (root) {
  "use strict";
  const BACKUP_DIR = "update-backup";
  const INFO_FILE = "backup-info.json";

  async function getDir(dir, path, create) {
    let d = dir;
    for (const seg of path.split("/").filter(Boolean)) d = await d.getDirectoryHandle(seg, { create: !!create });
    return d;
  }
  function split(path) { const i = path.lastIndexOf("/"); return i < 0 ? ["", path] : [path.slice(0, i), path.slice(i + 1)]; }

  async function readFile(dir, path) {
    try {
      const [dp, name] = split(path);
      const d = dp ? await getDir(dir, dp, false) : dir;
      const fh = await d.getFileHandle(name);
      return new Uint8Array(await (await fh.getFile()).arrayBuffer());
    } catch (e) { if (e && (e.name === "NotFoundError" || e.name === "TypeMismatchError")) return null; throw e; }
  }
  async function writeFile(dir, path, data) {
    const [dp, name] = split(path);
    const d = dp ? await getDir(dir, dp, true) : dir;
    const fh = await d.getFileHandle(name, { create: true });
    const w = await fh.createWritable();
    try { await w.write(data); } finally { await w.close(); }
  }
  async function removeFile(dir, path) {
    try {
      const [dp, name] = split(path);
      const d = dp ? await getDir(dir, dp, false) : dir;
      await d.removeEntry(name);
    } catch (e) { if (!(e && e.name === "NotFoundError")) throw e; }
  }
  async function removeDirIfExists(dir, name) {
    try { await dir.removeEntry(name, { recursive: true }); } catch (e) { if (!(e && e.name === "NotFoundError")) throw e; }
  }

  // Thư mục được chọn phải đúng là thư mục extension đang chạy.
  async function verifyFolderIdentity(dir, runningVersion) {
    const data = await readFile(dir, "manifest.json");
    if (!data) return { ok: false, message: "Thư mục này không có manifest.json — hãy chọn đúng thư mục extension AD88." };
    let m; try { m = JSON.parse(new TextDecoder().decode(data)); } catch (e) { return { ok: false, message: "manifest.json trong thư mục bị lỗi." }; }
    if (!String(m.name || "").startsWith("AD88 XNK TOOL")) return { ok: false, message: "Đây không phải thư mục AD88 XNK TOOL." };
    if (m.version !== runningVersion) return { ok: false, message: `Thư mục này là bản ${m.version}, còn extension đang chạy là ${runningVersion}. Hãy chọn đúng thư mục đã Load unpacked.` };
    return { ok: true, message: "Đúng thư mục extension.", manifest: m };
  }

  // entries: [{path,data}] đã sắp thứ tự (manifest.json cuối). Trả { backedUp, added }.
  async function install(dir, entries, meta) {
    await removeDirIfExists(dir, BACKUP_DIR);
    const backedUp = [], added = [];
    for (const e of entries) {
      const old = await readFile(dir, e.path);
      if (old) { await writeFile(dir, BACKUP_DIR + "/files/" + e.path, old); backedUp.push(e.path); } else added.push(e.path);
    }
    const info = { from: meta.from, to: meta.to, at: new Date().toISOString(), backedUp, added };
    await writeFile(dir, BACKUP_DIR + "/" + INFO_FILE, new TextEncoder().encode(JSON.stringify(info)));
    const written = [];
    try {
      for (const e of entries) { await writeFile(dir, e.path, e.data); written.push(e.path); }
      // đọc lại để chắc chắn đã ghi đúng
      for (const e of entries) {
        const back = await readFile(dir, e.path);
        if (!back || back.length !== e.data.length) throw new Error("Ghi tệp không đầy đủ: " + e.path);
      }
    } catch (err) {
      try { await rollback(dir); } catch (e2) { err.rollbackFailed = String(e2 && e2.message || e2); }
      throw err;
    }
    return info;
  }

  async function readBackupInfo(dir) {
    const d = await readFile(dir, BACKUP_DIR + "/" + INFO_FILE);
    if (!d) return null;
    try { return JSON.parse(new TextDecoder().decode(d)); } catch (e) { return null; }
  }

  // Khôi phục: chép lại tệp cũ, xóa tệp mới thêm (chỉ những tệp đã ghi theo backup-info).
  async function rollback(dir) {
    const info = await readBackupInfo(dir);
    if (!info) throw new Error("Không có bản sao lưu để khôi phục.");
    for (const p of info.backedUp) {
      const old = await readFile(dir, BACKUP_DIR + "/files/" + p);
      if (!old) throw new Error("Bản sao lưu thiếu tệp: " + p);
    }
    for (const p of info.backedUp) await writeFile(dir, p, await readFile(dir, BACKUP_DIR + "/files/" + p));
    for (const p of info.added) await removeFile(dir, p);
    return info;
  }

  root.AD88UpdateInstaller = { install, rollback, readBackupInfo, verifyFolderIdentity, readFile, writeFile, removeFile, BACKUP_DIR };
})(typeof globalThis !== "undefined" ? globalThis : this);
