// AD88 XNK TOOL — lõi cập nhật (thuần hàm, không phụ thuộc DOM): so sánh phiên bản, kiểm tra chữ ký,
// đọc zip, kiểm tra gói. Dùng chung cho trang update.html, background.js, công cụ xuất bản và test.
(function (root) {
  "use strict";
  const MAX_TOTAL_BYTES = 80 * 1024 * 1024;
  const MAX_FILES = 600;
  // Các tệp của chính cơ chế cập nhật KHÔNG bao giờ bị ghi đè bằng bản cập nhật (để luôn còn đường khôi phục).
  const FROZEN = ["update.html", "update.js", "update.css", "src/update-core.js", "update-config.js", "update-public-key.js", "api-keys.js"];
  const SKIP_PREFIX = ["update-backup/", "tests/", "__MACOSX/", ".git/"];

  const te = new TextEncoder();

  function b64uToBytes(str) {
    const v = String(str || "");
    if (!/^[A-Za-z0-9_-]+$/.test(v)) throw new Error("base64url không hợp lệ");
    const s = v.replace(/-/g, "+").replace(/_/g, "/") + "=".repeat((4 - v.length % 4) % 4);
    const bin = atob(s); const out = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  }
  function bytesToB64u(bytes) {
    let s = ""; for (let i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]);
    return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  }
  async function sha256Hex(bytes) {
    const d = new Uint8Array(await crypto.subtle.digest("SHA-256", bytes));
    return Array.from(d, b => b.toString(16).padStart(2, "0")).join("");
  }

  // "1.4.116" → [1,4,116]; sai định dạng → null
  function parseVersion(v) {
    const m = /^(\d{1,4})\.(\d{1,4})\.(\d{1,5})$/.exec(String(v || "").trim());
    return m ? [Number(m[1]), Number(m[2]), Number(m[3])] : null;
  }
  function compareVersions(a, b) {
    const x = parseVersion(a), y = parseVersion(b);
    if (!x || !y) return NaN;
    for (let i = 0; i < 3; i++) if (x[i] !== y[i]) return x[i] < y[i] ? -1 : 1;
    return 0;
  }

  // Chuỗi được ký — gắn phiên bản + tên zip + SHA-256 nên không thể tráo zip hay hạ cấp mà giữ chữ ký.
  function signedMessage(info) {
    return "AD88UPD1\n" + info.version + "\n" + info.zip + "\n" + info.sha256;
  }

  // Kiểm tra version.json: dạng dữ liệu + chữ ký. KHÔNG kiểm tra zip (làm ở verifyZipAgainstInfo).
  async function verifyInfo(info, publicJwk) {
    if (!info || typeof info !== "object") return fail("BAD_INFO", "version.json không hợp lệ.");
    if (!parseVersion(info.version)) return fail("BAD_INFO", "Số phiên bản trong version.json không hợp lệ.");
    if (typeof info.zip !== "string" || !/^[A-Za-z0-9._-]{3,80}\.zip$/.test(info.zip)) return fail("BAD_INFO", "Tên tệp zip không hợp lệ.");
    if (typeof info.sha256 !== "string" || !/^[0-9a-f]{64}$/.test(info.sha256)) return fail("BAD_INFO", "SHA-256 không hợp lệ.");
    if (typeof info.sig !== "string") return fail("BAD_SIG", "Thiếu chữ ký bản cập nhật.");
    if (!publicJwk || !publicJwk.x || !publicJwk.y) return fail("NO_PUBKEY", "Tool chưa có khóa công khai cập nhật.");
    let sig; try { sig = b64uToBytes(info.sig); } catch (e) { return fail("BAD_SIG", "Chữ ký không đúng định dạng."); }
    if (sig.length !== 64) return fail("BAD_SIG", "Chữ ký không đúng định dạng.");
    let ok = false;
    try {
      const key = await crypto.subtle.importKey("jwk", { kty: "EC", crv: "P-256", x: publicJwk.x, y: publicJwk.y }, { name: "ECDSA", namedCurve: "P-256" }, false, ["verify"]);
      ok = await crypto.subtle.verify({ name: "ECDSA", hash: "SHA-256" }, key, sig, te.encode(signedMessage(info)));
    } catch (e) { ok = false; }
    if (!ok) return fail("BAD_SIG", "Chữ ký bản cập nhật KHÔNG hợp lệ — từ chối cài.");
    return { ok: true, code: "OK", message: "Chữ ký hợp lệ." };
  }
  function fail(code, message) { return { ok: false, code, message }; }

  async function verifyZipAgainstInfo(zipBytes, info) {
    const h = await sha256Hex(zipBytes);
    if (h !== info.sha256) return fail("BAD_HASH", "Tệp zip tải về không khớp SHA-256 đã ký (tải lỗi hoặc bị tráo).");
    return { ok: true, code: "OK", message: "SHA-256 khớp." };
  }

  // ---------- đọc zip (stored + deflate) ----------
  function u16(b, o) { return b[o] | (b[o + 1] << 8); }
  function u32(b, o) { return (b[o] | (b[o + 1] << 8) | (b[o + 2] << 16) | (b[o + 3] << 24)) >>> 0; }
  function safePath(name) {
    let p = String(name || "").replace(/\\/g, "/");
    if (!p || p.startsWith("/") || /^[A-Za-z]:/.test(p) || p.includes("\0")) return null;
    if (p.split("/").some(seg => seg === ".." || seg === "")) return null;
    return p;
  }
  async function inflateRaw(data) {
    const ds = new DecompressionStream("deflate-raw");
    const w = ds.writable.getWriter(); w.write(data); w.close();
    return new Uint8Array(await new Response(ds.readable).arrayBuffer());
  }
  async function readZip(bytes) {
    const n = bytes.length;
    if (n < 22) throw new Error("Tệp zip quá nhỏ/hỏng.");
    let eocd = -1;
    for (let i = n - 22; i >= Math.max(0, n - 22 - 65535); i--) { if (u32(bytes, i) === 0x06054b50) { eocd = i; break; } }
    if (eocd < 0) throw new Error("Không tìm thấy phần cuối zip (tệp hỏng).");
    const count = u16(bytes, eocd + 10), cdSize = u32(bytes, eocd + 12), cdOff = u32(bytes, eocd + 16);
    if (count === 0xffff || cdOff === 0xffffffff) throw new Error("Zip64 không được hỗ trợ.");
    if (count > MAX_FILES) throw new Error("Zip có quá nhiều tệp.");
    if (cdOff + cdSize > n) throw new Error("Zip hỏng (danh mục vượt kích thước).");
    const entries = []; let p = cdOff, total = 0;
    for (let i = 0; i < count; i++) {
      if (u32(bytes, p) !== 0x02014b50) throw new Error("Zip hỏng (danh mục sai).");
      const flags = u16(bytes, p + 8), method = u16(bytes, p + 10), csize = u32(bytes, p + 20), usize = u32(bytes, p + 24);
      const nameLen = u16(bytes, p + 28), extraLen = u16(bytes, p + 30), cmtLen = u16(bytes, p + 32), lho = u32(bytes, p + 42);
      const name = new TextDecoder().decode(bytes.subarray(p + 46, p + 46 + nameLen));
      p += 46 + nameLen + extraLen + cmtLen;
      if (name.endsWith("/")) continue;                       // thư mục
      if (flags & 1) throw new Error("Zip có mã hóa — không hỗ trợ.");
      const path = safePath(name);
      if (!path) throw new Error("Đường dẫn trong zip không an toàn: " + name);
      total += usize; if (total > MAX_TOTAL_BYTES) throw new Error("Zip giải nén quá lớn.");
      if (u32(bytes, lho) !== 0x04034b50) throw new Error("Zip hỏng (đầu tệp sai): " + name);
      const start = lho + 30 + u16(bytes, lho + 26) + u16(bytes, lho + 28);
      if (start + csize > n) throw new Error("Zip hỏng (dữ liệu vượt kích thước): " + name);
      const raw = bytes.subarray(start, start + csize);
      let data;
      if (method === 0) data = raw.slice();
      else if (method === 8) data = await inflateRaw(raw);
      else throw new Error("Kiểu nén zip không hỗ trợ (" + method + "): " + name);
      if (data.length !== usize) throw new Error("Zip hỏng (sai kích thước): " + name);
      entries.push({ path, data });
    }
    return entries;
  }

  // Bỏ thư mục gốc chung nếu zip được nén kiểu "thư-mục/…"; lọc tệp không cần.
  function normalizeEntries(entries) {
    let list = entries.slice();
    const tops = new Set(list.map(e => e.path.split("/")[0]));
    const hasRootManifest = list.some(e => e.path === "manifest.json");
    if (!hasRootManifest && tops.size === 1 && list.every(e => e.path.includes("/"))) {
      const top = [...tops][0] + "/"; list = list.map(e => ({ path: e.path.slice(top.length), data: e.data }));
    }
    return list.filter(e => e.path && !SKIP_PREFIX.some(pf => e.path.startsWith(pf)) && !/\.(bak|orig|tmp)$/i.test(e.path) && !/(^|\/)\.DS_Store$/.test(e.path));
  }

  // Kiểm tra gói trước khi cài: manifest đúng phiên bản, mọi tệp manifest nhắc tới đều có trong gói.
  function validatePackage(entries, info, currentName) {
    const map = new Map(entries.map(e => [e.path, e.data]));
    const mdata = map.get("manifest.json");
    if (!mdata) return fail("NO_MANIFEST", "Gói cập nhật không có manifest.json.");
    let m; try { m = JSON.parse(new TextDecoder().decode(mdata)); } catch (e) { return fail("BAD_MANIFEST", "manifest.json trong gói bị lỗi."); }
    if (m.manifest_version !== 3) return fail("BAD_MANIFEST", "manifest.json không phải Manifest V3.");
    if (m.version !== info.version) return fail("VERSION_MISMATCH", `manifest.json ghi ${m.version} nhưng bản cập nhật khai báo ${info.version}.`);
    if (currentName && !String(m.name || "").startsWith("AD88 XNK TOOL")) return fail("BAD_MANIFEST", "Gói không phải AD88 XNK TOOL.");
    const need = [];
    if (m.background && m.background.service_worker) need.push(m.background.service_worker);
    for (const cs of m.content_scripts || []) { need.push(...(cs.js || []), ...(cs.css || [])); }
    for (const war of m.web_accessible_resources || []) for (const r of war.resources || []) if (!r.includes("*")) need.push(r);
    // Tệp đóng băng không nằm trong gói (giữ bản đang cài) nên không bắt buộc có mặt.
    const missing = need.filter(f => !map.has(f) && !FROZEN.includes(f));
    if (missing.length) return fail("MISSING_FILES", "Gói thiếu tệp manifest nhắc tới: " + missing.slice(0, 5).join(", "));
    // Mọi file .js trong gói phải không rỗng
    const emptyJs = entries.filter(e => /\.js$/.test(e.path) && e.data.length === 0).map(e => e.path);
    if (emptyJs.length) return fail("EMPTY_FILE", "Gói có tệp JS rỗng: " + emptyJs.slice(0, 3).join(", "));
    return { ok: true, code: "OK", message: "Gói hợp lệ.", manifest: m };
  }

  // Danh sách tệp sẽ ghi (bỏ tệp đóng băng), manifest.json xếp CUỐI.
  function installOrder(entries) {
    const list = entries.filter(e => !FROZEN.includes(e.path));
    list.sort((a, b) => (a.path === "manifest.json") - (b.path === "manifest.json"));
    return list;
  }

  root.AD88UpdateCore = { b64uToBytes, bytesToB64u, sha256Hex, parseVersion, compareVersions, signedMessage, verifyInfo, verifyZipAgainstInfo,
    readZip, normalizeEntries, validatePackage, installOrder, FROZEN, safePath };
})(typeof globalThis !== "undefined" ? globalThis : this);
