// AD88 XNK TOOL — trang Cập nhật (chạy trong tab của extension).
// Quy trình: tải version.json → kiểm tra chữ ký → tải zip → kiểm tra SHA-256 + gói → sao lưu → ghi tệp → nạp lại extension.
(() => {
  "use strict";
  const C = AD88UpdateCore, I = AD88UpdateInstaller;
  const $ = id => document.getElementById(id);
  const running = chrome.runtime.getManifest().version;
  let dirHandle = null, remoteInfo = null, busy = false;

  const logEl = $("log");
  function log(msg) { logEl.textContent += `[${new Date().toLocaleTimeString("vi-VN")}] ${msg}\n`; logEl.scrollTop = logEl.scrollHeight; }
  function setState(id, text, cls) { const el = $(id); el.textContent = text; el.className = "state" + (cls ? " " + cls : ""); }

  // ---- lưu/đọc quyền thư mục trong IndexedDB của extension ----
  function idb() {
    return new Promise((res, rej) => { const r = indexedDB.open("ad88-update", 1); r.onupgradeneeded = () => r.result.createObjectStore("kv"); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
  }
  async function idbGet(k) { const db = await idb(); return new Promise((res, rej) => { const q = db.transaction("kv").objectStore("kv").get(k); q.onsuccess = () => res(q.result); q.onerror = () => rej(q.error); }); }
  async function idbSet(k, v) { const db = await idb(); return new Promise((res, rej) => { const t = db.transaction("kv", "readwrite"); t.objectStore("kv").put(v, k); t.oncomplete = () => res(); t.onerror = () => rej(t.error); }); }

  async function checkDirPermission(interactive) {
    if (!dirHandle) return false;
    let p = await dirHandle.queryPermission({ mode: "readwrite" });
    if (p !== "granted" && interactive) p = await dirHandle.requestPermission({ mode: "readwrite" });
    return p === "granted";
  }

  async function refreshDirState() {
    $("btnPerm").hidden = true;
    if (!dirHandle) { setState("dirState", "Chưa chọn thư mục", ""); $("btnInstall").disabled = true; refreshBackup(); return; }
    if (!(await checkDirPermission(false))) { setState("dirState", `Đã chọn “${dirHandle.name}” nhưng cần cấp lại quyền ghi.`, "new"); $("btnPerm").hidden = false; $("btnInstall").disabled = true; return; }
    const id = await I.verifyFolderIdentity(dirHandle, running);
    if (!id.ok) { setState("dirState", id.message, "bad"); $("btnInstall").disabled = true; return; }
    setState("dirState", `✓ Thư mục “${dirHandle.name}” đúng và có quyền ghi.`, "ok");
    if (remoteInfo) $("btnInstall").disabled = false;
    refreshBackup();
  }

  async function refreshBackup() {
    $("btnRollback").hidden = true;
    if (!dirHandle || !(await checkDirPermission(false))) return;
    try {
      const info = await I.readBackupInfo(dirHandle);
      if (info) { setState("backupState", `Có bản sao lưu: ${info.from} (trước khi lên ${info.to}, ${new Date(info.at).toLocaleString("vi-VN")})`, "ok"); $("btnRollback").hidden = false; }
      else setState("backupState", "Chưa có bản sao lưu", "");
    } catch (e) { setState("backupState", "Không đọc được bản sao lưu", "bad"); }
  }

  $("btnPick").onclick = async () => {
    try {
      if (!window.showDirectoryPicker) throw new Error("Trình duyệt này không hỗ trợ chọn thư mục.");
      const h = await window.showDirectoryPicker({ id: "ad88-ext", mode: "readwrite" });
      const id = await I.verifyFolderIdentity(h, running);
      if (!id.ok) { setState("dirState", id.message, "bad"); log("✗ " + id.message); return; }
      dirHandle = h; await idbSet("dir", h); log(`✓ Đã chọn thư mục “${h.name}”.`);
      await refreshDirState();
    } catch (e) { if (e && e.name !== "AbortError") { log("✗ " + (e.message || e)); setState("dirState", String(e.message || e), "bad"); } }
  };
  $("btnPerm").onclick = async () => { try { await checkDirPermission(true); } catch (e) { log("✗ " + (e.message || e)); } await refreshDirState(); };

  async function fetchBytes(url) {
    const r = await fetch(url, { cache: "no-store" });
    if (!r.ok) throw new Error(`Tải thất bại (${r.status}): ${url}`);
    return new Uint8Array(await r.arrayBuffer());
  }

  $("btnCheck").onclick = async () => {
    if (busy) return; busy = true; $("btnCheck").disabled = true; remoteInfo = null; $("btnInstall").hidden = true; $("notes").hidden = true;
    try {
      setState("remoteState", "Đang kiểm tra…", "");
      const base = AD88_UPDATE_BASE_URL;
      const raw = await fetchBytes(base + "version.json?t=" + Date.now());
      let info; try { info = JSON.parse(new TextDecoder().decode(raw)); } catch (e) { throw new Error("version.json không đọc được."); }
      const v = await C.verifyInfo(info, window.AD88_UPDATE_PUBLIC_KEY);
      if (!v.ok) throw new Error(v.message);
      const cmp = C.compareVersions(info.version, running);
      if (cmp <= 0) { setState("remoteState", `✓ Bạn đang dùng bản mới nhất (${running}).`, "ok"); log("Không có bản mới."); return; }
      remoteInfo = info;
      setState("remoteState", `Có bản mới: ${info.version} (đang chạy ${running}).`, "new");
      if (info.notes) { $("notes").textContent = String(info.notes).slice(0, 2000); $("notes").hidden = false; }
      $("btnInstall").hidden = false; $("btnInstall").disabled = !(dirHandle && await checkDirPermission(false));
      log(`Bản mới ${info.version} — chữ ký hợp lệ.`);
    } catch (e) { setState("remoteState", "✗ " + (e.message || e), "bad"); log("✗ " + (e.message || e)); }
    finally { busy = false; $("btnCheck").disabled = false; }
  };

  $("btnInstall").onclick = async () => {
    if (busy || !remoteInfo) return;
    if (!dirHandle || !(await checkDirPermission(true))) { log("✗ Cần chọn thư mục và cấp quyền ghi."); return; }
    if (!confirm(`Cập nhật từ ${running} lên ${remoteInfo.version}?\nTool sẽ tự sao lưu bản hiện tại và nạp lại extension.`)) return;
    busy = true; $("btnInstall").disabled = true; $("btnCheck").disabled = true;
    try {
      const id = await I.verifyFolderIdentity(dirHandle, running); if (!id.ok) throw new Error(id.message);
      log("Đang tải gói cập nhật…");
      const zip = await fetchBytes(AD88_UPDATE_BASE_URL + remoteInfo.zip);
      const h = await C.verifyZipAgainstInfo(zip, remoteInfo); if (!h.ok) throw new Error(h.message);
      log("✓ SHA-256 khớp. Đang đọc gói…");
      const entries = C.normalizeEntries(await C.readZip(zip));
      const pkg = C.validatePackage(entries, remoteInfo, true); if (!pkg.ok) throw new Error(pkg.message);
      const ordered = C.installOrder(entries);
      log(`✓ Gói hợp lệ (${ordered.length} tệp). Đang sao lưu và ghi tệp…`);
      await I.install(dirHandle, ordered, { from: running, to: remoteInfo.version });
      log(`✓ Đã cập nhật lên ${remoteInfo.version}.`);
      try { await chrome.storage.local.set({ AD88_UPDATE_LAST: { from: running, to: remoteInfo.version, at: Date.now() } }); } catch (e) {}
      setState("remoteState", `✓ Đã cập nhật lên ${remoteInfo.version}. Extension sẽ tự nạp lại; hãy F5 trang BO.`, "ok");
      setTimeout(() => { try { chrome.runtime.reload(); } catch (e) { log("Hãy bấm Nạp lại ở chrome://extensions."); } }, 1500);
    } catch (e) {
      const extra = e && e.rollbackFailed ? " (khôi phục tự động cũng lỗi: " + e.rollbackFailed + ")" : "";
      log("✗ Cập nhật thất bại: " + (e.message || e) + extra);
      setState("remoteState", "✗ Cập nhật thất bại: " + (e.message || e) + " — bản hiện tại giữ nguyên/đã khôi phục.", "bad");
      busy = false; $("btnCheck").disabled = false; $("btnInstall").disabled = false; await refreshBackup();
    }
  };

  $("btnRollback").onclick = async () => {
    if (busy) return;
    if (!dirHandle || !(await checkDirPermission(true))) { log("✗ Cần quyền ghi thư mục."); return; }
    if (!confirm("Khôi phục về bản trước lần cập nhật gần nhất?")) return;
    busy = true;
    try {
      const info = await I.rollback(dirHandle);
      log(`✓ Đã khôi phục về ${info.from}. Extension sẽ tự nạp lại; hãy F5 trang BO.`);
      setState("backupState", `✓ Đã khôi phục về ${info.from}.`, "ok");
      setTimeout(() => { try { chrome.runtime.reload(); } catch (e) {} }, 1500);
    } catch (e) { log("✗ Khôi phục thất bại: " + (e.message || e)); setState("backupState", "✗ " + (e.message || e), "bad"); busy = false; }
  };

  (async () => {
    $("curVer").textContent = running;
    try { dirHandle = (await idbGet("dir")) || null; } catch (e) { dirHandle = null; }
    await refreshDirState();
    if (new URLSearchParams(location.search).get("auto") === "1") $("btnCheck").click();
  })();
})();
