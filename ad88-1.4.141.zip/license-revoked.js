// AD88 XNK TOOL — danh sách mã License đã thu hồi.
// Mặc định rỗng; có thể thay bằng file do issuer tạo khi cần.
window.AD88_LICENSE_REVOKED = [];
