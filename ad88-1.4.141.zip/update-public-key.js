// AD88 XNK TOOL — khóa CÔNG KHAI kiểm tra chữ ký bản cập nhật (an toàn để phát hành).
window.AD88_UPDATE_PUBLIC_KEY = {"kty":"EC","crv":"P-256","x":"RDmgtRA3JR3YrdMAK5Q-cn9-2FWcUK2U34H7tBra35w","y":"Ibrx6ne2HtS0IqSJlSu_E3aWpD598nOsUwGWwXQ5oOQ"};
