// AWEI AD88 XNK TOOL — background service worker
//  1) Gọi API Bank Check: ký HMAC + gọi mạng ở đây; chỉ chạy khi máy có License hợp lệ.
//     Khóa API lấy từ chrome.storage.local (Cài đặt → Khóa API Bank Check), không nằm trong mã nguồn.
//  2) Cập nhật: mở trang update.html và kiểm tra có bản mới (đọc version.json, kiểm tra chữ ký).
//  3) Bridge kiểm tra địa chỉ TRON (USDT TRC20).
self.window = self; // các tệp khóa công khai gán vào window.*
importScripts('src/api-constants.js', 'src/hmac.js', 'src/license-verify.js', 'license-public-key.js', 'license-revoked.js',
              'src/update-core.js', 'update-config.js', 'update-public-key.js');
try { importScripts('api-keys.js'); } catch (e) { /* máy cài từ bản cũ chưa có api-keys.js: vẫn chạy, dùng khóa trong storage */ }

function ad88NewNonce() {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) return crypto.randomUUID();
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
    const r = Math.random() * 16 | 0;
    return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
  });
}

// ---------- License theo máy ----------
async function ad88DeviceCode() {
  const d = await chrome.storage.local.get([AD88_STORAGE_DEVICE]);
  const cur = ad88NormalizeDeviceCode(d[AD88_STORAGE_DEVICE]);
  if (cur) return cur;
  const fresh = ad88GenerateDeviceCode();
  await chrome.storage.local.set({ [AD88_STORAGE_DEVICE]: fresh });
  return fresh;
}
async function ad88LicenseCheck() {
  const deviceCode = await ad88DeviceCode();
  const st = await chrome.storage.local.get([AD88_STORAGE_LICENSE_TOKEN]);
  const res = await ad88VerifyLicense({
    token: st[AD88_STORAGE_LICENSE_TOKEN], deviceCode, nowSec: Math.floor(Date.now() / 1000),
    publicKeyJwk: self.AD88_LICENSE_PUBLIC_KEY || null,
    revokedIds: Array.isArray(self.AD88_LICENSE_REVOKED) ? self.AD88_LICENSE_REVOKED.map(x => String(x).toLowerCase()) : []
  });
  return { ok: res.ok, code: res.code, message: res.message, deviceCode, info: res.info };
}

// ---------- Bank Check ----------
async function ad88BankApi(message) {
  const url = String(message && message.url || '');
  if (url !== AD88_API_BANKING_URL) return { ok: false, bridgeError: true, message: 'URL không được phép.' };
  const body = message.body;
  if (!body || typeof body !== 'object') return { ok: false, bridgeError: true, message: 'Body không hợp lệ.' };

  const lic = await ad88LicenseCheck();
  if (!lic.ok) {
    return { ok: false, licenseError: true, licenseRequired: true,
      message: (lic.message || 'Chưa có License hợp lệ.') + ' Vào Cài đặt → Mở khóa Key để kích hoạt.' };
  }
  const keys = await chrome.storage.local.get([AD88_STORAGE_LICENSE, AD88_STORAGE_SECRET]);
  const built = self.AD88_BUILTIN_API_KEYS || {};
  const licenseKey = String(keys[AD88_STORAGE_LICENSE] || built.license || '').trim();
  const secretKey = String(keys[AD88_STORAGE_SECRET] || built.secret || '').trim();
  if (!licenseKey || !secretKey) {
    return { ok: false, licenseError: true, keyMissing: true,
      message: 'Chưa nhập License Key / Secret Key của API Bank Check. Vào Cài đặt → Khóa API Bank Check để nhập.' };
  }

  let timeoutId = null, controller = null;
  try {
    const timestamp = Math.floor(Date.now() / 1000).toString();
    const nonce = ad88NewNonce();
    const rawBody = JSON.stringify(body);
    const signature = hmacSha256(secretKey, `${timestamp}.${nonce}.${rawBody}`);
    const timeoutMs = Number(message.timeoutMs);
    if (Number.isFinite(timeoutMs) && timeoutMs > 0) {
      controller = new AbortController();
      timeoutId = setTimeout(() => controller.abort(), timeoutMs);
    }
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-License-Key': licenseKey, 'X-Timestamp': timestamp, 'X-Nonce': nonce, 'X-Signature': signature },
      body: rawBody,
      signal: controller ? controller.signal : undefined
    });
    if (timeoutId) clearTimeout(timeoutId);
    const result = await response.json().catch(() => null);
    if (response.status === 401 || response.status === 409) {
      return { ok: false, licenseError: true, status: response.status, message: (result && result.message) || 'License Key hoặc Secret Key không hợp lệ.' };
    }
    if (!response.ok) {
      return { ok: false, licenseError: false, status: response.status, result, message: (result && result.message) || 'Không thể kết nối máy chủ.' };
    }
    return { ok: true, status: response.status, result };
  } catch (err) {
    if (timeoutId) clearTimeout(timeoutId);
    const timedOut = !!(err && err.name === 'AbortError');
    return { ok: false, timeout: timedOut, bridgeError: !timedOut, message: timedOut ? 'Bank Checker phản hồi quá chậm.' : 'Không thể kết nối máy chủ.' };
  }
}

// ---------- Cập nhật ----------
async function ad88CheckUpdate() {
  const running = chrome.runtime.getManifest().version;
  try {
    const r = await fetch(AD88_UPDATE_BASE_URL + 'version.json?t=' + Date.now(), { cache: 'no-store' });
    if (!r.ok) return { ok: false, running, message: 'Không tải được version.json (' + r.status + ').' };
    const info = await r.json();
    const v = await AD88UpdateCore.verifyInfo(info, self.AD88_UPDATE_PUBLIC_KEY);
    if (!v.ok) return { ok: false, running, message: v.message };
    const cmp = AD88UpdateCore.compareVersions(info.version, running);
    return { ok: true, running, available: cmp > 0, version: info.version, notes: String(info.notes || '').slice(0, 500) };
  } catch (e) { return { ok: false, running, message: 'Không kiểm tra được bản mới: ' + String(e && e.message || e) }; }
}

function ad88FromOurPage(sender) {
  return !!(sender && sender.id === chrome.runtime.id && typeof sender.url === 'string' &&
    sender.url.startsWith(AD88_ALLOWED_PAGE_ORIGIN + '/'));
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message) return;
  const type = message.type;

  if (type === 'AD88_BANK_API' || type === 'AD88_CHECK_UPDATE' || type === 'AD88_OPEN_UPDATE') {
    if (!ad88FromOurPage(sender)) { sendResponse({ ok: false, bridgeError: true, message: 'Nguồn gọi không hợp lệ.' }); return; }
    if (type === 'AD88_OPEN_UPDATE') {
      chrome.tabs.create({ url: chrome.runtime.getURL('update.html' + (message.auto ? '?auto=1' : '')) })
        .then(() => sendResponse({ ok: true }), e => sendResponse({ ok: false, message: String(e && e.message || e) }));
      return true;
    }
    const job = type === 'AD88_BANK_API' ? ad88BankApi(message) : ad88CheckUpdate();
    job.then(sendResponse, e => sendResponse({ ok: false, bridgeError: true, message: String(e && e.message || e) }));
    return true;
  }

  if (type === 'AD88_VALIDATE_TRON_ADDRESS') {
    (async () => {
      try {
        const headers = {'Content-Type':'application/json'};
        if (message.apiKey) headers['TRON-PRO-API-KEY'] = String(message.apiKey);
        const r = await fetch('https://api.trongrid.io/wallet/validateaddress', {
          method:'POST', headers,
          body:JSON.stringify({address:String(message.address||'').trim(),visible:true})
        });
        const data = await r.json().catch(() => null);
        sendResponse({ok:r.ok,httpStatus:r.status,data});
      } catch (e) {
        sendResponse({ok:false,networkError:true,error:String(e?.message||e)});
      }
    })();
    return true;
  }
});
