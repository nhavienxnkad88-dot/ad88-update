// AD88 XNK TOOL — License runtime (ECDSA P-256 / SHA-256).
// Chỉ chứa public key và token License; tuyệt đối không chứa private key.
(() => {
  "use strict";
  const STORAGE_KEY = "AD88_XNK_LICENSE_TOKEN_V1";
  const DEVICE_KEY = "AD88_XNK_DEVICE_CODE_V1";
  const ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const PREFIX = "AD88.";

  function b64uDecode(s) {
    const t = String(s || "").replace(/-/g, "+").replace(/_/g, "/");
    const pad = t.length % 4 ? "=".repeat(4 - (t.length % 4)) : "";
    const bin = atob(t + pad);
    const out = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  }

  function normalizeDeviceCode(input) {
    const s = String(input || "").toUpperCase().replace(/[^A-Z0-9]/g, "");
    if (s.length !== 16) return "";
    for (const ch of s) if (ALPHABET.indexOf(ch) < 0) return "";
    return `${s.slice(0,4)}-${s.slice(4,8)}-${s.slice(8,12)}-${s.slice(12,16)}`;
  }

  function storageGet(keys) {
    return new Promise(resolve => {
      try { chrome.storage.local.get(keys, x => resolve(x || {})); }
      catch { resolve({}); }
    });
  }
  function storageSet(obj) {
    return new Promise(resolve => {
      try { chrome.storage.local.set(obj, resolve); } catch { resolve(); }
    });
  }

  async function getDeviceCode() {
    const saved = await storageGet([DEVICE_KEY]);
    const n = normalizeDeviceCode(saved[DEVICE_KEY]);
    if (n) return n;
    const bytes = crypto.getRandomValues(new Uint8Array(16));
    let s = "";
    for (let i = 0; i < 16; i++) s += ALPHABET[bytes[i] % ALPHABET.length];
    const code = normalizeDeviceCode(s);
    await storageSet({ [DEVICE_KEY]: code });
    return code;
  }

  async function getToken() {
    const x = await storageGet([STORAGE_KEY]);
    return String(x[STORAGE_KEY] || "").trim();
  }
  async function setToken(token) {
    await storageSet({ [STORAGE_KEY]: String(token || "").trim() });
  }
  async function clearToken() {
    try { await chrome.storage.local.remove(STORAGE_KEY); } catch {}
  }

  function parseToken(token) {
    const raw = String(token || "").trim();
    if (!raw.startsWith(PREFIX)) throw new Error("License Key không đúng định dạng.");
    const body = raw.slice(PREFIX.length);
    const dot = body.indexOf(".");
    if (dot <= 0) throw new Error("License Key bị thiếu chữ ký.");
    const p64 = body.slice(0, dot), s64 = body.slice(dot + 1);
    const payloadText = new TextDecoder().decode(b64uDecode(p64));
    let payload;
    try { payload = JSON.parse(payloadText); } catch { throw new Error("Dữ liệu License không hợp lệ."); }
    if (!payload || payload.v !== 1 || !/^[0-9a-f]{12}$/.test(String(payload.i || ""))) {
      throw new Error("License Key không hợp lệ.");
    }
    return { raw, p64, sig: b64uDecode(s64), payload };
  }

  async function verifySignature(parsed) {
    if (!window.AD88_LICENSE_PUBLIC_KEY) throw new Error("Thiếu khóa công khai License.");
    const key = await crypto.subtle.importKey(
      "jwk", window.AD88_LICENSE_PUBLIC_KEY,
      { name: "ECDSA", namedCurve: "P-256" }, false, ["verify"]
    );
    return !!await crypto.subtle.verify(
      { name: "ECDSA", hash: "SHA-256" },
      key, parsed.sig, new TextEncoder().encode(parsed.p64)
    );
  }

  function statusMessage(code, payload) {
    const exp = Number(payload?.e || 0);
    if (code === "VALID") return exp ? `Đã kích hoạt · hết hạn ${new Date(exp * 1000).toLocaleDateString("vi-VN")}` : "Đã kích hoạt · Vĩnh viễn";
    if (code === "NO_KEY") return "Chưa kích hoạt License";
    if (code === "WRONG_DEVICE") return "License thuộc máy khác";
    if (code === "EXPIRED") return "License đã hết hạn";
    if (code === "REVOKED") return "License đã bị thu hồi";
    return "License không hợp lệ";
  }

  async function validate(token) {
    const device = await getDeviceCode();
    const raw = String(token || "").trim();
    if (!raw) return { ok:false, code:"NO_KEY", device, message:"Chưa kích hoạt License" };
    try {
      const parsed = parseToken(raw);
      const goodSig = await verifySignature(parsed);
      if (!goodSig) return { ok:false, code:"BAD_SIGNATURE", device, message:"Sai chữ ký License" };
      const p = parsed.payload;
      if (normalizeDeviceCode(p.d) !== device) return { ok:false, code:"WRONG_DEVICE", device, payload:p, message:"License thuộc máy khác" };
      if (Array.isArray(window.AD88_LICENSE_REVOKED) && window.AD88_LICENSE_REVOKED.map(String).includes(String(p.i).toLowerCase())) {
        return { ok:false, code:"REVOKED", device, payload:p, message:"License đã bị thu hồi" };
      }
      const exp = Number(p.e || 0);
      if (exp > 0 && Math.floor(Date.now()/1000) > exp) return { ok:false, code:"EXPIRED", device, payload:p, message:"License đã hết hạn" };
      return { ok:true, code:"VALID", device, payload:p, message:statusMessage("VALID",p) };
    } catch (e) {
      return { ok:false, code:"INVALID", device, message:e?.message || "License không hợp lệ" };
    }
  }

  async function getStatus() {
    const token = await getToken();
    return validate(token);
  }

  async function activate(token) {
    const device = await getDeviceCode();
    const check = await validate(token);
    if (!check.ok) {
      return check;
    }
    await setToken(token);
    return { ...check, device };
  }

  window.AD88_LICENSE = {
    getDeviceCode, getToken, setToken, clearToken, parseToken, validate, getStatus, activate
  };
})();
