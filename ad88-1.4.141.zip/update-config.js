// AD88 XNK TOOL — cấu hình cập nhật. Nơi đặt version.json và gói zip (GitHub Pages của bạn).
// Chỉ đổi giá trị này khi chuyển sang nơi lưu trữ khác (phải cài lại tay vì tệp này được "đóng băng").
const AD88_UPDATE_BASE_URL = "https://nhavienxnkad88-dot.github.io/ad88-update/";
