// AD88 XNK TOOL — Provider Registry
// SINGLE SOURCE OF TRUTH cho nhà thứ 3.
// Khi thêm provider mới về sau: thêm 1 object vào AD88_PROVIDER_REGISTRY.
// Settings / toggle / MIN-MAX / currency / Core selection đều đọc từ registry này.
// Provider VND mới xuất hiện trực tiếp trong BO vẫn được Core nhận diện động; Registry chỉ là nơi chuẩn hóa alias/cấu hình cho nhà đã biết.
// Thứ tự mảng = thứ tự chuẩn hiển thị và thứ tự fallback VND.
// usdtPriority chỉ dùng cho USDT: số nhỏ hơn được ưu tiên trước.

const AD88_PROVIDER_REGISTRY = Object.freeze([
  { name:"V6Pay(VND)(二)", currency:"VND", min:null, max:null, aliases:["V6Pay(VND)(二)","V6Pay(VND)","V6Pay"], usdtPriority:null },
  { name:"33Pay",    currency:"VND",  min:50000,    max:499000,    aliases:["33Pay"], usdtPriority:null },
  { name:"RCPAY",    currency:"USDT", min:null,     max:null,     aliases:["RCPAY","RCPay"], usdtPriority:20 },
  { name:"U2PAY",    currency:"USDT", min:null,     max:null,     aliases:["U2PAY","U2Pay","U2Pay2"], usdtPriority:10 },
  { name:"VN196Pay", currency:"VND",  min:50000,    max:499000,   aliases:["VN196Pay","196"], usdtPriority:null },
  { name:"FastPay",  currency:"VND",  min:100000,   max:10000000, aliases:["FastPay"], usdtPriority:null },
  { name:"GO-PAY",   currency:"VND",  min:10000000, max:300000000,aliases:["GO-PAY","GoPay"], usdtPriority:null },
  { name:"VipPay",   currency:"VND",  min:5000000,  max:10000000,aliases:["VipPay","VIPPay"], usdtPriority:null },
  { name:"PPPAY",    currency:"VND",  min:5000000,  max:10000000,aliases:["PPPAY"], usdtPriority:null },
  { name:"OkPay",    currency:"VND",  min:500000,   max:5000000, aliases:["OkPay","OKPAY"], usdtPriority:null },
  { name:"A8Pay",    currency:"VND",  min:500000,   max:5000000, aliases:["A8Pay"], usdtPriority:null },
  { name:"BB168Pay", currency:"VND",  min:null,     max:null,     aliases:["BB168Pay","BB168PAY","BB168 Pay"], usdtPriority:null },
  { name:"JYPay(VND)(二)", currency:"VND", min:null, max:null, aliases:["JYPay(VND)(二)","JYPay"], usdtPriority:null },
  { name:"PaYoPay(VND)(二)", currency:"VND", min:null, max:null, aliases:["PaYoPay(VND)(二)","PaYoPay(VND)","PaYoPay"], usdtPriority:null },
  { name:"888Pay", currency:"VND", min:null, max:null, aliases:["888Pay","888PAY"], usdtPriority:null },
  { name:"WHPAY",    currency:"USDT", min:null,     max:null,     aliases:["WHPAY","WHPay"], usdtPriority:30 }
]);

// 888Pay hiển thị trong Toggle/Config nhưng TẮT mặc định; không ghi đè lựa chọn đã lưu.
try {
  const raw = localStorage.getItem("AD88_XNK_PROVIDER_TOGGLES");
  const state = raw ? (JSON.parse(raw) || {}) : {};
  if (state["888Pay"] === undefined) { state["888Pay"] = false; localStorage.setItem("AD88_XNK_PROVIDER_TOGGLES", JSON.stringify(state)); }
} catch {}

function AD88_getProviderRegistry(){
  return AD88_PROVIDER_REGISTRY.map(p => ({...p, aliases:[...(p.aliases||[])]}));
}
function AD88_providerCanonical(name){
  const raw=String(name??"").trim();
  // BO có thể hiển thị provider kèm hậu tố currency, ví dụ:
  // "BB168Pay(VND)", "U2Pay(USDT)". Hậu tố này chỉ là cách BO
  // hiển thị loại tiền, không phải tên provider. Chuẩn hóa để Toggle,
  // MIN/MAX, alias và thống kê dùng cùng một provider key.
  const n=raw.toUpperCase()
    .replace(/\s+/g,"")
    .replace(/\((?:VND|USDT)\)$/i,"");
  const hit=AD88_PROVIDER_REGISTRY.find(p =>
    [p.name,...(p.aliases||[])].some(a=>String(a).toUpperCase().replace(/\s+/g,"")===n)
  );
  return hit ? hit.name : raw;
}
function AD88_providerDefinition(name){
  const key=AD88_providerCanonical(name);
  return AD88_PROVIDER_REGISTRY.find(p=>p.name===key)||null;
}
function AD88_providerNames(){
  return AD88_PROVIDER_REGISTRY.map(p=>p.name);
}
function AD88_providerFallback(){
  return AD88_PROVIDER_REGISTRY.map(({name,currency,min,max})=>({name,currency,min,max}));
}
function AD88_usdtProviders(){
  return AD88_PROVIDER_REGISTRY
    .filter(p=>p.currency==="USDT")
    .slice()
    .sort((a,b)=>(a.usdtPriority??9999)-(b.usdtPriority??9999));
}
