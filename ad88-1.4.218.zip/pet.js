// AD88 XNK TOOL — ROBOT PET (1.4.217)
// Robot thay cho nút thu nhỏ: bảng tool đóng -> robot hiện ra đi lại khắp trang BO.
// Bấm trái = mở bảng tool. Bấm phải = menu. Kéo = đặt lại chỗ.
// KHÔNG đụng tới bắt đơn / Bank Check / khóa - mở khóa.
(() => {
  "use strict";
  const SKINS = {
    blue: {name:"Robot trắng", g:{side:{n:8,w:119,h:169},front:{n:8,w:119,h:162},back:{n:8,w:112,h:158},q_front:{n:8,w:96,h:137},q_back:{n:8,w:95,h:139},idle:{n:4,w:100,h:138},sleep:{n:4,w:133,h:99},laptop:{n:4,w:105,h:128},jump:{n:6,w:104,h:133},happy:{n:6,w:112,h:127}}},
    red:  {name:"Robot đỏ",    g:{side:{n:8,w:76,h:107},front:{n:8,w:84,h:103},back:{n:8,w:79,h:101},q_front:{n:8,w:77,h:109},q_back:{n:8,w:80,h:105},idle:{n:4,w:86,h:104},jump:{n:4,w:91,h:101},laptop:{n:4,w:96,h:109},sleep:{n:4,w:128,h:102},happy:{n:6,w:108,h:116}}}
  };
  const SIZES = [["Nhỏ",92],["Vừa",128],["To",170],["Rất to",215]];
  const K = {on:"AD88_PET_ON", skin:"AD88_PET_SKIN", size:"AD88_PET_SIZE", move:"AD88_PET_MOVE", pos:"AD88_PET_POS"};
  const get=(k,d)=>{try{const v=localStorage.getItem(k);return v===null?d:v;}catch(_){return d;}};
  const set=(k,v)=>{try{localStorage.setItem(k,v);}catch(_){}};
  const petOn   =()=>get(K.on,"1")==="1";
  const petMove =()=>get(K.move,"1")==="1";
  const skinId  =()=>SKINS[get(K.skin,"blue")]?get(K.skin,"blue"):"blue";
  const petSize =()=>{const n=Number(get(K.size,128));return Number.isFinite(n)&&n>=60&&n<=300?n:128;};
  const url=(sk,g,i)=>{try{return chrome.runtime.getURL("assets/pet/"+sk+"/"+g+"_"+i+".webp");}catch(_){return "";}};

  let pet,imgEl,shadow,bub,menu,root,started=false;
  let x=0,y=0,vx=0,vy=0,tx=0,ty=0,face=1,grp="",frm=-1,t=0,bob=0,lastTs=0;
  let state="walk", stateUntil=0, lastEdge="", raf=0, dragging=false, moved=false, dragDX=0, dragDY=0;
  const SPEED=84, ACC=300, DEC=420;

  function meta(){ return SKINS[skinId()].g; }
  function lite(){ try{return document.documentElement.classList.contains("ad88-lite");}catch(_){return false;} }
  function panelOpen(){ const p=document.getElementById("ad88-tool-panel"); return !!p && !p.classList.contains("ad88-hidden"); }
  function botStatus(){ try{ return window.AD88_XNK_BOT && window.AD88_XNK_BOT.status ? window.AD88_XNK_BOT.status() : null; }catch(_){ return null; } }

  function build(){
    if (pet) return;
    pet=document.createElement("div"); pet.id="ad88-pet";
    imgEl=document.createElement("img"); imgEl.alt=""; imgEl.draggable=false; pet.appendChild(imgEl);
    shadow=document.createElement("div"); shadow.id="ad88-pet-shadow";
    bub=document.createElement("div"); bub.id="ad88-pet-bub"; bub.textContent="?";
    menu=document.createElement("div"); menu.id="ad88-pet-menu";
    document.body.appendChild(shadow); document.body.appendChild(pet); document.body.appendChild(bub); document.body.appendChild(menu);
    preload();
    const p=JSON.parse(get(K.pos,"null")||"null");
    x=(p&&Number.isFinite(p.x))?p.x:Math.max(20,innerWidth-260);
    y=(p&&Number.isFinite(p.y))?p.y:Math.max(20,innerHeight-240);
    bindPet();
    show("idle",0);
    newTarget();
  }
  function preload(){
    const g=meta(), sk=skinId();
    for(const k in g) for(let i=1;i<=g[k].n;i++){ const im=new Image(); im.src=url(sk,k,i); }
  }
  function show(g,i){
    const m=meta()[g]; if(!m) return;
    if(grp!==g||frm!==i){ grp=g; frm=i; imgEl.src=url(skinId(),g,i+1); }
    const h=petSize(); pet.style.width=Math.round(h*m.w/m.h)+"px"; pet.style.height=h+"px";
  }
  function viewOf(deg){
    if(deg>=67.5&&deg<=112.5) return ["front",1];
    if(deg<=-67.5&&deg>=-112.5) return ["back",1];
    if(Math.abs(deg)<=22.5) return ["side",1];
    if(Math.abs(deg)>=157.5) return ["side",-1];
    if(deg>22.5&&deg<67.5) return ["q_front",1];
    if(deg>112.5&&deg<157.5) return ["q_front",-1];
    if(deg<-22.5&&deg>-67.5) return ["q_back",1];
    return ["q_back",-1];
  }
  function bounds(){ const w=pet.offsetWidth||110, h=pet.offsetHeight||130; return {L:4,T:4,R:Math.max(8,innerWidth-w-4),B:Math.max(8,innerHeight-h-4)}; }
  function newTarget(){ const b=bounds();
    tx=b.L+30+Math.random()*Math.max(1,(b.R-b.L-60)); ty=b.T+30+Math.random()*Math.max(1,(b.B-b.T-60));
    go("walk",1e9); }
  function go(s,d){ state=s; stateUntil=performance.now()+d; t=0;
    if(s==="think"){ bub.style.display="block"; } else { bub.style.display="none"; } }
  // Khi tool dang xu ly don thi uu tien ngoi laptop; tool dung thi di ngu.
  function restChoice(){
    const st=botStatus();
    if(st && st.currentOrder) return ["laptop",3200];
    if(st && st.running===false) return ["sleep",3600];
    const r=Math.random();
    if(r<.28) return ["laptop",3000];
    if(r<.52) return ["sleep",3200];
    if(r<.74) return ["happy",1800];
    return ["jump",1500];
  }
  function edgeRoutine(){
    go("think",1200);
    setTimeout(()=>{ if(!visible()) return; const [s,d]=restChoice(); go(s,d);
      setTimeout(()=>{ if(!visible()) return; go("idle",700);
        setTimeout(()=>{ if(!visible()) return; afterEdge(); },700); }, d);
    },1200);
  }
  function afterEdge(){ const b=bounds();
    if(lastEdge==="T"||lastEdge==="B"){ tx=(x<(b.L+b.R)/2)?b.R-8:b.L+8; ty=Math.max(b.T,Math.min(b.B,y+(lastEdge==="T"?12:-12))); }
    else { tx=(lastEdge==="L")?b.R-8:b.L+8; ty=Math.max(b.T,Math.min(b.B,y+(Math.random()*140-70))); }
    go("walk",1e9);
  }
  function visible(){ return !!pet && pet.style.display!=="none"; }

  function loop(ts){
    raf=0; if(!visible()) return;
    const dt=Math.min(.05,(ts-lastTs)/1000||0); lastTs=ts;
    const g=meta();
    if(state==="walk"){
      if(!petMove()||lite()){ show("idle",Math.floor((t+=dt*5))%g.idle.n); }
      else{
        const dx=tx-x, dy=ty-y, dist=Math.hypot(dx,dy);
        const want=dist<80?SPEED*Math.max(.16,dist/80):SPEED;
        const ux=dist?dx/dist:0, uy=dist?dy/dist:0;
        const rate=(Math.hypot(ux*want,uy*want)>Math.hypot(vx,vy)?ACC:DEC)*dt;
        vx+=Math.max(-rate,Math.min(rate,ux*want-vx)); vy+=Math.max(-rate,Math.min(rate,uy*want-vy));
        x+=vx*dt; y+=vy*dt;
        const b=bounds(); let hit="";
        if(x<=b.L){x=b.L;hit="L";} else if(x>=b.R){x=b.R;hit="R";}
        if(y<=b.T){y=b.T;hit="T";} else if(y>=b.B){y=b.B;hit="B";}
        const sp=Math.hypot(vx,vy);
        if(sp>6){ const deg=Math.atan2(vy,vx)*180/Math.PI, v=viewOf(deg); face=v[1];
          t+=dt*(sp/SPEED)*8.4; show(v[0],Math.floor(t)%g[v[0]].n); }
        if(hit){ vx=vy=0; lastEdge=hit; show("idle",0); edgeRoutine(); }
        else if(dist<7&&sp<12){ vx=vy=0;
          if(Math.random()<.22){ go("think",1000); setTimeout(()=>{ if(visible()) newTarget(); },1000); }
          else { const [s,d]=restChoice(); go(s,d); setTimeout(()=>{ if(visible()) newTarget(); },d); }
        }
      }
    } else {
      const key = state==="think" ? "idle" : state;
      t += dt*((state==="laptop"||state==="sleep")?5:7);
      show(key, Math.floor(t)%g[key].n);
    }
    bob = (state==="walk" && Math.hypot(vx,vy)>6) ? -Math.abs(Math.sin(t*Math.PI))*2.2 : 0;
    const depth = 0.92+0.14*(y/Math.max(1,innerHeight-pet.offsetHeight));
    pet.style.transform="translate("+x.toFixed(1)+"px,"+(y+bob).toFixed(1)+"px) scale("+depth.toFixed(3)+")";
    imgEl.style.transform="scaleX("+face+")";
    const w=pet.offsetWidth, h=pet.offsetHeight;
    shadow.style.transform="translate("+(x+w/2-30).toFixed(1)+"px,"+(y+h-12).toFixed(1)+"px) scale("+(0.8*depth).toFixed(3)+","+(0.7*depth).toFixed(3)+")";
    bub.style.transform="translate("+(x+w*0.74).toFixed(1)+"px,"+(y-4).toFixed(1)+"px)";
    kick();
  }
  function kick(){ if(!raf && visible()){ lastTs=performance.now(); raf=requestAnimationFrame(loop); } }

  // ====== CHUOT ======
  function openPanel(){ try{ const f=document.getElementById("ad88-tool-fab"); if(f) f.click(); }catch(_){} hideMenu(); sync(); }
  function bindPet(){
    pet.addEventListener("pointerdown",e=>{ if(e.button!==0) return;
      dragging=true; moved=false; dragDX=e.clientX-x; dragDY=e.clientY-y; pet.setPointerCapture(e.pointerId); hideMenu(); });
    pet.addEventListener("pointermove",e=>{ if(!dragging) return;
      const nx=e.clientX-dragDX, ny=e.clientY-dragDY;
      if(Math.abs(nx-x)>3||Math.abs(ny-y)>3) moved=true;
      const b=bounds(); x=Math.max(b.L,Math.min(nx,b.R)); y=Math.max(b.T,Math.min(ny,b.B)); vx=vy=0; });
    pet.addEventListener("pointerup",e=>{ if(!dragging) return; dragging=false;
      set(K.pos,JSON.stringify({x:Math.round(x),y:Math.round(y)}));
      if(moved){ newTarget(); } else { openPanel(); } });
    pet.addEventListener("contextmenu",e=>{ e.preventDefault(); e.stopPropagation(); showMenu(e.clientX,e.clientY); });
    window.addEventListener("resize",()=>{ const b=bounds(); x=Math.max(b.L,Math.min(x,b.R)); y=Math.max(b.T,Math.min(y,b.B)); });
    document.addEventListener("pointerdown",e=>{ if(menu&&!menu.contains(e.target)&&e.target!==pet&&!pet.contains(e.target)) hideMenu(); },true);
    window.addEventListener("AD88_TOOL_SETTING_CHANGED",()=>sync());
  }
  function hideMenu(){ if(menu){ menu.classList.remove("on"); menu.innerHTML=""; } }
  function row(icon,text,extra){ return '<div class="ad88-pet-it"'+(extra||"")+'><i>'+icon+'</i><span>'+text+'</span></div>'; }
  function showMenu(mx,my){
    const sk=skinId();
    menu.innerHTML =
      '<b>AD88 XNK TOOL</b>' +
      row("🗔","Mở bảng tool đẩy đơn",' data-act="open"') +
      '<div class="ad88-pet-sep"></div>' +
      '<div class="ad88-pet-lab">Cỡ robot</div>' +
      '<div class="ad88-pet-sizes">'+SIZES.map(s=>'<button type="button" data-size="'+s[1]+'"'+(petSize()===s[1]?' class="on"':'')+'>'+s[0]+'</button>').join("")+'</div>' +
      '<div class="ad88-pet-lab">Đổi robot</div>' +
      '<div class="ad88-pet-sizes">'+Object.keys(SKINS).map(k=>'<button type="button" data-skin="'+k+'"'+(sk===k?' class="on"':'')+'>'+SKINS[k].name+'</button>').join("")+'</div>' +
      '<div class="ad88-pet-sep"></div>' +
      row(petMove()?"⏸":"▶", petMove()?"Cho robot đứng yên":"Cho robot đi lại",' data-act="move"') +
      row("👁","Ẩn robot (về nút cũ)",' data-act="hide"') +
      row("⚙","Cài đặt",' data-act="set"');
    menu.classList.add("on");
    const w=menu.offsetWidth||210, h=menu.offsetHeight||240;
    menu.style.left=Math.max(4,Math.min(mx,innerWidth-w-6))+"px";
    menu.style.top=Math.max(4,Math.min(my,innerHeight-h-6))+"px";
    menu.onclick=e=>{
      const sz=e.target.closest("[data-size]"), sn=e.target.closest("[data-skin]"), it=e.target.closest("[data-act]");
      if(sz){ set(K.size,sz.dataset.size); show(grp||"idle",frm<0?0:frm); hideMenu(); return; }
      if(sn){ set(K.skin,sn.dataset.skin); grp=""; frm=-1; preload(); show("idle",0); hideMenu(); return; }
      if(!it) return;
      const a=it.dataset.act;
      if(a==="open") openPanel();
      else if(a==="move"){ set(K.move, petMove()?"0":"1"); hideMenu(); if(petMove()) newTarget(); }
      else if(a==="hide"){ set(K.on,"0"); hideMenu(); sync(); }
      else if(a==="set"){ openPanel(); setTimeout(()=>{ const b=document.getElementById("ad88-tool-main"); const s=document.querySelector('#ad88-tool-main .ad88-menu button[data-page="settings"], #ad88-tool-main .ad88-menu button'); if(s) s.click(); },120); }
    };
  }

  // ====== BAT/TAT THEO TRANG THAI BANG TOOL ======
  function sync(){
    const want = petOn() && !panelOpen();
    try{ document.documentElement.classList.toggle("ad88-pet-on", petOn()); }catch(_){}
    if(want){ build(); pet.style.display="block"; shadow.style.display="block"; kick(); }
    else if(pet){ pet.style.display="none"; shadow.style.display="none"; bub.style.display="none"; hideMenu(); if(raf){cancelAnimationFrame(raf);raf=0;} }
  }
  function start(){
    if(started) return; started=true;
    sync();
    // bang tool dong/mo -> bat tat robot
    const p=document.getElementById("ad88-tool-panel");
    if(p && window.MutationObserver){ new MutationObserver(()=>sync()).observe(p,{attributes:true,attributeFilter:["class"]}); }
    document.addEventListener("visibilitychange",()=>{ if(!document.hidden) kick(); });
    setInterval(sync, 2000);
  }
  window.AD88_PET={ sync, on:()=>{set(K.on,"1");sync();}, off:()=>{set(K.on,"0");sync();},
                    setSkin:k=>{if(SKINS[k]){set(K.skin,k);grp="";frm=-1;preload();show("idle",0);}},
                    setSize:n=>{set(K.size,n);show(grp||"idle",0);},
                    setMove:b=>{set(K.move,b?"1":"0");if(b)newTarget();},
                    get:()=>({on:petOn(),skin:skinId(),size:petSize(),move:petMove()}) };
  (function wait(){ if(document.getElementById("ad88-xnk-tool-root")){ root=document.getElementById("ad88-xnk-tool-root"); start(); } else setTimeout(wait,300); })();
})();
