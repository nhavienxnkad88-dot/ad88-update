// AD88 XNK TOOL — UI shell. Core order-processing remains in content.js.
(() => {
  'use strict';
  const S={running:false,processed:0,skipped:0,manual:0,lastOrder:'—',speedHistory:[]};
  const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const q=(sel,root=document)=>root.querySelector(sel);
  const formatAmountInput=(v,currency='VND')=>{
    if(currency==='USDT'){
      let s=String(v??'').replace(/,/g,'.').replace(/[^0-9.]/g,'');
      const parts=s.split('.');
      if(parts.length>2)s=parts[0]+'.'+parts.slice(1).join('');
      return s;
    }
    const d=String(v??'').replace(/[^0-9]/g,'');
    return d?d.replace(/\B(?=(\d{3})+(?!\d))/g,'.'):'';
  };
  const parseAmountInput=(v,currency='VND')=>{
    if(currency==='USDT'){
      const s=String(v??'').replace(/,/g,'.').trim();
      if(s==='')return null;
      const n=Number(s);
      return Number.isFinite(n)?n:null;
    }
    const d=String(v??'').replace(/[^0-9]/g,'');
    return d===''?null:Number(d);
  };
  function getProviderConfigState(){
    let saved={};
    try{saved=JSON.parse(localStorage.getItem('AD88_XNK_PROVIDER_CONFIG')||'{}')||{};}catch{saved={};}
    const out={};
    for(const key of PROVIDERS){
      const def=PROVIDER_CONFIG_DEFAULTS[key]||{};
      let item=saved[key];
      if(!item && typeof AD88_providerCanonical==='function'){
        for(const [savedKey,v] of Object.entries(saved)){
          const canonical=AD88_providerCanonical(savedKey);
          if(canonical===key){item=v;break;}
          if(v && AD88_providerCanonical(v.name||'')===key){item=v;break;}
        }
      }
      out[key]={
        name:def.name||key,
        currency:def.currency||'VND',
        min:item && item.min!==undefined && item.min!==null && item.min!=='' ? item.min : (def.min??null),
        max:item && item.max!==undefined && item.max!==null && item.max!=='' ? item.max : (def.max??null)
      };
    }
    return out;
  }
  function setProviderConfigState(state){
    const out={};
    for(const key of PROVIDERS){
      const def=PROVIDER_CONFIG_DEFAULTS[key]||{};
      const x=state?.[key]||{};
      out[key]={
        name:def.name||key,
        currency:def.currency||'VND',
        min:x.min===undefined?null:x.min,
        max:x.max===undefined?null:x.max
      };
    }
    localStorage.setItem('AD88_XNK_PROVIDER_CONFIG',JSON.stringify(out));
    window.dispatchEvent(new CustomEvent('AD88_PROVIDER_CONFIG_CHANGED',{detail:out}));
  }
  // Provider Registry: toàn bộ tên/currency/MIN/MAX/alias lấy từ provider-registry.js.
  const PROVIDERS = typeof AD88_providerNames === 'function' ? AD88_providerNames() : [];
  const PROVIDER_CONFIG_DEFAULTS = typeof AD88_providerDefinition === 'function'
    ? Object.fromEntries(PROVIDERS.map(k => { const p=AD88_providerDefinition(k)||{}; return [k,{name:p.name||k,currency:p.currency||'VND',min:p.min??null,max:p.max??null}]; }))
    : {};

  const LED_COLORS=[
    {name:'Xanh AD88',value:'#2DB38D'},
    {name:'Cyan',value:'#00E5FF'},
    {name:'Xanh dương',value:'#2196FF'},
    {name:'Tím',value:'#9C5CFF'},
    {name:'Hồng',value:'#FF4FA3'},
    {name:'Đỏ',value:'#FF4D6D'},
    {name:'Cam',value:'#FF9D3D'},
    {name:'Vàng',value:'#FFD43B'},
    {name:'Xanh lá',value:'#35E07F'},
    {name:'Trắng',value:'#F4FAFF'},
    {name:'Xanh băng',value:'#7DD3FC'},
    {name:'Tím hồng',value:'#D946EF'}
  ];
  function getProviderState(){
    try{return JSON.parse(localStorage.getItem('AD88_XNK_PROVIDER_TOGGLES')||'{}')}catch{return {}}
  }
  function setProviderState(s){localStorage.setItem('AD88_XNK_PROVIDER_TOGGLES',JSON.stringify(s));window.dispatchEvent(new CustomEvent('AD88_PROVIDER_TOGGLES_CHANGED',{detail:s}));}
  function getLedColor(){return localStorage.getItem('AD88_XNK_LED_COLOR')||'#2DB38D'}
  function setLedColor(c){localStorage.setItem('AD88_XNK_LED_COLOR',c);document.documentElement.style.setProperty('--ad88-led',c);window.dispatchEvent(new CustomEvent('AD88_LED_COLOR_CHANGED',{detail:c}));}
  function getLedSettings(){
    const num=(k,d)=>{const v=Number(localStorage.getItem(k));return Number.isFinite(v)?v:d};
    return {brightness:num('AD88_XNK_LED_BRIGHTNESS',90),speed:num('AD88_XNK_LED_SPEED',50),effect:localStorage.getItem('AD88_XNK_LED_EFFECT')||'single',enabled:localStorage.getItem('AD88_XNK_LED_ENABLED')!=='0',thick:num('AD88_XNK_LED_THICK',60)};
  }
  function setLedSetting(k,v){localStorage.setItem(k,String(v));window.dispatchEvent(new CustomEvent('AD88_LED_SETTINGS_CHANGED',{detail:{key:k,value:v}}));}
  /* ===== Giao diện banner (chỉ đổi hình nền tiêu đề; logo, chữ, giờ, font, màu giữ nguyên) ===== */
  const BANNER_THEMES=[
    {id:'christmas',name:'Giáng sinh',desc:'Giao diện hiện tại (mặc định)',file:'assets/ad88-header-christmas.svg'},
    {id:'circuit',name:'Mạch điện tử',desc:'Mạch xanh ngọc, xung điện chạy',file:'assets/ad88-header-circuit.svg'},
    {id:'city',name:'Thành phố pháo hoa',desc:'Thành phố neon, pháo hoa bắn liên tục',file:'assets/ad88-header-city.svg'}
  ];
  function getBannerThemeId(){let v='';try{v=localStorage.getItem('AD88_XNK_BANNER_THEME')||'';}catch(e){}return BANNER_THEMES.some(t=>t.id===v)?v:'christmas';}
  function setBannerThemeId(id){try{localStorage.setItem('AD88_XNK_BANNER_THEME',id);}catch(e){}window.dispatchEvent(new CustomEvent('AD88_BANNER_THEME_CHANGED',{detail:{id}}));}
  function applyBannerTheme(root){
    const hd=(root||document).querySelector('.ad88-head.new-head');if(!hd)return;
    const t=BANNER_THEMES.find(x=>x.id===getBannerThemeId())||BANNER_THEMES[0];
    hd.style.setProperty('--ad88-head-art',`url('${chrome.runtime.getURL(t.file)}')`);
    hd.dataset.banner=t.id;
  }
  const TOOL_SETTINGS_DEFAULTS={auto:true,bank:true,unlock:true,returnUnlock:true,lockWatchdog:true,bankBadSkip:true,usdt:true,scanTop:true,scanBottom:false,noticeClose:true,autoReload:false,dayPause:true,fabAlways:true,logDetail:false,bankPrefetchNext:false,maintCancel:false,sound:true,returnReasonLog:true,lite:false};
  function getToolSettings(){
    const out={};
    for(const [k,d] of Object.entries(TOOL_SETTINGS_DEFAULTS)){
      const raw=localStorage.getItem('AD88_XNK_SETTING_'+k);
      out[k]=raw===null?d:raw==='true';
    }
    return out;
  }
  function getToolPanelOpen(){
    const raw=localStorage.getItem('AD88_XNK_TOOL_PANEL_OPEN');
    return raw===null ? true : raw==='true';
  }
  // 1.4.207: giao diện thu nhỏ thành biểu tượng tròn → ngừng vẽ lại bảng/thống kê/số dư (mở lại thì vẽ ngay).
  function panelHidden(){try{const p=document.getElementById('ad88-tool-panel');return !!p&&p.classList.contains('ad88-hidden');}catch(_){return false;}}
  function setToolPanelOpen(v){
    localStorage.setItem('AD88_XNK_TOOL_PANEL_OPEN',String(!!v));
  }
  // 1.4.163: CHẾ ĐỘ NHẸ (mặc định TẮT). Chỉ tắt hiệu ứng giao diện và giảm tần suất vẽ lại; KHÔNG đụng tới xử lý đơn.
  function applyLiteMode(){try{
    const on=!!getToolSettings().lite;document.documentElement.classList.toggle('ad88-lite',on);
    if(on){const root=document.getElementById('ad88-xnk-tool-root');const sv=root&&root.querySelector('#ad88-stats-view');
      if(sv&&!sv.classList.contains('ad88-hidden')){sv.classList.add('ad88-hidden');root.querySelector('#ad88-home-content')?.classList.remove('ad88-hidden');root.querySelector('#ad88-tool-main')?.classList.remove('stats-mode');}}
    else if(typeof renderStatus==='function'){setTimeout(()=>{try{renderStatus();}catch(_){}},0);}
  }catch(_){}}
  // 1.4.233: ĐÃ BỎ HẲN phần số dư nhà thứ 3 (nút SỐ DƯ, bảng số dư, mục cài đặt số dư). Lớp ad88-bal-off giữ để hàng nút xếp 5 ô.
  try{document.documentElement.classList.add('ad88-bal-off');}catch(_){}
  // 1.4.236: ĐÃ BỎ HẲN robot đi lại (pet.js) cho nhẹ → gỡ lớp robot cũ + dọn cài đặt robot
  try{document.documentElement.classList.toggle('ad88-fab-always',!!getToolSettings().fabAlways);}catch(_){} // 1.4.236: công tắc Luôn hiện viên thuốc
  try{document.documentElement.classList.remove('ad88-pet-on');['AD88_PET_ON','AD88_PET_SKIN','AD88_PET_SIZE','AD88_PET_MOVE','AD88_PET_POS'].forEach(k=>localStorage.removeItem(k));}catch(_){}
  // dọn dữ liệu số dư cũ còn lưu trong trình duyệt (giữ nguyên "nhà ưu tiên" vì phần chọn nhà khi đẩy đơn vẫn dùng)
  try{['AD88_XNK_PROVIDER_BALANCES','AD88_XNK_BALFEED_AT','AD88_XNK_BALREFRESH_AT','AD88_XNK_BALANCE_THRESHOLDS','AD88_XNK_BALANCE_HIGH','AD88_XNK_BALANCE_STYLE','AD88_XNK_BALANCE_REFRESH_SEC','AD88_XNK_SETTING_balanceRefresh','AD88_XNK_SETTING_balanceScan','AD88_XNK_SETTING_balanceFeed'].forEach(k=>localStorage.removeItem(k));}catch(_){}
  try{applyLiteMode();window.addEventListener('AD88_TOOL_SETTING_CHANGED',e=>{if(!e.detail||e.detail.key==='lite')applyLiteMode();});}catch(_){}
  // 1.4.210: THEME SÁNG / TỐI / TỰ ĐỘNG (mặc định TỐI như cũ). Chỉ đổi màu giao diện của Tool, không đụng xử lý đơn.
  const THEME_LABELS={dark:'Tối',light:'Sáng',auto:'Tự động (6h–18h sáng)'};
  function getThemeMode(){try{const v=localStorage.getItem('AD88_XNK_THEME_MODE');return (v==='light'||v==='auto')?v:'dark';}catch(_){return 'dark';}}
  function themeIsLight(mode){if(mode==='light')return true;if(mode==='auto'){const h=new Date().getHours();return h>=6&&h<18;}return false;}
  function applyTheme(){try{document.documentElement.classList.toggle('ad88-theme-light',themeIsLight(getThemeMode()));}catch(_){}}
  function setThemeMode(m){try{localStorage.setItem('AD88_XNK_THEME_MODE',m);}catch(_){}applyTheme();}
  try{applyTheme();setInterval(()=>{if(getThemeMode()==='auto')applyTheme();},300000);}catch(_){}
  function setToolSetting(k,v){
    localStorage.setItem('AD88_XNK_SETTING_'+k,String(!!v));
    window.dispatchEvent(new CustomEvent('AD88_TOOL_SETTING_CHANGED',{detail:{key:k,value:!!v}}));
  }
  function playNotice(){
    try{
      if(!getToolSettings().sound)return;
      const Ctx=window.AudioContext||window.webkitAudioContext;
      if(!Ctx)return;
      const ctx=new Ctx(); const osc=ctx.createOscillator(); const gain=ctx.createGain();
      osc.type='sine'; osc.frequency.value=880; gain.gain.setValueAtTime(.045,ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(.001,ctx.currentTime+.16); osc.connect(gain);gain.connect(ctx.destination);
      osc.start();osc.stop(ctx.currentTime+.16);
    }catch{}
  }

  function healthStatus(){
    try{return window.AD88_XNK_BOT?.status?.()?.health||{};}catch{return {}}
  }
  function fmtMs(v){
    const n=Number(v);
    if(!Number.isFinite(n)) return '—';
    if(n<1000) return Math.round(n)+'ms';
    return (n/1000).toFixed(n>=10000?0:1)+'s';
  }
  function fmtUptime(v){
    const n=Math.max(0,Math.floor(Number(v)||0)/1000);
    const s=Math.floor(n%60), m=Math.floor(n/60)%60, h=Math.floor(n/3600);
    return [h,m,s].map((x,i)=>i===0?String(x).padStart(2,'0'):String(x).padStart(2,'0')).join(':');
  }
  function healthTone(h){
    if(h.state==='ERROR') return ['bad','LỖI'];
    if(h.state==='WARNING') return ['warn','CẢNH BÁO'];
    if(h.state==='IDLE') return ['idle','ĐANG CHỜ'];
    return ['good','TỐT'];
  }
  function renderHealthPage(el){
    const h=healthStatus(), [tone,label]=healthTone(h), avg=fmtMs(h.avgProcessMs), p95=fmtMs(h.p95Ms), p99=fmtMs(h.p99Ms);
    el.innerHTML=head('Sức khỏe & tốc độ')+`<div class="ad88-health-page ad88-detail-page"><div class="health-hero ${tone}"><span class="health-pulse"></span><div><b>${label}</b><small>${h.auto?'Tool đang tự động xử lý':'Tool chưa chạy tự động'}</small></div><strong>${h.queue||0}<small>đơn chờ</small></strong></div><div class="health-grid ad88-detail-grid"><div><span>Heartbeat</span><b>${fmtMs(h.heartbeatMs)}</b></div><div><span>Last action</span><b>${fmtMs(h.lastActionMs)}</b></div><div><span>Website / DOM</span><b>${h.currentStep||'Ready'}</b></div><div><span>API TB</span><b>${fmtMs(h.avgApiMs)}</b></div><div><span>Lỗi</span><b class="${h.errors?'bad-t':''}">${h.errors||0}</b></div><div><span>Timeout</span><b class="${h.timeouts?'bad-t':''}">${h.timeouts||0}</b></div></div><div class="health-section-title ad88-detail-section-title">TỐC ĐỘ XỬ LÝ</div><div class="speed-grid ad88-detail-grid"><div><span>Trung bình</span><b>${avg}</b></div><div><span>P50</span><b>${fmtMs(h.p50Ms)}</b></div><div><span>P95</span><b>${p95}</b></div><div><span>P99</span><b>${p99}</b></div><div><span>Nhanh nhất</span><b>${fmtMs(h.fastestMs)}</b></div><div><span>Chậm nhất</span><b>${fmtMs(h.slowestMs)}</b></div></div><div class="health-current ad88-detail-current"><div><span>Đơn hiện tại</span><b>${esc(h.currentOrder||'—')}</b></div><div><span>Bước hiện tại</span><b>${esc(h.currentStep||'Sẵn sàng')}</b></div><div><span>Thời gian đơn</span><b>${fmtMs(h.currentElapsedMs)}</b></div><div><span>Uptime</span><b>${fmtUptime(h.uptimeMs)}</b></div></div>${h.lastError?`<div class="health-error">⚠ ${esc(h.lastError)}</div>`:''}<div class="health-note ad88-detail-note">Đánh giá dựa trên tiến trình thực tế, thời gian xử lý, heartbeat, API, timeout và trạng thái DOM.</div></div>`;
    q('[data-back]',el).onclick=back;
  }

  function create(){
    if(q('#ad88-xnk-tool-root')) return;
    const savedAction=Number(localStorage.getItem('AD88_XNK_CFG_ACTION_TIMEOUT'));
    const savedBank=Number(localStorage.getItem('AD88_XNK_CFG_BANK_TIMEOUT'));
    const savedDelay=Number(localStorage.getItem('AD88_XNK_CFG_NEXT_DELAY'));
    if(window.XNK_CONFIG){
      if(Number.isFinite(savedAction)&&savedAction>0) window.XNK_CONFIG.actionTimeoutMs=savedAction;
      if(Number.isFinite(savedBank)&&savedBank>0) window.XNK_CONFIG.bankCheckTimeoutMs=savedBank;
      if(Number.isFinite(savedDelay)&&savedDelay>0) window.XNK_CONFIG.nextOrderDelayMs=savedDelay;
      const bool=(k,d)=>{const v=localStorage.getItem(k);return v===null?d:v==='true'};
      const num=(k,d)=>{const v=Number(localStorage.getItem(k));return Number.isFinite(v)?v:d};
      window.XNK_CONFIG.autoSync=bool('AD88_XNK_AUTO_SYNC',window.XNK_CONFIG.autoSync!==false);
      window.XNK_CONFIG.pollMinMs=num('AD88_XNK_POLL_MIN',window.XNK_CONFIG.pollMinMs||100);
      window.XNK_CONFIG.pollMaxMs=num('AD88_XNK_POLL_MAX',window.XNK_CONFIG.pollMaxMs||650);
      window.XNK_CONFIG.nextOrderDelayMinMs=num('AD88_XNK_DELAY_MIN',window.XNK_CONFIG.nextOrderDelayMinMs||350);
      window.XNK_CONFIG.nextOrderDelayMaxMs=num('AD88_XNK_DELAY_MAX',window.XNK_CONFIG.nextOrderDelayMaxMs||3000);
    }
    document.documentElement.style.setProperty('--ad88-led',getLedColor());
    const root=document.createElement('div');root.id='ad88-xnk-tool-root';root.dataset.ui='new';
    root.innerHTML=`
      <button id="ad88-tool-fab" title="AD88 XNK TOOL"><em class="fab-led"></em><span class="fab-name">AD88</span><span class="fab-txt"><small class="fab-state" id="ad88-fab-state">Đang chạy</small><small class="fab-sub" id="ad88-fab-sub" hidden></small></span></button>
      <section id="ad88-tool-panel" class="${getToolPanelOpen()?'':'ad88-hidden'}">
        <div class="ad88-resize-handle ad88-resize-br" id="ad88-resize-handle"></div><div class="ad88-resize-handle ad88-resize-tl" id="ad88-resize-handle-tl"></div>
        <header class="ad88-head new-head" style="--ad88-head-art:url('${chrome.runtime.getURL('assets/ad88-header-christmas.svg')}');--ad88-logo:url('${chrome.runtime.getURL('assets/ad88-logo.png')}')">
          <div class="ad88-brand new-brand"><strong class="ad88-logo-text"><i>AD</i><b>88</b></strong><span><b>XNK TOOL</b><small>v${AD88_VERSION}</small></span></div>
          <div class="new-head-status"><span class="status-dot"></span><div><b id="tool-run-status">Đang chạy</b><small id="tool-runtime">00:00:00</small></div></div>
          <div class="ad88-head-actions"><button data-act="min" title="Thu gọn">−</button><button data-act="close" title="Đóng">×</button></div>
        <div class="ad88-snow" aria-hidden="true"><i></i><i></i><i></i></div></header>
        <div id="ad88-led-palette" class="ad88-led-palette ad88-hidden"><div class="ad88-led-palette-title">MÀU ĐÈN LED</div><div class="ad88-led-swatches">${LED_COLORS.map(c=>`<button type="button" data-led="${c.value}" title="${c.name}" aria-label="${c.name}" style="--c:${c.value}"><span></span></button>`).join('')}</div></div>
        <main id="ad88-tool-main" class="new-main">
          <div id="ad88-daypause-banner" class="ad88-daypause-banner" hidden></div>
          <div id="ad88-maint-banner" class="ad88-maint-banner" hidden>🛠 ĐANG BẬT BẢO TRÌ NGÂN HÀNG — mọi đơn ngân hàng sẽ bị buộc hủy. Tắt trong Cài đặt khi ngân hàng hoạt động lại.</div>
          <div class="new-actions"><button class="run" data-act="run" type="button"><span>▶</span><b>CHẠY</b></button><button class="stop" data-act="stop" type="button"><span>■</span><b>DỪNG</b></button><button data-page="settings" title="Cài đặt"><svg class="na-ic" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 6h10M18 6h2M4 12h4M12 12h8M4 18h12"/><circle cx="16" cy="6" r="2"/><circle cx="10" cy="12" r="2"/><circle cx="18" cy="18" r="2"/></svg><small>Cài đặt</small></button><button data-page="log" title="Check thông tin"><svg class="na-ic" viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4M8 11l2 2 4-4"/></svg><small>Check thông tin</small></button><button data-act="stats" title="Thống kê"><svg class="na-ic" viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="12" width="4" height="8" rx="1"/><rect x="10" y="4" width="4" height="16" rx="1"/><rect x="17" y="9" width="4" height="11" rx="1"/></svg><small>THỐNG KÊ</small></button></div>
          <div class="new-home-content" id="ad88-home-content">
          <div class="new-dashboard">
            <section class="new-card health-card"><div class="new-card-title"><span>❤</span><b>BẢNG SỨC KHỎE</b><i>?</i><strong id="tool-health-label">TỐT</strong></div>
              <div class="health-list">
                <div><span>▣</span><label>Tool</label><b id="new-health-tool">Đang chạy</b></div>
                <div><span>◎</span><label>Kết nối website</label><b id="new-health-web">Ổn định</b></div>
                <div><span>▣</span><label>API</label><b id="new-health-api">—</b></div>
                <div><span>▣</span><label>DOM</label><b id="new-health-dom">Ready</b></div>
                <div><span>◉</span><label>Queue</label><b id="new-health-queue">0 đơn</b></div>
                <div><span>↻</span><label>Đang xử lý</label><b id="new-health-order">—</b></div>
                <div><span>»</span><label>Bước hiện tại</label><b id="new-health-step">Sẵn sàng</b></div>
                <div><span>◷</span><label>Last action</label><b id="new-health-last">—</b></div>
                <div><span>△</span><label>Lỗi / Timeout</label><b id="new-health-errors">0 / 0</b></div>
              </div>
            </section>
            <section class="new-card speed-card"><div class="new-card-title"><span>◔</span><b>TỐC ĐỘ XỬ LÝ</b><i>?</i><select id="new-speed-window"><option>10 phút gần nhất</option><option>30 phút gần nhất</option><option>Hôm nay</option></select></div>
              <div class="speed-chart-wrap"><div class="speed-axis">Đơn/phút</div><svg id="tool-speed-chart" viewBox="0 0 220 92" preserveAspectRatio="none" aria-label="Biểu đồ tốc độ"><defs><linearGradient id="speedFill" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stop-color="#2DB38D" stop-opacity=".42"/><stop offset="1" stop-color="#2DB38D" stop-opacity="0"/></linearGradient></defs><path id="speed-area" fill="url(#speedFill)" d="M0 80 L0 80 L220 80 Z"></path><polyline id="speed-line" fill="none" stroke="#2DB38D" stroke-width="2" points="0,80 220,80"></polyline><g id="speed-dots"></g></svg><div class="speed-times"><span>10:40</span><span>10:42</span><span>10:44</span><span>10:46</span><span>10:48</span><span>10:50</span></div></div>
              <div class="speed-metrics"><div><span>⚡</span><b id="tool-speed">—</b><small>đơn/phút</small></div><div><span>◷</span><b id="tool-avg">—</b><small>TB mỗi đơn</small></div><div><span>▶</span><b id="tool-fastest">—</b><small>Nhanh nhất</small></div><div><span>⌛</span><b id="tool-slowest">—</b><small>Chậm nhất</small></div></div>
            </section>
          </div>
          <section class="new-card current-card"><div class="new-card-title"><span>◌</span><b>ĐƠN HIỆN TẠI</b><button data-page="health">Chi tiết <em>›</em></button></div><div class="current-grid"><div><small>Mã đơn</small><b id="new-order-id">—</b></div><div><small>Số tiền</small><b id="new-order-amount">—</b><em id="new-order-currency">VNĐ</em></div><div><small>Nhà thứ ba</small><b id="new-order-provider">—</b></div><div><small>Thời gian</small><b id="new-order-time">00:00</b></div><div><small>Trạng thái</small><b class="current-status" id="new-order-status">Đang kiểm tra</b></div></div></section>
          <div class="new-hidden-stats" aria-hidden="true"><span id="tool-order">—</span><span id="tool-done">0</span><span id="tool-skip">0</span><span id="tool-manual">0</span></div>
          </div>
          <section id="ad88-stats-view" class="ad88-stats-view ad88-hidden" aria-label="Thống kê xử lý"></section>
          <div class="new-mini-footer"><button data-page="providers">Nhà thứ 3</button><button data-page="about">Thông tin Tool</button><span>v${AD88_VERSION}</span></div>
        </main>
        <section id="ad88-tool-sub" class="ad88-hidden"></section>
      </section>`;
    document.body.appendChild(root);
    ensureLedFrame(q('#ad88-tool-panel',root));
    restorePosition(root);bind(root);setupFabReveal(root);refreshCore();
    applyBannerTheme(root);window.addEventListener('AD88_BANNER_THEME_CHANGED',()=>applyBannerTheme(root));
    const panel=q('#ad88-tool-panel',root);
    if(panel && 'ResizeObserver' in window){const ro=new ResizeObserver(()=>{updateNewUiScale(panel);updateLedFrame(panel);});ro.observe(panel);}
    window.addEventListener('AD88_LED_COLOR_CHANGED',()=>updateLedFrame(panel));
    window.addEventListener('AD88_LED_SETTINGS_CHANGED',()=>updateLedFrame(panel));
    window.addEventListener('resize',()=>{updateNewLayout(panel);updateLedFrame(panel);clampRootToViewport(root,true);savePosition(root);});
  }
  function ensureLedFrame(panel){
    if(!panel || panel.querySelector('.ad88-led-frame')) return;
    const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');
    svg.classList.add('ad88-led-frame');
    svg.setAttribute('aria-hidden','true');
    panel.appendChild(svg);
    updateLedFrame(panel);
  }
  // LED viền v2: nét sắc (không dùng blur filter nên không bị lem), đuôi sao chổi chuyển mờ dần,
  // vầng sáng bằng lớp nét rộng trong suốt. Mỗi hiệu ứng được dựng riêng.
  function buildLedMarkup(w,h,r,ls){
    const bright=Math.max(.1,Math.min(5,ls.brightness/100));
    const clip=v=>Math.max(0,Math.min(1,v));
    const D=Math.max(1.2,5.5-(Math.max(10,Math.min(100,ls.speed))/100)*4.5);
    const sw=(2.6+Math.min(bright,2)*.4).toFixed(2);
    const geo=`x="1.5" y="1.5" width="${Math.max(1,w-3)}" height="${Math.max(1,h-3)}" rx="${Math.max(1,r-1)}" ry="${Math.max(1,r-1)}" pathLength="1000" fill="none" vector-effect="non-scaling-stroke"`;
    const rect=(cls,extra,style)=>`<rect class="led-seg ${cls}" ${geo} ${extra} style="${style}"/>`;
    let out='';
    const track=op=>rect('led-track',`stroke-width="1"`,`stroke:currentColor;opacity:${clip(op*bright).toFixed(2)}`);
    const comet=(scale,dur,delay,rev,pieces,glow,col)=>{const C=col||'currentColor';
      const L=[260,190,130,85,50,24].slice(6-pieces).map(v=>Math.round(v*scale));
      const O=[.16,.26,.4,.58,.8,1].slice(6-pieces);
      let m='';
      L.forEach((len,i)=>{
        const o=rev?0:len, anim=rev?'led-run-rev':'led-run';
        const st=`stroke:${C};stroke-dasharray:${len} ${1000-len};--o:${o}px;animation:${anim} ${dur}s linear ${-delay}s infinite`;
        if(glow) m+=rect('led-glow',`stroke-width="9" stroke-linecap="round"`,st+`;opacity:${clip(O[i]*.22*bright).toFixed(2)}`);
        m+=rect('led-core',`stroke-width="${sw}" stroke-linecap="round"`,st+`;opacity:${clip(O[i]*(.55+.45*bright)).toFixed(2)}`);
      });
      const hl=Math.max(4,Math.round(12*scale));
      m+=rect('led-head',`stroke-width="1.6" stroke-linecap="round"`,`stroke:#fff;stroke-dasharray:${hl} ${1000-hl};--o:${hl}px;animation:led-run ${dur}s linear ${-delay}s infinite;opacity:${clip(.9*Math.min(1,bright)).toFixed(2)}`);
      return m;
    };
    switch(ls.effect==='two'?'two-way':ls.effect){
      case 'two-way': out=track(.16)+comet(.8,D,0,false,6,true)+comet(.8,D,D/2,true,6,true);break;
      case 'multi': out=track(.16)+[0,1,2,3].map(i=>comet(.42,D*1.15,D*1.15*i/4,false,4,false)).join('');break;
      case 'comet': out=track(.14)+comet(1.9,D*1.25,0,false,6,true);break;
      case 'pulse': out=rect('led-glow',`stroke-width="7"`,`stroke:currentColor;opacity:${clip(.2*bright)};animation:led-breathe ${Math.max(1.2,D*.6)}s ease-in-out infinite`)+rect('led-core',`stroke-width="${sw}"`,`stroke:currentColor;animation:led-breathe ${Math.max(1.2,D*.6)}s ease-in-out infinite`);break;
      case 'rainbow': {
        const N=12,len=1000/N;
        out=Array.from({length:N},(_,i)=>rect('led-core',`stroke-width="${sw}"`,`stroke:hsl(${i*360/N},95%,${Math.round(52+Math.min(bright,1.5)*6)}%);stroke-dasharray:${len+2} ${1000-len-2};--o:${-i*len}px;animation:led-run ${D*1.6}s linear infinite;opacity:${clip(.55+.45*bright)}`)).join('');
        out=track(.10)+out;break;}
      case 'wave': {
        const N=14,len=1000/N;
        out=track(.10)+Array.from({length:N},(_,i)=>rect('led-core',`stroke-width="${sw}"`,`stroke:currentColor;stroke-dasharray:${len-3} ${1000-len+3};stroke-dashoffset:${-i*len}px;animation:led-wave ${D*.9}s ease-in-out ${-(i/N)*D*.9}s infinite`)).join('');break;}
      case 'spark': {
        const cfg=[[1,0,false],[1.35,.4,true],[.8,.7,false]];
        out=track(.14)+cfg.map(([k,d,rev])=>{const len=14,dur=D*k*1.1;const st=`stroke:currentColor;stroke-dasharray:${len} ${1000-len};--o:${rev?0:len}px;animation:${rev?'led-run-rev':'led-run'} ${dur}s linear ${-d*dur}s infinite`;
          return rect('led-glow',`stroke-width="8" stroke-linecap="round"`,st+`;opacity:${clip(.3*bright)}`)+rect('led-core',`stroke-width="${sw}" stroke-linecap="round"`,st)+rect('led-head',`stroke-width="1.2" stroke-linecap="round"`,`stroke:#fff;stroke-dasharray:5 995;--o:${rev?0:5}px;animation:${rev?'led-run-rev':'led-run'} ${dur}s linear ${-d*dur}s infinite`);}).join('');break;}
      case 'chase': out=track(.14)+['#ff4d6d','#ffd34a','#35c6ff'].map((c,i)=>comet(.7,D*1.2,D*1.2*i/3,false,5,true,c)).join('');break;
      case 'dual': out=track(.14)+comet(.9,D,0,false,6,true)+comet(.9,D,D/2,true,6,true,'#ff4d9a');break;
      case 'snake': out=track(.14)+comet(3.2,D*1.5,0,false,6,true);break;
      case 'fire': out=track(.12)+comet(1.3,D*.9,0,false,6,true,'#ff4a1c')+comet(.85,D*.9,D*.22,false,5,true,'#ffa526')+comet(.5,D*.9,D*.4,false,4,true,'#ffe27a');break;
      case 'marquee': {const g=`stroke-linecap="round" stroke-width="3.4"`;out=track(.12)+rect('led-glow',`stroke-linecap="round" stroke-width="8"`,`stroke:currentColor;stroke-dasharray:0.1 8.9;opacity:${clip(.25*bright)};animation:led-march ${D*.5}s linear infinite`)+rect('led-core',g,`stroke:currentColor;stroke-dasharray:0.1 8.9;animation:led-march ${D*.5}s linear infinite;opacity:${clip(.6+.4*bright)}`);break;}
      case 'xmas': {const cols=['#ff3b3b','#ffd34a','#3be07a','#35c6ff'];out=track(.12)+cols.map((c,i)=>rect('led-core',`stroke-linecap="round" stroke-width="4"`,`stroke:${c};stroke-dasharray:0.1 35.9;stroke-dashoffset:${-i*9}px;filter:none;animation:led-xblink ${D*.5}s ease-in-out ${-i*D*.125}s infinite`)+rect('led-glow',`stroke-linecap="round" stroke-width="9"`,`stroke:${c};stroke-dasharray:0.1 35.9;stroke-dashoffset:${-i*9}px;opacity:.28;animation:led-xblink ${D*.5}s ease-in-out ${-i*D*.125}s infinite`)).join('');break;}
      case 'heart': out=rect('led-glow',`stroke-width="8"`,`stroke:currentColor;opacity:${clip(.22*bright)};animation:led-beat ${D*.5}s ease-in-out infinite`)+rect('led-core',`stroke-width="${sw}"`,`stroke:currentColor;animation:led-beat ${D*.5}s ease-in-out infinite`);break;
      case 'corner': {const per=2*(w+h);const pos=[(w)/per,(w+h)/per,(2*w+h)/per,1];out=track(.14)+pos.map((q,i)=>{const len=90,off=-(q*1000-len/2);const st=`stroke:currentColor;stroke-dasharray:${len} ${1000-len};stroke-dashoffset:${off}px;animation:led-corner ${D*.9}s ease-in-out ${-i*D*.9/4}s infinite`;return rect('led-glow',`stroke-width="9" stroke-linecap="round"`,st+`;opacity:0`)+rect('led-core',`stroke-width="${sw}" stroke-linecap="round"`,st);}).join('');break;}
      case 'static': out=rect('led-glow',`stroke-width="7"`,`stroke:currentColor;opacity:${clip(.16*bright)}`)+rect('led-core',`stroke-width="${sw}"`,`stroke:currentColor;opacity:${clip(.55+.45*bright)}`);break;
      default: out=track(.16)+comet(1,D,0,false,6,true);
    }
    const T=Math.max(.3,Math.min(2,(ls.thick||60)/100));
    return out.replace(/stroke-width="([\d.]+)"/g,(m,v)=>`stroke-width="${Math.max(.5,v*T).toFixed(2)}"`);
  }
  function updateLedFrame(panel){
    if(!panel) return;
    const svg=panel.querySelector('.ad88-led-frame');
    if(!svg) return;
    const w=Math.max(20,panel.clientWidth),h=Math.max(20,panel.clientHeight);
    const radius=Math.min(14,Math.max(8,parseFloat(getComputedStyle(panel).borderRadius)||12));
    const ls=getLedSettings();
    const color=getComputedStyle(document.documentElement).getPropertyValue('--ad88-led').trim()||getLedColor();
    const key=[w,h,radius,ls.brightness,ls.speed,ls.effect,color,ls.enabled,ls.thick].join('|');
    svg.setAttribute('viewBox',`0 0 ${w} ${h}`);svg.setAttribute('width',w);svg.setAttribute('height',h);
    if(svg.dataset.key===key) return;
    svg.dataset.key=key;
    svg.style.color=color;
    { const b=Math.max(.1,Math.min(3,ls.brightness/100)); svg.style.filter=b>1?`brightness(${(1+(b-1)*.45).toFixed(2)}) saturate(${(1+(b-1)*.3).toFixed(2)}) drop-shadow(0 0 ${((b-1)*2.2).toFixed(1)}px ${color})`:''; }
    svg.style.display=ls.enabled?'':'none';
    svg.innerHTML=ls.enabled?buildLedMarkup(w,h,radius,ls):'';
  }

  // 1.4.214: viên thuốc hiện khi chuột lại gần (bán kính 150px) + tự hiện 4 giây sau khi tải trang
  // để người dùng biết nó đang nằm ở đâu. Không động tới xử lý đơn / Bank Check.
  function setupFabReveal(root){
    const fab=q('#ad88-tool-fab',root); if(!fab) return;
    let rect=null,rectAt=0,last=0,peekT=null;
    const invalidate=()=>{rect=null;};
    const getRect=()=>{const n=Date.now();if(!rect||n-rectAt>700){const r=fab.getBoundingClientRect();if(!r.width)return null;rect=r;rectAt=n;}return rect;};
    try{
      window.addEventListener('resize',invalidate,{passive:true});
      window.addEventListener('scroll',invalidate,{passive:true});
      document.addEventListener('mousemove',e=>{
        const n=Date.now(); if(n-last<90) return; last=n;
        const r=getRect(); if(!r) return;
        const dx=Math.max(r.left-e.clientX,0,e.clientX-r.right);
        const dy=Math.max(r.top-e.clientY,0,e.clientY-r.bottom);
        fab.classList.toggle('fab-near',(dx*dx+dy*dy)<=22500);
      },{passive:true});
    }catch(_){}
    const peek=(ms)=>{try{fab.classList.add('fab-peek');clearTimeout(peekT);peekT=setTimeout(()=>fab.classList.remove('fab-peek'),ms||4000);}catch(_){}};
    window.AD88_FAB_PEEK=peek; // chi dung khi go tay trong Console, khong tu chay
  }
  // 1.4.214: bảo đảm nút thu nhỏ LUÔN nằm trong màn hình. Trước đây vị trí cũ lưu theo
  // góc phải-dưới của chấm tròn 54px; viên thuốc rộng ~133px nên có máy bị đẩy ra ngoài mép
  // màn hình và không bao giờ thấy. Hàm này đo đúng nút rồi kéo cả khung vào trong.
  function ensureFabVisible(root){
    try{
      if(!panelHidden()) return;
      const fab=q('#ad88-tool-fab',root); if(!fab) return;
      const r=fab.getBoundingClientRect(); if(!r.width||!r.height) return;
      const m=6,vw=window.innerWidth,vh=window.innerHeight;
      let dx=0,dy=0;
      if(r.left<m) dx=m-r.left; else if(r.right>vw-m) dx=(vw-m)-r.right;
      if(r.top<m) dy=m-r.top; else if(r.bottom>vh-m) dy=(vh-m)-r.bottom;
      if(!dx&&!dy) return;
      const cur=root.getBoundingClientRect();
      root.style.left=Math.round(cur.left+dx)+'px';
      root.style.top=Math.round(cur.top+dy)+'px';
      root.style.right='auto';root.style.bottom='auto';
      saveFabAnchor(root);
      try{localStorage.setItem('AD88_XNK_TOOL_POSITION',JSON.stringify({x:Math.round(cur.left+dx),y:Math.round(cur.top+dy)}));}catch(_){}
    }catch(_){}
  }
  function clampRootToViewport(root, preferPanel=false){
    const panel=q('#ad88-tool-panel',root);
    const fab=q('#ad88-tool-fab',root);
    const target=preferPanel && panel && !panel.classList.contains('ad88-hidden') ? panel : (panel && !panel.classList.contains('ad88-hidden') ? panel : fab);
    if(!target)return;
    const rr=root.getBoundingClientRect();
    const tr=target.getBoundingClientRect();
    let dx=0,dy=0;
    const margin=6;
    if(tr.left < margin) dx=margin-tr.left;
    else if(tr.right > window.innerWidth-margin) dx=(window.innerWidth-margin)-tr.right;
    if(tr.top < margin) dy=margin-tr.top;
    else if(tr.bottom > window.innerHeight-margin) dy=(window.innerHeight-margin)-tr.bottom;
    if(dx||dy){
      const x=Math.max(0,Math.min(rr.left+dx,window.innerWidth-rr.width));
      const y=Math.max(0,Math.min(rr.top+dy,window.innerHeight-rr.height));
      root.style.left=x+'px';root.style.top=y+'px';root.style.right='auto';root.style.bottom='auto';
    }
  }
  function restorePosition(root){
    let saved=null;
    try{ saved=JSON.parse(localStorage.getItem('AD88_XNK_TOOL_POSITION')||'null'); }catch{}
    const apply=()=>{
      const panel=q('#ad88-tool-panel',root);
      const target=panel && !panel.classList.contains('ad88-hidden') ? panel : q('#ad88-tool-fab',root);
      const r=target?.getBoundingClientRect();
      const w=r?.width||54, h=r?.height||54;
      const sx=Number.isFinite(saved?.x)?saved.x:(window.innerWidth-w-10);
      const sy=Number.isFinite(saved?.y)?saved.y:(window.innerHeight-h-10);
      const x=Math.max(4,Math.min(sx,window.innerWidth-w-4));
      const y=Math.max(4,Math.min(sy,window.innerHeight-h-4));
      root.style.left=x+'px';root.style.top=y+'px';root.style.right='auto';root.style.bottom='auto';
      clampRootToViewport(root);
      if(panelHidden()) applyFabAnchor(root); else ensureFabVisible(root);
    };
    requestAnimationFrame(()=>requestAnimationFrame(apply));
    let rsT=null;try{window.addEventListener('resize',()=>{clearTimeout(rsT);rsT=setTimeout(()=>ensureFabVisible(root),250);},{passive:true});}catch(_){}
  }
  // 1.4.215: nhớ riêng chỗ đặt của viên thuốc. Mở bảng lớn ra có thể phải xê bảng cho vừa
  // màn hình, nhưng thu nhỏ lại thì viên thuốc phải quay về đúng chỗ người dùng đã kéo.
  function saveFabAnchor(root){
    try{const r=root.getBoundingClientRect();localStorage.setItem('AD88_XNK_FAB_ANCHOR',JSON.stringify({x:Math.round(r.left),y:Math.round(r.top)}));}catch(_){}
  }
  function applyFabAnchor(root){
    try{
      const a=JSON.parse(localStorage.getItem('AD88_XNK_FAB_ANCHOR')||'null');
      if(a&&Number.isFinite(a.x)&&Number.isFinite(a.y)){
        root.style.left=a.x+'px';root.style.top=a.y+'px';root.style.right='auto';root.style.bottom='auto';
      }
    }catch(_){}
    ensureFabVisible(root);
  }
  function savePosition(root,anchorToo){
    const r=root.getBoundingClientRect();
    try{localStorage.setItem('AD88_XNK_TOOL_POSITION',JSON.stringify({x:Math.round(r.left),y:Math.round(r.top)}));}catch{}
    if(anchorToo||panelHidden()) saveFabAnchor(root);
  }
  function makeDraggable(root){
    const handles=[q('#ad88-tool-fab',root),q('.ad88-head',root)].filter(Boolean);
    handles.forEach(handle=>{
      let drag=null;
      handle.addEventListener('pointerdown',e=>{
        // FAB itself is the drag handle; header buttons are excluded.
        // The previous guard rejected the FAB because the FAB is a <button>,
        // making it impossible to drag the collapsed Tool.
        if(e.button!==0) return;
        if(handle !== q('#ad88-tool-fab',root) && e.target.closest('button')) return;
        const r=root.getBoundingClientRect();
        drag={sx:e.clientX,sy:e.clientY,x:r.left,y:r.top,moved:false};
        handle.setPointerCapture?.(e.pointerId);
        e.preventDefault();
      });
      handle.addEventListener('pointermove',e=>{
        if(!drag)return;
        const dx=e.clientX-drag.sx,dy=e.clientY-drag.sy;
        if(Math.abs(dx)+Math.abs(dy)>4)drag.moved=true;
        if(!drag.moved)return;
        const r=root.getBoundingClientRect();
        const x=Math.max(4,Math.min(drag.x+dx,window.innerWidth-r.width-4));
        const y=Math.max(4,Math.min(drag.y+dy,window.innerHeight-r.height-4));
        root.style.left=x+'px';root.style.top=y+'px';root.style.right='auto';root.style.bottom='auto';
      });
      handle.addEventListener('pointerup',()=>{
        if(drag?.moved){savePosition(root,true);root.dataset.ad88Dragged='1';}
        drag=null;
      });
      handle.addEventListener('pointercancel',()=>{if(drag?.moved)savePosition(root,true);drag=null;});
    });
  }
  function bind(root){
    q('#ad88-tool-fab',root).onclick=()=>{
      if(root.dataset.ad88Dragged==='1'){delete root.dataset.ad88Dragged;return;}
      const panel=q('#ad88-tool-panel',root);const open=panel.classList.toggle('ad88-hidden')===false;setToolPanelOpen(open);requestAnimationFrame(()=>{if(!open)applyFabAnchor(root);else clampRootToViewport(root,true);savePosition(root);updateLedFrame(panel);if(open){try{renderStatus();}catch(_){}}});
    };
    makeDraggable(root);
    makeResizable(root);
    window.addEventListener('keydown',e=>{
      if(e.ctrlKey && e.shiftKey && e.code==='KeyA'){
        e.preventDefault();
        const panel=q('#ad88-tool-panel',root);
        const w=panel?.getBoundingClientRect().width||282, h=panel?.getBoundingClientRect().height||420;
        const x=Math.max(6,(window.innerWidth-w)/2), y=Math.max(6,(window.innerHeight-h)/2);
        root.style.left=x+'px';root.style.top=y+'px';root.style.right='auto';root.style.bottom='auto';
        savePosition(root);
        panel?.classList.remove('ad88-hidden');
        setToolPanelOpen(true);
        requestAnimationFrame(()=>{clampRootToViewport(root,true);savePosition(root);try{renderStatus();}catch(_){}});
      }
    });
    root.addEventListener('click',e=>{
      const b=e.target.closest('button');if(!b)return;const act=b.dataset.act,page=b.dataset.page;
      if(b.dataset.led){setLedColor(b.dataset.led);return;}
      if(act==='min'){q('#ad88-tool-panel',root).classList.add('ad88-hidden');setToolPanelOpen(false);applyFabAnchor(root);savePosition(root);return;}
      if(act==='stats'){toggleStatsView(root,'stats');return;}
      if(act==='home'){
        const home=q('#ad88-home-content',root), stats=q('#ad88-stats-view',root), main=q('#ad88-tool-main',root);
        if(stats&&home&&main){stats.classList.add('ad88-hidden');home.classList.remove('ad88-hidden');main.classList.remove('stats-mode');}
        root.querySelectorAll('[data-act="stats"],[data-act="balance"]').forEach(x=>x.classList.remove('is-active'));
        return;
      }
      if(act==='close'){q('#ad88-tool-panel',root).classList.add('ad88-hidden');setToolPanelOpen(false);applyFabAnchor(root);savePosition(root);return;}
      if(act==='run'){
        window.AD88_LICENSE?.getStatus?.().then(lic=>{
          if(!lic?.ok){ alert('🔒 ' + (lic?.message || 'Vui lòng kích hoạt License trong Cài đặt → Mở khóa Key.')); openPage('license'); return; }
          window.AD88_XNK_BOT?.start?.(); renderStatus();
        }); return;
      }
      if(act==='stop'){window.AD88_XNK_BOT?.stop?.();renderStatus();return;}
      if(page==='provider-amount'){openPage('provider-amount');return;}
      if(page)openPage(page);
    });
  }

  function getPanelSize(){
    const panel=q('#ad88-tool-panel');
    const r=panel?.getBoundingClientRect();
    return {w:r?.width||282,h:r?.height||420};
  }
  function saveSize(panel){
    const r=panel.getBoundingClientRect();
    const isNew=panel.closest('#ad88-xnk-tool-root')?.dataset.ui==='new';
    const key=isNew?'AD88_XNK_TOOL_SIZE_NEWUI':'AD88_XNK_TOOL_SIZE';
    try{localStorage.setItem(key,JSON.stringify({w:Math.round(r.width),h:Math.round(r.height)}));}catch{}
  }
  function restoreSize(panel){
    let saved=null;
    const isNew=panel.closest('#ad88-xnk-tool-root')?.dataset.ui==='new';
    const key=isNew?'AD88_XNK_TOOL_SIZE_NEWUI':'AD88_XNK_TOOL_SIZE';
    try{saved=JSON.parse(localStorage.getItem(key)||'null');}catch{}
    if(!saved)return;
    const defaultW=isNew?460:282, defaultH=isNew?375:420;
    const sw=(isNew && saved && saved.w<390)?defaultW:(saved?.w||defaultW);
    const sh=(isNew && saved && saved.h<330)?defaultH:(saved?.h||defaultH);
    const w=Math.max(isNew?460:240,Math.min(sw,isNew?1000:520));
    const h=Math.max(isNew?260:300,Math.min(sh,isNew?850:window.innerHeight-8));
    panel.style.width=w+'px';
    panel.style.height=h+'px';
  }
  function updateNewLayout(panel){
    if(!panel || panel.closest('#ad88-xnk-tool-root')?.dataset.ui!=='new') return;
    const main=q('#ad88-tool-main',panel.parentElement);
    const actions=q('.new-actions',main);
    const dash=q('.new-dashboard',main);
    const current=q('.current-card',main);
    if(!main||!actions||!dash||!current)return;
    const cs=getComputedStyle(main);
    const padY=(parseFloat(cs.paddingTop)||0)+(parseFloat(cs.paddingBottom)||0);
    const available=Math.max(0,main.clientHeight-padY);
    const actionH=actions.offsetHeight;
    const currentH=92;
    const gap=8;
    const minDash=300;
    const target=Math.max(minDash,available-actionH-currentH-gap);
    dash.style.height=Math.round(target)+'px';
    dash.style.minHeight=minDash+'px';
  }

  function updateNewUiScale(panel){
    /* 1.4.6: typography stays at a fixed readable size.
       Resizing changes the viewport only; short panels scroll vertically. */
    if(!panel)return;
    panel.style.setProperty('--new-ui-scale','1');
    /* 1.4.185: chỉ hàng nút CHẠY / DỪNG / Cài đặt / Check thông tin / Thống kê / Số dư: chữ và biểu tượng to dần theo bề rộng khung (665px trở xuống = 1, tối đa x1.35) */
    try{const w=panel.getBoundingClientRect().width||0;panel.style.setProperty('--na-s',Math.max(1,Math.min(1.3,w/665)).toFixed(3));}catch(_){}
  }
  function makeResizable(root){
    const panel=q('#ad88-tool-panel',root),br=q('#ad88-resize-handle',root),tl=q('#ad88-resize-handle-tl',root);
    if(!panel||!br)return;
    restoreSize(panel);
    updateNewUiScale(panel);updateNewLayout(panel);
    let resize=null;
    const start=(handle,e,corner)=>{
      if(e.button!==0)return;
      const r=panel.getBoundingClientRect(), rr=root.getBoundingClientRect();
      resize={sx:e.clientX,sy:e.clientY,w:r.width,h:r.height,rootX:rr.left,rootY:rr.top,moved:false,corner};
      handle.setPointerCapture?.(e.pointerId);
      e.preventDefault();e.stopPropagation();
    };
    const move=e=>{
      if(!resize)return;
      const dx=e.clientX-resize.sx,dy=e.clientY-resize.sy;
      const isNew=root.dataset.ui==='new';
      const minW=isNew?460:240,minH=isNew?260:300;
      const maxW=Math.min(isNew?1000:520,window.innerWidth-8);
      const maxH=Math.min(isNew?850:820,window.innerHeight-8);
      let w,h;
      if(resize.corner==='tl'){
        w=Math.max(minW,Math.min(maxW,resize.w-dx));
        h=Math.max(minH,Math.min(maxH,resize.h-dy));
        root.style.left=Math.max(4,resize.rootX+(resize.w-w))+'px';
        root.style.top=Math.max(4,resize.rootY+(resize.h-h))+'px';
      }else{
        w=Math.max(minW,Math.min(maxW,resize.w+dx));
        h=Math.max(minH,Math.min(maxH,resize.h+dy));
      }
      panel.style.width=w+'px';panel.style.height=h+'px';
      resize.moved=true;
      updateNewUiScale(panel);updateNewLayout(panel);updateLedFrame(panel);
    };
    const finish=()=>{if(!resize)return;if(resize.moved){saveSize(panel);savePosition(root);}resize=null;};
    br.addEventListener('pointerdown',e=>start(br,e,'br'));
    br.addEventListener('pointermove',move);br.addEventListener('pointerup',finish);br.addEventListener('pointercancel',finish);
    if(tl){tl.addEventListener('pointerdown',e=>start(tl,e,'tl'));tl.addEventListener('pointermove',move);tl.addEventListener('pointerup',finish);tl.addEventListener('pointercancel',finish);}
  }
  function renderStatus(){
    const st=window.AD88_XNK_BOT?.status?.()||{};S.running=!!st.auto;
    const h=st.health||healthStatus();
    const set=(id,v)=>{const e=q('#'+id);if(e)e.textContent=v};
    set('tool-run-status',S.running?((st.dayPause&&st.dayPause.active)?'CHỜ QUA NGÀY':'ĐANG CHẠY'):'ĐÃ DỪNG');
    const now=new Date();
    set('tool-runtime',now.toLocaleTimeString('vi-VN',{hour12:false,hour:'2-digit',minute:'2-digit',second:'2-digit'}));
    const runBtn=q('.new-actions .run,.ad88-runrow .run'), stopBtn=q('.new-actions .stop,.ad88-runrow .stop');
    if(runBtn&&stopBtn){runBtn.classList.toggle('is-active',!S.running);runBtn.classList.toggle('is-inactive',S.running);stopBtn.classList.toggle('is-active',S.running);stopBtn.classList.toggle('is-inactive',!S.running);}
    set('tool-order',st.currentOrder||h.currentOrder||'—');
    set('tool-done',st.processed?.length||h.processed||0);
    set('tool-skip',st.skipped?.length||h.skipped||0);
    set('tool-manual',st.manual?.length||h.manual||0);
    // 1.4.165: CHẾ ĐỘ NHẸ — không cập nhật Bảng sức khỏe / Tốc độ xử lý (đã ẩn); chỉ giữ thẻ "Đơn hiện tại".
    if(document.documentElement.classList.contains('ad88-lite')){
      set('new-order-id',h.currentOrder||'—');
      set('new-order-amount', h.currentAmount!=null ? Number(h.currentAmount).toLocaleString('vi-VN') : '—');
      set('new-order-currency', h.currentCurrency || 'VNĐ');
      set('new-order-provider', h.currentProvider || 'Đang chọn...');
      set('new-order-time',h.currentElapsedMs?Math.floor(h.currentElapsedMs/1000).toString().padStart(2,'0')+'s':'00:00');
      set('new-order-status',S.running?(h.currentStep||'Đang kiểm tra'):'Đã dừng');
      return;
    }
    const [tone,label]=healthTone(h);
    set('tool-health-label',label);
    const speed=h.avgProcessMs ? ((60000/h.avgProcessMs).toFixed(1)+' đơn/phút') : '—';
    set('tool-speed',speed);
    set('tool-avg',fmtMs(h.avgProcessMs));
    set('new-health-tool',S.running?'Đang chạy':'Đã dừng');
    set('new-health-web',h.heartbeatMs!=null && h.heartbeatMs<5000?'Ổn định':(h.heartbeatMs<10000?'Chậm':'Mất kết nối'));
    set('new-health-api',h.avgApiMs!=null?fmtMs(h.avgApiMs):'—');
    set('new-health-dom',h.currentStep&&h.currentStep!=='Sẵn sàng'?'Ready':'Ready');
    set('new-health-queue',String(h.queue||0)+' đơn');
    set('new-health-order',h.currentOrder||'—');
    set('new-health-step',h.currentStep||'Sẵn sàng');
    set('new-health-last',fmtMs(h.lastActionMs));
    set('new-health-errors',String(h.errors||0)+' / '+String(h.timeouts||0));
    const setStatusTone=(id,cls)=>{const e=q('#'+id);if(e)e.className=cls};
    setStatusTone('new-health-tool',S.running?'status-green':'status-red');
    setStatusTone('new-health-web',h.heartbeatMs!=null&&h.heartbeatMs<5000?'status-green':(h.heartbeatMs<10000?'status-amber':'status-red'));
    setStatusTone('new-health-api','status-blue');
    setStatusTone('new-health-dom','status-green');
    setStatusTone('new-health-queue','status-blue');
    setStatusTone('new-health-order','status-blue');
    setStatusTone('new-health-step','status-amber');
    setStatusTone('new-health-last','status-blue');
    setStatusTone('new-health-errors',(Number(h.errors||0)+Number(h.timeouts||0))===0?'status-green':'status-red');
    set('new-order-id',h.currentOrder||'—');
    set('new-order-amount', h.currentAmount!=null ? Number(h.currentAmount).toLocaleString('vi-VN') : '—');
    set('new-order-currency', h.currentCurrency || 'VNĐ');
    set('new-order-provider', h.currentProvider || 'Đang chọn...');
    set('new-order-time',h.currentElapsedMs?Math.floor(h.currentElapsedMs/1000).toString().padStart(2,'0')+'s':'00:00');
    set('new-order-status',S.running?(h.currentStep||'Đang kiểm tra'):'Đã dừng');
    set('tool-fastest',fmtMs(h.fastestMs));
    set('tool-slowest',fmtMs(h.slowestMs));
    const avgSpeed=h.avgProcessMs ? 60000/h.avgProcessMs : null;
    if(Number.isFinite(avgSpeed)){S.speedHistory.push(avgSpeed);if(S.speedHistory.length>24)S.speedHistory.shift();}
    const svg=q('#tool-speed-chart');
    if(svg && S.speedHistory.length){
      const vals=S.speedHistory, max=Math.max(1,...vals), min=0, w=220, hgt=70, pad=3;
      const pts=vals.map((v,i)=>{const x=vals.length===1?w/2:pad+i*(w-2*pad)/(vals.length-1);const y=pad+(hgt-pad*2)*(1-v/max);return [x,y];});
      const points=pts.map(p=>p.join(',')).join(' ');
      const line=q('#speed-line');if(line)line.setAttribute('points',points);
      const area=q('#speed-area');if(area)area.setAttribute('d',`M${pts[0][0]} ${hgt} L${pts.map(p=>p.join(' ')).join(' L')} L${pts[-1]?.[0]||pts[pts.length-1][0]} ${hgt} Z`);
      const dots=q('#speed-dots');if(dots)dots.innerHTML=pts.map(([x,y])=>`<circle cx="${x}" cy="${y}" r="2.2" fill="#2DB38D"/>`).join('');
    }
    const bar=q('#tool-healthbar');
    if(bar){bar.classList.remove('good','warn','bad','idle');bar.classList.add(tone);}
    const dot=q('#tool-health-dot');if(dot){dot.className='health-dot '+tone;}
  }
  let lastNoticeKey='';
  function refreshCore(){
    renderStatus();
    let lastDone=0,lastSkipped=0,lastManual=0,liteTick=0;
    const timer=setInterval(()=>{
      if(!document.body.contains(q('#ad88-xnk-tool-root'))){clearInterval(timer);return;}
      const st=window.AD88_XNK_BOT?.status?.()||{};
      const doneCount=st.processed?.length||0, skippedCount=st.skipped?.length||0, manualCount=st.manual?.length||0;
      if((doneCount>lastDone||skippedCount>lastSkipped||manualCount>lastManual) && (lastDone||lastSkipped||lastManual)){playNotice();}
      lastDone=doneCount; lastSkipped=skippedCount; lastManual=manualCount;
      // 1.4.213: viên thuốc trạng thái (ẩn khi chuột rời). Chỉ đổi chữ khi thay đổi, rất nhẹ.
      try{ ensureFabVisible(document.getElementById('ad88-xnk-tool-root')); }catch(_){}
      // 1.4.230: băng cảnh báo khi đang bật Bảo trì ngân hàng (giao diện + viên thuốc)
      try{ const mAll=!!getToolSettings().maintCancel; const mSet=getBankMaint(); const names=bankListAll().filter(b=>mSet.has(b.key)).map(b=>b.name); const mOn=mAll||names.length>0;
        const mb=document.getElementById('ad88-maint-banner');
        if(mb){ const txt=mAll?'🛠 ĐANG BẢO TRÌ TẤT CẢ NGÂN HÀNG — mọi đơn ngân hàng sẽ bị buộc hủy. Bỏ tích trong Bật/tắt ngân hàng khi ngân hàng hoạt động lại.':('🛠 ĐANG BẢO TRÌ: '+names.slice(0,4).join(', ')+(names.length>4?' +'+(names.length-4):'')+' — đơn của '+(names.length>1?'các ngân hàng này':'ngân hàng này')+' sẽ bị buộc hủy.'); if(mb.textContent!==txt&&mOn) mb.textContent=txt; if(mb.hidden===mOn) mb.hidden=!mOn; }
        const fb=document.getElementById('ad88-tool-fab'); if(fb&&fb.classList.contains('fab-maint')!==mOn) fb.classList.toggle('fab-maint',mOn); }catch(_){}
      // 1.4.232: băng "chờ qua ngày" + dòng giờ chuẩn trong Cài đặt
      const dpA=!!(st.auto&&st.dayPause&&st.dayPause.active);
      try{ const db=document.getElementById('ad88-daypause-banner');
        if(db){ if(dpA){ const t=Math.ceil((st.dayPause.resumeInMs||0)/1000); const txt='🌙 ĐANG CHỜ QUA NGÀY MỚI — Tool tự đẩy đơn lại sau '+String(Math.floor(t/60)).padStart(2,'0')+':'+String(t%60).padStart(2,'0'); if(db.textContent!==txt) db.textContent=txt; }
          if(db.hidden===dpA) db.hidden=!dpA; }
        const cn=document.getElementById('ad88-clock-note'); if(cn){ const t2=clockNoteText(); if(cn.textContent!==t2) cn.textContent=t2; } }catch(_){}
      try{
        const fab=document.getElementById('ad88-tool-fab');
        if(fab){
          // 1.4.235: viên thuốc theo trạng thái, dài/ngắn theo chữ
          const v=fabView(st,Date.now());
          const el=document.getElementById('ad88-fab-state'), sub=document.getElementById('ad88-fab-sub');
          if(el&&el.textContent!==v.t) el.textContent=v.t;
          if(sub){ if(sub.textContent!==v.s) sub.textContent=v.s; if(sub.hidden===!!v.s) sub.hidden=!v.s; }
          if(fab.classList.contains('fab-two')!==!!v.s) fab.classList.toggle('fab-two',!!v.s);
          if(fab.dataset.k!==v.k){
            const prev=fab.dataset.k; fab.dataset.k=v.k;
            fab.classList.toggle('fab-stopped',v.k==='stop');
            fab.classList.toggle('fab-alert',v.k==='check');
            if(prev&&v.k==='wrong'){ try{ window.AD88_FAB_PEEK&&window.AD88_FAB_PEEK(8000); }catch(_){} }
          }
        }
      }catch(_){}
      if(panelHidden()) return; // 1.4.207: đang thu nhỏ → không vẽ lại (âm báo ở trên vẫn chạy)
      // Chế độ nhẹ: vẽ lại trạng thái 3 giây/lần thay vì 1 giây/lần (âm báo vẫn kiểm tra mỗi giây).
      if(document.documentElement.classList.contains('ad88-lite') && (liteTick++%3)) return;
      renderStatus();
    },1000);
  }
  function getTodayKey(){ return new Date().toLocaleDateString('vi-VN'); }
  function localDateTimeValue(d){
    const x=new Date(d);
    const pad=n=>String(n).padStart(2,'0');
    return `${x.getFullYear()}-${pad(x.getMonth()+1)}-${pad(x.getDate())}T${pad(x.getHours())}:${pad(x.getMinutes())}`;
  }
  function parseLogTimestamp(x){
    const ts=Number(x?.timestamp);
    if(Number.isFinite(ts)&&ts>0) return ts;
    const m=String(x?.date||'').match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
    const t=String(x?.time||'').match(/^(\d{1,2}):(\d{2}):(\d{2})$/);
    if(!m||!t) return 0;
    const d=new Date(Number(m[3]),Number(m[2])-1,Number(m[1]),Number(t[1]),Number(t[2]),Number(t[3]));
    return Number.isFinite(d.getTime())?d.getTime():0;
  }
  function getSavedLogRange(){
    const start=new Date(); start.setHours(0,0,0,0);
    const now=new Date();
    return {
      from:localStorage.getItem('AD88_XNK_LOG_FROM')||localDateTimeValue(start),
      to:localStorage.getItem('AD88_XNK_LOG_TO')||localDateTimeValue(now)
    };
  }
  function saveLogRange(from,to){
    localStorage.setItem('AD88_XNK_LOG_FROM',from);
    localStorage.setItem('AD88_XNK_LOG_TO',to);
  }
  function filterLogsByRange(logs,from,to){
    const fromMs=new Date(from).getTime(), toMs=new Date(to).getTime();
    if(!Number.isFinite(fromMs)||!Number.isFinite(toMs)||fromMs>toMs) return [];
    return (Array.isArray(logs)?logs:[]).filter(x=>{const ts=parseLogTimestamp(x);return ts>=fromMs&&ts<=toMs;});
  }
  function setQuickLogRange(mode){
    const now=new Date();
    if(mode==='yesterday'){
      const start=new Date(now); start.setDate(start.getDate()-1); start.setHours(0,0,0,0);
      const end=new Date(start); end.setHours(23,59,59,999);
      saveLogRange(localDateTimeValue(start),localDateTimeValue(end));
      return;
    }
    const start=new Date(now); start.setHours(0,0,0,0);
    saveLogRange(localDateTimeValue(start),localDateTimeValue(now));
  }
  function money(v,c='VND'){
    const n=Number(v);
    if(!Number.isFinite(n)) return '—';
    return `${n.toLocaleString('vi-VN')} ${c==='USDT'?'USDT':'VND'}`;
  }
  function statsRows(){
    const st=window.AD88_XNK_BOT?.status?.()||{};
    const logs=Array.isArray(st.orderLogs)?st.orderLogs:[];
    const today=getTodayKey();
    const todayLogs=logs.filter(x=>!x.date||x.date===today);
    const done=todayLogs.filter(x=>x.state==='DONE');
    const returned=todayLogs.filter(x=>x.state==='RETURN');
    const nocheck=todayLogs.filter(x=>x.state==='NOCHECK'); // 1.4.249: đơn không kiểm tra được (đã mở khóa trả đơn để tra tay)
    const sums=arr=>{const v=arr.filter(x=>(x.currency||'VND')!=='USDT').reduce((a,x)=>a+(Number(x.amount)||0),0);const u=arr.filter(x=>x.currency==='USDT').reduce((a,x)=>a+(Number(x.amount)||0),0);return {v,u};};
    return {todayLogs,done,returned,nocheck,sumDone:sums(done),sumReturned:sums(returned),sumNocheck:sums(nocheck)};
  }
  // 1.4.239: Thống kê hiện đủ HỌ TÊN + NGÂN HÀNG + STK; bấm vào đơn để xem chi tiết (đơn trả lại: vì sao sai).
  function logCustomer(x){
    const parts=[x.bank,x.account].filter(Boolean).map(esc).join(' · ');
    if(!x.name&&!parts) return '<span class="ol2-muted">Chưa có thông tin khách</span>';
    return (x.name?`<b>${esc(x.name)}</b>`:'')+(x.name&&parts?' · ':'')+parts;
  }
  // Tách lý do "A | Nhãn: giá trị | ..." thành từng dòng dễ đọc; đổi chữ nội bộ ("API") sang lời thường.
  function reasonParts(reason){
    const segs=String(reason||'').split(/\s*\|\s*/).map(t=>t.trim()).filter(Boolean);
    const out={title:'',rows:[]};
    segs.forEach((t,i)=>{
      const m=t.match(/^([^:]{2,40}):\s*(.+)$/);
      if(m&&i>0){let k=m[1].trim(); if(/từ\s*api/i.test(k)) k='Tên ngân hàng trả về'; if(/^chi tiết$/i.test(k)) k='Chi tiết'; out.rows.push([k,m[2].trim().replace(/\bAPI\b/g,'ngân hàng')]);}
      else if(!out.title) out.title=t.replace(/\bAPI\b/g,'ngân hàng');
      else out.rows.push(['',t.replace(/\bAPI\b/g,'ngân hàng')]);
    });
    return out;
  }
  function shortReason(x){const r=reasonParts(x.reason);const t=r.title||x.label||'Đơn trả lại';if(/số điện thoại/i.test(t))return 'STK là số điện thoại';return t.length>34?t.slice(0,32)+'…':t;}
  function statsTable(title,items,type){
    const rows=items.slice().reverse().slice(0,10);
    const body=rows.length?rows.map(x=>`<button type="button" class="ol2-row ${type}" data-log-id="${esc(x.logId||'')}"><div class="ol2-l1"><time>${esc(x.time||'')}</time><b class="ol2-no">${esc(x.order||'—')}</b><span class="ol2-st">${type==='done'?'✓ Thành công':type==='nocheck'?'⚠ Chưa kiểm tra được':'↷ '+esc(shortReason(x))}</span></div><div class="ol2-l2">${logCustomer(x)}</div><div class="ol2-l3">${Number(x.amount)>0?esc(money(x.amount,x.currency)):'—'}${x.provider?' · '+esc(x.provider):''}<i>Xem chi tiết ›</i></div></button>`).join(''):`<div class="ol2-empty">Chưa có dữ liệu</div>`;
    return `<section class="stats-table-card ol2-card ${type}"><div class="stats-table-head"><b>${title}</b></div><div class="ol2-list">${body}</div></section>`;
  }

  function findLog(id){const st=window.AD88_XNK_BOT?.status?.()||{};const logs=Array.isArray(st.orderLogs)?st.orderLogs:[];return logs.find(x=>String(x.logId)===String(id))||null;}
  function copyText(t){t=String(t||'').trim();if(!t)return Promise.resolve(false);
    try{if(navigator.clipboard&&window.isSecureContext)return navigator.clipboard.writeText(t).then(()=>true,()=>fallback());}catch(_){}
    return Promise.resolve(fallback());
    function fallback(){try{const ta=document.createElement('textarea');ta.value=t;ta.style.cssText='position:fixed;left:-9999px;top:0;opacity:0';document.body.appendChild(ta);ta.select();const ok=document.execCommand('copy');ta.remove();return !!ok;}catch(_){return false;}}}
  // 1.4.240: bảng chi tiết đơn trong Thống kê + nút "Kiểm tra lại đơn này" (mở CHECK ĐƠN XUẤT, điền sẵn mã đơn, chỉ chạy khi bấm).
  // Đơn ghi từ bản cũ (trước 1.4.239) không có họ tên / ngân hàng / STK: chỉ ghi chú, KHÔNG tự tra lại BO (tránh nặng Tool).
  function showLogDetail(x){
    if(!x)return;
    const root=q('#ad88-xnk-tool-root');if(!root)return;
    q('.ol2-modal',root)?.remove();
    const ok=x.state==='DONE';
    const nc=x.state==='NOCHECK'; // 1.4.249
    const rp=reasonParts(x.reason);
    const cp=v=>v?`<button type="button" class="ol2-cp" data-copy="${esc(v)}" title="Sao chép">⧉ Chép</button>`:'';
    const row=(k,v,copy)=>`<div class="ol2-kv"><span>${k}</span><b>${v?esc(v):'—'}</b>${copy&&v?cp(v):''}</div>`;
    const check=/^NGÂN HÀNG BẢO TRÌ/.test(String(x.reason||''))?'Ngân hàng bảo trì':x.check==='VALID'?'Đúng thông tin':x.check==='INVALID'?'Sai thông tin':x.check?'Chưa kiểm tra được':'';
    const old=!x.name&&!x.bank&&!x.account;
    const amt=Number(x.amount)>0?money(x.amount,x.currency):'';
    const m=document.createElement('div');
    m.className='ol2-modal';
    m.innerHTML=`<div class="ol2-sheet ${ok?'done':nc?'nocheck':'returned'}" role="dialog" aria-label="Chi tiết đơn">
      <div class="ol2-sh-head"><span class="ol2-badge">${ok?'✓ THÀNH CÔNG':nc?'⚠ KHÔNG KIỂM TRA ĐƯỢC':'↷ ĐƠN TRẢ LẠI'}</span><time>${esc(x.date||'')} ${esc(x.time||'')}</time><button type="button" class="ol2-close" aria-label="Đóng">×</button></div>
      ${!ok?`<div class="ol2-why${nc?' nc':''}"><b>${esc(nc?'Tool chưa kiểm tra được đơn này — đã mở khóa trả đơn, nhân viên kiểm tra tay':(rp.title||'Đơn trả lại'))}</b>${rp.rows.map(([k,v])=>`<div>${k?`<span>${esc(k)}:</span> `:''}${esc(v)}</div>`).join('')}</div>`:''}
      <div class="ol2-grid">
        ${row('Mã đơn',x.order,true)}
        ${row('Họ tên trên đơn',x.name,true)}
        ${row('Ngân hàng',x.bank,false)}
        ${row('Số tài khoản',x.account,true)}
        ${x.apiName?row('Tên ngân hàng trả về',x.apiName,false):''}
        ${check?row('Kết quả Check Bank',check,false):''}
        ${row('Số tiền',amt,false)}
        ${row('Nhà thứ 3',x.provider||'',false)}
        ${row('Người thao tác',x.operator||'',false)}
      </div>
      ${old?`<div class="ol2-note">Đơn này ghi từ bản cũ nên chưa lưu họ tên, ngân hàng, STK. Muốn xem thì bấm “Kiểm tra lại đơn này”.</div>`:''}
      ${!old&&x.account&&x.name?`<div class="ol2-actions ol2-bw"><button type="button" class="ol2-bwcheck">🏦 Kiểm tra ngân hàng</button><small>Tra thẳng trên web VietinBank, cho kết quả của ngân hàng.</small></div><div class="ol2-bwres" hidden></div>`:''}
      <div class="ol2-actions"><button type="button" class="ol2-recheck">⟳ Kiểm tra lại đơn này</button><small>Mở CHECK ĐƠN XUẤT, tra đơn trên BO và chạy Bank Check mới.</small></div>
      </div>`;
    root.appendChild(m);
    const onKey=e=>{if(e.key==='Escape'){e.stopPropagation();close();}};
    const close=()=>{m.remove();document.removeEventListener('keydown',onKey,true);};
    document.addEventListener('keydown',onKey,true);
    m.addEventListener('click',e=>{if(e.target===m)close();});
    q('.ol2-close',m).onclick=close;
    q('.ol2-recheck',m).onclick=()=>{close();openOrderCheck(x.order);};
    {const bb=q('.ol2-bwcheck',m),res=q('.ol2-bwres',m);
      if(bb)bb.onclick=async()=>{
        const bot=window.AD88_XNK_BOT;
        if(!bot||typeof bot.bankWebCheck!=='function'){res.hidden=false;res.className='ol2-bwres warn';res.innerHTML='<b>Tool chưa sẵn sàng</b><span>Tải lại trang BO rồi thử lại.</span>';return;}
        bb.disabled=true;bb.textContent='⏳ Đang tra ngân hàng…';res.hidden=false;res.className='ol2-bwres wait';res.innerHTML='<b>Đang tra trên VietinBank…</b><span>Thường mất vài giây.</span>';
        let r;try{r=await bot.bankWebCheck({expectedName:x.name,bankName:x.bank,account:x.account});}catch(e){r={tone:'warn',title:'Lỗi khi tra',detail:String(e&&e.message||e)};}
        if(!m.isConnected)return;
        res.className='ol2-bwres '+(r.tone||'warn');res.innerHTML=`<b>${esc(r.title||'')}</b><span>${esc(r.detail||'')}</span>`;
        bb.disabled=false;bb.textContent='🏦 Kiểm tra ngân hàng lại';
      };}
    m.querySelectorAll('.ol2-cp').forEach(b=>b.onclick=()=>copyText(b.dataset.copy).then(okc=>{b.textContent=okc?'✓ Đã chép':'Không chép được';b.classList.toggle('done',okc);setTimeout(()=>{b.textContent='⧉ Chép';b.classList.remove('done');},1300);}));
  }
  function refreshLogViews(){
    const root=q('#ad88-xnk-tool-root');if(!root)return;
    const stats=q('#ad88-stats-view',root);
    if(stats&&!stats.classList.contains('ad88-hidden')&&stats.dataset.view==='stats'){const lists=[...stats.querySelectorAll('.ol2-list')].map(l=>l.scrollTop),sc=stats.scrollTop;renderStats(stats);stats.scrollTop=sc;stats.querySelectorAll('.ol2-list').forEach((l,i)=>{l.scrollTop=lists[i]||0;});}
    const sub=q('#ad88-tool-sub',root);
    const pg=sub&&!sub.classList.contains('ad88-hidden')?q('.ol2-page[data-type]',sub):null;
    if(pg){const big=q('.ol2-biglist',sub),b=big?big.scrollTop:0,sc=sub.scrollTop;renderFilteredLog(sub,pg.dataset.type);sub.scrollTop=sc;const nb=q('.ol2-biglist',sub);if(nb)nb.scrollTop=b;}
  }
  function openOrderCheck(no){
    const main=q('#ad88-tool-main'),sub=q('#ad88-tool-sub');if(!main||!sub)return;
    main.classList.add('ad88-hidden');sub.classList.remove('ad88-hidden');sub.classList.remove('provider-page-host');
    renderOrderCheck(sub,no);
  }
  function bindLogClicks(el){el.querySelectorAll('[data-log-id]').forEach(b=>b.addEventListener('click',()=>showLogDetail(findLog(b.dataset.logId))));}

  function renderFilteredLog(el,type){
    const st=window.AD88_XNK_BOT?.status?.()||{};
    const logs=Array.isArray(st.orderLogs)?st.orderLogs:[];
    const today=getTodayKey();
    const items=logs.filter(x=>(!x.date||x.date===today) && x.state===(type==='done'?'DONE':type==='nocheck'?'NOCHECK':'RETURN'));
    const title=type==='done'?'DANH SÁCH ĐƠN ĐÃ XỬ LÝ':type==='nocheck'?'DANH SÁCH ĐƠN KHÔNG KIỂM TRA ĐƯỢC':'DANH SÁCH ĐƠN TRẢ LẠI';
    const timeHead=type==='done'?'Thời gian giao dịch thành công':type==='nocheck'?'Thời gian trả đơn để kiểm tra tay':'Thời gian trả lại đơn';
    const rows=items.length?items.map(x=>{const rp=reasonParts(x.reason);return `<button type="button" class="ol2-item ${type}" data-log-id="${esc(x.logId||'')}"><div class="ol2-i1"><span class="ol2-st">${type==='done'?'✓ THÀNH CÔNG':type==='nocheck'?'⚠ CHƯA KIỂM TRA ĐƯỢC':'↷ '+esc(shortReason(x))}</span><time>${esc(x.time||'')}</time></div><div class="ol2-i2">Đơn <b>${esc(x.order||'—')}</b></div><div class="ol2-i3">${logCustomer(x)}</div>${type!=='done'&&rp.rows.length?`<div class="ol2-i4">${rp.rows.slice(0,2).map(([k,v])=>`<div>${k?`<span>${esc(k)}:</span> `:''}${esc(v)}</div>`).join('')}</div>`:''}<div class="ol2-i5">${Number(x.amount)>0?esc(money(x.amount,x.currency)):'—'} · Nhà thứ 3: ${esc(x.provider||'—')} · ${esc(x.operator||'—')}<i>Xem chi tiết ›</i></div></button>`;}).join(''):`<div class="ol2-empty">Chưa có dữ liệu ${type==='done'?'đã xử lý':type==='nocheck'?'đơn không kiểm tra được':'trả lại'} trong ngày hôm nay.</div>`;
    el.innerHTML=head(title)+`<div class="ad88-log-live ol2-page" data-type="${type}"><div class="ad88-log-live-head"><span>${timeHead.toUpperCase()}</span><div class="ad88-log-actions"><b>${items.length}</b></div></div><div class="ol2-biglist">${rows}</div></div>`;
    el.querySelectorAll('[data-back]').forEach(b=>b.onclick=back);
    bindLogClicks(el);
  }
  // 1.4.249: ngân hàng đang tự nhận bảo trì (nhiều tài khoản liên tiếp không tra được) → hiện dải báo trên Thống kê.
  function maintBanner(){
    let list=[]; try{ list=(window.AD88_XNK_AUTO_MAINT&&window.AD88_XNK_AUTO_MAINT.list())||[]; }catch(_){}
    if(!list.length) return '';
    return `<div class="stats-maint">🛠 <b>Đang bảo trì:</b> ${list.map(x=>`<span>${esc(x.name)}</span>`).join('')}<small>Đơn của ngân hàng này vẫn được check; không tra được thì trả đơn với note bảo trì. Tra ra thông tin lại là tự hết bảo trì.</small></div>`;
  }
  function renderStats(el){
    const d=statsRows();
    const total=d.done.length+d.returned.length+d.nocheck.length;
    const pct=n=>total?((n/total)*100).toFixed(1):'0.0';
    el.innerHTML=`<div class="stats-page">
      <div class="stats-page-head"><div><span>▥</span><b>THỐNG KÊ XỬ LÝ HÔM NAY</b></div><div class="stats-head-actions"><label>▣ Hôm nay (${new Date().toLocaleDateString('vi-VN')})</label><button type="button" id="stats-refresh">↻ Làm mới</button></div></div>
      <div class="stats-summary">
        <button type="button" class="stats-box stats-box-go done" data-stat-all="done" title="Bấm để xem tất cả đơn đã xử lý"><span>✓</span><small>ĐÃ XỬ LÝ</small><strong>${d.done.length} đơn</strong><em>Tổng: ${d.sumDone.v?money(d.sumDone.v,'VND'):''}${d.sumDone.u?`${d.sumDone.v?' · ':''}${money(d.sumDone.u,'USDT')}`:''}</em><i style="width:${pct(d.done.length)}%"></i><b class="stats-go" aria-hidden="true">›</b></button>
        <button type="button" class="stats-box stats-box-go returned" data-stat-all="returned" title="Bấm để xem tất cả đơn trả lại"><span>↷</span><small>ĐƠN TRẢ LẠI</small><strong>${d.returned.length} đơn</strong><em>Tổng: ${d.sumReturned.v?money(d.sumReturned.v,'VND'):''}${d.sumReturned.u?`${d.sumReturned.v?' · ':''}${money(d.sumReturned.u,'USDT')}`:''}</em><i style="width:${pct(d.returned.length)}%"></i><b class="stats-go" aria-hidden="true">›</b></button>
        <button type="button" class="stats-box stats-box-go nocheck" data-stat-all="nocheck" title="Bấm để xem tất cả đơn không kiểm tra được"><span>!</span><small>KHÔNG KIỂM TRA ĐƯỢC</small><strong>${d.nocheck.length} đơn</strong><em>Tổng: ${d.sumNocheck.v?money(d.sumNocheck.v,'VND'):''}${d.sumNocheck.u?`${d.sumNocheck.v?' · ':''}${money(d.sumNocheck.u,'USDT')}`:''}</em><i style="width:${pct(d.nocheck.length)}%"></i><b class="stats-go" aria-hidden="true">›</b></button>
      </div>${maintBanner()}
      <div class="stats-lists">${statsTable('DANH SÁCH ĐƠN ĐÃ XỬ LÝ',d.done,'done')}${statsTable('DANH SÁCH ĐƠN TRẢ LẠI',d.returned,'returned')}${statsTable('DANH SÁCH ĐƠN KHÔNG KIỂM TRA ĐƯỢC',d.nocheck,'nocheck')}</div>
      <div class="stats-home-back"><button type="button" data-act="home">← &nbsp; QUAY LẠI GIAO DIỆN TRANG CHỦ</button></div>
    </div>`;
    q('#stats-refresh',el).onclick=()=>renderStats(el);
    el.querySelectorAll('[data-stat-all]').forEach(b=>b.onclick=()=>openPage(b.dataset.statAll==='done'?'log-done':b.dataset.statAll==='nocheck'?'log-nocheck':'log-returned'));
    bindLogClicks(el);
  }
  function toggleStatsView(root,view){
    view=view||'stats';
    if(document.documentElement.classList.contains('ad88-lite')&&view!=='off')return; // 1.4.165: chế độ nhẹ tắt Thống kê / Số dư
    const home=q('#ad88-home-content',root), stats=q('#ad88-stats-view',root), main=q('#ad88-tool-main',root);
    if(!home||!stats||!main)return;
    const hidden=stats.classList.contains('ad88-hidden');
    const same=!hidden&&stats.dataset.view===view;
    const sb=q('[data-act="stats"]',root),bb=q('[data-act="balance"]',root);
    if(same){stats.classList.add('ad88-hidden');home.classList.remove('ad88-hidden');main.classList.remove('stats-mode');delete stats.dataset.view;if(sb)sb.classList.remove('is-active');if(bb)bb.classList.remove('is-active');return;}
    home.classList.add('ad88-hidden');stats.classList.remove('ad88-hidden');main.classList.add('stats-mode');stats.dataset.view=view;
    renderStats(stats);
    if(sb)sb.classList.toggle('is-active',view==='stats');if(bb)bb.classList.toggle('is-active',view==='balance');
  }
  function openPage(page){const main=q('#ad88-tool-main'),sub=q('#ad88-tool-sub');if(!main||!sub)return;main.classList.add('ad88-hidden');sub.classList.remove('ad88-hidden');sub.classList.remove('provider-page-host');if(page==='health')renderHealthPage(sub);else if(page==='providers')renderProviders(sub);else if(page==='banks')renderBankToggles(sub);else if(page==='bank-nf')renderBankNfManual(sub);else if(page==='bank-keep')renderBankKeep(sub);else if(page==='provider-amount')renderProviderAmountSettings(sub);else if(page==='settings')renderSettings(sub);else if(page==='license')renderLicenseSettings(sub);else if(page==='apikeys')renderApiKeys(sub);else if(page==='led')renderLedSettings(sub);else if(page==='banner')renderBannerSettings(sub);else if(page==='log')renderLog(sub);else if(page==='log-done')renderFilteredLog(sub,'done');else if(page==='log-returned')renderFilteredLog(sub,'returned');else if(page==='log-nocheck')renderFilteredLog(sub,'nocheck');else renderAbout(sub);}
  function back(){q('#ad88-tool-main')?.classList.remove('ad88-hidden');q('#ad88-tool-sub')?.classList.add('ad88-hidden');}
  function head(title){return `<div class="ad88-subhead"><button data-back="1">‹</button><b>${title}</b><button data-back="1">×</button></div>`;}
  window.addEventListener('AD88_ORDER_LOG_CHANGED',()=>{const sub=q('#ad88-tool-sub');if(sub&&!sub.classList.contains('ad88-hidden')&&sub.querySelector('.ol2-page[data-type]'))refreshLogViews();});
  window.addEventListener('AD88_BANK_AUTO_MAINT',()=>{try{refreshLogViews();}catch(_){}}); // 1.4.249: dải "Đang bảo trì" trên Thống kê // 1.4.240: danh sách "Xem tất cả" tự cập nhật, không nhảy sang trang Nhật ký
  // 1.4.216: bật/tắt từng ngân hàng. Ngân hàng TẮT thì Tool không bắt đơn của ngân hàng đó.
  function bankListAll(){ try{ return (window.AD88_XNK_BANK_LIST||[]).slice(); }catch(_){ return []; } }
  function getBankOff(){ try{ const a=JSON.parse(localStorage.getItem('AD88_XNK_BANK_OFF')||'[]'); return new Set(Array.isArray(a)?a.map(x=>String(x).toUpperCase()):[]); }catch(_){ return new Set(); } }
  function setBankOff(set){ try{ localStorage.setItem('AD88_XNK_BANK_OFF',JSON.stringify([...set])); }catch(_){} }
  // 1.4.231: ngân hàng đang BẢO TRÌ (buộc hủy với note bảo trì)
  function getBankMaint(){ try{ const a=JSON.parse(localStorage.getItem('AD88_XNK_BANK_MAINT')||'[]'); return new Set(Array.isArray(a)?a.map(x=>String(x).toUpperCase()):[]); }catch(_){ return new Set(); } }
  function setBankMaint(set){ try{ localStorage.setItem('AD88_XNK_BANK_MAINT',JSON.stringify([...set])); }catch(_){} }
  function maintNote(){ return ((typeof XNK_CONFIG!=='undefined')&&XNK_CONFIG.maintenanceNote)||'NGÂN HÀNG THỤ HƯỞNG CỦA QUÝ KHÁCH ĐANG BẢO TRÌ XIN QUÝ KHÁCH VUI LÒNG QUAY LẠI SAU Ạ.'; }
  function bankCountLabel(){ const all=bankListAll(); if(!all.length) return ''; const off=getBankOff(); const on=all.filter(b=>!off.has(b.key)).length; const mAll=!!getToolSettings().maintCancel; const mN=all.filter(b=>getBankMaint().has(b.key)).length; return on+'/'+all.length+(mAll?' · 🛠 tất cả':(mN?' · 🛠 '+mN:'')); }
  // 1.4.217: cài đặt robot đi lại

  function bankSumHtml(on,total,maintN,mAll){
    return `Đang bắt đơn của <b>${on}</b>/${total} ngân hàng`+(on<total?` · đang tắt <i>${total-on}</i>`:'')+(mAll?` · <u>🛠 TẤT CẢ đang bảo trì</u>`:(maintN?` · <u>🛠 ${maintN} đang bảo trì</u>`:''));
  }
  function renderBankToggles(el){
    el.classList.add('provider-page-host');
    const all=bankListAll();
    if(!all.length){ el.innerHTML=head('Bật/tắt ngân hàng')+'<div class="ad88-loading">Chưa đọc được danh sách ngân hàng. Hãy tải lại trang BO (F5) rồi mở lại.</div>'; q('[data-back]',el).onclick=back; return; }
    const draw=()=>{
      const off=getBankOff(), maint=getBankMaint(), mAll=!!getToolSettings().maintCancel, kw=(el.querySelector('#bank-search')?.value||'').trim().toUpperCase();
      const show=all.filter(b=>!kw||b.name.toUpperCase().includes(kw)||b.key.includes(kw.replace(/[^A-Z0-9]/g,'')));
      const on=all.filter(b=>!off.has(b.key)).length;
      el.innerHTML=head('Bật/tắt ngân hàng')+
        `<div class="ad88-bank-tools"><input id="bank-search" type="text" placeholder="Tìm ngân hàng..." value="${kw.replace(/"/g,'&quot;')}"><button type="button" id="bank-all-on">Bật tất cả</button><button type="button" id="bank-all-off">Tắt tất cả</button></div>`+
        `<div class="ad88-bank-sum">${bankSumHtml(on,all.length,all.filter(b=>maint.has(b.key)).length,mAll)}</div>`+
        `<div class="ad88-provider-list">${show.map(b=>{const o=!off.has(b.key), m=mAll||maint.has(b.key);
          return `<div class="ad88-provider-row bank-row${o?'':' off'}${m?' maint':''}" data-row="${b.key}"><span class="provider-dot"></span><b>${b.name}</b><label class="bank-maint" title="Bảo trì: buộc hủy đơn của ngân hàng này với note bảo trì"><input class="bank-maint-toggle" data-bank="${b.key}" type="checkbox" ${m?'checked':''} ${mAll?'disabled':''}><span>🛠 Bảo trì</span></label><label class="bank-sw"><input class="provider-toggle bank-toggle" data-bank="${b.key}" type="checkbox" ${o?'checked':''}><i class="provider-switch"><span></span><em>${o?'✓':'×'}</em></i></label></div>`;}).join('')
          || '<div class="ad88-loading">Không tìm thấy ngân hàng nào.</div>'}</div>`+
        `<label class="bank-maint-all${mAll?' on':''}"><input id="bank-maint-all" type="checkbox" ${mAll?'checked':''}><span>🛠 TẤT CẢ NGÂN HÀNG ĐỀU BẢO TRÌ</span><small>Tích vào: mọi đơn ngân hàng đều bị buộc hủy với note bảo trì</small></label>`+
        `<div class="ad88-balance-foot"><span>Tắt ngân hàng nào thì Tool KHÔNG bắt đơn của ngân hàng đó (không khóa đơn).<br>Tích 🛠 Bảo trì ngân hàng nào thì Tool bắt đơn của ngân hàng đó và BUỘC HỦY với note bảo trì (không check).</span></div>`;
      q('[data-back]',el).onclick=back;
      const sb=el.querySelector('#bank-search');
      if(sb){ sb.oninput=()=>{const v=sb.value;draw();const n=el.querySelector('#bank-search');if(n){n.value=v;n.focus();n.setSelectionRange(v.length,v.length);} }; if(kw){sb.focus();sb.setSelectionRange(kw.length,kw.length);} }
      el.querySelector('#bank-all-on').onclick=()=>{setBankOff(new Set());draw();};
      el.querySelector('#bank-all-off').onclick=()=>{setBankOff(new Set(all.map(b=>b.key)));draw();};
      el.querySelectorAll('.bank-toggle').forEach(inp=>inp.onchange=()=>{
        const s2=getBankOff(); if(inp.checked)s2.delete(inp.dataset.bank); else s2.add(inp.dataset.bank);
        setBankOff(s2);
        const row=inp.closest('.ad88-provider-row'); row?.classList.toggle('off',!inp.checked);
        const em=row?.querySelector('.provider-switch em'); if(em)em.textContent=inp.checked?'✓':'×';
        const sum=el.querySelector('.ad88-bank-sum'); const on2=all.filter(b=>!s2.has(b.key)).length;
        if(sum)sum.innerHTML=bankSumHtml(on2,all.length,all.filter(b=>getBankMaint().has(b.key)).length,!!getToolSettings().maintCancel);
      });
      // 1.4.231: ô Bảo trì từng ngân hàng
      el.querySelectorAll('.bank-maint-toggle').forEach(inp=>inp.onchange=()=>{
        const m2=getBankMaint(); if(inp.checked)m2.add(inp.dataset.bank); else m2.delete(inp.dataset.bank);
        setBankMaint(m2);
        inp.closest('.ad88-provider-row')?.classList.toggle('maint',inp.checked);
        const sum=el.querySelector('.ad88-bank-sum'); const on2=all.filter(b=>!getBankOff().has(b.key)).length;
        if(sum)sum.innerHTML=bankSumHtml(on2,all.length,all.filter(b=>m2.has(b.key)).length,false);
        try{window.dispatchEvent(new CustomEvent('AD88_TOOL_SETTING_CHANGED',{detail:{key:'bankMaint'}}));}catch(_){}
      });
      // 1.4.231: ô TẤT CẢ NGÂN HÀNG ĐỀU BẢO TRÌ (thay nút bảo trì cũ trong Cài đặt) — bật phải xác nhận
      const ma=el.querySelector('#bank-maint-all');
      if(ma) ma.onchange=()=>{
        if(ma.checked){ let okM=false; try{ okM=window.confirm('BẬT BẢO TRÌ TẤT CẢ NGÂN HÀNG?\n\nTool sẽ BUỘC HỦY BỎ TẤT CẢ đơn ngân hàng bắt được, với note:\n"'+maintNote()+'"\n\nĐơn đã hủy không lấy lại được.'); }catch(_){ okM=false; } if(!okM){ ma.checked=false; return; } }
        setToolSetting('maintCancel',ma.checked);
        draw();
      };
    };
    draw(); el.scrollTop=0; requestAnimationFrame(()=>{el.scrollTop=0;});
  }
  // 1.4.248: Cài đặt → Check Bank → "Không tìm thấy tài khoản → báo vàng, không trả đơn".
  // Mặc định KHÔNG tích ngân hàng nào. Tích ngân hàng nào: tra cứu báo không tìm thấy số tài khoản → popup vàng, Tool KHÔNG trả đơn,
  // nhân viên tra tay. Không tích: Tool báo sai và trả đơn như đơn sai thông tin.
  function getBankNf(){ try{ const a=JSON.parse(localStorage.getItem('AD88_XNK_BANK_NF_MANUAL')||'[]'); return new Set(Array.isArray(a)?a.map(x=>String(x).toUpperCase()):[]); }catch(_){ return new Set(); } }
  function setBankNf(set){ try{ localStorage.setItem('AD88_XNK_BANK_NF_MANUAL',JSON.stringify([...set])); }catch(_){} }
  function bankNfSumHtml(all,set){
    const names=all.filter(b=>set.has(b.key)).map(b=>b.name);
    if(names.length&&names.length>=all.length) return `Đang tích <b>tất cả ${names.length}</b> ngân hàng — ngân hàng nào báo không tìm thấy tài khoản cũng hiện <span class="nf-names">popup vàng</span>, không trả đơn.`;
    return names.length?`Đang tích <b>${names.length}</b> ngân hàng: <span class="nf-names">${names.map(esc).join(', ')}</span>`:'Chưa tích ngân hàng nào — không tìm thấy tài khoản thì Tool <b>trả đơn</b> như đơn sai thông tin.';
  }
  function renderBankNfManual(el){
    el.classList.add('provider-page-host');
    const all=bankListAll();
    const title='Không tìm thấy tài khoản';
    if(!all.length){ el.innerHTML=head(title)+'<div class="ad88-loading">Chưa đọc được danh sách ngân hàng. Hãy tải lại trang BO (F5) rồi mở lại.</div>'; q('[data-back]',el).onclick=()=>openPage('settings'); return; }
    const draw=()=>{
      const set=getBankNf(), kw=(el.querySelector('#nf-search')?.value||'').trim().toUpperCase();
      const show=all.filter(b=>!kw||b.name.toUpperCase().includes(kw)||b.key.includes(kw.replace(/[^A-Z0-9]/g,'')));
      el.innerHTML=head(title)+
        `<div class="nf-intro"><b>Tích ngân hàng nào</b> thì khi tra cứu báo <b>không tìm thấy số tài khoản</b>, Tool hiện <span class="nf-y">popup vàng</span>, <b>không trả đơn</b> — nhân viên tra tay trên app ngân hàng.<br><b>Không tích</b>: Tool báo sai và <span class="nf-r">trả đơn</span> như đơn sai thông tin.<br>Máy đang bật <b>🏦 Check qua ngân hàng</b>: Tool tra lại trên VietinBank trước — ngân hàng không ra thông tin thì <span class="nf-r">trả đơn</span> dù đã tích; mục này chỉ còn tác dụng khi <b>không tra được</b> trên VietinBank (tab chưa mở / chưa đăng nhập). Bỏ tích hết thì lúc đó cũng trả đơn.</div>`+
        `<div class="ad88-bank-tools nf-tools"><input id="nf-search" type="text" placeholder="Tìm ngân hàng..." value="${kw.replace(/"/g,'&quot;')}"><div class="nf-allbtns"><button type="button" id="nf-all" class="nf-all-on">✓ Chọn tất cả</button><button type="button" id="nf-clear" class="nf-all-off">✕ Tắt tất cả</button></div></div>`+
        `<div class="ad88-bank-sum nf-sum">${bankNfSumHtml(all,set)}</div>`+
        `<div class="ad88-provider-list">${show.map(b=>{const on=set.has(b.key);
          return `<label class="ad88-provider-row nf-row${on?' nf-on':''}" data-row="${b.key}"><span class="provider-dot"></span><b>${esc(b.name)}</b><span class="nf-tag">${on?'Báo vàng':'Trả đơn'}</span><input class="nf-toggle" data-bank="${b.key}" type="checkbox" ${on?'checked':''}><i class="nf-box" aria-hidden="true">${on?'✓':''}</i></label>`;}).join('')
          || '<div class="ad88-loading">Không tìm thấy ngân hàng nào.</div>'}</div>`;
      q('[data-back]',el).onclick=()=>openPage('settings');
      const sb=el.querySelector('#nf-search');
      if(sb){ sb.oninput=()=>{const v=sb.value;draw();const n=el.querySelector('#nf-search');if(n){n.value=v;n.focus();n.setSelectionRange(v.length,v.length);} }; if(kw){sb.focus();sb.setSelectionRange(kw.length,kw.length);} }
      el.querySelector('#nf-clear').onclick=()=>{setBankNf(new Set());draw();};
      el.querySelector('#nf-all').onclick=()=>{setBankNf(new Set(all.map(b=>b.key)));draw();}; // 1.4.251: tích hết mọi ngân hàng
      el.querySelectorAll('.nf-toggle').forEach(inp=>inp.onchange=()=>{
        const s2=getBankNf(); if(inp.checked)s2.add(inp.dataset.bank); else s2.delete(inp.dataset.bank);
        setBankNf(s2);
        const row=inp.closest('.nf-row'); row?.classList.toggle('nf-on',inp.checked);
        const tg=row?.querySelector('.nf-tag'); if(tg)tg.textContent=inp.checked?'Báo vàng':'Trả đơn';
        const bx=row?.querySelector('.nf-box'); if(bx)bx.textContent=inp.checked?'✓':'';
        const sum=el.querySelector('.nf-sum'); if(sum)sum.innerHTML=bankNfSumHtml(all,s2);
      });
    };
    draw(); el.scrollTop=0; requestAnimationFrame(()=>{el.scrollTop=0;});
  }
  // 1.4.252: GIỮ ĐĂNG NHẬP NGÂN HÀNG — bật/tắt việc tự F5 tab web ngân hàng mỗi 3 phút (chạy ở nền, kể cả khi đóng trang BO).
  function bankKeepMsg(type,extra){return new Promise(res=>{try{chrome.runtime.sendMessage(Object.assign({type},extra||{}),r=>{void chrome.runtime.lastError;res(r||{ok:false});});}catch(_){res({ok:false});}});}
  function renderBankKeep(el){
    el.classList.add('provider-page-host');
    const title='Check qua ngân hàng';
    const hhmm=t=>{const d=new Date(t);return String(d.getHours()).padStart(2,'0')+':'+String(d.getMinutes()).padStart(2,'0');};
    const tabLine=(t,on)=>{let st='Chờ lượt F5 đầu';if(!on)st='Chưa bật';else if(t.wait&&t.wait>(t.at||0))st='Đang dùng — F5 lượt sau';else if(t.at)st='Đã F5 lúc '+hhmm(t.at);
      return `<div class="bk-tab"><b>${esc(t.bank||'Ngân hàng')}</b><span>${esc(t.title||'')}</span><em class="${on&&t.at?'ok':''}">${st}</em></div>`;};
    const autoOn=()=>{try{return localStorage.getItem('AD88_BANKWEB_AUTO')!=='0';}catch(_){return true;}};
    const draw=st=>{
      if(!document.body.contains(el)||el.classList.contains('ad88-hidden'))return;
      const on=!!st.on, tabs=Array.isArray(st.tabs)?st.tabs:[];
      const bw=st.bw||{}, bwOn=!!bw.on;
      const bwState={READY:['ok','VietinBank đã đăng nhập, đang ở màn chuyển tiền — sẵn sàng tra (nhanh nhất)'],OPEN:['ok','VietinBank đã đăng nhập — Tool sẽ tự mở màn "Chuyển tiền liên ngân hàng" khi tra'],LOGGED_OUT:['bad','Tab VietinBank chưa đăng nhập — hãy đăng nhập'],NO_SCRIPT:['warn','Tải lại (F5) tab VietinBank 1 lần để Tool tra được'],NO_TAB:['bad','Chưa mở web VietinBank — mở ipay.vietinbank.vn và đăng nhập ở 1 tab']}[bw.tabState]||['warn','Đang kiểm tra...'];
      const lastTxt=bw.last&&bw.last.at?('Lần tra gần nhất '+hhmm(bw.last.at)+': '+(bw.last.ok?(bw.last.found?'ra tên chủ tài khoản':(bw.last.unsure?'ngân hàng chưa xác nhận':'ngân hàng báo không tìm thấy')):'không tra được')):'';
      el.innerHTML=head(title)+`<div class="bk-page">`+
        `<label class="setting-row bk-switch bk-master"><span>🏦 Máy này dùng chức năng Check qua ngân hàng</span><input id="bw-on" type="checkbox" ${bwOn?'checked':''}><i class="switch"></i></label>`+
        (!bwOn?`<div class="nf-intro">Đang <b>TẮT</b> trên máy này — Tool chỉ check bằng API như cũ, không đụng tới web ngân hàng. Máy nào có đăng nhập web <b>VietinBank iPay</b> thì bật lên.</div></div>`:
        `<div class="bk-status ${bwState[0]}">${bwState[1]}${lastTxt?`<small>${esc(lastTxt)}</small>`:''}</div>`+
        (()=>{const c=bw.counts||{},t=c.today||{};return `<div class="bk-count"><div class="bk-cnum"><b>${Number(t.total)||0}</b><small>lượt tra hôm nay</small></div><div class="bk-cdet"><span>Ra tên: <b>${Number(t.found)||0}</b></span><span>Không tìm thấy: <b>${Number(t.notFound)||0}</b></span><span>Ngân hàng lỗi/không xác nhận: <b>${Number(t.unsure)||0}</b></span><span>Không tra được: <b>${Number(t.failed)||0}</b></span><span class="bk-cold">Hôm qua <b>${Number(c.yesterday)||0}</b>, 7 ngày <b>${Number(c.week)||0}</b>, 30 ngày <b>${Number(c.month)||0}</b></span></div></div>`;})()+
        sessHTML(bw.session)+
        `<div class="bk-sec">Tự tra ngầm</div>`+
        `<div class="nf-intro">Check <b>không ra tên</b> → Tool tự tra ngầm trên tab <b>VietinBank</b>: khớp tên → <b>đúng</b>; khác tên → <b>sai</b>; ngân hàng <b>không ra thông tin (bất kể lý do) → trả đơn sai thông tin</b>, kể cả ngân hàng đang tích báo vàng. Chỉ khi <b>không tra được</b> (tab chưa mở / chưa đăng nhập) mới xử lý theo mục "Không tìm thấy tài khoản".<br>Nhanh nhất khi để tab VietinBank ở màn <b>Chuyển tiền → Liên ngân hàng</b>. Tool không bấm Tiếp tục, không nhập số tiền, không chuyển tiền.</div>`+
        `<label class="setting-row bk-switch"><span>🔎 Tự tra ngầm khi API check không ra tên</span><input id="bw-auto" type="checkbox" ${autoOn()?'checked':''}><i class="switch"></i></label>`+
        `<div class="bk-note">Tắt mục này thì Tool không tự tra, nhưng vẫn dùng được nút <b>🏦 Kiểm tra ngân hàng</b> khi mở chi tiết đơn.</div>`+
        `<div class="bk-sec">Giữ đăng nhập</div>`+
        `<div class="nf-intro">Cứ <b>3 phút</b> Tool tự <b>F5</b> tab web ngân hàng (<b>VietinBank, MB Bank, TPBank</b>) để ngân hàng không tự đăng xuất. Đang thao tác trên tab ngân hàng hoặc Tool đang tra thì chờ lượt sau.</div>`+
        `<label class="setting-row bk-switch"><span>↻ Tự F5 tab ngân hàng mỗi 3 phút</span><input id="bk-on" type="checkbox" ${on?'checked':''}><i class="switch"></i></label>`+
        (st.ok===false?'<div class="bk-empty">Chưa đọc được trạng thái. Tải lại trang BO (F5) rồi mở lại.</div>':
        `<div class="bk-list">${tabs.length?tabs.map(t=>tabLine(t,on)).join(''):'<div class="bk-empty">Chưa thấy tab ngân hàng nào đang mở.</div>'}</div>`)+
        `<div class="nf-allbtns bk-btns"><button type="button" id="bk-now" class="bk-now"${tabs.length?'':' disabled'}>↻ F5 ngay</button><button type="button" id="bk-refresh" class="bk-refresh">Kiểm tra lại</button></div></div>`);
      q('[data-back]',el).onclick=()=>{clearInterval(el._bkTimer);openPage('settings');};
      const bko=el.querySelector('#bk-on'); if(bko)bko.onchange=e=>{bankKeepMsg('AD88_BANK_KEEP_SET',{on:e.target.checked}).then(draw);};
      el.querySelector('#bw-on').onchange=e=>{const v=e.target.checked;if(v){try{if(localStorage.getItem('AD88_BANKWEB_AUTO')==null)localStorage.setItem('AD88_BANKWEB_AUTO','1');}catch(_){}}(v?Promise.resolve():bankKeepMsg('AD88_BANK_KEEP_SET',{on:false})).then(()=>bankKeepMsg('AD88_BANKWEB_SET',{on:v})).then(draw);}; // tắt chức năng trên máy → tắt luôn tự F5
      const bwa=el.querySelector('#bw-auto'); if(bwa)bwa.onchange=e=>{try{localStorage.setItem('AD88_BANKWEB_AUTO',e.target.checked?'1':'0');}catch(_){}};
      const bkr=el.querySelector('#bk-refresh'); if(bkr)bkr.onclick=()=>bankKeepMsg('AD88_BANK_KEEP_STATE').then(draw);
      const nb=el.querySelector('#bk-now'); if(nb)nb.onclick=()=>{nb.disabled=true;nb.textContent='Đang F5...';bankKeepMsg('AD88_BANK_KEEP_NOW').then(draw);};
    };
    el.innerHTML=head(title)+'<div class="ad88-loading">Đang đọc...</div>';
    q('[data-back]',el).onclick=()=>openPage('settings');
    bankKeepMsg('AD88_BANK_KEEP_STATE').then(draw);
    clearInterval(el._bkTimer);
    el._bkTimer=setInterval(()=>{if(!el.querySelector('.bk-page')||el.classList.contains('ad88-hidden')){clearInterval(el._bkTimer);return;}bankKeepMsg('AD88_BANK_KEEP_STATE').then(draw);},20000);
    el.scrollTop=0;
  }
  function renderProviders(el){
    el.classList.add('provider-page-host');
    const st=getProviderState();
    el.innerHTML=head('Bật/tắt nhà thứ 3')+`<div class="ad88-provider-list">${PROVIDERS.map(name=>{
      const on=st[name]!==false;
      return `<label class="ad88-provider-row"><span class="provider-dot"></span><b>${name}</b><input class="provider-toggle" data-provider="${name}" type="checkbox" ${on?'checked':''}><i class="provider-switch"><span></span><em>${on?'✓':'×'}</em></i></label>`;
    }).join('')}</div><div class="ad88-balance-foot"><span>Chỉ bật nhà được phép tự động đẩy đơn</span></div>`;
    el.scrollTop=0;
    requestAnimationFrame(()=>{el.scrollTop=0;});
    q('[data-back]',el).onclick=back;
    el.querySelectorAll('.provider-toggle').forEach(inp=>inp.onchange=()=>{const s=getProviderState();s[inp.dataset.provider]=inp.checked;setProviderState(s);inp.closest('.ad88-provider-row')?.classList.toggle('off',!inp.checked);});
  }
  // 1.4.234: Cài đặt gom theo NHÓM (bấm tên nhóm để mở/đóng). Giữ nguyên id từng mục nên mọi nút/công tắc chạy như cũ.
  const SGROUP_KEY='AD88_XNK_SETTINGS_OPEN';
  function sgroupOpenSet(){try{const v=JSON.parse(localStorage.getItem(SGROUP_KEY)||'[]');return new Set(Array.isArray(v)?v:[]);}catch(_){return new Set();}}
  function sgroup(id,icon,title,sub,body){return `<details class="ad88-sgroup" data-g="${id}"${sgroupOpenSet().has(id)?' open':''}><summary class="ad88-sgroup-head"><span class="sg-ic">${icon}</span><span class="sg-txt"><b>${title}</b><small>${sub}</small></span><i class="sg-chev">›</i></summary><div class="ad88-sgroup-body">${body}</div></details>`;}
  function renderSettings(el){
    const st=getToolSettings();
    el.innerHTML=head('Cài đặt')+`<div class="ad88-settings ad88-settings-grouped">${sgroup('xuly','⚙','Xử lý đơn','Tự động xử lý, USDT, hướng bắt đơn, thời gian xử lý',`${toggle('auto','Tự động xử lý đơn',st.auto)}${toggle('usdt','Xử lý đơn USDT (TRC20 / ERC20)',st.usdt)}${toggle('scanTop','Bắt đơn từ trên xuống (đơn mới nhất trước)',st.scanTop)}${toggle('scanBottom','Bắt đơn từ dưới lên (đơn cũ nhất trước)',st.scanBottom)}${toggle('noticeClose','Tự đóng popup thông báo của BO',st.noticeClose)}<button class="setting-row" id="process-time">⏱ <span>Thời gian xử lý</span><i>›</i></button><button class="setting-row" id="reset-session">↻ <span>Đặt lại phiên xử lý</span><i>›</i></button>`)}${sgroup('bank','🔍','Check Bank','Tự động kiểm tra, check trước đơn kế tiếp, khóa API',`${toggle('bank','Tự động kiểm tra Bank',st.bank)}${toggle('bankPrefetchNext','Check Bank trước cho đơn kế tiếp (nhanh hơn, tốn thêm lượt gọi API)',st.bankPrefetchNext)}${toggle('bankBadSkip','Bỏ qua thành viên vừa bị trả sai ngân hàng (180 phút)',st.bankBadSkip)}<button class="setting-row" id="bank-nf-settings" type="button">🟡 <span>Không tìm thấy tài khoản → báo vàng, không trả đơn</span><i>›</i></button><button class="setting-row" id="apikey-settings" type="button">🔑 <span>Khóa API Bank Check</span><i>›</i></button>`)}${sgroup('bankweb','🏦','Check qua ngân hàng','Riêng từng máy: tra tên trên web VietinBank, giữ đăng nhập',`<button class="setting-row" id="bank-keep-settings" type="button">🏦 <span>Check qua ngân hàng (VietinBank)</span><i>›</i></button>`)}${sgroup('mokhoa','🔓','Mở khóa đơn','Tự mở khóa, đơn nhà thứ 3 trả về, quá 2 phút',`${toggle('unlock','Tự động mở khóa',st.unlock)}${toggle('returnUnlock','Tự mở khóa đơn nhà thứ 3 trả về',st.returnUnlock)}${toggle('lockWatchdog','Chưa xử lý quá 2 phút tự mở khóa',st.lockWatchdog)}`)}${sgroup('nha3','🏦','Nhà thứ 3 &amp; ngân hàng','Số tiền, bật/tắt nhà thứ 3, bật/tắt & bảo trì ngân hàng',`<button class="setting-row" id="provider-amount-settings" data-page="provider-amount" type="button">💰 <span>Cài đặt số tiền bên thứ 3</span><i>›</i></button><button class="setting-row provider-toggle-settings" id="provider-toggle-settings">🏦 <span>Bật/tắt nhà thứ 3</span><i>›</i></button><button class="setting-row" id="bank-toggle-settings" type="button">🏛 <span>Bật/tắt ngân hàng</span><b>${bankCountLabel()}</b><i>›</i></button>`)}${sgroup('chongtreo','🛡','Chống treo &amp; qua ngày','Tự F5, dừng đẩy đơn qua ngày, giờ chuẩn',`${toggle('autoReload','Tự F5 trang BO khi rảnh (mỗi 45 phút) rồi tự chạy lại — chống trang Ối, hỏng',st.autoReload)}${toggle('dayPause','Dừng đẩy đơn qua ngày ('+((typeof XNK_CONFIG!=='undefined'&&XNK_CONFIG.dayPauseStart)||'23:58:00')+' → '+((typeof XNK_CONFIG!=='undefined'&&XNK_CONFIG.dayPauseEnd)||'00:00:05')+' giờ chuẩn VN)',st.dayPause)}<div class="ad88-clock-note" id="ad88-clock-note">${clockNoteText()}</div>`)}${sgroup('giaodien','🎨','Giao diện','Chế độ nhẹ, sáng/tối, banner, đèn LED, viên thuốc',`${toggle('lite','Chế độ nhẹ (giao diện cơ bản, tắt hiệu ứng)',st.lite)}${toggle('fabAlways','Luôn hiện viên thuốc khi thu nhỏ Tool (tắt = chỉ hiện khi đưa chuột lại gần)',st.fabAlways)}<button class="setting-row" id="theme-settings" type="button">🌓 <span>Chế độ sáng / tối</span><b id="theme-label">${THEME_LABELS[getThemeMode()]}</b><i>⟳</i></button><button class="setting-row" id="banner-settings" type="button">🖼 <span>Giao diện banner</span><b>${(BANNER_THEMES.find(t=>t.id===getBannerThemeId())||BANNER_THEMES[0]).name}</b><i>›</i></button><button class="setting-row" id="led-settings">💡 <span>Điều chỉnh đèn LED</span><i>›</i></button>`)}${sgroup('nhatky','📋','Nhật ký','Log lý do đơn trả lại, log chi tiết, xóa nhật ký',`<button class="setting-row" id="return-reason-log-settings" type="button">▤ <span>Log lý do đơn trả lại</span><b>${st.returnReasonLog?'BẬT':'TẮT'}</b><i>›</i></button>${toggle('logDetail','Log chi tiết (chỉ bật khi cần dò lỗi — nặng hơn)',st.logDetail)}<button class="setting-row" id="clear-log">♲ <span>Xóa nhật ký phiên</span><i>›</i></button>`)}${sgroup('license','🔑','License &amp; cập nhật','Mở khóa Key, cập nhật Tool, ngôn ngữ',`<button class="setting-row" id="license-settings">🔑 <span>Mở khóa Key</span><i>›</i></button><button class="setting-row" id="check-update" type="button">↻ <span>Cập nhật Tool</span><b id="update-badge">v${AD88_VERSION}</b><i>›</i></button><div class="setting-row">🌐 <span>Ngôn ngữ</span><b>Tiếng Việt</b></div>`)}</div>`;
    el.querySelectorAll('details.ad88-sgroup').forEach(d=>d.addEventListener('toggle',()=>{try{const o=sgroupOpenSet();if(d.open)o.add(d.dataset.g);else o.delete(d.dataset.g);localStorage.setItem(SGROUP_KEY,JSON.stringify([...o]));}catch(_){}}));
    q('[data-back]',el).onclick=back;
    ['auto','bank','unlock','returnUnlock','lockWatchdog','bankBadSkip','lite','usdt','scanTop','scanBottom','noticeClose','autoReload','dayPause','logDetail','bankPrefetchNext','fabAlways'].forEach(id=>{
      const input=q('#'+id,el);
      input.onchange=e=>{
        setToolSetting(id,e.target.checked);
        // 1.4.204: hướng bắt đơn — luôn có đúng 1 hướng bật (bật hướng này thì hướng kia tắt; tắt hướng đang bật thì hướng kia tự bật).
        if(id==='fabAlways'){try{document.documentElement.classList.toggle('ad88-fab-always',!!e.target.checked);}catch(_){}}
        if(id==='scanTop'||id==='scanBottom'){const other=id==='scanTop'?'scanBottom':'scanTop';const on=e.target.checked;setToolSetting(other,!on);const oi=q('#'+other,el);if(oi)oi.checked=!on;}
        if(id==='auto'){
          if(e.target.checked) window.AD88_XNK_BOT?.start?.(); else window.AD88_XNK_BOT?.stop?.();
          renderStatus();
        }
      };
    });
    q('#provider-amount-settings',el).onclick=e=>{e.preventDefault();e.stopPropagation();openPage('provider-amount');};
    q('#provider-toggle-settings',el).onclick=()=>openPage('providers');
    q('#bank-toggle-settings',el).onclick=()=>openPage('banks');
    q('#return-reason-log-settings',el).onclick=()=>renderReturnReasonLogSettings(el);
    q('#license-settings',el).onclick=()=>openPage('license');
    {const ak=q('#apikey-settings',el);if(ak)ak.onclick=()=>openPage('apikeys');}
    {const nf=q('#bank-nf-settings',el);if(nf)nf.onclick=()=>openPage('bank-nf');}
    {const bk=q('#bank-keep-settings',el);if(bk)bk.onclick=()=>openPage('bank-keep');}
    q('#led-settings',el).onclick=()=>openPage('led');
    q('#theme-settings',el).onclick=()=>{const order=['dark','light','auto'];const nx=order[(order.indexOf(getThemeMode())+1)%3];setThemeMode(nx);const lb=q('#theme-label',el);if(lb)lb.textContent=THEME_LABELS[nx];};
    q('#banner-settings',el).onclick=()=>openPage('banner');
    q('#reset-session',el).onclick=()=>{
      window.AD88_XNK_BOT?.reset?.();
      renderStatus();
      alert('Đã đặt lại phiên xử lý. Lịch sử đơn của phiên hiện tại đã được xóa.');
    };
    q('#clear-log',el).onclick=()=>{
      window.AD88_XNK_BOT?.reset?.();
      renderStatus();
      alert('Đã xóa nhật ký phiên xử lý.');
    };
    q('#process-time',el).onclick=()=>renderProcessTiming(el);
    q('#check-update',el).onclick=async()=>{
      const r=await ad88SendToBackground({type:'AD88_OPEN_UPDATE',auto:true},5000);
      if(!r||!r.ok)alert('Không mở được trang cập nhật: '+((r&&r.message)||'thử F5 trang BO.'));
    };
    ad88SendToBackground({type:'AD88_CHECK_UPDATE'},8000).then(r=>{const b=q('#update-badge',el);if(!b)return;b.textContent=(r&&r.ok&&r.available)?('CÓ BẢN MỚI '+r.version):('v'+AD88_VERSION);if(r&&r.ok&&r.available)b.style.color='#ffb454';});
  }
  // showToast được gọi ở nhiều nơi (tải CSV, kích hoạt…) nhưng trước đây chưa được định nghĩa.
  function showToast(message,error=false){try{showToolToast(q('#ad88-tool-sub')||document.body,message,error);}catch(e){}}
  function renderApiKeys(el){
    el.innerHTML=head('Khóa API Bank Check')+`<div class="ad88-timing ad88-sync-page"><div class="sync-intro"><div class="sync-intro-icon">🔑</div><div><b>Khóa API Bank Check</b><small>Khóa chỉ lưu trong bộ nhớ extension, không nằm trong mã nguồn. Không chia sẻ khóa này cho người khác.</small></div></div><div class="sync-section-title">TRẠNG THÁI</div><div class="setting-row"><span>Khóa hiện tại</span><b id="key-state">…</b></div><div class="sync-section-title">NHẬP KHÓA</div><div class="sync-grid"><label class="sync-field"><span>License Key</span><div><input id="key-license" type="password" autocomplete="off" spellcheck="false" placeholder="ak_…"></div></label><label class="sync-field"><span>Secret Key</span><div><input id="key-secret" type="password" autocomplete="off" spellcheck="false" placeholder="sk_…"></div></label></div><button class="setting-row sync-save" id="key-save">✓ <span>Lưu khóa</span><i>›</i></button><button class="setting-row" id="key-clear">♲ <span>Xóa khóa đã lưu</span><i>›</i></button></div>`;
    q('[data-back]',el).onclick=()=>openPage('settings');
    const refresh=async()=>{const st=await window.AD88_apiKeys.status();const t=q('#key-state',el);if(!t)return;if(st.hasLicense&&st.hasSecret){t.textContent='ĐÃ NHẬP (…'+esc(st.licenseTail)+')';return;}let b=null;try{b=await ad88SendToBackground({type:'AD88_API_KEY_STATE'},5000);}catch(_){}t.textContent=(b&&b.builtin)?'ĐÃ CÓ SẴN TRONG TOOL — không cần nhập':(b&&b.ok?'CHƯA CÓ KHÓA — cài bản FULL hoặc nhập khóa':'Không đọc được trạng thái');t.style.color=(b&&b.builtin)?'#3ddc97':'#ff6b6b';};
    refresh();
    q('#key-save',el).onclick=async()=>{
      const l=q('#key-license',el).value.trim(),sk=q('#key-secret',el).value.trim();
      if(!l||!sk||/\s/.test(l+sk)){showToolToast(el,'Cần nhập đủ License Key và Secret Key (không chứa khoảng trắng)',true);return;}
      const ok=await window.AD88_apiKeys.save(l,sk);
      q('#key-license',el).value='';q('#key-secret',el).value='';
      await refresh();
      showToolToast(el,ok?'✓ Đã lưu khóa':'Không lưu được khóa',!ok);
    };
    q('#key-clear',el).onclick=async()=>{
      if(!confirm('Xóa License Key và Secret Key đã lưu? Bank Check sẽ không chạy cho đến khi nhập lại.'))return;
      await window.AD88_apiKeys.clear();
      await refresh();
      showToolToast(el,'Đã xóa khóa');
    };
  }
  async function renderLicenseSettings(el){
    const escLocal=v=>String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
    const icon=(name,cls='')=>{
      const a={
        key:`<svg class="${cls}" viewBox="0 0 48 48" aria-hidden="true"><path d="M19.5 27.5a9.5 9.5 0 1 1 6.1-16.8l5.3 5.3h10.4v6.1h-4v4h-4v4h-5.8l-3.5-3.5a9.5 9.5 0 0 1-4.5.9Z"/><circle cx="19" cy="18" r="3.1" fill="#07191a" stroke="none"/></svg>`,
        shield:`<svg class="${cls}" viewBox="0 0 48 48" aria-hidden="true"><path d="M24 4 40 10v11c0 10.5-6.6 18.7-16 23-9.4-4.3-16-12.5-16-23V10L24 4Z"/><path d="m16.5 24 5 5 10-11" fill="none" stroke="#07191a" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
        database:`<svg class="${cls}" viewBox="0 0 48 48" aria-hidden="true"><ellipse cx="24" cy="9" rx="14" ry="6"/><path d="M10 9v15c0 3.3 6.3 6 14 6s14-2.7 14-6V9" fill="none"/><path d="M10 24v15c0 3.3 6.3 6 14 6s14-2.7 14-6V24" fill="none"/></svg>`,
        gear:`<svg class="${cls}" viewBox="0 0 48 48" aria-hidden="true"><path d="m29.5 5 1.3 5.2a15 15 0 0 1 4.2 2.4l5.1-1.6 3.5 6-4 3.6a15 15 0 0 1 0 4.8l4 3.6-3.5 6-5.1-1.6a15 15 0 0 1-4.2 2.4L29.5 41h-7l-1.3-5.2a15 15 0 0 1-4.2-2.4l-5.1 1.6-3.5-6 4-3.6a15 15 0 0 1 0-4.8l-4-3.6 3.5-6 5.1 1.6a15 15 0 0 1 4.2-2.4L22.5 5h7Z"/><circle cx="26" cy="22" r="6" fill="#07191a" stroke="none"/></svg>`,
        lock:`<svg class="${cls}" viewBox="0 0 48 48" aria-hidden="true"><rect x="9" y="20" width="30" height="22" rx="4"/><path d="M15 20v-6c0-5 4-9 9-9s9 4 9 9v6" fill="none" stroke="currentColor" stroke-width="5"/><circle cx="24" cy="30" r="3" fill="#07191a" stroke="none"/></svg>`,
        check:`<svg class="${cls}" viewBox="0 0 48 48" aria-hidden="true"><circle cx="24" cy="24" r="20"/><path d="m14 24 7 7 14-15" fill="none" stroke="#06201c" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
        copy:`<svg class="${cls}" viewBox="0 0 48 48" aria-hidden="true"><rect x="15" y="13" width="23" height="27" rx="3" fill="none" stroke="currentColor" stroke-width="3"/><path d="M10 33V10c0-2 1.5-3 3-3h18" fill="none" stroke="currentColor" stroke-width="3"/></svg>`,
        trash:`<svg class="${cls}" viewBox="0 0 48 48" aria-hidden="true"><path d="M11 13h26M19 13V8h10v5M15 13l2 29h14l2-29" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M20 19v17M28 19v17" fill="none" stroke="currentColor" stroke-width="3"/></svg>`
      }; return a[name]||'';
    };
    el.innerHTML=head('Mở khóa Key')+`<div class="ad88-license-page christmas-license">
      <div class="ad88-license-card christmas-license-card">
        <div class="ad88-license-icon">${icon('key')}</div>
        <div class="license-card-copy"><h3>LICENSE AD88 XNK TOOL</h3><p>Kích hoạt License Key được cấp riêng cho máy này.</p></div>
        <div class="license-card-brand">AD<span>88</span><i>♛</i></div>
      </div>
      <div class="ad88-license-device christmas-device"><small>MÃ MÁY</small><b id="ad88-license-device">Đang lấy mã máy…</b><button type="button" id="ad88-copy-device">${icon('copy')}<span>Sao chép</span></button></div>
      <label class="ad88-license-label">LICENSE KEY</label>
      <textarea id="ad88-license-input" class="ad88-license-input christmas-license-input" rows="4" placeholder="Dán License Key AD88.… vào đây"></textarea>
      <div class="ad88-license-actions christmas-actions"><button type="button" id="ad88-license-activate">${icon('key')}<span>KÍCH HOẠT</span></button><button type="button" id="ad88-license-clear" class="danger">${icon('trash')} XÓA KEY</button></div>
      <div id="ad88-license-status" class="ad88-license-status christmas-status">Đang kiểm tra…</div>
      <div class="ad88-license-note">License được xác minh bằng chữ ký ECDSA P-256. Tool không chứa private key.</div>

      <section class="ad88-license-info artwork-license-info" aria-label="Thông tin và bản quyền">
        <img src="${chrome.runtime.getURL('assets/ad88-license-info-christmas.png')}" alt="AD88 XNK TOOL - Thông tin và bản quyền" draggable="false">
      </section>
    </div>`;
    q('[data-back]',el).onclick=back;
    const deviceEl=q('#ad88-license-device',el), input=q('#ad88-license-input',el), status=q('#ad88-license-status',el);
    const render=lic=>{
      deviceEl.textContent=lic.device||'—';
      status.textContent=(lic.ok?'✓ ':'✕ ')+(lic.message||'License không hợp lệ');
      status.className='ad88-license-status christmas-status '+(lic.ok?'ok':'bad');
      if(lic.ok && lic.payload) status.textContent='✓ '+lic.message+(lic.payload.n?` · ${lic.payload.n}`:'');
    };
    try{
      const token=await window.AD88_LICENSE.getToken();
      if(token) input.value=token;
      render(await window.AD88_LICENSE.getStatus());
    }catch{ status.textContent='✕ Không thể đọc trạng thái License'; status.className='ad88-license-status christmas-status bad'; }
    q('#ad88-copy-device',el).onclick=async()=>{
      try{await navigator.clipboard.writeText(deviceEl.textContent);showToast('Đã sao chép Mã máy');}
      catch{alert('Mã máy: '+deviceEl.textContent);}
    };
    q('#ad88-license-activate',el).onclick=async()=>{
      const token=input.value.trim();
      if(!token){alert('Vui lòng nhập License Key.');return;}
      const btn=q('#ad88-license-activate',el);btn.disabled=true;btn.textContent='ĐANG KIỂM TRA…';
      try{
        const lic=await window.AD88_LICENSE.activate(token);
        render(lic);
        if(lic.ok){showToast('✓ Kích hoạt License thành công');}
        else{alert('Không thể kích hoạt: '+lic.message);}
      }finally{btn.disabled=false;btn.innerHTML=icon('key')+'<span>KÍCH HOẠT</span>';}
    };
    q('#ad88-license-clear',el).onclick=async()=>{
      if(!confirm('Xóa License Key đang lưu trên máy này?'))return;
      await window.AD88_LICENSE.clearToken(); input.value=''; render(await window.AD88_LICENSE.getStatus());
      try{window.AD88_XNK_BOT?.stop?.();}catch{}
    };
  }

  function renderReturnReasonLogSettings(el){
    const on=!!getToolSettings().returnReasonLog;
    el.innerHTML=head('Log lý do đơn trả lại')+`<div class="ad88-return-reason-settings"><div class="return-reason-intro"><div class="return-reason-icon">▤</div><div><b>CHI TIẾT LÝ DO ĐƠN TRẢ LẠI</b><small>Khi Bank Check kết luận sai thông tin, nhật ký sẽ lưu nguyên nhân cụ thể để dễ đối chiếu.</small></div></div><label class="setting-row"><span>Hiển thị lý do chi tiết trong nhật ký</span><input id="cfg-return-reason-log" type="checkbox" ${on?'checked':''}><i class="switch"></i></label><div class="return-reason-example"><b>Ví dụ log</b><div>HỌ TÊN KHÔNG KHỚP · Tên trên đơn: NGUYEN VAN MINH · Tên từ API: NGUYEN TRAN THU HAI · Chi tiết: Tên chủ tài khoản không khớp...</div></div><div class="return-reason-note">Tắt mục này không xóa nhật ký cũ. Các đơn trả lại mới sẽ chỉ lưu lý do ngắn.</div></div>`;
    q('[data-back]',el).onclick=()=>openPage('settings');
    q('#cfg-return-reason-log',el).onchange=e=>setToolSetting('returnReasonLog',e.target.checked);
  }

  function renderProviderAmountSettings(el){
    const cfg=getProviderConfigState();
    el.innerHTML=head('Cài đặt số tiền bên thứ 3')+`<div class="ad88-provider-config"><div class="provider-config-note">Cài đặt khoảng tiền xử lý cho từng nhà thứ 3. <b>VND: nhập trực tiếp số tiền</b> · <b>USDT: nhập đúng số USDT</b>. Số tiền sẽ tự thêm dấu chấm để dễ đọc, ví dụ <b>5.000.000</b> hoặc <b>10.000.000</b>.</div><div class="provider-config-list">${PROVIDERS.map(key=>{const x=cfg[key];const cur=x.currency||'VND';return `<div class="provider-config-card" data-key="${esc(key)}"><div class="provider-config-title"><span class="provider-dot"></span><b>${esc(x.name)}</b><em class="provider-currency ${cur==='USDT'?'usdt':'vnd'}">${cur}</em></div><div class="provider-config-fields"><label><span>MIN</span><input class="provider-min-input" type="text" inputmode="decimal" autocomplete="off" value="${x.min==null?'':formatAmountInput(x.min,cur)}" placeholder="Không giới hạn"></label><label><span>MAX</span><input class="provider-max-input" type="text" inputmode="decimal" autocomplete="off" value="${x.max==null?'':formatAmountInput(x.max,cur)}" placeholder="Không giới hạn"></label></div><div class="provider-unit-hint">${cur==='USDT'?'Đơn vị: USDT (10 = 10 USDT)':'Đơn vị: VND trực tiếp (100.000 = 100.000 VNĐ)'}</div></div>`}).join('')}<div class="provider-config-save-wrap"><button class="setting-row provider-config-save" id="save-provider-config">✓ <span>Lưu cấu hình</span><i>›</i></button></div></div></div>`;
    el.querySelectorAll('.provider-min-input,.provider-max-input').forEach(input=>{
      input.addEventListener('input',()=>{
        const card=input.closest('.provider-config-card');
        const key=card?.dataset.key;
        const cur=PROVIDER_CONFIG_DEFAULTS[key]?.currency||'VND';
        const before=input.value.slice(0,input.selectionStart??input.value.length);
        const digitsBefore=before.replace(/[^0-9]/g,'').length;
        input.value=formatAmountInput(input.value,cur);
        let pos=0,seen=0;
        while(pos<input.value.length && seen<digitsBefore){if(/[0-9]/.test(input.value[pos]))seen++;pos++;}
        try{input.setSelectionRange(pos,pos)}catch{}
      });
    });
    q('[data-back]',el).onclick=()=>openPage('settings');
    requestAnimationFrame(()=>{
      const panel=q('#ad88-tool-panel');
      const list=q('.provider-config-list',el);
      if(panel&&list){
        const available=Math.max(180,Math.min(window.innerHeight-220,panel.clientHeight-150));
        list.style.maxHeight=available+'px';
      }
    });
    q('#save-provider-config',el).onclick=()=>{
      const out={};
      let invalid='';
      el.querySelectorAll('.provider-config-card').forEach(card=>{
        const key=card.dataset.key;
        const minRaw=card.querySelector('.provider-min-input').value.trim();
        const maxRaw=card.querySelector('.provider-max-input').value.trim();
        const currency=(PROVIDER_CONFIG_DEFAULTS[key]?.currency==='USDT')?'USDT':'VND';
        const min=parseAmountInput(minRaw,currency), max=parseAmountInput(maxRaw,currency);
        const name=PROVIDER_CONFIG_DEFAULTS[key]?.name||key;
        if(min!==null && (!Number.isFinite(min)||min<0)){invalid=`MIN của ${name} không hợp lệ.`;return;}
        if(max!==null && (!Number.isFinite(max)||max<0)){invalid=`MAX của ${name} không hợp lệ.`;return;}
        if(min!==null && max!==null && min>max){invalid=`MIN không được lớn hơn MAX của ${name}.`;return;}
        out[key]={name,currency,min,max};
      });
      if(invalid){showToolToast(el,invalid,true);return;}
      out.__vndDirectUnitMigrated=true;
      setProviderConfigState(out);
      showToolToast(el,'✓ Đã áp dụng');
    };
  }
  function showToolToast(el,message,error=false){
    let toast=q('.ad88-tool-toast',el);
    if(!toast){toast=document.createElement('div');toast.className='ad88-tool-toast';const host=q('#ad88-tool-panel')||el;host.appendChild(toast);}
    toast.textContent=message;
    toast.classList.toggle('error',!!error);
    toast.classList.remove('show');
    requestAnimationFrame(()=>toast.classList.add('show'));
    clearTimeout(toast._timer);
    toast._timer=setTimeout(()=>toast.classList.remove('show'),1600);
  }
  function renderProcessTiming(el){
    const cfg=window.XNK_CONFIG||{},auto=cfg.autoSync!==false,pollMin=Number(cfg.pollMinMs)||100,pollMax=Number(cfg.pollMaxMs)||650,dmin=Number(cfg.nextOrderDelayMinMs)||350,dmax=Number(cfg.nextOrderDelayMaxMs)||3000;
    el.innerHTML=head('Tốc độ & đồng bộ')+`<div class="ad88-timing ad88-sync-page"><div class="sync-intro"><div class="sync-intro-icon">⚡</div><div><b>Tốc độ & đồng bộ</b><small>AUTO SYNC ưu tiên trạng thái DOM/API thực tế, giúp Tool không chạy nhanh hơn khi website chưa cập nhật.</small></div></div><label class="setting-row sync-master"><span>⚡ Đồng bộ tốc độ tự động</span><input id="cfg-auto-sync" type="checkbox" ${auto?'checked':''}><i class="switch"></i></label><div class="sync-section-title">THỜI GIAN CHỜ</div><div class="sync-grid"><label class="sync-field"><span>Chờ thao tác</span><div><input id="cfg-action" type="number" min="1000" max="30000" step="500" value="${Number(cfg.actionTimeoutMs)||8000}"><b>ms</b></div></label><label class="sync-field"><span>Bank Check timeout</span><div><input id="cfg-bank" type="number" min="3000" max="60000" step="500" value="${Number(cfg.bankCheckTimeoutMs)||15000}"><b>ms</b></div></label><label class="sync-field"><span>Cooldown cơ sở</span><div><input id="cfg-delay" type="number" min="100" max="30000" step="100" value="${Number(cfg.nextOrderDelayMs)||2200}"><b>ms</b></div></label></div><div class="sync-section-title">POLLING & COOLDOWN</div><div class="sync-grid"><label class="sync-field"><span>Polling MIN</span><div><input id="cfg-poll-min" type="number" min="50" max="1000" step="10" value="${pollMin}"><b>ms</b></div></label><label class="sync-field"><span>Polling MAX</span><div><input id="cfg-poll-max" type="number" min="100" max="2000" step="10" value="${pollMax}"><b>ms</b></div></label><label class="sync-field"><span>Cooldown MIN</span><div><input id="cfg-delay-min" type="number" min="100" max="10000" step="50" value="${dmin}"><b>ms</b></div></label><label class="sync-field"><span>Cooldown MAX</span><div><input id="cfg-delay-max" type="number" min="200" max="30000" step="100" value="${dmax}"><b>ms</b></div></label></div><button class="setting-row sync-save" id="save-timing">✓ <span>Lưu cấu hình tốc độ & đồng bộ</span><i>›</i></button></div>`;
    q('[data-back]',el).onclick=()=>openPage('settings');
    q('#save-timing',el).onclick=()=>{const a=Math.max(1000,Math.min(30000,Number(q('#cfg-action',el).value)||8000)),b=Math.max(3000,Math.min(60000,Number(q('#cfg-bank',el).value)||15000)),d=Math.max(100,Math.min(30000,Number(q('#cfg-delay',el).value)||2200)),pmin=Math.max(50,Math.min(1000,Number(q('#cfg-poll-min',el).value)||100)),pmax=Math.max(pmin,Math.min(2000,Number(q('#cfg-poll-max',el).value)||650)),dmin2=Math.max(100,Math.min(10000,Number(q('#cfg-delay-min',el).value)||350)),dmax2=Math.max(dmin2,Math.min(30000,Number(q('#cfg-delay-max',el).value)||3000));localStorage.setItem('AD88_XNK_CFG_ACTION_TIMEOUT',String(a));localStorage.setItem('AD88_XNK_CFG_BANK_TIMEOUT',String(b));localStorage.setItem('AD88_XNK_CFG_NEXT_DELAY',String(d));if(window.XNK_CONFIG){window.XNK_CONFIG.actionTimeoutMs=a;window.XNK_CONFIG.bankCheckTimeoutMs=b;window.XNK_CONFIG.nextOrderDelayMs=d;window.XNK_CONFIG.autoSync=!!q('#cfg-auto-sync',el).checked;window.XNK_CONFIG.pollMinMs=pmin;window.XNK_CONFIG.pollMaxMs=pmax;window.XNK_CONFIG.nextOrderDelayMinMs=dmin2;window.XNK_CONFIG.nextOrderDelayMaxMs=dmax2;}localStorage.setItem('AD88_XNK_AUTO_SYNC',String(!!q('#cfg-auto-sync',el).checked));localStorage.setItem('AD88_XNK_POLL_MIN',String(pmin));localStorage.setItem('AD88_XNK_POLL_MAX',String(pmax));localStorage.setItem('AD88_XNK_DELAY_MIN',String(dmin2));localStorage.setItem('AD88_XNK_DELAY_MAX',String(dmax2));showToolToast(el,'✓ Đã lưu cấu hình tốc độ & đồng bộ');};
  }

  function renderLedSettings(el){
    const ls=getLedSettings();
    el.innerHTML=head('Điều chỉnh đèn LED')+`<div class="ad88-led-settings ${ls.enabled?'':'led-off'}"><label class="led-onoff"><input id="led-enabled" type="checkbox" ${ls.enabled?'checked':''}><span class="led-onoff-sw"></span><b id="led-enabled-text">${ls.enabled?'Đèn LED: ĐANG BẬT':'Đèn LED: ĐÃ TẮT'}</b></label><div class="led-setting-title">🎨 Màu LED</div><div class="ad88-led-swatches led-settings-swatches">${LED_COLORS.map(c=>`<button type="button" data-led="${c.value}" title="${c.name}" style="--c:${c.value}"><span></span></button>`).join('')}</div><label class="led-range-row"><span>Độ sáng</span><output id="led-bright-out">${ls.brightness}%</output><input id="led-bright" type="range" min="10" max="300" value="${ls.brightness}"></label><label class="led-range-row"><span>Độ dày</span><output id="led-thick-out">${ls.thick}%</output><input id="led-thick" type="range" min="30" max="200" value="${ls.thick}"></label><label class="led-range-row"><span>Tốc độ</span><output id="led-speed-out">${ls.speed}%</output><input id="led-speed" type="range" min="10" max="100" value="${ls.speed}"></label><div class="led-setting-title">Hiệu ứng</div><div class="led-effects">${[['single','Chạy đơn'],['two','Hai chiều'],['multi','Nhiều điểm'],['comet','Comet Tail'],['pulse','Pulse toàn viền'],['rainbow','Rainbow Flow'],['wave','Wave'],['spark','Spark'],['chase','Đuổi 3 màu'],['dual','Hai màu đối nghịch'],['snake','Rắn dài'],['fire','Lửa'],['marquee','Bóng đèn chạy'],['xmas','Đèn Giáng sinh nhấp nháy'],['heart','Nhịp tim'],['corner','Chớp 4 góc'],['static','Tĩnh']].map(([v,n])=>`<label><input type="radio" name="led-effect" value="${v}" ${ls.effect===v?'checked':''}><span>○</span>${n}</label>`).join('')}</div></div>`;
    q('[data-back]',el).onclick=()=>openPage('settings');
    el.querySelectorAll('[data-led]').forEach(b=>b.onclick=()=>setLedColor(b.dataset.led));
    const br=q('#led-bright',el),bo=q('#led-bright-out',el); br.oninput=()=>{bo.value=br.value+'%';setLedSetting('AD88_XNK_LED_BRIGHTNESS',br.value)};
    const th=q('#led-thick',el),tho=q('#led-thick-out',el); th.oninput=()=>{tho.value=th.value+'%';setLedSetting('AD88_XNK_LED_THICK',th.value)};
    const sp=q('#led-speed',el),so=q('#led-speed-out',el); sp.oninput=()=>{so.value=sp.value+'%';setLedSetting('AD88_XNK_LED_SPEED',sp.value)};
    const en=q('#led-enabled',el);if(en)en.onchange=()=>{setLedSetting('AD88_XNK_LED_ENABLED',en.checked?'1':'0');q('#led-enabled-text',el).textContent=en.checked?'Đèn LED: ĐANG BẬT':'Đèn LED: ĐÃ TẮT';el.querySelector('.ad88-led-settings').classList.toggle('led-off',!en.checked)};
    el.querySelectorAll('input[name=led-effect]').forEach(r=>r.onchange=()=>setLedSetting('AD88_XNK_LED_EFFECT',r.value));
  }
  function renderBannerSettings(el){
    const cur=getBannerThemeId();
    el.innerHTML=head('Giao diện banner')+`<div class="ad88-banner-settings"><p class="banner-note">Chọn hình nền cho phần tiêu đề. Logo, chữ và giờ chạy giữ nguyên.</p>${BANNER_THEMES.map(t=>`<button type="button" class="banner-card ${t.id===cur?'selected':''}" data-banner="${t.id}" aria-pressed="${t.id===cur}"><span class="banner-preview" style="--prev:url('${chrome.runtime.getURL(t.file)}')"></span><span class="banner-info"><b>${t.name}</b><small>${t.desc}</small></span><i class="banner-check">${t.id===cur?'✓ Đang dùng':'Chọn'}</i></button>`).join('')}</div>`;
    q('[data-back]',el).onclick=()=>openPage('settings');
    el.querySelectorAll('.banner-card').forEach(b=>b.onclick=()=>{
      setBannerThemeId(b.dataset.banner);
      el.querySelectorAll('.banner-card').forEach(x=>{const on=x===b;x.classList.toggle('selected',on);x.setAttribute('aria-pressed',on);x.querySelector('.banner-check').textContent=on?'✓ Đang dùng':'Chọn';});
    });
  }
  // 1.4.232: giờ chuẩn VN (lấy từ máy chủ BO) — hiển thị độ lệch đồng hồ máy này
  function fmtLech(ms){const t=Math.round(Math.abs(ms)/1000),m=Math.floor(t/60),s=t%60;return (m?m+' phút ':'')+s+' giây';}
  function clockNoteText(){
    const dp=window.AD88_XNK_BOT?.status?.()?.dayPause;
    if(!dp) return '🕒 Đang lấy giờ chuẩn…';
    const hms=new Date(dp.stdTime+7*3600000).toISOString().slice(11,19);
    if(dp.offsetMs==null) return '🕒 Chưa lấy được giờ chuẩn — tạm dùng giờ máy tính';
    const off=-dp.offsetMs; // máy - chuẩn
    const lech=Math.abs(off)<2000?'Máy này đúng giờ chuẩn':('Máy này '+(off>0?'NHANH':'CHẬM')+' hơn giờ chuẩn '+fmtLech(off));
    return '🕒 Giờ chuẩn VN: '+hms+' · '+lech;
  }
  // 1.4.235: chữ trên viên thuốc theo trạng thái (ưu tiên từ trên xuống)
  function fabView(st,now){
    const need=Number(st.needCheck||0), ev=st.lastEvent||null, dp=st.dayPause||{};
    if(!st.auto) return {k:'stop',t:'Đã dừng',s:need?need+' đơn cần kiểm tra':''};
    if(dp.active) return {k:'night',t:'Chờ qua ngày',s:''};
    if(need) return {k:'check',t:need+' đơn cần kiểm tra',s:st.needCheckNo?('Đơn '+st.needCheckNo+(need>1?' và '+(need-1)+' đơn khác':'')):''}; // 1.4.237: ghi mã đơn
    if(ev&&ev.kind==='RETURN'&&now-ev.at<8000) return {k:'wrong',t:ev.maint?'Ngân hàng bảo trì':'Sai thông tin',s:'Đã trả đơn về'};
    if(ev&&ev.kind==='DONE'&&now-ev.at<3000) return {k:'done',t:'Đã xử lý',s:''};
    if(st.currentOrder) return {k:'busy',t:'Đang xử lý đơn',s:''};
    if(ev) return {k:'done',t:'Đã xử lý',s:''};
    return {k:'idle',t:'Đang chờ đơn',s:''};
  }
  function toggle(id,label,on){return `<label class="setting-row"><span>⚙ ${label}</span><input id="${id}" type="checkbox" ${on?'checked':''}><i class="switch"></i></label>`;}
  function downloadOrderLogCsv(logs){
    const rows=(Array.isArray(logs)?logs:[]).filter(x=>x.state==='DONE'||x.state==='RETURN');
    if(!rows.length){
      showToast('Chưa có nhật ký để tải');
      return;
    }
    const escCsv=v=>{const s=String(v??'');return /[\",\n]/.test(s)?'\"'+s.replace(/\"/g,'\"\"')+'\"':s};
    const done=rows.filter(x=>x.state==='DONE').length;
    const returned=rows.filter(x=>x.state==='RETURN').length;
    const lines=[];
    lines.push(['BÁO CÁO NHẬT KÝ XỬ LÝ ĐƠN AD88 XNK TOOL']);
    lines.push(['Ngày xuất',new Date().toLocaleDateString('vi-VN')]);
    lines.push(['Tổng số đơn',rows.length]);
    lines.push(['Thành công',done]);
    lines.push(['Đơn trả lại',returned]);
    lines.push([]);
    lines.push(['Ngày','Thời gian','Người thao tác','Mã đơn','Kết quả','Nhà thứ 3','Số tiền VND','USDT','Lý do']);
    rows.slice().reverse().forEach(x=>lines.push([
      x.date||'',x.time||'',x.operator||'',x.order||'',x.label||x.state||'',x.provider||'',
      x.currency==='USDT'?'':(x.amount!=null?Number(x.amount).toLocaleString('vi-VN'):''),
      x.currency==='USDT'?(x.amount!=null?Number(x.amount).toLocaleString('en-US',{maximumFractionDigits:8}):''):'',
      x.reason||''
    ]));
    const csv='\uFEFF'+lines.map(r=>r.map(escCsv).join(',')).join('\r\n');
    const blob=new Blob([csv],{type:'text/csv;charset=utf-8;'});
    const url=URL.createObjectURL(blob);
    const a=document.createElement('a');
    const stamp=new Date().toISOString().slice(0,10);
    a.href=url;a.download=`AD88_XNK_NHAT_KY_${stamp}.csv`;
    document.body.appendChild(a);a.click();a.remove();
    setTimeout(()=>URL.revokeObjectURL(url),1000);
    showToast('Đã tải file nhật ký');
  }
  // ===== 1.4.180: Nhật ký → tab "Kiểm tra đơn" (chỉ đọc; gọi window.AD88_XNK_BOT.checkOrder) =====
  // 1.4.202: ô nhập ở các trang Check luôn dán/gõ được dù trang BO có chặn phím tắt/chuột phải;
  // nếu Ctrl+V bị chặn thì tự đọc clipboard điền vào ô.
  function ckHardenInput(input){
    if(!input||input.dataset.ckHard)return;input.dataset.ckHard='1';
    ['keydown','keyup','keypress','paste','input','beforeinput','contextmenu','copy','cut'].forEach(t=>input.addEventListener(t,e=>e.stopPropagation()));
    input.addEventListener('keydown',e=>{
      if((e.ctrlKey||e.metaKey)&&String(e.key).toLowerCase()==='v'){
        const before=input.value;
        setTimeout(()=>{
          if(input.value!==before)return;
          try{navigator.clipboard&&navigator.clipboard.readText&&navigator.clipboard.readText().then(t=>{t=String(t||'').trim();if(t&&input.value===before){input.value=t;input.dispatchEvent(new Event('input',{bubbles:true}));}}).catch(()=>{});}catch(_){}
        },60);
      }
    });
  }
  function ckTabsHTML(active){return `<div class="ck-tabs"><button type="button" data-ck-tab="log" class="${active==='log'?'on':''}">NHẬT KÝ</button><button type="button" data-ck-tab="check" class="${active==='check'?'on':''}">CHECK ĐƠN XUẤT</button><button type="button" data-ck-tab="dep" class="${active==='dep'?'on':''}">CHECK ĐƠN NHẬP</button><button type="button" data-ck-tab="acct" class="${active==='acct'?'on':''}">CHECK TÊN TK</button></div>`;}
  function wireCkTabs(el){
    el.querySelectorAll('[data-ck-tab]').forEach(b=>b.onclick=()=>{const t=b.dataset.ckTab;if(t==='check')renderOrderCheck(el);else if(t==='dep')renderDepositCheck(el);else if(t==='acct')renderAccountCheck(el);else renderLog(el);});
  }
  // 1.4.185: các mục Nhật ký / Check: từ khung ~700px trở xuống giữ cỡ chữ hiện tại; kéo khung to hơn thì chữ, số, nút, biểu tượng to dần (tối đa x1.3 ở 1000px)
  function wireCkScale(el){
    const page=q('.ad88-log-page',el);
    if(!page)return;
    try{el._ckRO&&el._ckRO.disconnect();}catch(_){}
    const apply=()=>{
      const w=page.getBoundingClientRect().width||0;
      const z=Math.max(1,Math.min(1.3,1+(w-700)/300*0.3));
      page.style.setProperty('--ck-zoom',z.toFixed(3));
    };
    apply();
    if(typeof ResizeObserver==='function'){el._ckRO=new ResizeObserver(apply);el._ckRO.observe(page);}
  }
  function wireLogHeadDrag(el){
    const root=q('#ad88-xnk-tool-root');
    const head=q('.ad88-log-page-head',el);
    if(!root||!head)return;
    let drag=null;
    const moveDrag=e=>{
      if(!drag)return;
      const dx=e.clientX-drag.sx,dy=e.clientY-drag.sy;
      if(Math.abs(dx)+Math.abs(dy)>3)drag.moved=true;
      if(!drag.moved)return;
      const r=root.getBoundingClientRect();
      const x=Math.max(4,Math.min(drag.x+dx,window.innerWidth-r.width-4));
      const y=Math.max(4,Math.min(drag.y+dy,window.innerHeight-r.height-4));
      root.style.left=x+'px';root.style.top=y+'px';root.style.right='auto';root.style.bottom='auto';
      e.preventDefault();
    };
    const stopDrag=()=>{
      if(!drag)return;
      if(drag.moved)savePosition(root,true);
      drag=null;
      document.removeEventListener('mousemove',moveDrag);
      document.removeEventListener('mouseup',stopDrag);
    };
    head.addEventListener('mousedown',e=>{
      if(e.button!==0||e.target.closest('button'))return;
      const r=root.getBoundingClientRect();
      drag={sx:e.clientX,sy:e.clientY,x:r.left,y:r.top,moved:false};
      document.addEventListener('mousemove',moveDrag);
      document.addEventListener('mouseup',stopDrag);
      e.preventDefault();
    });
  }
  function renderCheckLock(el){
    const bot=window.AD88_XNK_BOT;
    el.innerHTML=head('Check thông tin')+`<div class="ad88-settings ck-lock"><div class="ck-lock-ic"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="4.5" y="10.5" width="15" height="10" rx="2.5"/><path d="M8 10.5V8a4 4 0 0 1 8 0v2.5"/><circle cx="12" cy="15.5" r="1.3"/></svg></div><div class="ck-lock-msg">Vì vấn đề bảo mật, khi không có key không thể kiểm tra thông tin.</div><input id="ck-key" type="password" autocomplete="off" spellcheck="false" placeholder="Nhập key để mở"><button type="button" id="ck-unlock">MỞ KHÓA</button><div class="ck-lock-err" id="ck-lock-err"></div></div>`;
    q('[data-back]',el).onclick=back;
    el.querySelectorAll('[data-back]').forEach(b=>b.onclick=back);
    const inp=q('#ck-key',el),btn=q('#ck-unlock',el),err=q('#ck-lock-err',el);
    let busy=false;
    const go=async()=>{
      if(busy)return;
      busy=true;btn.disabled=true;err.textContent='';
      try{
        const r=await bot.checkLock.unlock(inp.value);
        if(r&&r.ok){inp.value='';renderLog(el);return;}
        err.textContent=(r&&r.message)||'Key không đúng.';
      }catch(_){err.textContent='Không kiểm tra được key.';}
      busy=false;btn.disabled=false;inp.select();
    };
    btn.onclick=go;
    inp.onkeydown=e=>{if(e.key==='Enter')go();};
    setTimeout(()=>{try{inp.focus();}catch(_){}},50);
  }
  function checkLockedGate(el){
    const lk=window.AD88_XNK_BOT&&window.AD88_XNK_BOT.checkLock;
    if(lk&&!lk.isOpen()){renderCheckLock(el);return true;}
    return false;
  }
  // 1.4.254: thẻ kết quả tra trên ngân hàng (VietinBank) — dùng ở CHECK ĐƠN XUẤT và chi tiết đơn.
  function bkDur(ms){ms=Number(ms)||0;const m=Math.round(ms/60000);if(m<1)return 'dưới 1 phút';if(m<60)return m+' phút';const h=Math.floor(m/60);return h+' giờ '+(m%60)+' phút';}
  function sessHTML(se){
    if(!se||!se.current)return '';
    const hhmm=t=>{const d=new Date(t);return String(d.getHours()).padStart(2,'0')+':'+String(d.getMinutes()).padStart(2,'0');};
    let box='';
    if(se.current==='in'&&se.loginAt){box=`<div class="bk-sess ok"><b>Đang đăng nhập</b><span>Từ ${hhmm(se.loginAt)} — đã giữ được <b>${bkDur(Date.now()-se.loginAt)}</b>.</span></div>`;}
    else if(se.current==='out'&&se.logoutAt){box=`<div class="bk-sess bad"><b>Đã văng lúc ${hhmm(se.logoutAt)}</b><span>Giữ được <b>${bkDur(se.keptMs)}</b> trước khi văng.<br>Lý do: ${esc(se.reason||'Không rõ')}.</span></div>`;}
    const h=(Array.isArray(se.history)?se.history:[]).slice(0,5);
    const hist=h.length?`<details class="bk-sesshist"><summary>Các lần văng gần đây (${h.length})</summary>${h.map(x=>`<div class="bk-sessrow"><span>${hhmm(x.logoutAt)}</span><span>giữ ${bkDur(x.keptMs)}</span><em>${esc(x.reason||'Không rõ')}</em></div>`).join('')}</details>`:'';
    return `<div class="bk-sec">Nhật ký phiên VietinBank</div>${box}${hist}`;
  }
  const BW_FAIL={NO_TAB:'Chưa mở web VietinBank (ipay.vietinbank.vn).',LOGGED_OUT:'Tab VietinBank chưa đăng nhập.',NOT_TRANSFER_PAGE:'Chưa mở được màn chuyển tiền trên VietinBank.',BANK_NOT_IN_LIST:'VietinBank không có ngân hàng này trong danh sách.',NO_RESPONSE:'VietinBank chưa phản hồi.',BUSY:'Đang tra đơn khác.'};
  function bwCardHTML(b){
    if(!b||(b.failed&&b.reason==='OFF'))return '';
    let tone='warn',txt='';
    if(b.name){tone=b.match?'ok':'bad';txt=(b.match?'✓ ':'✕ ')+b.name+(b.match?' — khớp họ tên trên đơn':' — KHÁC họ tên trên đơn');}
    else if(b.notFound){tone='bad';txt='✕ '+(b.msg||'Ngân hàng báo không tìm thấy số tài khoản.');}
    else if(b.unsure){tone='bad';txt='✕ '+(b.msg||'Ngân hàng không xác nhận được tài khoản.');}
    else txt='! '+(BW_FAIL[b.reason]||'Chưa tra được trên ngân hàng.');
    return `<div class="ck-card ck-bw"><h5>KẾT QUẢ NGÂN HÀNG <em>tra trên VietinBank</em></h5><div class="ck-bw-v ${tone}">${esc(txt)}</div></div>`;
  }
  function renderOrderCheck(el,prefill){
    if(checkLockedGate(el))return;
    const rowsHTML=(arr)=>(arr||[]).map(r=>`<div class="ck-row"><span>${esc(r[0])}</span><b class="${r[2]==='warn'?'ck-warn':r[2]==='ok'?'ck-ok':r[2]==='bad'?'ck-bad':''}">${esc(r[1])}</b></div>`).join('');
    el.innerHTML=`<div class="ad88-log-page ck-page"><div class="ad88-log-page-head"><div class="ad88-log-title"><span>▣</span><div><b>NHẬT KÝ XỬ LÝ ĐƠN</b><small>Kiểm tra lại thông tin một đơn theo số lệnh</small></div></div><button class="ad88-log-home" type="button" data-back="1">← QUAY LẠI GIAO DIỆN TRANG CHỦ</button></div>${ckTabsHTML('check')}
      <div class="ck-search"><input id="ck-input" type="text" inputmode="numeric" autocomplete="off" placeholder="Dán số lệnh đơn cần kiểm tra"><button type="button" id="ck-go">KIỂM TRA</button></div>
      <div id="ck-out"><div class="ck-hint">Dán số lệnh đầy đủ (có thể kèm tiền tố 01–09 ở đầu) rồi bấm KIỂM TRA. Tool tra đơn trên BO (đơn cũ cũng được, tìm tới 6 tháng gần nhất), gọi Bank Check, và cho biết khách có bao nhiêu tài khoản, tài khoản trên đơn là cũ hay mới. Chỉ xem, không khóa/đổi đơn.</div></div></div>`;
    q('[data-back]',el).onclick=back;wireCkTabs(el);wireLogHeadDrag(el);wireCkScale(el);
    const input=q('#ck-input',el),go=q('#ck-go',el),out=q('#ck-out',el);ckHardenInput(input);
    const histHTML=(h)=>h&&h.length?`<div class="ck-card"><h5>LỊCH SỬ XỬ LÝ CỦA ĐƠN NÀY <em>${h.length} dòng</em></h5>${h.map(x=>`<div class="ck-row ck-hist"><span>${esc(x.time)}</span><b class="${x.state==='DONE'?'ck-ok':x.state==='RETURN'||x.state==='STOP'?'ck-bad':''}">${esc(x.label)}${x.provider?' · '+esc(x.provider):''}${x.reason?' — '+esc(x.reason):''}</b></div>`).join('')}</div>`:'';
    const acctHTML=(ac,av)=>{
      if(!ac)return '';
      if(ac.error)return `<div class="ck-card"><h5>TÀI KHOẢN CỦA KHÁCH <em>không lấy được</em></h5><div class="ck-note">${esc(ac.error)}</div></div>`;
      const tag=(t,c)=>`<i class="ck-tag ${c}">${t}</i>`;
      const rowsA=(ac.items||[]).map(x=>`<div class="ck-acct ${x.match?'hit':''}"><div class="ck-acct-main"><b>${esc(x.bank)}</b><span>${esc(x.masked)}</span></div><div class="ck-acct-meta"><span>${esc(x.type)} · tạo ${esc(x.created)}</span><div>${x.match?tag('TÀI KHOẢN TRÊN ĐƠN','hit'):''}${x.newest?tag('MỚI NHẤT','new'):''}${x.def?tag('MẶC ĐỊNH','def'):''}${x.active?'':tag('ĐÃ HỦY','off')}</div></div></div>`).join('');
      return `<div class="ck-card"><h5>TÀI KHOẢN CỦA KHÁCH <em>${esc(ac.summary||'')}</em></h5>${rowsA||'<div class="ck-note">Khách chưa có tài khoản rút nào.</div>'}</div>`;
    };
    const render=(r)=>{
      if(!r||r.ok===false){out.innerHTML=`<div class="ck-verdict warn"><i>!</i><div>${esc(r&&r.message||'Không kiểm tra được.')}</div></div>${histHTML(r&&r.history)}`;return;}
      const v=r.verdict||{tone:'warn',title:'',detail:''};
      const ico=v.tone==='ok'?'✓':v.tone==='bad'?'✕':'!';
      const av=r.acctVerdict;
      const avPill=av&&av.tone!=='ok'?`<u title="${esc(av.detail||'')}">${esc(String(av.title||'').replace(/\(theo BO\)/i,'').trim())}${av.detail?' · '+esc((String(av.detail).match(/\(([^)]*trước[^)]*)\)/)||[])[1]||''):''}</u>`:'';
      const api=r.api;
      const cmpHTML=api=>{const ic={ok:'✓',bad:'✕',na:'?'};
        let h=api.compare.map(c=>`<div class="ck-ab"><small>${esc(c.label.replace('Họ tên chủ tài khoản','Họ tên'))}</small><div class="${esc(c.state)}">${ic[c.state]} ${esc(c.api)}</div></div>`).join('');
        if(api.where&&api.where.tone!=='ok')h+=`<div class="ck-cmp-w ${esc(api.where.tone)}">${esc(api.where.text)}</div>`;
        h+=`<div class="ck-ab-at">Gọi lúc ${esc(api.at||'—')}</div>`;
        if(api.fields&&api.fields.length)h+='<details class="ck-cmp-d"><summary>Chi tiết API trả về</summary>'+api.fields.map(f=>`<div><b>${esc(f[0])}</b>: ${esc(f[1])}</div>`).join('')+'</details>';
        return h;};
      const apiRows=api&&api.usdt?[['Mạng',api.bank||'—'],['Địa chỉ ví',api.account||'—'],['Xác minh',api.status==='VALID'?'✓ Hợp lệ':api.status==='INVALID'?'✕ Không hợp lệ':'Chưa kết luận',api.status==='VALID'?'ok':api.status==='INVALID'?'bad':'warn'],['Gọi lúc',api.at||'—']]:api?[['Ngân hàng (API)',api.bank||'—'],['Số tài khoản (API)',api.account||'—'],['Tên chủ TK (API)',api.fullname||(api.nameNotReturned?'API không trả tên':'—')],['Xác minh',api.status==='VALID'?'✓ Khớp':api.status==='INVALID'?'✕ Không khớp':'Chưa kết luận',api.status==='VALID'?'ok':api.status==='INVALID'?'bad':'warn'],['Gọi lúc',api.at||'—']]:[];
      const srcTxt=r.source==='API'?'tra từ BO':'đọc từ dòng đơn';
      out.innerHTML=`${r.note?`<div class="ck-note ck-prefix">${esc(r.note)}</div>`:''}<div class="ck-verdict ck-vc ${esc(v.tone)}"><i>${ico}</i><b>${esc(v.title)}</b><span>${esc(v.detail)}</span>${avPill}</div><div class="ck-grid2"><div class="ck-card"><h5>THÔNG TIN TRÊN BO <em>${srcTxt}</em></h5>${rowsHTML(r.bo)}</div><div class="ck-card"><h5>${api&&api.usdt?'KIỂM TRA VÍ USDT':'KẾT QUẢ API NGÂN HÀNG'} <em>${api&&api.usdt?'qua mạng blockchain':'gọi trực tiếp'}</em></h5>${api?(api.compare&&!api.usdt?cmpHTML(api):rowsHTML(apiRows))+(api.message?`<div class="ck-note">${esc(api.message)}</div>`:'')+'<div class="ck-note">Chỉ xem, không khóa/không đổi đơn</div>':'<div class="ck-note">Chưa gọi API.</div>'}</div></div>${bwCardHTML(api&&api.bankWeb)}${acctHTML(r.accounts,av)}${histHTML(r.history)}`;
    };
    let busy=false;
    const run=async()=>{
      if(busy)return;
      const bot=window.AD88_XNK_BOT;
      if(!bot||typeof bot.checkOrder!=='function'){render({ok:false,message:'Tool chưa sẵn sàng, hãy tải lại trang BO rồi thử lại.'});return;}
      busy=true;go.disabled=true;go.textContent='ĐANG KIỂM TRA…';out.innerHTML='<div class="ck-hint">Đang đọc đơn và gọi Bank Check…</div>';
      try{render(await bot.checkOrder(input.value));}catch(e){render({ok:false,message:String(e&&e.message||e)});}
      busy=false;go.disabled=false;go.textContent='KIỂM TRA';
    };
    go.onclick=run;input.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();run();}};
    if(prefill){input.value=String(prefill);run();} // 1.4.240: mở từ Thống kê → điền sẵn mã đơn và kiểm tra luôn
    else setTimeout(()=>{try{input.focus();}catch(_){}} ,50);
  }
  // ===== 1.4.183: tab "CHECK ĐƠN NHẬP" (đơn nạp, chỉ đọc; gọi window.AD88_XNK_BOT.checkDeposit) =====
  function renderDepositCheck(el){
    if(checkLockedGate(el))return;
    const rowsHTML=(arr)=>(arr||[]).map(r=>`<div class="ck-row"><span>${esc(r[0])}</span><b class="${r[2]==='warn'?'ck-warn':r[2]==='ok'?'ck-ok':r[2]==='bad'?'ck-bad':''}">${esc(r[1])}</b></div>`).join('');
    el.innerHTML=`<div class="ad88-log-page ck-page"><div class="ad88-log-page-head"><div class="ad88-log-title"><span>▣</span><div><b>NHẬT KÝ XỬ LÝ ĐƠN</b><small>Kiểm tra đơn NẠP theo số lệnh</small></div></div><button class="ad88-log-home" type="button" data-back="1">← QUAY LẠI GIAO DIỆN TRANG CHỦ</button></div>${ckTabsHTML('dep')}
      <div class="ck-search"><input id="ck-input" type="text" inputmode="numeric" autocomplete="off" placeholder="Dán số lệnh đơn nạp cần kiểm tra"><button type="button" id="ck-go">KIỂM TRA</button></div>
      <div id="ck-out"><div class="ck-hint">Dán số lệnh đơn nạp rồi bấm KIỂM TRA. Tool tra đơn ở cả “Tổng nạp tiền” và “Tổng nạp nhanh” trên BO (tìm tới 6 tháng gần nhất) và hiện đủ: tài khoản, thời gian tạo/thành công, cấp độ, tiền tệ, số tiền, hạng mục, nhà thứ 3, tỷ lệ phí, người thao tác, tình trạng đơn. Chỉ xem, không bấm/khóa/đổi đơn.</div></div></div>`;
    q('[data-back]',el).onclick=back;wireCkTabs(el);wireLogHeadDrag(el);wireCkScale(el);
    const input=q('#ck-input',el),go=q('#ck-go',el),out=q('#ck-out',el);ckHardenInput(input);
    const render=(r)=>{
      if(!r||r.ok===false){out.innerHTML=`<div class="ck-verdict warn"><i>!</i><div>${esc(r&&r.message||'Không kiểm tra được.')}</div></div>`;return;}
      const v=r.verdict||{tone:'warn',title:'',detail:''};
      const ico=v.tone==='ok'?'✓':v.tone==='bad'?'✕':'!';
      out.innerHTML=`<div class="ck-verdict ${esc(v.tone)}"><i>${ico}</i><div>${esc(v.title)}<br><span>${esc(v.detail)}</span></div></div><div class="ck-grid2"><div class="ck-card"><h5>THÔNG TIN ĐƠN NẠP <em>tra từ BO</em></h5>${rowsHTML(r.left)}</div><div class="ck-card"><h5>KÊNH NẠP</h5>${rowsHTML(r.right)}</div></div><div class="ck-card"><h5>TIỀN &amp; PHÍ NHÀ THỨ 3 <em>phí lấy từ BO</em></h5>${rowsHTML(r.money)}</div><div class="ck-card"><h5>THÔNG TIN KHÁCH</h5>${rowsHTML(r.extra)}</div>`;
    };
    let busy=false;
    const run=async()=>{
      if(busy)return;
      const bot=window.AD88_XNK_BOT;
      if(!bot||typeof bot.checkDeposit!=='function'){render({ok:false,message:'Tool chưa sẵn sàng, hãy tải lại trang BO rồi thử lại.'});return;}
      busy=true;go.disabled=true;go.textContent='ĐANG KIỂM TRA…';out.innerHTML='<div class="ck-hint">Đang tra đơn nạp trên BO…</div>';
      try{render(await bot.checkDeposit(input.value));}catch(e){render({ok:false,message:String(e&&e.message||e)});}
      busy=false;go.disabled=false;go.textContent='KIỂM TRA';
    };
    go.onclick=run;input.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();run();}};
    setTimeout(()=>{try{input.focus();}catch(_){}} ,50);
  }
  // ===== 1.4.239: CHECK TÊN TK — bấm vào một lần nạp để xem đủ thông tin đơn (mã đơn, giờ, tiền, nhà thứ 3, phí…). Chỉ xem.
  function showDepRowDetail(r,account){
    if(!r)return;
    const root=q('#ad88-xnk-tool-root');if(!root)return;
    q('.ol2-modal',root)?.remove();
    const d=r.detail||null;
    const tone=r.tone==='ok'?'ok':r.tone==='bad'?'bad':'warn';
    const badge=tone==='ok'?'✓ NẠP THÀNH CÔNG':tone==='bad'?'✕ NẠP KHÔNG THÀNH CÔNG':'… ĐƠN ĐANG CHỜ';
    const COPY={'Số lệnh':1,'Mã đơn nhà thứ 3':1};
    const okv=v=>v&&v!=='—'&&!/^—/.test(v);
    const cp=v=>`<button type="button" class="ol2-cp" data-copy="${esc(v)}" title="Sao chép">⧉ Chép</button>`;
    const rowsHTML=(arr)=>(arr||[]).filter(x=>x&&x[0]!=='Số lệnh').map(x=>`<div class="ck-row${COPY[x[0]]&&okv(String(x[1]))?' cp':''}"><span>${esc(x[0])}</span><b class="${x[2]==='warn'?'ck-warn':x[2]==='ok'?'ck-ok':x[2]==='bad'?'ck-bad':''}">${esc(x[1])}</b>${COPY[x[0]]&&okv(String(x[1]))?cp(String(x[1])):''}</div>`).join('');
    const amt=r.vnd?Number(r.vnd).toLocaleString('en-US')+' VND':String(r.amount);
    const fallback=[["Tài khoản thành viên",String(account||'—')],["Tạo lệnh lúc",r.created||'—'],["Thành công lúc",r.done||'—',tone==='ok'?'ok':''],["Số tiền",amt],["Hạng mục nạp",r.cat||'—'],["Nhà thứ 3",r.prov||'—'],["Tình trạng đơn",r.status||'—',tone]];
    const v=d&&d.verdict;
    const m=document.createElement('div');
    m.className='ol2-modal ck-modal';
    m.innerHTML=`<div class="ol2-sheet ck-sheet ${tone}" role="dialog" aria-label="Chi tiết đơn nạp">
      <div class="ol2-sh-head"><span class="ol2-badge">${badge}</span><time>Lần nạp #${esc(String(r.no||''))}</time><button type="button" class="ol2-close" aria-label="Đóng">×</button></div>
      <div class="ck-no"><span>Mã đơn</span><b>${esc(r.orderNo||'—')}</b>${okv(r.orderNo)?cp(r.orderNo):''}</div>
      <div class="ck-no-meta"><b>${esc(amt)}</b>${r.first?'<i class="ck-tag def">NẠP ĐẦU</i>':''}<span>${esc(account||'')}</span></div>
      ${v&&v.detail?`<div class="ck-verdict ${tone}"><i>${tone==='ok'?'✓':tone==='bad'?'✕':'!'}</i><div>${esc(v.detail)}</div></div>`:''}
      ${d?`<div class="ck-grid2"><div class="ck-card"><h5>THÔNG TIN ĐƠN NẠP</h5>${rowsHTML(d.left)}</div><div class="ck-card"><h5>KÊNH NẠP</h5>${rowsHTML(d.right)}</div></div><div class="ck-card"><h5>TIỀN &amp; PHÍ NHÀ THỨ 3 <em>phí lấy từ BO</em></h5>${rowsHTML(d.money)}</div><div class="ck-card"><h5>THÔNG TIN KHÁCH</h5>${rowsHTML(d.extra)}</div>`:`<div class="ck-card"><h5>THÔNG TIN ĐƠN NẠP</h5>${rowsHTML(fallback)}</div>`}
    </div>`;
    root.appendChild(m);
    const close=()=>{m.remove();document.removeEventListener('keydown',onKey,true);};
    const onKey=e=>{if(e.key==='Escape'){e.stopPropagation();close();}};
    document.addEventListener('keydown',onKey,true);
    m.addEventListener('click',e=>{if(e.target===m)close();});
    q('.ol2-close',m).onclick=close;
    m.querySelectorAll('.ol2-cp').forEach(b=>b.onclick=()=>copyText(b.dataset.copy).then(okc=>{b.textContent=okc?'✓ Đã chép':'Không chép được';b.classList.toggle('done',okc);setTimeout(()=>{b.textContent='⧉ Chép';b.classList.remove('done');},1300);}));
  }
  // ===== 1.4.184: tab "CHECK TÊN TK" (lịch sử nạp của một tài khoản thành viên; chỉ đọc; gọi window.AD88_XNK_BOT.checkAccount) =====
  function renderAccountCheck(el){
    if(checkLockedGate(el))return;
    const rowsHTML=(arr)=>(arr||[]).map(r=>`<div class="ck-row"><span>${esc(r[0])}</span><b class="${r[2]==='warn'?'ck-warn':r[2]==='ok'?'ck-ok':r[2]==='bad'?'ck-bad':''}">${esc(r[1])}</b></div>`).join('');
    el.innerHTML=`<div class="ad88-log-page ck-page"><div class="ad88-log-page-head"><div class="ad88-log-title"><span>▣</span><div><b>NHẬT KÝ XỬ LÝ ĐƠN</b><small>Kiểm tra lịch sử nạp theo tên tài khoản</small></div></div><button class="ad88-log-home" type="button" data-back="1">← QUAY LẠI GIAO DIỆN TRANG CHỦ</button></div>${ckTabsHTML('acct')}
      <div class="ck-search"><input id="ck-input" type="text" autocomplete="off" placeholder="Nhập tên tài khoản thành viên"><button type="button" id="ck-go">KIỂM TRA</button></div>
      <div class="ck-range"><span>Lịch sử:</span><button type="button" data-days="31" class="on">1 tháng</button><button type="button" data-days="90">3 tháng</button><button type="button" data-days="180">6 tháng</button></div>
      <div id="ck-out"><div class="ck-hint">Nhập tên tài khoản thành viên rồi bấm KIỂM TRA. Tool lấy lịch sử nạp 1 tháng gần nhất (chọn 3 hoặc 6 tháng nếu muốn xem lâu hơn): khách đã nạp thành công bao nhiêu lần, tổng tiền, và từng lần nạp: giờ tạo, giờ thành công, số tiền, hạng mục, nhà thứ 3, tình trạng. Chỉ xem, không bấm/khóa/đổi đơn.</div></div></div>`;
    q('[data-back]',el).onclick=back;wireCkTabs(el);wireLogHeadDrag(el);wireCkScale(el);
    const input=q('#ck-input',el),go=q('#ck-go',el),out=q('#ck-out',el);ckHardenInput(input);
    let days=31;
    el.querySelectorAll('.ck-range [data-days]').forEach(b=>b.onclick=()=>{days=Number(b.dataset.days);el.querySelectorAll('.ck-range [data-days]').forEach(x=>x.classList.toggle('on',x===b));if(input.value.trim())run();});
    const dt=(v)=>{const m=String(v||'').match(/^(\d{4}-\d\d-\d\d) (\d\d:\d\d:\d\d)$/);return m?`${esc(m[1])}<span class="ck-sp"> </span><br>${esc(m[2])}`:esc(v||'—');};
    const tbl=(rows)=>`<div class="ck-trow ck-thead"><span>#</span><span>Tạo lúc</span><span>Thành công lúc</span><span class="r">Số tiền</span><span>Hạng mục · nhà</span><span>Tình trạng</span></div>`+(rows||[]).map((r,i)=>`<button type="button" class="ck-trow ck-trow-btn ${r.tone==='ok'?'ok':r.tone==='bad'?'bad':r.tone==='warn'?'warn':''}" data-ck-row="${i}" title="Bấm để xem đủ thông tin đơn"><span>${r.no}</span><span>${dt(r.created)}</span><span>${dt(r.done)}</span><span class="r"><b>${r.vnd?esc(Number(r.vnd).toLocaleString('en-US')):esc(String(r.amount))}</b>${r.first?'<i class="ck-tag def">NẠP ĐẦU</i>':''}</span><span>${esc(r.cat)} · ${esc(r.prov)}</span><span class="${r.tone==='ok'?'ck-ok':r.tone==='bad'?'ck-bad':r.tone==='warn'?'ck-warn':''}">${esc(r.status)}</span><span class="ck-trow-sub"><em>Mã đơn</em><b>${esc(r.orderNo||'—')}</b><i>Xem chi tiết ›</i></span></button>`).join('');
    const render=(r)=>{
      if(!r||r.ok===false){out.innerHTML=`<div class="ck-verdict warn"><i>!</i><div>${esc(r&&r.message||'Không kiểm tra được.')}</div></div>`;return;}
      const v=r.verdict||{tone:'warn',title:'',detail:''};
      const ico=v.tone==='ok'?'✓':v.tone==='bad'?'✕':'!';
      const warns=(r.warns||[]).map(w=>`<div class="ck-verdict warn"><i>!</i><div>${esc(w)}</div></div>`).join('');
      out.innerHTML=`<div class="ck-verdict ${esc(v.tone)}"><i>${ico}</i><div>${esc(v.title)}<br><span>${esc(v.detail)}</span></div></div>${warns}${r.summary&&r.summary.length?`<div class="ck-card"><h5>THÔNG TIN KHÁCH <em>${esc(r.account)}</em></h5>${rowsHTML(r.summary)}</div><div class="ck-card"><h5>CÁC LẦN NẠP <em>${r.count} đơn · mới nhất ở trên · bấm vào đơn để xem đủ thông tin</em></h5><div class="ck-tbl">${tbl(r.rows)}</div></div>`:''}`;
      const rows=Array.isArray(r.rows)?r.rows:[];
      out.querySelectorAll('[data-ck-row]').forEach(b=>b.onclick=()=>showDepRowDetail(rows[Number(b.dataset.ckRow)],r.account));
    };
    let busy=false;
    const run=async()=>{
      if(busy)return;
      const bot=window.AD88_XNK_BOT;
      if(!bot||typeof bot.checkAccount!=='function'){render({ok:false,message:'Tool chưa sẵn sàng, hãy tải lại trang BO rồi thử lại.'});return;}
      busy=true;go.disabled=true;go.textContent='ĐANG KIỂM TRA…';out.innerHTML='<div class="ck-hint">Đang đọc lịch sử nạp trên BO…</div>';
      try{render(await bot.checkAccount(input.value,{days}));}catch(e){render({ok:false,message:String(e&&e.message||e)});}
      busy=false;go.disabled=false;go.textContent='KIỂM TRA';
    };
    go.onclick=run;input.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();run();}};
    setTimeout(()=>{try{input.focus();}catch(_){}} ,50);
  }
  function renderLog(el){
    if(checkLockedGate(el))return;
    const root=q('#ad88-xnk-tool-root');
    if(!root) return;
    const st=window.AD88_XNK_BOT?.status?.()||{};
    const logs=Array.isArray(st.orderLogs)?st.orderLogs:[];
    const range=getSavedLogRange();
    const filtered=filterLogsByRange(logs,range.from,range.to).filter(x=>x.state==='DONE'||x.state==='RETURN').slice().sort((a,b)=>(Number(b.timestamp)||0)-(Number(a.timestamp)||0));
    const fmtDateTime=x=>`${esc(x.date||'—')} ${esc(x.time||'—')}`;
    const amountText=x=>x.amount!=null?`${Number(x.amount).toLocaleString('vi-VN')} ${esc(x.currency||'')}`:'—';
    const statusMeta=x=>{
      if(x.state==='DONE') return ['success','✓','Thành công'];
      if(x.state==='RETURN') return ['return','↶','Trả lại'];
      return ['return','↶','Trả lại'];
    };
    const pageSize=10;
    let page=1;
    const totalPages=Math.max(1,Math.ceil(filtered.length/pageSize));

    el.innerHTML=`<div class="ad88-log-page">
      <div class="ad88-log-page-head"><div class="ad88-log-title"><span>▣</span><div><b>NHẬT KÝ XỬ LÝ ĐƠN</b><small>Theo dõi toàn bộ hoạt động xử lý đơn của tool</small></div></div><button class="ad88-log-home" type="button" data-back="1">← QUAY LẠI GIAO DIỆN TRANG CHỦ</button></div>
      <div class="ad88-log-filter ad88-log-filter-pro"><div class="ad88-log-quick"><button type="button" id="log-today">Hôm nay</button><button type="button" id="log-yesterday">Hôm qua</button><button type="button" id="log-7days">7 ngày</button><button type="button" id="log-30days">30 ngày</button><button type="button" id="log-custom">Chọn thời gian</button></div><div class="ad88-log-date-row"><label><span>TỪ NGÀY</span><input id="log-from" type="datetime-local" value="${esc(range.from)}"></label><label><span>ĐẾN NGÀY</span><input id="log-to" type="datetime-local" value="${esc(range.to)}"></label><button type="button" id="log-apply" class="primary">⌕ ÁP DỤNG</button><button type="button" id="download-order-log" class="excel" ${filtered.length?'':'disabled'}>▣ XUẤT EXCEL</button></div></div>
      <section class="ad88-log-table-card ad88-log-table-card-full"><div class="ad88-log-table-head"><div><b>▣ DANH SÁCH NHẬT KÝ XỬ LÝ ĐƠN</b><span>Hiển thị ${filtered.length.toLocaleString('vi-VN')} dòng</span></div><span>${esc(range.from.replace('T',' '))} → ${esc(range.to.replace('T',' '))}</span></div><div class="ad88-log-table-scroll"><table class="ad88-log-table"><thead><tr><th>STT</th><th>THỜI GIAN</th><th>MÃ ĐƠN</th><th>SỐ TIỀN VND</th><th>USDT</th><th>NHÀ THỨ 3</th><th>NGƯỜI THAO TÁC</th><th>TRẠNG THÁI</th><th>LÝ DO</th></tr></thead><tbody id="ad88-log-tbody"></tbody></table></div><div class="ad88-log-pagination" id="ad88-log-pagination"></div></section>
    </div>`;

    const tbody=q('#ad88-log-tbody',el), pager=q('#ad88-log-pagination',el);
    const renderTable=()=>{
      const start=(page-1)*pageSize, rows=filtered.slice(start,start+pageSize);
      tbody.innerHTML=rows.length?rows.map((x,i)=>{const [tone,icon,label]=statusMeta(x);const isUsdt=x.currency==='USDT';const vndText=!isUsdt&&x.amount!=null?`${Number(x.amount).toLocaleString('vi-VN')} VND`:'—';const usdtText=isUsdt&&x.amount!=null?`${Number(x.amount).toLocaleString('en-US',{maximumFractionDigits:8})} USDT`:'—';return `<tr data-log-index="${start+i}"><td>${start+i+1}</td><td>${fmtDateTime(x)}</td><td class="order-no">${esc(x.order||'—')}</td><td class="amount">${vndText}</td><td class="amount ${isUsdt?'usdt':''}">${usdtText}</td><td>${esc(x.provider||'—')}</td><td>${esc(x.operator||'—')}</td><td><b class="log-status ${tone}">${icon} ${label}</b></td><td class="log-reason-cell">${x.state==='RETURN'?esc(x.reason||'—'):'—'}</td></tr>`}).join(''):`<tr><td colspan="9"><div class="ad88-log-empty">Không có đơn trong khoảng thời gian đã chọn.</div></td></tr>`;
      const nums=Array.from({length:Math.min(totalPages,7)},(_,i)=>i+1).map(p=>`<button type="button" class="${page===p?'active':''}" data-journal-page="${p}">${p}</button>`).join('');
      pager.innerHTML=`<span>Hiển thị <b>${pageSize}</b> dòng/trang</span><div><button type="button" data-journal-page="prev" aria-label="Trang trước">‹</button>${nums}${totalPages>7?`<i>…</i><button type="button" data-journal-page="${totalPages}">${totalPages}</button>`:''}<button type="button" data-journal-page="next" aria-label="Trang sau">›</button></div><span>Trang ${page} / ${totalPages} (Tổng: ${filtered.length.toLocaleString('vi-VN')} dòng)</span>`;
      pager.querySelectorAll('[data-journal-page]').forEach(b=>b.onclick=e=>{
        e.preventDefault();
        e.stopPropagation();
        const action=b.dataset.journalPage;
        const p=action==='next'?Math.min(totalPages,page+1):action==='prev'?Math.max(1,page-1):Number(action);
        if(p>=1&&p<=totalPages&&p!==page){page=p;renderTable();}
      });
    };
    renderTable();
    q('[data-back]',el).onclick=back;
    try{const hd=q('.ad88-log-page-head',el);if(hd&&!q('.ck-tabs',el)){hd.insertAdjacentHTML('afterend',ckTabsHTML('log'));wireCkTabs(el);}wireCkScale(el);}catch(_){}
    const from=q('#log-from',el),to=q('#log-to',el);
    const apply=()=>{if(!from?.value||!to?.value)return;const a=new Date(from.value).getTime(),b=new Date(to.value).getTime();if(!Number.isFinite(a)||!Number.isFinite(b)||a>b){showToast('Khoảng thời gian không hợp lệ');return;}saveLogRange(from.value,to.value);renderLog(el);};
    q('#log-apply',el).onclick=apply;
    q('#log-today',el).onclick=()=>{setQuickLogRange('today');renderLog(el);};
    q('#log-yesterday',el).onclick=()=>{setQuickLogRange('yesterday');renderLog(el);};
    q('#log-7days',el).onclick=()=>{const now=new Date(),start=new Date(now);start.setDate(start.getDate()-6);start.setHours(0,0,0,0);saveLogRange(localDateTimeValue(start),localDateTimeValue(now));renderLog(el);};
    q('#log-30days',el).onclick=()=>{const now=new Date(),start=new Date(now);start.setDate(start.getDate()-29);start.setHours(0,0,0,0);saveLogRange(localDateTimeValue(start),localDateTimeValue(now));renderLog(el);};
    q('#log-custom',el).onclick=()=>from?.focus();
    const dl=q('#download-order-log',el);if(dl)dl.onclick=()=>downloadOrderLogCsv(filtered);

    // Journal-only drag: use the desktop mouse events on the actual journal header.
    // This intentionally does NOT touch the global Tool/root drag handlers.
    const logHead=q('.ad88-log-page-head',el);
    if(logHead){
      let drag=null;
      const moveDrag=e=>{
        if(!drag)return;
        const dx=e.clientX-drag.sx,dy=e.clientY-drag.sy;
        if(Math.abs(dx)+Math.abs(dy)>3)drag.moved=true;
        if(!drag.moved)return;
        const r=root.getBoundingClientRect();
        const x=Math.max(4,Math.min(drag.x+dx,window.innerWidth-r.width-4));
        const y=Math.max(4,Math.min(drag.y+dy,window.innerHeight-r.height-4));
        root.style.left=x+'px';root.style.top=y+'px';root.style.right='auto';root.style.bottom='auto';
        e.preventDefault();
      };
      const stopDrag=()=>{
        if(!drag)return;
        if(drag.moved) savePosition(root,true);
        drag=null;
        document.removeEventListener('mousemove',moveDrag);
        document.removeEventListener('mouseup',stopDrag);
      };
      logHead.addEventListener('mousedown',e=>{
        if(e.button!==0 || e.target.closest('button'))return;
        const r=root.getBoundingClientRect();
        drag={sx:e.clientX,sy:e.clientY,x:r.left,y:r.top,moved:false};
        document.addEventListener('mousemove',moveDrag);
        document.addEventListener('mouseup',stopDrag);
        e.preventDefault();
      });
    }
  }
  function renderAbout(el){el.innerHTML=head('Thông tin Tool')+`<div class="ad88-about"><b>AD88 XNK TOOL</b><p>Phát triển Tool kiểm tra đơn, số tài khoản ngân hàng và xử lý đơn trên bộ WG.</p><p>Phát triển bởi <b>Awei</b> dành riêng cho <b>AD88</b>.</p><p><b>Cấm sao chép, sao lưu, phân phối, chỉnh sửa hoặc sử dụng Tool dưới bất cứ hình thức nào ngoài AD88 khi chưa được Awei cho phép.</b></p><p>Cấu hình nhà thứ 3 cho phép bật/tắt từng cổng tự động. Tắt cổng nào thì Tool không tự chọn cổng đó.</p><small>Version ${AD88_VERSION}</small></div>`;q('[data-back]',el).onclick=back;}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',create);else create();
})();