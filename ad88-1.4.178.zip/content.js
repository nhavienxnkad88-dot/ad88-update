// Bản chuyên dụng cho Brand: AD88 (platform: "WGAD88").
// 1.4.116: License Key / Secret Key của API Bank Check KHÔNG còn nằm trong mã nguồn.
// Khóa nhập ở Cài đặt → Khóa API Bank Check (lưu ở chrome.storage.local); việc ký HMAC và gọi API
// do background.js thực hiện (chỉ khi máy có License hợp lệ).
const BASE_URL = "https://apibo.memberappu.com";
const BANKING_API_URL = `${BASE_URL}/api/v4/banking-info`;

const BRAND_ID = "WGAD88";
const BRAND_NAME = "AD88";

const SHORTCUT_STORAGE_KEY = "bankVipShortcut_ad88";
const DEFAULT_SHORTCUT = { ctrl: false, alt: true, shift: false, meta: false, code: "KeyS" };

const currentPlatform = BRAND_ID;

function getStoredShortcut() {
  return new Promise(resolve => {
    const timer = setTimeout(() => resolve(DEFAULT_SHORTCUT), 200);
    try {
      if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) {
        chrome.storage.local.get([SHORTCUT_STORAGE_KEY], data => {
          clearTimeout(timer);
          const raw = data && data[SHORTCUT_STORAGE_KEY];
          // "code" là format mới (so theo phím vật lý). Nếu còn bản lưu cũ dạng "key" (trước khi
          // sửa lỗi Mac) thì bỏ qua, dùng lại mặc định thay vì so khớp sai.
          resolve(raw && raw.code ? raw : DEFAULT_SHORTCUT);
        });
      } else {
        clearTimeout(timer);
        resolve(DEFAULT_SHORTCUT);
      }
    } catch (e) {
      clearTimeout(timer);
      resolve(DEFAULT_SHORTCUT);
    }
  });
}
function setStoredShortcut(shortcut) {
  return new Promise(resolve => {
    try {
      chrome.storage.local.set({ [SHORTCUT_STORAGE_KEY]: shortcut }, resolve);
    } catch (e) {
      resolve();
    }
  });
}

let currentShortcut = DEFAULT_SHORTCUT;
let capturingShortcut = false; // true khi widget đang chờ người dùng bấm tổ hợp phím mới

// ---- Cầu nối gọi API Bank Check qua background.js ----
const AD88_STORAGE_LICENSE = "AD88_API_LICENSE_KEY";
const AD88_STORAGE_SECRET = "AD88_API_SECRET_KEY";

function ad88StorageGet(keys) {
  return new Promise(resolve => {
    try {
      chrome.storage.local.get(keys, data => resolve(chrome.runtime.lastError ? {} : (data || {})));
    } catch (e) { resolve({}); }
  });
}
function ad88StorageSet(obj) {
  return new Promise(resolve => {
    try { chrome.storage.local.set(obj, () => resolve(!chrome.runtime.lastError)); }
    catch (e) { resolve(false); }
  });
}
function ad88StorageRemove(keys) {
  return new Promise(resolve => {
    try { chrome.storage.local.remove(keys, () => resolve(!chrome.runtime.lastError)); }
    catch (e) { resolve(false); }
  });
}

// Quản lý khóa API do người dùng nhập. Không bao giờ trả về/ghi log toàn bộ khóa.
window.AD88_apiKeys = {
  async status() {
    const d = await ad88StorageGet([AD88_STORAGE_LICENSE, AD88_STORAGE_SECRET]);
    const lic = String(d[AD88_STORAGE_LICENSE] || "").trim();
    const sec = String(d[AD88_STORAGE_SECRET] || "").trim();
    return { hasLicense: !!lic, hasSecret: !!sec, licenseTail: lic ? lic.slice(-4) : "" };
  },
  async save(license, secret) {
    const lic = String(license || "").trim();
    const sec = String(secret || "").trim();
    if (!lic || !sec || /\s/.test(lic + sec)) return false;
    return ad88StorageSet({ [AD88_STORAGE_LICENSE]: lic, [AD88_STORAGE_SECRET]: sec });
  },
  async clear() { return ad88StorageRemove([AD88_STORAGE_LICENSE, AD88_STORAGE_SECRET]); }
};

// Gửi message sang background, luôn có "van" thời gian để không treo luồng xử lý đơn.
function ad88SendToBackground(message, guardMs) {
  return new Promise(resolve => {
    let settled = false;
    const finish = v => { if (!settled) { settled = true; clearTimeout(timer); resolve(v); } };
    const timer = setTimeout(() => finish({ ok: false, timeout: true, bridgeError: true,
      message: "Background không phản hồi kịp thời gian." }), guardMs);
    try {
      chrome.runtime.sendMessage(message, res => {
        const err = chrome.runtime.lastError;
        if (err) return finish({ ok: false, bridgeError: true, message: String(err.message || err) });
        finish(res || { ok: false, bridgeError: true, message: "Background không trả dữ liệu." });
      });
    } catch (e) {
      // Thường gặp khi extension vừa được tải lại/cập nhật nhưng tab BO chưa F5.
      finish({ ok: false, bridgeError: true,
        message: "Extension vừa được tải lại — hãy F5 trang BO. (" + String(e && e.message || e) + ")" });
    }
  });
}

// Giữ nguyên chữ ký và kiểu kết quả của fetchApiV4 cũ để phần còn lại của core không đổi.
async function fetchApiV4(url, body, options = {}) {
  const startedAt = Date.now();
  const timeoutMs = Number(options && options.timeoutMs);
  const hasTimeout = Number.isFinite(timeoutMs) && timeoutMs > 0;
  const guardMs = (hasTimeout ? timeoutMs : 30000) + 3000;
  const metric = detail => { try { window.dispatchEvent(new CustomEvent("AD88_API_METRIC", { detail })); } catch {} };

  const res = await ad88SendToBackground({ type: "AD88_BANK_API", url, body, timeoutMs: hasTimeout ? timeoutMs : 0 }, guardMs);
  const ms = Date.now() - startedAt;

  if (res.keyMissing || res.licenseError) {
    metric({ ms, ok: false, status: res.status || 0 });
    return { ok: false, licenseError: true, message: res.message || "License Key hoặc Secret Key không hợp lệ." };
  }
  if (res.timeout) {
    metric({ ms, ok: false, error: true, timeout: true });
    return { ok: false, licenseError: false, timeout: true, message: "Bank Checker phản hồi quá chậm; sẽ kiểm tra lại theo AUTO SYNC." };
  }
  if (res.bridgeError) {
    metric({ ms, ok: false, error: true, timeout: false });
    return { ok: false, licenseError: false, message: res.message || "Không thể kết nối máy chủ." };
  }
  metric({ ms, ok: !!res.ok, status: res.status || 0 });
  if (!res.ok) {
    return { ok: false, licenseError: false, result: res.result, message: res.message || "Không thể kết nối máy chủ." };
  }
  return { ok: true, licenseError: false, result: res.result };
}

// Hàm loại bỏ dấu tiếng Việt VÀ XÓA HẾT KHOẢNG TRẮNG
function removeVietnameseTones(str) {
  if (!str) return "";
  return str
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .replace(/đ/g, "d")
    .replace(/Đ/g, "D")
    .toUpperCase()
    .replace(/\s+/g, "") // Xóa toàn bộ dấu cách
    .trim();
}

// Bảng ánh xạ 50 ngân hàng từ WG GetBankList sang mã code của banklookup + USDT Crypto
const BANK_MAP = [
  { keys: ["USDT-TRC20", "USDT-Trc20", "USDT TRC20", "USDT_TRC20", "TRC20", "USDT (TRC20)", "USDT (TRC-20)"], code: "USDT-TRC20" },
  { keys: ["USDT-ERC20", "USDT-Erc20", "USDT ERC20", "USDT_ERC20", "ERC20", "USDT (ERC20)", "USDT (ERC-20)"], code: "USDT-ERC20" },
  { keys: ["USDT", "TETHER", "VÍ USDT", "TIỀN ẢO", "SỐ TIỀN ẢO"], code: "USDT" },
  { keys: ["LIO Bank", "LIO", "LioBank"], code: "LIO" },
  { keys: ["ACB", "ACB BANK", "Á Châu"], code: "ACB" },
  { keys: ["BIDV", "BIDV BANK"], code: "BIDV" },
  { keys: ["Vietin Bank(VTB)", "Vietin Bank", "VietinBank", "VTB", "CTG", "VIETTINBANK", "VIETTIN BANK", "VIET TINBANK", "VIET TIN BANK"], code: "VTB" },
  { keys: ["VBSP", "NHCSXH", "Chính sách xã hội"], code: "VBSP" },
  { keys: ["LIENVIETPOSTBANK(LPB)", "LIENVIETBANK(LPB)", "LIENVIETPOSTBANK", "LIENVIETBANK", "LIENVIET BANK", "LPBank", "LPB"], code: "LPB" },
  { keys: ["PVcom  Bank", "PVcom Bank", "PVCOMBANK", "PVC", "PVCB"], code: "PVCB" },
  { keys: ["VIET A BANK(VAB)", "VIET A BANK", "VIETABANK", "VAB"], code: "VAB" },
  { keys: ["Nam A BANK", "NamABank", "NAM A", "NAB"], code: "NAB" },
  { keys: ["AGRIBANK", "VBA", "VARB", "Nông nghiệp"], code: "VARB" },
  { keys: ["ShinhanBank", "Shinhan Bank", "SHINHAN BANK VN", "SHBVN", "SHINHAN"], code: "SHBVN" },
  { keys: ["HDBank", "HD BANK", "HDB"], code: "HDB" },
  { keys: ["VPBANK", "VP BANK", "VPB"], code: "VPB" },
  { keys: ["VIB", "VIB BANK"], code: "VIB" },
  { keys: ["BAOVIETBANK", "BAO VIET BANK", "BaoVietBank", "BVB"], code: "BVB" },
  { keys: ["BVBANK", "BV BANK", "BVBank", "VIET CAPITAL BANK", "VIETCAPITALBANK", "VIET CAPITAL BANK (BVBANK)", "VIETCAPITAL", "VCCB", "Bản Việt", "BAN VIET", "BANVIETBANK", "Ngân hàng Bản Việt"], code: "VCCB" },
  { keys: ["CIMB", "CIMB BANK"], code: "CIMB" },
  { keys: ["MARITIMEBANK(MSB)", "MARITIMEBANK", "MSB BANK", "MSB", "MARTIMEBANK", "MARTIME BANK", "MARTIMEBANK(MSB)"], code: "MSB" },
  { keys: ["BACABANK(BAB)", "BACA BANK", "BAC A BANK", "BacABank", "BAB"], code: "BAB" },
  { keys: ["IVB", "Indovina Bank", "INDOVINA"], code: "IVB" },
  { keys: ["SAIGONBANK(SGB)", "SAIGONBANK", "SaigonBank", "SGB"], code: "SGB" },
  { keys: ["Vietcom Bank(VCB)", "Vietcom Bank", "VIETCOMBANK", "VIETCOM BANK", "VIET COM BANK", "VIETCOMBANK(VCB)", "VCB", "VCBNEO", "Ngoại thương"], code: "VCB" },
  { keys: ["NCB", "Quốc Dân"], code: "NCB" },
  { keys: ["CAKE", "CAKE BY VPBANK"], code: "CAKE" },
  { keys: ["UBANK BY VP BANK(UBANK)", "UBANK BY VP BANK", "UBANK", "UB"], code: "UB" },
  { keys: ["Vikki Bank", "VIKKI BY HDBANK", "VikkiBank", "VIKKI", "DAB"], code: "DAB" },
  { keys: ["Woori Bank", "WOORI", "WOO"], code: "WOO" },
  { keys: ["SACOMBANK(STB)", "SACOMBANK", "Sacombank", "STB"], code: "SCB" }, // Sacombank (banklookup code: SCB, bin: 970403)
  { keys: ["OCB", "OCB BANK", "Phương Đông"], code: "OCB" },
  { keys: ["MB BANK", "MBBANK", "MB", "Quân đội"], code: "MB" },
  { keys: ["KIENLONGBANK(KLB)", "KIENLONGBANK", "KienLongBank", "KLBANK", "KLB"], code: "KLB" },
  { keys: ["SHB", "SHB BANK"], code: "SHB" },
  { keys: ["CB", "CB BANK", "CBBank", "CBB", "Xây dựng"], code: "CBB" },
  { keys: ["EXIMBANK(EIB)", "EXIMBANK", "Eximbank", "EIB", "Xuất Nhập Khẩu"], code: "EIB" },
  { keys: ["TECHCOMBANK(TCB)", "TECHCOMBANK", "Techcombank", "TCB", "Kỹ thương"], code: "TCB" },
  { keys: ["GPBANK", "GP BANK", "GPBank", "GPB", "Dầu Khí"], code: "GPB" },
  { keys: ["VDB", "Ngân hàng Phát triển Việt Nam"], code: "VDB" },
  { keys: ["VIET BANK", "VIETBANK", "VietBank", "VB", "Việt Nam Thương Tín"], code: "VB" },
  { keys: ["TPBank", "TPBANK", "TPB", "Tiên Phong"], code: "TPB" },
  { keys: ["SeABank", "SEABANK", "SEAB", "Đông Nam Á"], code: "SEAB" },
  { keys: ["HSBC(HSCB VIETNAM)", "HSBC", "HSCB VIETNAM"], code: "HSBC" },
  { keys: ["ABBANK(ABB)", "ABBANK", "ABB", "An Bình"], code: "ABB" },
  { keys: ["TIMO BANK", "TIMO", "Timo"], code: "TIMO" },
  { keys: ["VIETNAM RUSSIA BANK(VRB)", "VIETNAM RUSSIA BANK", "VRB(VIET NGA)", "VRB", "Việt Nga"], code: "VRB" },
  { keys: ["PUBLICBANKVIETNAM(VIDBANK -PUBLICBANK)", "PUBLICBANKVIETNAM(PUBLICBANK)", "PUBLICBANK", "PBVN"], code: "PBVN" },
  { keys: ["United Overseas bank(UOB)", "United Overseas bank", "UOB"], code: "UOB" },
  { keys: ["PG BANK", "PGBANK", "PGB", "Petrolimex"], code: "PGB" },
  { keys: ["SCB BANK(SCB)", "SCB BANK", "SGCB", "Sài Gòn"], code: "SGCB" }, // Ngân hàng TMCP Sài Gòn (banklookup code: SGCB, bin: 970429)
  { keys: ["NGAN HANG HOP TAC(Co-opBank)", "NGAN HANG HOP TAC", "CO-OPBANK", "COOPBANK", "COOPB", "Hợp tác xã"], code: "COOPB" },
  { keys: ["MBV NH TNHH MTV VIET NAM HIEN DAI", "MBV", "Oceanbank", "Việt Nam Hiện Đại"], code: "MBV" },
  { keys: ["HONG LEONG BANK (HLBVN)", "HONG LEONG BANK", "HONGLEONG BANK", "HLBVN", "HONG LEONG", "HLB"], code: "HLB" },
];

// Số BIN (codeBank) của từng mã ngân hàng, lấy từ trường "bin" trong banklookup.json
// (bổ sung MAFC/CITIBANK/KEBHANAHCM từ danh sách ngân hàng thành viên VietQR/Napas vì
// banklookup.json không có 3 ngân hàng này). ANZ/VDB/BIDC không có BIN vì không thuộc hệ
// VietQR/Napas — nếu gặp các mã này, resolveBankCode() vẫn trả code nhưng sẽ không có BIN,
// nơi gọi (checkAccountV3) sẽ tự bỏ qua không gửi bank/codeBank thay vì chặn cả lượt quét.
const BIN_BY_CODE = {
  ABB: 970425, ACB: 970416, BAB: 970409, BIDV: 970418, BVB: 970438,
  CAKE: 546034, CBB: 970444, CIMB: 422589, CITIBANK: 533948, COOPB: 970446,
  DAB: 970406, DBS: 796500, EIB: 970431, GPB: 970408, HDB: 970437,
  HLB: 970442, HSBC: 458761, IBKHCM: 970456, IBKHN: 970455, IVB: 970434,
  KB: 668888, KBKHCM: 970463, KBKHN: 970462, KEBHANAHCM: 970466, KLB: 970452,
  LIO: 963369, LPB: 970449, MAFC: 977777, MB: 970422, MBV: 970414,
  MOMO: 971025, MSB: 970426, NAB: 970428, NCB: 970419, NHB: 801011,
  OCB: 970448, PBVN: 970439, PGB: 970430, PVCB: 970412, SCB: 970403,
  SCBVN: 970410, SEAB: 970440, SGB: 970400, SGCB: 970429, SHB: 970443,
  SHBVN: 970424, TCB: 970407, TIMO: 963388, TPB: 970423, UB: 546035,
  UOB: 970458, VAB: 970427, VARB: 970405, VB: 970433, VBSP: 999888,
  VCB: 970436, VCCB: 970454, VIB: 970441, VPB: 970432, VRB: 970421,
  VTB: 970415, WOO: 970457,
};

// Tra mã ngân hàng (mã ngắn dùng cho API, vd "ACB") từ tên ngân hàng thô đọc được trên trang
// (vd "ACB BANK"). Ưu tiên khớp chính xác trước, tránh khớp nhầm kiểu "chứa chuỗi con"
// (vd "LIENVIETBANK" chứa "VIETBANK" nhưng là 2 ngân hàng khác nhau).
function resolveBankCode(rawBankName) {
  const raw = String(rawBankName || "").trim();
  const cleanRawBank = removeVietnameseTones(raw);
  if (!cleanRawBank) return "";

  const normalizedCode = value => removeVietnameseTones(String(value || "")).replace(/[^A-Z0-9]/g, "");
  const knownCodes = new Set(Object.keys(BIN_BY_CODE).map(v => normalizedCode(v)));

  // 0. Nếu chính là mã code chuẩn đã có trong BIN_BY_CODE hoặc Crypto.
  const compactInput = normalizedCode(raw);
  if (knownCodes.has(compactInput)) return compactInput;
  if (/^(USDT|TRC20|ERC20|USDTTRC20|USDTERC20)$/i.test(compactInput)) return compactInput;

  // 1. Nếu BO hiển thị mã trong ngoặc, ví dụ TECHCOMBANK(TCB), ưu tiên mã đó.
  // Đây là tín hiệu định danh mạnh hơn mọi phép tìm chuỗi con.
  const parenthesized = String(raw).match(/\(\s*([A-Za-z0-9_-]{2,12})\s*\)/g) || [];
  for (const part of parenthesized) {
    const m = part.match(/\(\s*([A-Za-z0-9_-]{2,12})\s*\)/);
    const candidate = normalizedCode(m?.[1] || "");
    if (candidate && knownCodes.has(candidate)) return candidate;
  }

  // 2. So khớp tuyệt đối với mã code trực tiếp.
  for (const item of BANK_MAP) {
    const itemCode = normalizedCode(item.code);
    if (itemCode && compactInput === itemCode) return item.code;
  }

  // 3. So khớp tuyệt đối với alias. Dùng compact form vì removeVietnameseTones()
  // đã loại khoảng trắng/dấu tiếng Việt.
  for (const item of BANK_MAP) {
    for (const k of item.keys || []) {
      const alias = normalizedCode(k);
      if (alias && compactInput === alias) return item.code;
    }
  }

  // 4. Fallback cho tên ngân hàng có trạng thái/ghi chú nối phía sau.
  // KHÔNG dùng includes() tự do nữa. Chỉ cho phép alias đủ dài xuất hiện ở
  // ĐẦU chuỗi, hoặc xuất hiện ngay sau một ranh giới rõ ràng. Điều này chặn
  // hoàn toàn lỗi kiểu:
  //   TECHCOMBANK(TCB) -> MB
  //   MBV ...          -> MB
  // trong khi vẫn nhận được tên như "TECHCOMBANK(TCB) Đã khóa...".
  const fallbackCandidates = [];
  for (const item of BANK_MAP) {
    for (const k of item.keys || []) {
      const aliasCompact = normalizedCode(k);
      if (!aliasCompact || aliasCompact.length < 4) continue;

      // Alias phải nằm ở đầu compact input. Không cho mã ngắn/chuỗi con ở giữa
      // tên ngân hàng thắng một alias đầy đủ.
      if (compactInput.startsWith(aliasCompact)) {
        fallbackCandidates.push({ code: item.code, alias: aliasCompact, length: aliasCompact.length });
      }
    }
  }
  if (fallbackCandidates.length) {
    fallbackCandidates.sort((a, b) => b.length - a.length);
    return fallbackCandidates[0].code;
  }

  // 5. Nếu truyền vào số BIN, tra ngược lại mã code.
  const numBin = parseInt(compactInput, 10);
  if (numBin && compactInput.length >= 4 && compactInput.length <= 8) {
    for (const [code, bin] of Object.entries(BIN_BY_CODE)) {
      if (bin === numBin) return code;
    }
  }
  return "";
}

function resolveBankAndBin(rawBank, rawCodeBank) {
  let bankCode = "";
  let binCode = "";

  if (rawBank) {
    bankCode = resolveBankCode(rawBank);
  }
  if (!bankCode && rawCodeBank) {
    bankCode = resolveBankCode(rawCodeBank);
  }

  if (bankCode) {
    if (BIN_BY_CODE[bankCode]) {
      binCode = String(BIN_BY_CODE[bankCode]);
    }
  }

  // Nếu binCode chưa có nhưng rawCodeBank là số BIN hợp lệ
  if (!binCode && rawCodeBank && /^\d+$/.test(String(rawCodeBank).trim())) {
    binCode = String(rawCodeBank).trim();
  }

  return { bankCode, binCode };
}


// Nhãn quét dùng để định vị dòng "người nộp đơn" (lấy account) và "tên thật" (lấy tên
// kỳ vọng để đối chiếu) trong bảng chi tiết đơn. Cả 4 Platform hiện dùng chung 1 mẫu
// bảng quản trị (whitelabel giống nhau) nên dùng chung 1 bộ nhãn — tách theo id để dễ
// tuỳ biến riêng sau này nếu 1 Platform nào đó đổi nhãn khác với mẫu chung.

(() => {
  "use strict";

  const TAG = "[AWEI AD88 XNK BOT v0.6.5 QUOTA AUTO v10 SKIP-RECALL]";
  const sleep = ms => new Promise(r => setTimeout(r, ms));

  // ===== AD88 XNK HEALTH + ADAPTIVE SYNC =====
  const HEALTH_MAX_SAMPLES = 120;
  const health = {
    startedAt: Date.now(),
    lastHeartbeatAt: Date.now(),
    lastActionAt: 0,
    currentStartedAt: 0,
    currentOrder: "",
    currentAmount: null,
    currentCurrency: "VND",
    currentProvider: "",
    currentStep: "Sẵn sàng",
    currentStepStartedAt: 0,
    processSamples: [],
    actionSamples: [],
    apiSamples: [],
    errors: 0,
    timeouts: 0,
    completed: 0,
    skipped: 0,
    manual: 0,
    lastResult: "",
    lastError: "",
    lastErrorAt: 0
  };

  function healthTouch(step = null) {
    health.lastHeartbeatAt = Date.now();
    if (step) {
      health.currentStep = String(step);
      health.currentStepStartedAt = Date.now();
    }
  }

  function healthStartOrder(no) {
    healthTouch("Đọc đơn");
    health.currentOrder = String(no || "");
    health.currentAmount = null;
    health.currentCurrency = "VND";
    health.currentProvider = "";
    health.currentStartedAt = Date.now();
  }

  function healthSetOrderMeta(amount = null, provider = "", currency = "VND") {
    const n = Number(amount);
    health.currentAmount = Number.isFinite(n) ? n : null;
    health.currentCurrency = String(currency || "VND");
    if (provider != null && String(provider).trim()) health.currentProvider = String(provider).trim();
    health.lastHeartbeatAt = Date.now();
  }

  function healthFinishOrder(state, no = "") {
    const now = Date.now();
    if (health.currentStartedAt) {
      health.processSamples.push(Math.max(0, now - health.currentStartedAt));
      if (health.processSamples.length > HEALTH_MAX_SAMPLES) health.processSamples.shift();
    }
    // IGNORE = chỉ phát hiện đơn không thuộc phạm vi xử lý của Tool
    // (ví dụ đơn đang bị người khác khóa). Không tính là đơn bỏ qua.
    health.completed += state === "DONE" ? 1 : 0;
    health.skipped += (state === "SKIP" || state === "RETURN") ? 1 : 0;
    health.manual += state === "STOP" ? 1 : 0;
    health.lastResult = state || "";
    health.lastActionAt = now;
    health.lastHeartbeatAt = now;
    health.currentOrder = "";
    health.currentAmount = null;
    health.currentCurrency = "VND";
    health.currentProvider = "";
    health.currentStartedAt = 0;
    health.currentStep = state === "DONE" ? "Hoàn tất"
      : state === "SKIP" ? "Bỏ qua"
      : state === "IGNORE" ? "Đang chờ đơn phù hợp"
      : "Cần kiểm tra";
    health.currentStepStartedAt = now;
  }

  function healthError(err, isTimeout = false) {
    health.errors++;
    if (isTimeout) health.timeouts++;
    health.lastError = String(err?.message || err || "Lỗi không xác định");
    health.lastErrorAt = Date.now();
    health.lastHeartbeatAt = Date.now();
  }

  function healthApi(ms, ok = true) {
    const n = Number(ms);
    if (Number.isFinite(n)) {
      health.apiSamples.push(n);
      if (health.apiSamples.length > HEALTH_MAX_SAMPLES) health.apiSamples.shift();
    }
    healthTouch(ok ? "API OK" : "API lỗi");
  }

  if (typeof window !== "undefined") {
    window.addEventListener("AD88_API_METRIC", e => {
      try { healthApi(e.detail?.ms, e.detail?.ok !== false); } catch {}
    });
  }

  function percentile(arr, p) {
    const a = Array.isArray(arr) ? arr.filter(Number.isFinite).slice().sort((x,y)=>x-y) : [];
    if (!a.length) return null;
    const idx = Math.min(a.length - 1, Math.max(0, Math.ceil((p / 100) * a.length) - 1));
    return a[idx];
  }

  function avg(arr) {
    const a = Array.isArray(arr) ? arr.filter(Number.isFinite) : [];
    return a.length ? a.reduce((s,v)=>s+v,0)/a.length : null;
  }

  function healthQueueCount() {
    try {
      const all = rows().filter(r => orderNo(r));
      return all.filter(r => {
        const no = orderNo(r);
        return no && !done.has(no) && !failed.has(no);
      }).length;
    } catch { return 0; }
  }

  function healthSnapshot() {
    const now = Date.now();
    const process = health.processSamples;
    const api = health.apiSamples;
    const action = health.actionSamples;
    const currentElapsed = health.currentStartedAt ? now - health.currentStartedAt : 0;
    const stepElapsed = health.currentStepStartedAt ? now - health.currentStepStartedAt : 0;
    const hbAge = Math.max(0, now - (health.lastHeartbeatAt || now));
    let state = "GOOD";
    if (health.lastErrorAt && now - health.lastErrorAt < 30000) state = "ERROR";
    else if (hbAge > 10000 || (currentElapsed > 120000) || health.timeouts > 0) state = "WARNING";
    else if (!running && !autoTimer) state = "IDLE";

    return {
      state,
      now,
      running: !!running,
      auto: !!autoTimer,
      heartbeatMs: hbAge,
      lastActionMs: health.lastActionAt ? now - health.lastActionAt : null,
      currentOrder: health.currentOrder || currentOrder || "",
      currentAmount: health.currentAmount,
      currentCurrency: health.currentCurrency || "VND",
      currentProvider: health.currentProvider || "",
      currentStep: health.currentStep || "Sẵn sàng",
      currentElapsedMs: currentElapsed,
      stepElapsedMs: stepElapsed,
      queue: healthQueueCount(),
      processed: processed.size,
      skipped: skipped.size,
      manual: manual.size,
      errors: health.errors,
      timeouts: health.timeouts,
      lastError: health.lastError,
      lastErrorAt: health.lastErrorAt,
      avgProcessMs: avg(process),
      p50Ms: percentile(process,50),
      p90Ms: percentile(process,90),
      p95Ms: percentile(process,95),
      p99Ms: percentile(process,99),
      fastestMs: process.length ? Math.min(...process) : null,
      slowestMs: process.length ? Math.max(...process) : null,
      avgApiMs: avg(api),
      avgActionMs: avg(action),
      samples: process.length,
      uptimeMs: health.startedAt ? now - health.startedAt : 0,
      autoSync: !!XNK_CONFIG.autoSync,
      pollMinMs: Number(XNK_CONFIG.pollMinMs)||100,
      pollMaxMs: Number(XNK_CONFIG.pollMaxMs)||650
    };
  }

  function syncDelay(attempt = 0) {
    const min = Math.max(50, Number(XNK_CONFIG.pollMinMs) || 100);
    const max = Math.max(min, Number(XNK_CONFIG.pollMaxMs) || 650);
    return Math.min(max, Math.round(min * Math.pow(1.35, Math.max(0, attempt))));
  }

  async function waitForSync(check, timeoutMs, label = "website") {
    const end = Date.now() + Math.max(250, Number(timeoutMs) || 8000);
    let attempt = 0;
    healthTouch(`Chờ ${label}`);
    while (Date.now() < end) {
      healthTouch(`Chờ ${label}`);
      try {
        if (check()) return true;
      } catch {}
      await sleep(XNK_CONFIG.autoSync === false ? 300 : syncDelay(attempt++));
    }
    healthError(`Timeout: ${label}`, true);
    return false;
  }

  const norm = s => (s || "").replace(/\s+/g, " ").trim();
  const lower = s => norm(s).toLowerCase();
  const log = (...a) => console.log(TAG, ...a);
  const warn = (...a) => console.warn(TAG, ...a);

  let running = false;
  let stopRequested = false;
  let hardStop = false;
  const done = new Set();
  const failed = new Set();
  // Thống kê UI tách riêng khỏi done/failed để không nhầm SKIP thành Đã xử lý.
  const processed = new Set();
  const skipped = new Set();
  const manual = new Set();
  const returned = new Set();
  const ORDER_LOG_KEY = "AD88_XNK_ORDER_LOGS";
  let currentOrder = "";
  // Dữ liệu USDT hiện được lấy trực tiếp từ cột "Dự kiến đến nơi (Nạp)" ngoài danh sách đơn.
  // Map này chỉ giữ tương thích với các nhánh cũ, không còn là nguồn chính của số tiền.
  const actualUsdtByOrder = new Map();

  // ===== NHẬN DIỆN NGƯỜI THAO TÁC =====
  // BO thực tế hiển thị username tại: <span class="avatar-wrapper">testawei</span>.
  // Chỉ lấy đúng node tài khoản, không quét text toàn trang để tránh bắt nhầm
  // các nút/chức năng như "Đóng hàng loạt".
  let currentOperatorName = "";
  const OPERATOR_BANNED = new Set([
    "đóng hàng loạt", "cài đặt", "đăng xuất", "logout", "settings",
    "tài khoản", "account", "admin"
  ]);

  function cleanOperatorText(v) {
    return String(v || "").replace(/\u00a0/g, " ").replace(/\s+/g, " ").trim();
  }

  function getCurrentOperatorName() {
    const selectors = [
      'span.avatar-wrapper[title="Cài đặt"]',
      '.avatar-wrapper[title="Cài đặt"]',
      'span.avatar-wrapper',
      '.avatar-wrapper',
      '.el-dropdown-link > span',
      '.el-dropdown-link span'
    ];
    for (const sel of selectors) {
      let nodes = [];
      try { nodes = [...document.querySelectorAll(sel)]; } catch {}
      for (const node of nodes) {
        const text = cleanOperatorText(node?.textContent || node?.innerText || "");
        if (!text || text.length > 80) continue;
        if (OPERATOR_BANNED.has(text.toLowerCase())) continue;
        // Username có thể là testawei/testwei..., nhưng không được lấy chính nhãn chức năng.
        if (/^(Đóng hàng loạt|Cài đặt|Đăng xuất|Logout|Settings|Tài khoản|Account|Admin)$/i.test(text)) continue;
        currentOperatorName = text;
        return text;
      }
    }
    return currentOperatorName;
  }

  // BO có thể render avatar sau document_idle; quét lại một vài lần và theo dõi DOM.
  function warmupOperatorName() { try { getCurrentOperatorName(); } catch {} }
  setTimeout(warmupOperatorName, 0);
  setTimeout(warmupOperatorName, 300);
  setTimeout(warmupOperatorName, 1000);
  setTimeout(warmupOperatorName, 2000);
  try {
    const observer = new MutationObserver(() => {
      if (!currentOperatorName) warmupOperatorName();
    });
    observer.observe(document.documentElement || document.body, {subtree:true, childList:true});
    setTimeout(() => { try { observer.disconnect(); } catch {} }, 15000);
  } catch {}

  function readOrderLogs() {
    try {
      const v = JSON.parse(localStorage.getItem(ORDER_LOG_KEY) || "[]");
      return Array.isArray(v) ? v : [];
    } catch { return []; }
  }

  function recordOrderLog(no, state, reason = "", row = null) {
    if (!no) return;
    let currency = "";
    let amount = null;
    try {
      const r = row || findRow(no);
      const info = r ? paymentInfoFromRow(r) : null;
      currency = info?.isUsdt ? "USDT" : "VND";
      amount = currency === "USDT"
        ? (actualUsdtByOrder.get(String(no)) ?? expectedProviderAmount(r, "USDT"))
        : expectedVnd(r);
    } catch {}
    const history = providerHistory.get(no) || [];
    const provider = history.length ? history[history.length - 1] : "";
    const labels = {
      DONE: "THÀNH CÔNG",
      SKIP: "BỎ QUA",
      STOP: "CẦN KIỂM TRA",
      RETURN: "ĐƠN TRẢ LẠI"
    };
    const now = new Date();
    const timeText = now.toLocaleTimeString("vi-VN", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
    const dateText = now.toLocaleDateString("vi-VN");
    const entry = {
      time: timeText,
      date: dateText,
      timestamp: now.getTime(),
      operator: getCurrentOperatorName() || currentOperatorName || "",
      successTime: state === "DONE" ? timeText : "",
      skipTime: state === "SKIP" ? timeText : "",
      order: String(no),
      state,
      label: labels[state] || state,
      reason: reason || "",
      provider: provider || "",
      amount: Number.isFinite(amount) ? amount : null,
      currency: currency || "",
      logId: `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`
    };
    // Mỗi lần xử lý là một sự kiện riêng. Không ghi đè log cũ chỉ vì mã đơn giống nhau.
    const logs = readOrderLogs();
    logs.unshift(entry);
    try {
      localStorage.setItem(ORDER_LOG_KEY, JSON.stringify(logs.slice(0, 1000)));
      window.dispatchEvent(new CustomEvent("AD88_ORDER_LOG_CHANGED", { detail: entry }));
    } catch {}
  }

  function clearOrderLogs() {
    try { localStorage.removeItem(ORDER_LOG_KEY); } catch {}
    try { window.dispatchEvent(new CustomEvent("AD88_ORDER_LOG_CHANGED")); } catch {}
  }
  let providerCursor = 0;
  // Lưu các nhà thứ 3 đã dùng cho từng đơn để khi đơn bị Hoàn trả
  // có thể chọn một nhà khác. Chỉ dùng trong phiên hiện tại.
  const providerHistory = new Map();

  // Manual CHECK theo từng mã đơn. Không dùng done/failed/skipped vì đây chỉ là
  // thao tác kiểm tra riêng, không được làm thay đổi trạng thái xử lý của AUTO.
  const manualCheckBusy = new Set();
  let manualCheckObserverStarted = false;

  // Cài đặt runtime của Tool — lưu bằng localStorage để UI và core dùng chung.
  function toolSetting(key, fallback = true) {
    try {
      const raw = localStorage.getItem("AD88_XNK_SETTING_" + key);
      if (raw === null) return fallback;
      return raw === "true";
    } catch { return fallback; }
  }


  function rows() {
    return [...document.querySelectorAll("tr.el-table__row")];
  }

  function orderNo(row) {
    const el = row?.querySelector(".el-link--inner, a.el-link, .copyBtns[data-rel]");
    if (el?.getAttribute("data-rel")) return norm(el.getAttribute("data-rel"));
    return norm(el?.innerText);
  }

  function findRow(no) {
    return rows().find(r => orderNo(r) === no);
  }

  function addManualCheckButton(row) {
    if (!row) return;
    const link = row.querySelector('.el-link--inner, a.el-link, .copyBtns[data-rel]');
    if (!link || !isActuallyVisible(link)) return;
    const host = link.parentElement || link;
    if (host.querySelector(':scope > [data-ad88-manual-check="1"]')) return;

    const no = orderNo(row);
    if (!no) return;

    const btn = document.createElement('button');
    btn.type = 'button';
    btn.setAttribute('data-ad88-manual-check', '1');
    btn.textContent = 'CHECK';
    btn.title = 'Kiểm tra Bank riêng cho đơn này';
    btn.style.cssText = [
      'margin-left:6px',
      'padding:2px 7px',
      'border:1px solid #2DB38D',
      'border-radius:5px',
      'background:#082B35',
      'color:#43D6B0',
      'font:700 10px/16px Segoe UI,Arial,sans-serif',
      'cursor:pointer',
      'vertical-align:middle',
      'letter-spacing:.3px',
      'box-shadow:0 0 0 0 rgba(45,179,141,0)',
      'transition:all .15s ease'
    ].join(';');

    btn.addEventListener('mouseenter', () => {
      btn.style.background = '#10484B';
      btn.style.boxShadow = '0 0 8px rgba(45,179,141,.28)';
    });
    btn.addEventListener('mouseleave', () => {
      btn.style.background = '#082B35';
      btn.style.boxShadow = '0 0 0 0 rgba(45,179,141,0)';
    });
    btn.addEventListener('click', async (ev) => {
      ev.preventDefault();
      ev.stopPropagation();
      const current = findRow(no);
      if (!current) return;
      await manualCheckOrderByRow(current);
    });

    // Nút CHECK nằm ngay cạnh mã lệnh, không thay đổi click mặc định của mã lệnh.
    link.insertAdjacentElement('afterend', btn);
  }

  function installManualCheckButtons() {
    for (const row of rows()) addManualCheckButton(row);

    if (manualCheckObserverStarted) return;
    manualCheckObserverStarted = true;
    try {
      const observer = new MutationObserver(() => {
        if (manualCheckObserverStarted) {
          for (const row of rows()) addManualCheckButton(row);
        }
      });
      observer.observe(document.body, { childList: true, subtree: true });
      window.__AD88_XNK_MANUAL_CHECK_OBSERVER = observer;
    } catch (_) {}
  }

  function operationButtons(row) {
    return [...row.querySelectorAll(
      "td.operation .private-button.text, td.operation .operation-btns .private-button.text, .operation-btns .private-button.text"
    )];
  }

  function action(row, text) {
    return operationButtons(row).find(el => lower(el.innerText) === lower(text));
  }

  // CHỈ dùng nút thao tác. Không dùng ô trạng thái "Đã mở khóa".
  function isLockedBySomeone(row) {
    return !!action(row, "Mở khóa");
  }

  function isAvailableToLock(row) {
    return !!action(row, "Khóa");
  }

  // BỘ LỌC ĐIỀU KIỆN XỬ LÝ ĐƠN
  // M / Mới / Thành viên chưa rút tiền mặt = Check Bank.
  // Các đơn có marker "Việc rút tiền được thực hiện lần ..." = bắt đơn nhưng
  // KHÔNG Check Bank, đi thẳng flow nhà thứ 3.
  // Các trạng thái còn lại = Direct Provider.
  function exactRowText(row, predicate) {
    if (!row || typeof predicate !== "function") return false;
    const nodes = [...row.querySelectorAll("div,span,b,strong,label,small,em,i,td")];
    return nodes.some(el => {
      const text = norm(el?.innerText || el?.textContent || "");
      return text && predicate(text);
    });
  }

  // ===== BỘ LỌC ĐƠN ĐẦU VÀO =====
  // Marker "Việc rút tiền được thực hiện lần đầu tiên" /
  // "Việc rút tiền được thực hiện lần thứ 2/3/4/..." đều là đơn PHẢI BẮT.
  // Nhóm này KHÔNG Check Bank và đi thẳng nhà thứ 3.
  // Regex cố ý bắt theo tiền tố "Việc rút tiền được thực hiện lần" để không
  // giới hạn số lần: lần đầu tiên, lần thứ 2 ... lần thứ 1000 đều hợp lệ.
  function hasWithdrawalAttemptMarker(row) {
    if (!row) return false;
    return exactRowText(row, text => {
      const n = removeVietnameseTones(text);
      return /VIECRUTTIENDUOCTHUCHIENLAN(?:DAUTIEN|THU\s*\d+)/.test(n);
    });
  }

  function hasPinkTestMarker(row) {
    if (!row) return false;
    const candidates = row.querySelectorAll("span,div,b,strong,label,small,em,i");
    for (const el of candidates) {
      const text = norm(el?.innerText || el?.textContent || "");
      if (text !== "Test") continue;
      const cls = String(el.className || "").toLowerCase();
      let r = null;
      try { r = el.getBoundingClientRect(); } catch (_) {}
      if (
        /tag|badge|label|vip|level|member|test/.test(cls) ||
        (r && r.width > 0 && r.width < 160 && r.height > 0 && r.height < 60)
      ) return true;
    }
    return false;
  }

  function hasExcludedTestGroup(row) {
    if (!row) return false;
    const t = removeVietnameseTones(norm(row.innerText || row.textContent || ""));
    return t.includes("NHOMTHU-测试") || t.includes("NHOMTHU - 测试");
  }

  function hasFirstWithdrawalMarker(row) {
    if (!row) return false;

    // QUAN TRỌNG: chỉ nhận M/Mới khi marker đang HIỂN THỊ thật sự trong
    // cột Phương thức thanh toán. Không đọc các node ẩn/template/dropdown
    // của Element UI vì chúng có thể chứa chữ M/Mới nhưng không phải badge của đơn.
    const accountInfo = row.querySelector(".accountInfoDataArr");
    if (accountInfo) {
      const markerNodes = [...accountInfo.querySelectorAll("span,div,b,strong,label,small,em,i")];
      const visibleMarkers = markerNodes.filter(el => {
        const text = norm(el?.innerText || el?.textContent || "");
        if (text !== "M" && removeVietnameseTones(text) !== "MOI") return false;
        return isActuallyVisible(el);
      });
      if (visibleMarkers.length) return true;
    }

    // "Thành viên chưa rút tiền mặt" là marker trạng thái duy nhất được phép
    // Check Bank theo text. "Thành viên rút tiền" tuyệt đối KHÔNG phải marker này.
    const firstCash = removeVietnameseTones("Thành viên chưa rút tiền mặt");
    if (exactRowText(row, text => removeVietnameseTones(text) === firstCash)) return true;

    return false;
  }

  function hasDirectProviderMarker(row) {
    if (!row) return false;

    const isDefault = exactRowText(row, text => {
      const n = removeVietnameseTones(text);
      return n === "MACDINH-默认";
    });
    if (isDefault) return true;

    const isTestGroup = exactRowText(row, text => {
      const n = removeVietnameseTones(text);
      return n === "NHOMTHU-测试" || n === "NHOMTHU";
    });
    return isTestGroup;
  }

  function classifyOrderEligibility(row) {
    if (hasPinkTestMarker(row)) {
      return { eligible: false, mode: "NONE", checkBank: false, reason: "TEST_BADGE" };
    }
    if (hasExcludedTestGroup(row)) {
      return { eligible: false, mode: "NONE", checkBank: false, reason: "NHOMTHU_TEST" };
    }

    // CHECK BANK CHỈ KHI CÓ ÍT NHẤT MỘT TRONG BA MARKER:
    // 1) badge M màu xanh; 2) badge Mới màu xanh;
    // 3) "Thành viên chưa rút tiền mặt".
    // Không còn ưu tiên đặc biệt cho "Việc rút tiền được thực hiện lần...".
    // Nếu dòng có M/Mới thì dù có thêm dòng "Việc rút tiền..." vẫn CHECK BANK.
    // Nếu không có cả 3 marker trên thì đi thẳng Direct Provider.
    const checkBankOrder = hasFirstWithdrawalMarker(row);
    if (checkBankOrder) {
      return { eligible: true, mode: "FIRST_WITHDRAWAL", checkBank: true };
    }

    return { eligible: true, mode: "DIRECT_PROVIDER", checkBank: false, reason: "NO_CHECK_BANK_MARKER" };
  }

  // QUY TẮC MỚI: nếu chính dòng đơn có nút "Làm mới gọi lại"
  // thì đơn đã rơi vào trạng thái bên thứ 3 xử lý không được / cần gọi lại.
  // Bot phải BỎ QUA HOÀN TOÀN, không khóa, không mở giao diện, không thanh toán.
  function isRefreshRecall(row) {
    if (!row) return false;
    if (action(row, "Làm mới gọi lại")) return true;
    const op = row.querySelector("td.operation");
    if (!op) return false;
    const text = lower(norm(op.innerText || op.textContent || ""));
    return text.includes("làm mới gọi lại");
  }

  function findTextButton(root, text) {
    if (!root) return null;
    return [...root.querySelectorAll(
      "button,.private-button.text,.el-button,span"
    )].find(e => lower(e.innerText) === lower(text) && e.offsetParent !== null);
  }

  function visibleDialogs() {
    return [...document.querySelectorAll(".el-dialog,.el-drawer")]
      .filter(e => e.offsetParent !== null);
  }

  function currentPanel() {
    const ds = visibleDialogs();
    return ds[ds.length - 1] || document;
  }

  function scrollElementForAction(el) {
    if (!el) return;
    try {
      el.scrollIntoView({ block: "center", inline: "nearest" });
    } catch (_) {}

    // Element UI often puts the processing form inside an internal scroll container.
    // Move every scrollable ancestor enough to make the control actually visible.
    let p = el.parentElement;
    let guard = 0;
    while (p && p !== document.body && guard++ < 30) {
      try {
        const cs = getComputedStyle(p);
        const scrollable = /(auto|scroll)/i.test(cs.overflowY) && p.scrollHeight > p.clientHeight + 4;
        if (scrollable) {
          const er = el.getBoundingClientRect();
          const pr = p.getBoundingClientRect();
          if (er.bottom > pr.bottom) p.scrollTop += er.bottom - pr.bottom + 80;
          if (er.top < pr.top) p.scrollTop -= pr.top - er.top + 80;
        }
      } catch (_) {}
      p = p.parentElement;
    }
  }

  async function scrollToBottomOfProcessing(panel) {
    const root = panel || currentPanel();
    if (!root) return;
    let candidate = null;
    const all = [root, ...root.querySelectorAll("*")];
    for (const el of all) {
      try {
        if (el.scrollHeight > el.clientHeight + 100) {
          const cs = getComputedStyle(el);
          if (/(auto|scroll)/i.test(cs.overflowY)) candidate = el;
        }
      } catch (_) {}
    }
    if (candidate) {
      candidate.scrollTop = candidate.scrollHeight;
      await sleep(250);
    }
  }

  function parseNum(s) {
    if (s == null) return null;
    let t = String(s).replace(/\s/g, "").replace(/,/g, "");
    const n = Number(t);
    return Number.isFinite(n) ? n : null;
  }

  function expectedVnd(row) {
    const money = row?.querySelector("td.money");
    if (!money) return null;

    const b = money.querySelector(".copyclip-box button[data-rel], button[data-rel]");
    const raw = b?.getAttribute("data-rel") ||
      money.querySelector("b.label-area")?.innerText ||
      money.innerText;

    const base = parseNum(raw);
    if (base == null) return null;

    const mc = norm(row.querySelector("td.memberCurrency")?.innerText);
    if (/VND1000\s*:\s*1/i.test(mc)) return base * 1000;

    // Nếu hệ thống đang hiển thị VND trực tiếp, giữ nguyên.
    if (/VND/i.test(mc)) return base;
    return base;
  }

  function extractUserId(row) {
    const tds = [...row.querySelectorAll("td")];
    if (tds[1]) {
      const txt = norm(tds[1].innerText);
      const m = txt.match(/\b\d{6,20}\b/);
      if (m) return m[0];
    }
    const all = [...row.querySelectorAll("a,.el-link--inner,span")]
      .map(e => norm(e.innerText)).filter(Boolean);
    return all.find(t => /^\d{6,20}$/.test(t)) || "";
  }

  function parseBankText(txt) {
    const clean = norm(txt);

    // Ưu tiên các dòng/khối có đúng nhãn của giao diện Xem lại chuyển tiền.
    // Không phụ thuộc vị trí span/div cụ thể vì Element UI có thể thay đổi DOM.
    const nameMatches = [
      /Họ\s*Tên\s*Thật\s*[:：]\s*(.+?)(?=\s*Tài khoản\/Địa chỉ|\s*ngân hàng|\s*Mã qr|$)/i,
      /Họ\s*Tên\s*[:：]\s*(.+?)(?=\s*Tài khoản|\s*ngân hàng|$)/i
    ];
    const acctMatches = [
      /Tài khoản\/Địa chỉ\s*[:：]\s*([A-Za-z0-9._-]+)/i,
      /Tài khoản\s*[:：]\s*([A-Za-z0-9._-]+)/i
    ];
    const bankMatches = [
      /ngân hàng\s*[:：]\s*([^\n\r]+?)(?=\s*Mã qr|\s*Họ\s*Tên|\s*Tài khoản|$)/i,
      /ngân hàng\s*[:：]?\s*([A-Z0-9 .()_-]+?)(?=\s*Mã qr|$)/i
    ];

    let name = "", acct = "", bank = "";
    for (const re of nameMatches) { const m = clean.match(re); if (m?.[1]) { name = norm(m[1]); break; } }
    for (const re of acctMatches) { const m = clean.match(re); if (m?.[1]) { acct = norm(m[1]); break; } }
    for (const re of bankMatches) { const m = clean.match(re); if (m?.[1]) { bank = norm(m[1]); break; } }

    return { expectedName: name, bankAccount: acct, bankName: bank };
  }

  function extractBankFieldsFromDom(root) {
    const scope = root || document;
    let name = "", acct = "", bank = "";

    // 1) Tìm trực tiếp trong từng element có nhãn + giá trị cùng một khối.
    const nodes = [...scope.querySelectorAll('div,span,td,li,p,label')];
    for (const el of nodes) {
      const t = norm(el.innerText);
      if (!t || t.length > 300) continue;
      if (!name) {
        const m = t.match(/^Họ\s*Tên\s*Thật\s*[:：]\s*(.+)$/i);
        if (m) name = norm(m[1]);
      }
      if (!acct) {
        const m = t.match(/^Tài khoản\/Địa chỉ\s*[:：]\s*(.+)$/i);
        if (m) acct = norm(m[1]).split(/\s+/)[0];
      }
      if (!bank) {
        const m = t.match(/^ngân hàng\s*[:：]\s*(.+)$/i);
        if (m) bank = norm(m[1]).split(/\s{2,}|Mã qr/i)[0];
      }
    }

    // 2) Nếu nhãn và giá trị nằm ở 2 node anh em, lấy text node kế bên.
    for (const el of nodes) {
      const t = norm(el.innerText);
      if (!t) continue;
      if (!name && /^Họ\s*Tên\s*Thật\s*[:：]?$/i.test(t)) {
        const n = el.nextElementSibling || el.parentElement?.nextElementSibling;
        if (n) name = norm(n.innerText);
      }
      if (!acct && /^Tài khoản\/Địa chỉ\s*[:：]?$/i.test(t)) {
        const n = el.nextElementSibling || el.parentElement?.nextElementSibling;
        if (n) acct = norm(n.innerText).split(/\s+/)[0];
      }
      if (!bank && /^ngân hàng\s*[:：]?$/i.test(t)) {
        const n = el.nextElementSibling || el.parentElement?.nextElementSibling;
        if (n) bank = norm(n.innerText).split(/\s{2,}|Mã qr/i)[0];
      }
    }

    return { expectedName: name, bankAccount: acct, bankName: bank };
  }

  // Nhận diện loại tài khoản ngay trong CHÍNH DÒNG ĐƠN hiện tại.
  // Không dùng document.querySelector() toàn trang vì có thể có nhiều đơn cùng lúc.
  function paymentTypeFromRow(row) {
    if (!row) return "";
    const el = row.querySelector('.accountInfoDataArr .account-type--body');
    return norm(el?.innerText || el?.textContent || "");
  }

  function isUsdtTrc20Row(row) {
    const type = removeVietnameseTones(paymentTypeFromRow(row));
    return type === "USDT-TRC20" || type.includes("USDT-TRC20");
  }

  // Nhận diện TẤT CẢ đơn USDT ngay trên chính dòng đơn.
  // Khi nhận diện USDT, flow mới sẽ SKIP trước khi bấm Khóa để tuyệt đối
  // không Check Bank / Provider / Payment đối với USDT trong phiên bản này.
  function isUsdtRow(row) {
    if (!row) return false;

    const type = removeVietnameseTones(paymentTypeFromRow(row))
      .replace(/[\s_]+/g, "");

    // Các dạng đang dùng trên website: USDT, USDT-TRC20, USDT-ERC20,
    // TETHER, Ví USDT, Tiền ảo...
    if (/^(USDT|TETHER|VIUSDT|TIENAO|SOTIENAO)(?:-?(?:TRC20|ERC20))?$/i.test(type)) {
      return true;
    }
    if (/^USDT-(?:TRC20|ERC20)$/i.test(type)) return true;

    // Fallback chỉ trong khối thông tin phương thức thanh toán của CHÍNH dòng.
    // Không quét toàn document để tránh nhận nhầm USDT của đơn khác.
    const infoText = norm(row.querySelector('.accountInfoDataArr')?.innerText || "");
    return /\bUSDT\b|\bUSDT[-\s_]*(?:TRC20|ERC20)\b/i.test(infoText);
  }

  function usdtAddressFromRow(row) {
    if (!row) return "";
    const nodes = [...row.querySelectorAll('.accountInfoDataArr div, .accountInfoDataArr span, .accountInfoDataArr td')];
    for (const el of nodes) {
      const text = norm(el.innerText || el.textContent || "");
      if (!text) continue;
      const m = text.match(/^Tài khoản\/Địa chỉ\s*[:：]\s*(.+)$/i);
      if (m) return norm(m[1]).split(/\s+/)[0];
    }
    return "";
  }

  // Mạng USDT của đơn: chỉ nhận TRC20 và ERC20. Loại USDT khác (USDT trơn, Tether, tiền ảo...) trả về null → Tool bỏ qua.
  function usdtNetworkFromRow(row) {
    if (!row) return null;
    const t = removeVietnameseTones(paymentTypeFromRow(row)).toUpperCase().replace(/[\s_()]+/g, "");
    if (/TRC-?20/.test(t)) return "TRC20";
    if (/ERC-?20/.test(t)) return "ERC20";
    return null;
  }

  function paymentInfoFromRow(row) {
    const paymentType = paymentTypeFromRow(row);
    const network = isUsdtRow(row) ? usdtNetworkFromRow(row) : null;
    return {
      paymentType,
      usdtNetwork: network,
      isUsdt: !!network,
      isUsdtTrc20: network === "TRC20",
      walletAddress: network ? usdtAddressFromRow(row) : ""
    };
  }

  // ===== USDT ERC20 (Ethereum): kiểm tra ví ngay trong Tool, không cần mạng =====
  // 0x + 40 ký tự hex. Nếu viết lẫn hoa/thường thì phải đúng checksum EIP-55 (sai 1 ký tự là phát hiện được).
  function keccak256Hex(str) {
    const RC = [0x0000000000000001n,0x0000000000008082n,0x800000000000808An,0x8000000080008000n,0x000000000000808Bn,0x0000000080000001n,0x8000000080008081n,0x8000000000008009n,0x000000000000008An,0x0000000000000088n,0x0000000080008009n,0x000000008000000An,0x000000008000808Bn,0x800000000000008Bn,0x8000000000008089n,0x8000000000008003n,0x8000000000008002n,0x8000000000000080n,0x000000000000800An,0x800000008000000An,0x8000000080008081n,0x8000000000008080n,0x0000000080000001n,0x8000000080008008n];
    const ROT = [[0,36,3,41,18],[1,44,10,45,2],[62,6,43,15,61],[28,55,25,21,56],[27,20,39,8,14]];
    const M = 0xFFFFFFFFFFFFFFFFn;
    const rotl = (x, n) => n === 0 ? x : ((x << BigInt(n)) | (x >> BigInt(64 - n))) & M;
    const data = new TextEncoder().encode(str);
    const rate = 136;
    const padded = new Uint8Array(Math.ceil((data.length + 1) / rate) * rate);
    padded.set(data); padded[data.length] = 0x01; padded[padded.length - 1] |= 0x80;
    const st = new Array(25).fill(0n);
    for (let off = 0; off < padded.length; off += rate) {
      for (let i = 0; i < rate / 8; i++) {
        let v = 0n;
        for (let b = 7; b >= 0; b--) v = (v << 8n) | BigInt(padded[off + i * 8 + b]);
        st[i] ^= v;
      }
      for (let round = 0; round < 24; round++) {
        const C = [];
        for (let x = 0; x < 5; x++) C[x] = st[x] ^ st[x + 5] ^ st[x + 10] ^ st[x + 15] ^ st[x + 20];
        for (let x = 0; x < 5; x++) {
          const D = C[(x + 4) % 5] ^ rotl(C[(x + 1) % 5], 1);
          for (let y = 0; y < 5; y++) st[x + 5 * y] ^= D;
        }
        const Bk = new Array(25).fill(0n);
        for (let x = 0; x < 5; x++) for (let y = 0; y < 5; y++) Bk[y + 5 * ((2 * x + 3 * y) % 5)] = rotl(st[x + 5 * y], ROT[x][y]);
        for (let x = 0; x < 5; x++) for (let y = 0; y < 5; y++) st[x + 5 * y] = Bk[x + 5 * y] ^ ((~Bk[(x + 1) % 5 + 5 * y] & M) & Bk[(x + 2) % 5 + 5 * y]);
        st[0] ^= RC[round];
      }
    }
    let out = "";
    for (let i = 0; i < 4; i++) { let v = st[i]; for (let b = 0; b < 8; b++) { out += Number(v & 0xFFn).toString(16).padStart(2, "0"); v >>= 8n; } }
    return out;
  }

  function validateUsdtErc20Address(address, no) {
    const wallet = norm(address);
    if (!wallet) return { status: "INVALID", reason: "EMPTY_ADDRESS" };
    if (!/^0x[0-9a-fA-F]{40}$/.test(wallet)) {
      log(no, "USDT ERC20 → địa chỉ sai định dạng (cần 0x + 40 ký tự hex):", wallet);
      return { status: "INVALID", reason: "BAD_ERC20_FORMAT" };
    }
    const body = wallet.slice(2);
    if (body === body.toLowerCase() || body === body.toUpperCase()) {
      log(no, "USDT ERC20 → địa chỉ đúng định dạng (không có checksum hoa/thường)");
      return { status: "VALID", reason: "NO_CHECKSUM" };
    }
    const hash = keccak256Hex(body.toLowerCase());
    for (let i = 0; i < 40; i++) {
      const ch = body[i];
      if (/[a-f]/i.test(ch)) {
        const wantUpper = parseInt(hash[i], 16) >= 8;
        if ((ch === ch.toUpperCase()) !== wantUpper) {
          log(no, "USDT ERC20 → SAI CHECKSUM EIP-55 tại vị trí", i, ":", wallet);
          return { status: "INVALID", reason: "BAD_EIP55_CHECKSUM" };
        }
      }
    }
    log(no, "USDT ERC20 → checksum EIP-55 hợp lệ");
    return { status: "VALID", reason: "EIP55_OK" };
  }

  async function validateUsdtTrc20Address(address, no) {
    const wallet = norm(address);
    if (!wallet) return { status: "INVALID", reason: "EMPTY_ADDRESS" };

    // Fast local guard: user-facing TRON Base58 addresses are 34 chars and start with T.
    // Do not use this alone as the final validation; the TRON node remains authoritative.
    if (!/^T[1-9A-HJ-NP-Za-km-z]{33}$/.test(wallet)) {
      log(no, "USDT TRC20 → địa chỉ sai định dạng Base58 TRON:", wallet);
      return { status: "INVALID", reason: "BAD_BASE58_FORMAT" };
    }

    if (XNK_CONFIG.tron?.enabled === false) {
      throw new Error("Kiểm tra địa chỉ TRON đang bị tắt trong cấu hình");
    }

    if (!chrome?.runtime?.sendMessage) {
      throw new Error("Không có bridge kiểm tra TRON của extension");
    }

    log(no, "USDT TRC20 → bắt đầu xác minh địa chỉ trên TRON Mainnet:", wallet);

    const result = await new Promise((resolve, reject) => {
      chrome.runtime.sendMessage({
        type: "AD88_VALIDATE_TRON_ADDRESS",
        address: wallet,
        apiKey: XNK_CONFIG.tron?.apiKey || ""
      }, response => {
        const err = chrome.runtime.lastError;
        if (err) return reject(new Error(err.message || "TRON bridge error"));
        resolve(response || null);
      });
    });

    if (!result || result.networkError) {
      throw new Error("Không thể kết nối TRON Mainnet để xác minh địa chỉ. Không được tự động đẩy đơn.");
    }

    if (!result.ok) {
      const detail = result.data?.Error || result.data?.error || `HTTP ${result.httpStatus || "?"}`;
      throw new Error("TRON Mainnet từ chối kiểm tra địa chỉ: " + detail);
    }

    const data = result.data || {};
    const valid = data.result === true || data.result?.result === true || data.valid === true;

    log(no, "TRON VALIDATE ADDRESS RAW:", data);
    log(no, "TRON ADDRESS STATUS:", valid ? "VALID" : "INVALID");

    return {
      status: valid ? "VALID" : "INVALID",
      raw: data
    };
  }


  // Chuẩn hóa tên ngân hàng dùng cho HIỂN THỊ POPUP.
  // Không được lấy innerText của cả row vì row còn chứa trạng thái, ghi chú,
  // tên nhân viên... Chỉ hiển thị tên ngân hàng/canonical code.
  function bankDisplayName(rawBankName, codeBank = "") {
    const raw = String(rawBankName || "").trim();
    const code = String(resolveBankCode(raw || codeBank) || resolveBankCode(codeBank) || "").toUpperCase();
    const canonical = {
      ACB:"ACB", BIDV:"BIDV", VTB:"Vietin Bank(VTB)", VBSP:"VBSP", LPB:"LienVietPostBank(LPB)",
      PVCB:"PVcomBank", VAB:"Viet A Bank(VAB)", NAB:"Nam A Bank", VARB:"Agribank", SHBVN:"ShinhanBank",
      HDB:"HDBank", VPB:"VPBank", VIB:"VIB", BVB:"BaoVietBank", VCCB:"BVBank (Viet Capital Bank)", CIMB:"CIMB Bank", MSB:"MaritimeBank(MSB)",
      BAB:"BacABank(BAB)", IVB:"Indovina Bank", SGB:"SaigonBank(SGB)", VCB:"Vietcom Bank(VCB)", NCB:"NCB",
      CAKE:"CAKE", UB:"Ubank(UB)", DAB:"Vikki Bank", WOO:"Woori Bank", SCB:"Sacombank(STB)",
      OCB:"OCB", MB:"MB BANK", KLB:"KienLongBank(KLB)", SHB:"SHB", CBB:"CB Bank", EIB:"Eximbank(EIB)",
      TCB:"Techcombank(TCB)", GPB:"GPBank", VDB:"VDB", VB:"VietBank", TPB:"TPBank", SEAB:"SeABank",
      HSBC:"HSBC", ABB:"ABBANK(ABB)", TIMO:"Timo Bank", VRB:"Vietnam-Russia Bank(VRB)", PBVN:"PublicBank Vietnam",
      UOB:"United Overseas Bank(UOB)", PGB:"PG Bank", SGCB:"SCB Bank(SGCB)", COOPB:"Co-opBank", MBV:"MBV", HLB:"Hong Leong Bank(HLBVN)"
    };
    if (canonical[code]) return canonical[code];

    // Nếu ngân hàng chưa có canonical map, cố gắng cắt phần trạng thái phía sau.
    let v = raw;
    v = v.replace(/\s+(?:Đã khóa|Mở khóa|Đang chờ|Chờ thanh toán|Đã thanh toán|Thành viên|Nhận xét|Buộc hủy|Việc rút tiền|Lệnh|Kết quả|Ghi chú).*$/iu, "").trim();
    v = v.replace(/\s{2,}.*/u, "").trim();
    return v || codeBank || raw || "—";
  }

  function bankDataFromPanel(panel, row) {
    // Ưu tiên panel hiện tại. Nếu Element UI không dùng .el-dialog/.el-drawer,
    // fallback sang DOM hiển thị toàn trang sau khi Xem lại chuyển tiền đã mở.
    // QUAN TRỌNG: thêm chính dòng đơn (row) làm nguồn dự phòng để không làm mất
    // tên ngân hàng khi panel hiển thị thiếu/khác cấu trúc DOM. Điều này đặc biệt
    // quan trọng với VTB/BIDV/MSB vì phone-gate phải biết đúng ngân hàng trước API.
    const sources = [panel, ...visibleDialogs(), row, document];
    let best = { expectedName: "", bankAccount: "", bankName: "" };
    for (const src of sources) {
      if (!src) continue;
      const byDom = extractBankFieldsFromDom(src);
      const byText = parseBankText(src.innerText || "");
      const candidate = {
        expectedName: byDom.expectedName || byText.expectedName,
        bankAccount: byDom.bankAccount || byText.bankAccount,
        bankName: byDom.bankName || byText.bankName
      };
      if (candidate.expectedName && candidate.bankAccount && candidate.bankName) {
        best = candidate;
        break;
      }
      if ((candidate.expectedName || candidate.bankAccount || candidate.bankName) &&
          Object.values(candidate).filter(Boolean).length > Object.values(best).filter(Boolean).length) best = candidate;
    }

    // Nếu parser lấy được STK nhưng bỏ sót tên ngân hàng, nhận diện lại ngay
    // trong CHÍNH dòng đơn, chỉ với 3 ngân hàng thuộc phone-gate. Không quét
    // toàn trang để tránh lấy nhầm ngân hàng của đơn khác.
    if (row) {
      const rowParsed = parseBankText(String(row.innerText || row.textContent || ""));
      const rowCode = resolveBankCode(rowParsed.bankName || "");
      // Dòng đơn hiện tại được ưu tiên hơn panel/dialog còn sót của đơn trước.
      if (rowCode && rowParsed.bankName) best.bankName = rowParsed.bankName;
      const rowText = removeVietnameseTones(String(row.innerText || row.textContent || ""));
      if (!best.bankName) {
        if (/VIETINBANK/.test(rowText) || /\bVTB\b/.test(rowText)) best.bankName = "Vietin Bank(VTB)";
        else if (/\bBIDV\b/.test(rowText)) best.bankName = "BIDV";
        else if (/MARITIMEBANK|MSB/.test(rowText)) best.bankName = "MaritimeBank(MSB)";
        else if (/VIETCOMBANK|VCB/.test(rowText)) best.bankName = "Vietcom Bank(VCB)";
        else if (/VIETBANK|VIET BANK/.test(rowText)) best.bankName = "VietBank";
      }
      if (!best.bankAccount) {
        const m = String(row.innerText || row.textContent || "").match(/Tài khoản\/Địa chỉ\s*[:：]\s*([A-Za-z0-9._-]+)/i);
        if (m?.[1]) best.bankAccount = norm(m[1]);
      }
    }

    const resolvedCode = resolveBankCode(best.bankName || "");
    const displayBank = bankDisplayName(best.bankName || "", resolvedCode);
    return {
      ...best,
      bankName: displayBank,
      codeBank: resolvedCode,
      userId: extractUserId(row)
    };
  }

  function bankResultStatus(obj) {
    // Auto Bank Checker có thể trả kết quả ở nhiều lớp:
    // {status:"VALID"}, {result:{status:"VALID"}}, {payload:{data:{status:"VALID"}}}, ...
    const seen = new Set();

    function walk(v, depth = 0) {
      if (depth > 6 || v == null || seen.has(v)) return "";
      if (typeof v === "string") {
        const s = v.trim().toUpperCase();
        if (s === "VALID" || s === "INVALID") return s;
        return "";
      }
      if (typeof v !== "object") return "";
      seen.add(v);

      // Ưu tiên các key trạng thái.
      for (const k of ["status", "bankStatus", "checkStatus", "resultStatus", "verifyStatus", "code"]) {
        if (v[k] != null) {
          const s = String(v[k]).trim().toUpperCase();
          if (s === "VALID" || s === "INVALID") return s;
        }
      }

      for (const k of ["result", "payload", "data", "response"]) {
        if (v[k] != null) {
          const s = walk(v[k], depth + 1);
          if (s) return s;
        }
      }
      return "";
    }

    return walk(obj);
  }

  function showBankPopup(no, data, status, raw) {
    const old = document.getElementById("ad88-bank-result");
    // Popup chỉ được phép hiển thị tên ngân hàng, không hiển thị toàn bộ innerText của row.
    const popupBankName = bankDisplayName(data?.bankName || "", data?.codeBank || "");
    if (data) data.bankName = popupBankName;
    if (old) old.remove();

    const valid = status === "VALID";
    const invalid = status === "INVALID";
    const accent = valid ? "#2DB38D" : invalid ? "#F04B5A" : "#F0A83A";
    const accentSoft = valid ? "rgba(45,179,141,.16)" : invalid ? "rgba(240,75,90,.16)" : "rgba(240,168,58,.16)";
    const title = valid
      ? "CHECK BANK THÀNH CÔNG"
      : invalid
        ? "CHECK BANK THẤT BẠI"
        : "CHECK BANK KHÔNG XÁC ĐỊNH";
    const detailedReason = invalid ? buildBankInvalidReason(data, raw || {}) : "";
    const message = valid
      ? "Thông tin hợp lệ → tiếp tục đẩy sang nhà thứ 3."
      : invalid
        ? detailedReason
        : (String(raw?.message || "").trim() || "Không có kết quả chắc chắn → Tool sẽ kiểm tra lại trước khi mở khóa.");
    const icon = valid ? "✓" : invalid ? "×" : "!";

    const box = document.createElement("div");
    box.id = "ad88-bank-result";
    box.style.cssText = `
      position:fixed;left:50%;top:34px;transform:translateX(-50%);
      z-index:2147483647;width:500px;max-width:calc(100vw - 28px);
      background:#071F31;color:#EAF4F8;border:1px solid ${accent};
      border-radius:16px;box-shadow:0 18px 55px rgba(0,0,0,.38),0 0 22px ${accentSoft};
      font-family:Segoe UI,Arial,sans-serif;overflow:hidden;
      box-sizing:border-box;animation:ad88BankIn .22s ease-out
    `;

    if (!document.getElementById("ad88-bank-result-style")) {
      const style = document.createElement("style");
      style.id = "ad88-bank-result-style";
      style.textContent = `
        @keyframes ad88BankIn{from{opacity:0;transform:translate(-50%,-12px) scale(.98)}to{opacity:1;transform:translate(-50%,0) scale(1)}}
        @keyframes ad88BankOut{from{opacity:1;transform:translate(-50%,0) scale(1)}to{opacity:0;transform:translate(-50%,-8px) scale(.98)}}
        #ad88-bank-result .ad88-bank-head{display:flex;align-items:center;gap:12px;padding:16px 18px;border-bottom:1px solid rgba(255,255,255,.09)}
        #ad88-bank-result .ad88-bank-icon{width:34px;height:34px;border-radius:50%;display:flex;align-items:center;justify-content:center;color:#fff;font-size:20px;font-weight:800;flex:0 0 34px}
        #ad88-bank-result .ad88-bank-title{font-size:18px;font-weight:800;letter-spacing:.15px;line-height:1.2;flex:1}
        #ad88-bank-result .ad88-bank-close{font-size:22px;line-height:1;color:#91A9B5;cursor:pointer;padding:2px 5px}
        #ad88-bank-result .ad88-bank-close:hover{color:#fff}
        #ad88-bank-result .ad88-bank-body{padding:18px 20px 20px}
        #ad88-bank-result .ad88-bank-row{display:grid;grid-template-columns:100px 1fr;gap:10px;padding:7px 0;border-bottom:1px solid rgba(255,255,255,.055);font-size:14px}
        #ad88-bank-result .ad88-bank-label{color:#8FA8B5;font-weight:600}
        #ad88-bank-result .ad88-bank-value{color:#F4FAFC;font-weight:650;word-break:break-word}
        #ad88-bank-result .ad88-bank-message{margin-top:16px;padding:11px 13px;border-radius:10px;background:${accentSoft};color:${accent};font-size:14px;font-weight:750;line-height:1.45}
        #ad88-bank-result .ad88-bank-brand{margin-top:13px;color:#607C8A;font-size:10px;letter-spacing:.25px}
      `;
      document.head.appendChild(style);
    }

    box.innerHTML = `
      <div class="ad88-bank-head">
        <div class="ad88-bank-icon" style="background:${accent};box-shadow:0 0 16px ${accentSoft}">${icon}</div>
        <div class="ad88-bank-title">${title}</div>
        <div class="ad88-bank-close" title="Đóng">×</div>
      </div>
      <div class="ad88-bank-body">
        <div class="ad88-bank-row"><div class="ad88-bank-label">Đơn</div><div class="ad88-bank-value">${String(no)}</div></div>
        <div class="ad88-bank-row"><div class="ad88-bank-label">Họ tên</div><div class="ad88-bank-value">${data?.expectedName || "—"}</div></div>
        <div class="ad88-bank-row"><div class="ad88-bank-label">Ngân hàng</div><div class="ad88-bank-value">${data?.bankName || "—"}</div></div>
        <div class="ad88-bank-row"><div class="ad88-bank-label">STK</div><div class="ad88-bank-value">${data?.bankAccount || "—"}</div></div>
        <div class="ad88-bank-message" style="background:${accentSoft};color:${accent}">${message}</div>
        <div class="ad88-bank-brand">AWEI • AD88 XNK TOOL</div>
      </div>
    `;

    document.body.appendChild(box);
    const close = () => {
      if (!box.isConnected) return;
      box.style.animation = "ad88BankOut .18s ease-in forwards";
      window.setTimeout(() => { if (box.isConnected) box.remove(); }, 180);
    };
    box.querySelector(".ad88-bank-close")?.addEventListener("click", close);

    // Bank Check result popup is informational only; auto-close so it never blocks the page.
    const popupLife = (valid || invalid) ? 5000 : 4000;
    window.setTimeout(close, popupLife);
  }

  function showFinalPopup(no, data, ok, message, provider = "") {
    // Thành công được ghi nhận trong Journal/Stats/health và không cần popup.
    // Chỉ giữ popup cho kết quả thất bại/trả lại để tránh làm gián đoạn flow.
    if (ok) return;

    const old = document.getElementById("ad88-bank-result");
    if (old) old.remove();
    const color = ok ? "#1f9d55" : "#d93025";
    const title = ok ? "ĐẨY SANG NHÀ THỨ 3 THÀNH CÔNG" : "ĐƠN THẤT BẠI – TRẢ LẠI THÀNH CÔNG";
    const box = document.createElement("div");
    box.id = "ad88-bank-result";
    box.style.cssText = `position:fixed;left:50%;top:28px;transform:translateX(-50%);z-index:2147483647;width:440px;background:#fff;border:3px solid ${color};border-radius:12px;box-shadow:0 10px 35px rgba(0,0,0,.28);font:14px Arial,sans-serif;overflow:hidden`;
    box.innerHTML = `
      <div style="background:${color};color:#fff;padding:10px 16px 12px;text-align:center">
        <div style="font-size:21px;font-weight:800;letter-spacing:1px">AWEI</div>
        <div style="font-size:12px;opacity:.9">AD88 XNK BOT</div>
        <div style="font-size:17px;font-weight:800;margin-top:7px">${title}</div>
      </div>
      <div style="padding:14px 16px;line-height:1.75">
        <div><b>Đơn:</b> ${String(no)}</div>
        <div><b>Họ tên:</b> ${data?.expectedName || ""}</div>
        <div><b>Ngân hàng:</b> ${data?.bankName || ""}</div>
        <div><b>STK:</b> ${data?.bankAccount || ""}</div>
        ${provider ? `<div><b>Nhà thứ 3:</b> ${provider}</div>` : ""}
        <div style="margin-top:9px;color:${color};font-weight:800;font-size:15px">${message}</div>
      </div>`;
    document.body.appendChild(box);
    setTimeout(() => box.remove(), 7000);
  }


  function normBankCompare(v) {
    const code = resolveBankCode(v || "");
    return code || removeVietnameseTones(v || "");
  }

  function normAccountCompare(v) {
    return String(v || "").replace(/[\s-]/g, "").trim().toUpperCase();
  }

  function normalizeBankHolderName(v) {
    return String(v || "")
      .normalize("NFD")
      .replace(/[̀-ͯ]/g, "")
      .replace(/đ/g, "d")
      .replace(/Đ/g, "D")
      .toUpperCase()
      .trim();
  }

  // Tên người có thể dùng dấu nháy hoặc dấu gạch nối trong cùng một từ,
  // ví dụ: NGUYEN EA'KRA / NGUYEN EA-KRA. Các dấu này chỉ là cách viết
  // khác nhau của cùng một phần tên, vì vậy khi đối chiếu sẽ bỏ qua chúng.
  // Hỗ trợ cả apostrophe/gạch nối ASCII và các biến thể Unicode thường gặp.
  function normalizeBankHolderNameCore(v) {
    return normalizeBankHolderName(v)
      .replace(/[\u0027\u0060\u00B4\u2018\u2019\u02BC\u02BB\u201B\u2032\uFF07\-\u2010\u2011\u2012\u2013\u2014\u2212]/g, "")
      .replace(/\s+/g, "");
  }

  function bankNameBoundaryPositions(v) {
    const s = normalizeBankHolderName(v);
    if (!s) return [];
    const parts = s.split(/\s+/).filter(Boolean);
    const positions = [];
    let pos = 0;
    for (let i = 0; i < parts.length - 1; i++) {
      // Dấu ' / - nằm trong một từ nên không tạo thêm ranh giới tên.
      pos += parts[i].replace(/[\u0027\u0060\u00B4\u2018\u2019\u02BC\u02BB\u201B\u2032\uFF07\-\u2010\u2011\u2012\u2013\u2014\u2212]/g, "").length;
      positions.push(pos);
    }
    return positions;
  }

  function hasSingleLetterNamePart(v) {
    const s = normalizeBankHolderName(v);
    if (!s || !/\s/.test(s)) return false;
    return s.split(/\s+/).filter(Boolean).some(part =>
      part.replace(/[\u0027\u0060\u00B4\u2018\u2019\u02BC\u02BB\u201B\u2032\uFF07\-\u2010\u2011\u2012\u2013\u2014\u2212]/g, "").length === 1
    );
  }

  function bankHolderNameMatches(expectedName, verifiedFullname) {
    const expectedRaw = String(expectedName || '').trim();
    const verifiedRaw = String(verifiedFullname || '').trim();
    if (!expectedRaw || !verifiedRaw) return false;

    // Một số ngân hàng trả fullname theo dạng TEN KHACH HANG_SO TAI KHOAN.
    // Chỉ bỏ đúng hậu tố "_ + toàn chữ số" ở CUỐI chuỗi Bank Check.
    const verifiedWithoutAccountSuffix = verifiedRaw.replace(/_\d+$/u, '');

    const expected = normalizeBankHolderName(expectedRaw);
    const verified = normalizeBankHolderName(verifiedWithoutAccountSuffix);
    if (!expected || !verified) return false;

    // Tên dân tộc có thể có apostrophe/gạch nối ở phía ngân hàng trong khi
    // BO chỉ hiển thị tên bình thường. Hai ký hiệu này được coi là ranh giới
    // từ tương đương với khoảng trắng khi đối chiếu.
    const punctuationToBoundary = /[\u0027\u0060\u00B4\u2018\u2019\u02BC\u02BB\u201B\u2032\uFF07\-\u2010\u2011\u2012\u2013\u2014\u2212]/g;
    const toTokens = (v) => normalizeBankHolderName(v)
      .replace(punctuationToBoundary, ' ')
      .split(/\s+/)
      .filter(Boolean);

    const expectedTokens = toTokens(expected);
    const verifiedTokens = toTokens(verified);
    if (!expectedTokens.length || !verifiedTokens.length) return false;

    // Đối chiếu 2 chiều ở cấp token: cùng số token và từng token phải khớp.
    // Điều này cho phép BO "Y THAN NIE" khớp Bank "Y'THAN NIE" / "Y-THAN NIE"
    // nhưng không cho phép một khoảng trắng bị chèn vào giữa một từ.
    const tokenExact = expectedTokens.length === verifiedTokens.length &&
      expectedTokens.every((v, i) => v === verifiedTokens[i]);
    if (tokenExact) return true;

    // QUY TẮC DÍNH LIỀN (1.4.127): chỉ chấp nhận khi chữ cái giống hệt nhau VÀ mọi
    // chỗ ngắt từ của tên trên BO đều cũng là chỗ ngắt từ của tên ngân hàng (API).
    //  - BO "DUONGANHDUY"  / Bank "DUONG ANH DUY" → ĐÚNG (BO viết dính, ngân hàng đúng)
    //  - BO "DUONGANH DUY" / Bank "DUONG ANH DUY" → ĐÚNG; BO "DUONG ANHDUY" → ĐÚNG
    //  - BO "DUONG ANH DUY" / Bank "DUONGANHDUY"  → SAI  (tên ngân hàng viết dính liền)
    //  - BO "DUONG ANH DUY" / Bank "DUONGANH DUY" → SAI  (ngân hàng dính một phần)
    const compact = tokens => tokens.join('');
    if (compact(expectedTokens) !== compact(verifiedTokens)) return false;
    const boundaries = tokens => {
      const set = new Set();
      let pos = 0;
      for (let i = 0; i < tokens.length - 1; i++) { pos += tokens[i].length; set.add(pos); }
      return set;
    };
    const verifiedBoundaries = boundaries(verifiedTokens);
    for (const pos of boundaries(expectedTokens)) {
      if (!verifiedBoundaries.has(pos)) return false;
    }
    return true;
  }

  // Tên khớp về chữ cái nhưng tên NGÂN HÀNG (API) bị viết dính liền so với BO.
  function bankNameIsFusedMismatch(expectedName, verifiedFullname) {
    try {
      const strip = v => normalizeBankHolderName(String(v || '').replace(/_\d+$/u, ''));
      const e = strip(expectedName), v = strip(verifiedFullname);
      if (!e || !v || bankHolderNameMatches(expectedName, verifiedFullname)) return false;
      const cut = x => x.replace(/[\u0027\u0060\u00B4\u2018\u2019\u02BC\u02BB\u201B\u2032\uFF07\-\u2010\u2011\u2012\u2013\u2014\u2212\s]+/g, '');
      return cut(e) === cut(v);
    } catch (_) { return false; }
  }

  function normNameCompare(v) {
    return normalizeBankHolderName(v).replace(/\s+/g, "");
  }

  function bankRecordMatchesRequest(rec, requested) {
    if (!rec) return false;
    const recAccount = normAccountCompare(rec.account);
    const reqAccount = normAccountCompare(requested.bankAccount || requested.account);
    if (reqAccount && recAccount && recAccount !== reqAccount) return false;

    const reqBank = normBankCompare(requested.bankName);
    if (reqBank) {
      const recBank = normBankCompare(rec.bank_name_raw || rec.bank || "");
      if (recBank && recBank !== reqBank) return false;
    }
    return true;
  }

  // TCB-ONLY RESPONSE NORMALIZER.
  // Không dùng cho ngân hàng khác. Một số response của Techcombank/Bank Checker
  // có thể đặt STK/verified/fullname trong field tên khác hoặc lồng trong object.
  // Mục tiêu duy nhất là tìm ĐÚNG record theo STK TCB, sau đó vẫn đi qua verified
  // + đối chiếu họ tên như flow 1.4.96, tuyệt đối không tự kết luận VALID.
  function tcbScalar(obj, keys) {
    if (!obj || typeof obj !== "object") return "";
    for (const key of keys) {
      const v = obj[key];
      if (v !== undefined && v !== null && String(v).trim() !== "") return v;
    }
    return "";
  }

  function tcbAccountOf(obj) {
    return tcbScalar(obj, [
      "account", "accountNumber", "account_number", "accountNo", "account_no",
      "bankaccount", "bankAccount", "bank_account", "stk", "STK",
      "soTaiKhoan", "so_tai_khoan"
    ]);
  }

  function tcbBankOf(obj) {
    return tcbScalar(obj, [
      "bank_name_raw", "bank_name", "bankName", "bank", "bankCode", "codeBank", "code_bank"
    ]);
  }

  function tcbNameOf(obj) {
    return tcbScalar(obj, [
      "fullname", "fullName", "holderName", "holder_name", "accountName",
      "account_name", "bank_fullname", "name", "tenChuTaiKhoan", "ten_chu_tai_khoan"
    ]);
  }

  function tcbParseVerifyScalar(v) {
    if (v === true || String(v).trim().toLowerCase() === "true" || String(v).trim() === "1" || String(v).trim().toUpperCase() === "VALID" || String(v).trim().toUpperCase() === "VERIFIED") return true;
    if (v === false || String(v).trim().toLowerCase() === "false" || String(v).trim() === "0" || String(v).trim().toUpperCase() === "INVALID" || String(v).trim().toUpperCase() === "FAILED") return false;
    return undefined;
  }

  // Đọc kết quả VERIFY ở bất kỳ tầng response nào, nhưng chỉ coi status/result là
  // kết quả xác minh khi nó nằm trong object có ngữ cảnh check/verify/validation.
  // Không bao giờ suy diễn từ một status HTTP/wrapper chung thành VALID/INVALID.
  function tcbVerifiedOf(obj, depth = 0, verifyContext = false) {
    if (!obj || typeof obj !== "object" || depth > 6) return undefined;
    if (Array.isArray(obj)) {
      for (const item of obj) {
        const found = tcbVerifiedOf(item, depth + 1, verifyContext);
        if (found !== undefined) return found;
      }
      return undefined;
    }

    const direct = tcbScalar(obj, [
      "verified", "isVerified", "is_verified", "valid", "isValid", "is_valid",
      "verificationResult", "verification_result", "verifyResult", "verify_result",
      "accountVerified", "account_verified", "bankAccountVerified", "bank_account_verified",
      "accountValid", "account_valid", "bankAccountValid", "bank_account_valid",
      "isMatch", "is_match"
    ]);
    if (direct !== "") {
      const parsed = tcbParseVerifyScalar(direct);
      if (parsed !== undefined) return parsed;
    }

    const localKeys = Object.keys(obj).map(k => String(k).toLowerCase());
    const localVerifyContext = verifyContext || localKeys.some(k => /verify|validat|check|owner|match/.test(k));
    if (localVerifyContext) {
      const status = tcbScalar(obj, ["status", "result", "checkStatus", "check_status", "verifyStatus", "verify_status", "verificationStatus", "verification_status"]);
      if (status !== "") {
        const parsed = tcbParseVerifyScalar(status);
        if (parsed !== undefined) return parsed;
      }
    }

    for (const [k, v] of Object.entries(obj)) {
      if (!v || typeof v !== "object") continue;
      const childContext = localVerifyContext || /verify|validat|check|owner|match|result|response|data|payload|detail|info/i.test(k);
      const found = tcbVerifiedOf(v, depth + 1, childContext);
      if (found !== undefined) return found;
    }
    return undefined;
  }

  function tcbFlattenCandidate(obj, depth = 0, out = []) {
    if (!obj || typeof obj !== "object" || depth > 4) return out;
    if (Array.isArray(obj)) {
      for (const item of obj) tcbFlattenCandidate(item, depth + 1, out);
      return out;
    }
    const account = tcbAccountOf(obj);
    if (account) out.push(obj);
    for (const [k, v] of Object.entries(obj)) {
      if (!v || typeof v !== "object") continue;
      // Chỉ đi sâu vào các vùng dữ liệu có khả năng là record; không quét bừa toàn response.
      if (/account|bank|digital|check|data|result|payload|response|detail|info/i.test(k)) {
        tcbFlattenCandidate(v, depth + 1, out);
      }
    }
    return out;
  }

  function tcbNormalizeRecord(rec) {
    if (!rec || typeof rec !== "object") return rec;
    const check = rec.check_result && typeof rec.check_result === "object" ? rec.check_result : {};
    const nested = rec.data && typeof rec.data === "object" ? rec.data : {};
    const account = tcbAccountOf(rec) || tcbAccountOf(check) || tcbAccountOf(nested);
    const bank = tcbBankOf(rec) || tcbBankOf(check) || tcbBankOf(nested);
    const fullname = tcbNameOf(rec) || tcbNameOf(check) || tcbNameOf(nested);
    const verified = tcbVerifiedOf(rec);
    return {
      ...rec,
      ...(account ? { account } : {}),
      ...(bank ? { bank_name_raw: bank } : {}),
      ...(fullname ? { fullname } : {}),
      ...(verified !== undefined ? { verified } : {}),
      check_result: { ...check, ...(fullname && !check.fullname ? { fullname } : {}), ...(account && !check.account ? { account } : {}) }
    };
  }

  // CHẶN SỐ ĐIỆN THOẠI VIỆT NAM CHỈ CHO VIETINBANK + BIDV + MSB.
  // Rule CHỐT: chỉ chặn số điện thoại nội địa đúng 10 chữ số, đầu 03, 05, 06, 07, 08, 09.
  // Không chặn dạng 84xxxxxxxxx hoặc +84xxxxxxxxx.
  function isVietnamesePhoneAccount(account) {
    const value = String(account || '').replace(/\s/g, '');
    return /^0[35-9]\d{8}$/.test(value); // đầu số 03, 05, 06, 07, 08, 09
  }

  function isPhoneBlockedBank(bankName, codeBank = '') {
    const raw = removeVietnameseTones(String(bankName || codeBank || ''));
    const code = String(resolveBankCode(bankName || codeBank || '') || '').toUpperCase();
    // Ưu tiên cả tên ngân hàng thô lẫn mã chuẩn để không phụ thuộc parser.
    // Chỉ áp dụng auto phone-block cho VietinBank/VTB, BIDV và MSB/MaritimeBank.
    // Chỉ dùng mã đã resolve chính xác; không dùng substring tên ngân hàng.
    // Vì vậy VietBank/VB và Vietcombank/VCB không thể rơi vào rule VietinBank.
    return code === 'VTB' || code === 'BIDV' || code === 'MSB';
  }

  function shouldBlockVietnamesePhoneForBank(account, bankName, codeBank = '') {
    return isPhoneBlockedBank(bankName, codeBank) && isVietnamesePhoneAccount(account);
  }

  async function checkAccountRawForXnk({ account, userId, expectedName, bankName, codeBank, bankAccount, bypassPhoneRule = false, requestTimeoutMs = 0 }) {
    // HARD GATE: auto Check Bank không được gửi số điện thoại nội địa 10 số
    // đầu 03-09 đối với VietinBank/VTB, BIDV, MSB. Gate chạy TRƯỚC API.
    // Manual CHECK cố ý bypass gate này. Các ngân hàng khác vẫn Check Bank bình thường.
    if (!bypassPhoneRule && shouldBlockVietnamesePhoneForBank(bankAccount || account, bankName, codeBank)) {
      log('BANK PHONE RULE BLOCK:', { bank: bankName || codeBank || '', account });
      return {
        status: 'INVALID',
        message: 'Số điện thoại Việt Nam không được phép kiểm tra tự động đối với VietinBank/BIDV/MSB.',
        failedBank: {
          bank: bankName || codeBank || '',
          account: bankAccount || account || ''
        },
        reasonCode: 'VIETNAM_PHONE_VTB_BIDV_MSB'
      };
    }

    const body = { account, platform: currentPlatform };
    if (userId) body.UserId = userId;

    if (bankName) {
      const bankCode = resolveBankCode(bankName);
      const resolvedBin = bankCode && BIN_BY_CODE[bankCode];
      if (bankCode) {
        body.bank = bankCode;
        if (resolvedBin) body.codeBank = String(resolvedBin);
      } else if (/usdt|trc20|erc20/i.test(bankName)) {
        body.bank = bankName.trim().toUpperCase();
      }
    } else if (codeBank) {
      const resolvedCode = resolveBankCode(codeBank);
      if (resolvedCode) {
        body.bank = resolvedCode;
        const resolvedBin = BIN_BY_CODE[resolvedCode];
        if (resolvedBin) body.codeBank = String(resolvedBin);
      }
    }
    if (bankAccount) body.bankaccount = bankAccount;

    log("BANK API REQUEST:", { ...body, platform: currentPlatform });
    const res = await fetchApiV4(BANKING_API_URL, body, { timeoutMs: requestTimeoutMs });
    if (res.licenseError) return { status: "ERROR", message: res.message || "License xác thực thất bại." };
    if (!res.ok) return { status: "ERROR", message: res.message || "Không kết nối được máy chủ Bank Checker." };

    const result = res.result;
    const bankAccounts = Array.isArray(result?.bankAccounts) ? result.bankAccounts : [];
    const digitalAccounts = Array.isArray(result?.digitalBankAccounts) ? result.digitalBankAccounts : [];

    // Không biến success=false thành ERROR một cách máy móc nếu server vẫn trả
    // dữ liệu tài khoản để kiểm tra. Chỉ ERROR khi không có dữ liệu kiểm tra dùng được.
    if (!result || result.error === true || (result.success !== true && !bankAccounts.length && !digitalAccounts.length)) {
      return {
        status: "ERROR",
        message: (result && (result.message || (result.data && result.data.message))) || "API không trả dữ liệu kiểm tra tài khoản.",
        raw: result
      };
    }

    const requestedAccount = normAccountCompare(bankAccount || account);
    const requestedBankCode = String(resolveBankCode(bankName || codeBank || "") || "").toUpperCase();
    const exactBank = bankAccounts.filter(x => bankRecordMatchesRequest(x, { bankName, bankAccount, account }));
    const exactDigital = digitalAccounts.filter(x => normAccountCompare(x.account) === requestedAccount);
    let target = exactBank[0] || exactDigital[0] || null;
    let verifiedTarget = target;

    // TCB-specific compatibility: some Bank Checker responses identify Techcombank
    // by a different label (e.g. full Vietnamese name) or omit the bank field, while
    // returning the exact requested account. Do NOT mark this UNKNOWN merely because
    // the bank label cannot be normalized. If exactly one returned record has the
    // exact requested account, use that record and continue the normal verified/name
    // checks. If multiple records share the account, keep the strict bank match.
    if (!verifiedTarget && requestedBankCode === "TCB" && requestedAccount) {
      const normalRecords = [...bankAccounts, ...digitalAccounts];
      const exactAccountOnly = normalRecords
        .filter(x => normAccountCompare(x.account) === requestedAccount);
      if (exactAccountOnly.length === 1) {
        verifiedTarget = tcbNormalizeRecord(exactAccountOnly[0]);
        log("BANK TCB ACCOUNT MATCH:", { account: requestedAccount, returnedBank: verifiedTarget.bank_name_raw || verifiedTarget.bank || "" });
      } else if (exactAccountOnly.length === 0) {
        // TCB-only nested-field fallback: API có thể trả record trong data/payload/response.
        const nestedCandidates = tcbFlattenCandidate(result);
        const nestedExact = nestedCandidates
          .filter(x => normAccountCompare(tcbAccountOf(x)) === requestedAccount);
        if (nestedExact.length === 1) {
          verifiedTarget = tcbNormalizeRecord(nestedExact[0]);
          log("BANK TCB NESTED ACCOUNT MATCH:", { account: requestedAccount, returnedBank: tcbBankOf(nestedExact[0]) || "" });
        }
      }
    }

    if (!verifiedTarget) {
      // Giữ nguyên cơ chế ổn định của 1.4.89: nếu API chỉ trả đúng MỘT
      // bản ghi thì dùng bản ghi đó để tiếp tục xác minh. Một số Bank Checker
      // không trả bank_name_raw/codeBank trong record dù tài khoản đã đúng,
      // nên ép khớp tuyệt đối ở đây sẽ biến đơn hợp lệ thành UNKNOWN vô hạn.
      // Nếu API trả nhiều bản ghi mà không xác định được target thì mới ERROR/RECHECK.
      const all = [...bankAccounts, ...digitalAccounts];
      // 1.4.128 — CHỐNG KẾT LUẬN NHẦM TÀI KHOẢN CŨ: nếu API chỉ trả đúng một bản ghi
      // nhưng bản ghi đó có STK RÕ RÀNG khác STK của đơn (ví dụ khách đã đổi sang STK/
      // ngân hàng mới còn API vẫn trả STK cũ), TUYỆT ĐỐI không dùng bản ghi cũ để
      // kết luận INVALID cho đơn mới. Trả ERROR → tool sẽ check lại, hết ngân sách thì
      // mở khóa + SKIP (không Buộc hủy). Bản ghi không có STK hoặc STK bị che (***)
      // vẫn xử lý như cũ.
      const onlyRec = all.length === 1 ? all[0] : null;
      const onlyAcc = onlyRec ? normAccountCompare(onlyRec.account || "") : "";
      const staleOnlyRecord = !!(onlyRec && onlyAcc && requestedAccount &&
        !/[*•Xx]{2,}/.test(String(onlyRec.account || "")) && onlyAcc !== requestedAccount);
      if (staleOnlyRecord) {
        log("BANK API CHỈ TRẢ TÀI KHOẢN KHÁC (có thể là TK cũ):", { requested: requestedAccount, returned: onlyAcc });
        return {
          status: "ERROR",
          message: "Bank Checker chỉ trả tài khoản khác với tài khoản của đơn (có thể là tài khoản cũ); không kết luận sai cho đơn mới.",
          reasonCode: "BANK_RECORD_ACCOUNT_MISMATCH",
          requested: { bank: bankName || codeBank || "", account: bankAccount || account || "" },
          returned: [{ bank: onlyRec.bank_name_raw || onlyRec.bank || "", account: onlyRec.account || "" }],
          raw: result
        };
      }
      if (all.length === 1) {
        verifiedTarget = all[0];
      } else {
        return {
          status: "ERROR",
          message: "Bank Checker không trả đúng tài khoản/ngân hàng của đơn; chưa đủ dữ liệu để kết luận.",
          reasonCode: "BANK_TARGET_MISMATCH",
          requested: { bank: bankName || codeBank || "", account: bankAccount || account || "" },
          returned: all.map(x => ({ bank: x.bank_name_raw || x.bank || "", account: x.account || "" })),
          raw: result
        };
      }
    }

    // ALL-BANK VERIFICATION CONTRACT (HARD SAFETY):
    // Chỉ 2 giá trị mới được phép kết luận từ API:
    //   true  = API xác minh thành công
    //   false = API xác minh thất bại rõ ràng
    // Mọi giá trị khác (undefined/null/rỗng/không đọc được) = UNKNOWN/ERROR.
    // Quy tắc này áp dụng cho TẤT CẢ ngân hàng, không chỉ TCB.
    const tcbTarget = requestedBankCode === "TCB" ? tcbNormalizeRecord(verifiedTarget) : verifiedTarget;
    const targetVerified = tcbVerifiedOf(tcbTarget);

    // HARD SAFETY: không được biến thiếu/không đọc được field xác minh thành INVALID.
    // true  = xác minh thành công
    // false = API xác minh thất bại rõ ràng
    // undefined/null = API chưa cung cấp kết quả xác minh chắc chắn -> UNKNOWN/ERROR
    // Trường hợp UNKNOWN/ERROR phải đi qua AUTO-RECHECK; hết ngân sách thì SKIP,
    // tuyệt đối không ép trả đơn như lỗi thông tin ngân hàng.
    if (targetVerified !== true && targetVerified !== false) {
      log("BANK VERIFY RESULT MISSING:", { bank: requestedBankCode || bankName || codeBank || "", account: requestedAccount || bankAccount || account || "", returnedBank: tcbTarget.bank_name_raw || tcbTarget.bank || "" });
      const apiMessage = String(tcbTarget.message || tcbTarget.check_result?.message || "").trim();
      const apiAccount = String(tcbTarget.account || "").trim();
      const apiBank = String(tcbTarget.bank_name_raw || tcbTarget.bank || "").trim();
      return {
        status: "ERROR",
        message: apiMessage || "API chưa trả kết quả xác minh tài khoản/ngân hàng rõ ràng.",
        reasonCode: "VERIFY_RESULT_MISSING",
        failedBank: {
          bank: apiBank,
          account: apiAccount,
          fullname: String(tcbTarget.fullname || tcbTarget.bank_fullname || tcbTarget.check_result?.fullname || "").trim()
        }
      };
    }

    if (targetVerified === false) {
      const apiMessage = String(tcbTarget.message || tcbTarget.check_result?.message || "").trim();
      const apiAccount = String(tcbTarget.account || "").trim();
      const apiBank = String(tcbTarget.bank_name_raw || tcbTarget.bank || "").trim();
      let reasonCode = "ACCOUNT_OR_BANK_INVALID";
      if (/tên|name|fullname|holder/i.test(apiMessage)) reasonCode = "NAME_MISMATCH";
      else if (/tài khoản|account|stk|số tài khoản|không tồn tại|not found/i.test(apiMessage)) reasonCode = "ACCOUNT_INVALID";
      else if (/ngân hàng|bank/i.test(apiMessage)) reasonCode = "BANK_INVALID";
      return { status: "INVALID", message: apiMessage || "API xác minh tài khoản/ngân hàng trả về INVALID.", reasonCode, failedBank: { bank: apiBank, account: apiAccount, fullname: String(tcbTarget.fullname || tcbTarget.bank_fullname || tcbTarget.check_result?.fullname || "").trim() } };
    }

    const verifiedFullname = tcbTarget.check_result?.fullname || tcbTarget.fullname || tcbTarget.bank_fullname || "";
    if (!expectedName || !verifiedFullname || !bankHolderNameMatches(expectedName, verifiedFullname)) {
      return { status: "INVALID", message: `Tên chủ tài khoản không khớp: ${verifiedFullname}` + (bankNameIsFusedMismatch(expectedName, verifiedFullname) ? " (tên từ ngân hàng viết dính liền)" : ""), failedBank: { bank: tcbTarget.bank_name_raw || tcbTarget.bank || "", account: tcbTarget.account || "", fullname: verifiedFullname } };
    }

    return { status: "VALID", message: "Tài khoản/ngân hàng đúng và đã được Bank Checker xác minh.", verifiedBank: { bank: tcbTarget.bank_name_raw || tcbTarget.bank || "", account: tcbTarget.account || "", fullname: verifiedFullname }, raw: result };
  }

  async function sendBankCheck(data, no, options = {}) {
    try {
      const scanAcc = data.bankAccount || data.account || "";
      if (!scanAcc && !data.userId) return { status: "ERROR", message: "Không có account/member ID." };

      const result = await checkAccountRawForXnk({
        account: scanAcc,
        userId: data.userId || "",
        expectedName: data.expectedName || "",
        bankName: data.bankName || "",
        codeBank: data.codeBank || resolveBankCode(data.bankName || ""),
        bankAccount: data.bankAccount || "",
        bypassPhoneRule: options.manual === true,
        requestTimeoutMs: options.requestTimeoutMs || 0
      });
      log(no, options.manual ? "→ MANUAL BANK CHECK:" : "→ BANK CHECK TRỰC TIẾP:", result);
      return result || { status: "ERROR", message: "Bank Checker không trả kết quả." };
    } catch (err) {
      return { status: "ERROR", message: err?.message || String(err) };
    }
  }

  async function manualCheckBankNow() {
    const no = currentOrder || "MANUAL";
    try {
      const panel = currentPanel();
      if (!panel) {
        showBankPopup(no, {}, "ERROR", { message: "Hãy mở giao diện Xem lại chuyển tiền của đơn cần kiểm tra trước." });
        return;
      }
      const row = no && no !== "MANUAL" ? findRow(no) : null;
      const data = bankDataFromPanel(panel, row);
      if (!data.expectedName || !data.bankAccount || !data.bankName) {
        showBankPopup(no, data, "ERROR", { message: "Không đọc đủ Họ tên + STK + Ngân hàng trong đơn đang mở." });
        return;
      }
      const result = await sendBankCheck(data, no, { manual: true });
      const status = bankResultStatus(result) || "ERROR";
      showBankPopup(no, data, status, result);
      log(no, "→ MANUAL BANK CHECK RESULT:", result);
    } catch (e) {
      showBankPopup(no, {}, "ERROR", { message: String(e?.message || e) });
      log(no, "→ MANUAL BANK CHECK ERROR:", String(e?.message || e));
    }
  }

  // CHECK thủ công theo từng mã đơn:
  // - Không cần bật AUTO.
  // - Nếu đơn chưa khóa: chính thao tác CHECK sẽ Khóa → mở Xem lại chuyển tiền →
  //   đọc dữ liệu → gọi đúng Bank Checker hiện tại với manual=true → đóng → Mở khóa.
  // - Không đẩy nhà 3, không Buộc hủy, không ghi done/failed/returned.
  // - Nếu đơn đã Mở khóa (đang do người khác khóa), tuyệt đối không đụng vào.
  async function manualCheckOrderByRow(row) {
    const no = orderNo(row);
    if (!no) return;
    if (manualCheckBusy.has(no)) return;

    manualCheckBusy.add(no);
    let ownLock = false;
    let panelOpenedByManual = false;
    try {
      if (currentPanel() && currentOrder === no) {
        const panel = currentPanel();
        const data = bankDataFromPanel(panel, row);
        if (!data.expectedName || !data.bankAccount || !data.bankName) {
          showBankPopup(no, data, "ERROR", { message: "Không đọc đủ Họ tên + STK + Ngân hàng trong đơn đang mở." });
          return;
        }
        const result = await sendBankCheck(data, no, { manual: true });
        showBankPopup(no, data, bankResultStatus(result) || "ERROR", result);
        log(no, "→ CHECK thủ công trên giao diện đang mở:", result);
        return;
      }

      const freshRow = findRow(no);
      if (!freshRow) {
        showBankPopup(no, {}, "ERROR", { message: "Không tìm thấy mã đơn trên danh sách hiện tại." });
        return;
      }

      if (isLockedBySomeone(freshRow)) {
        showBankPopup(no, {}, "ERROR", { message: "Đơn đang được người khác khóa → CHECK không can thiệp vào đơn." });
        log(no, "→ CHECK thủ công: SKIP vì đơn đang Mở khóa.");
        return;
      }

      if (!isAvailableToLock(freshRow)) {
        showBankPopup(no, {}, "ERROR", { message: "Đơn hiện không có nút Khóa để CHECK an toàn." });
        return;
      }

      const lockResult = await lockOne(no);
      if (lockResult?.status !== "LOCKED_BY_TOOL") {
        showBankPopup(no, {}, "ERROR", { message: "Không thể xác nhận CHECK đang giữ đúng đơn." });
        return;
      }
      ownLock = true;

      await openProcessing(no);
      panelOpenedByManual = true;
      const panel = currentPanel();
      const data = bankDataFromPanel(panel, findRow(no));
      if (!data.expectedName || !data.bankAccount || !data.bankName) {
        throw new Error("Không đọc đủ Họ tên + STK + Ngân hàng trong giao diện Xem lại chuyển tiền");
      }

      log(no, "→ CHECK thủ công: BANK DATA:", data);
      const result = await sendBankCheck(data, no, { manual: true });
      const status = bankResultStatus(result) || "ERROR";
      showBankPopup(no, data, status, result);
      log(no, "→ CHECK thủ công RESULT:", result);
    } catch (e) {
      showBankPopup(no, {}, "ERROR", { message: String(e?.message || e) });
      log(no, "→ CHECK thủ công ERROR:", String(e?.message || e));
    } finally {
      // CHECK thủ công không được để lại lock. Chỉ đóng/mở khóa nếu chính CHECK đã
      // tạo lock và mở giao diện. Nếu có lỗi, vẫn cố gắng trả đơn về trạng thái ban đầu.
      if (panelOpenedByManual) {
        try { await closeProcessingPanel(no); } catch (e) {
          log(no, "→ CHECK thủ công: không đóng được giao diện:", String(e?.message || e));
        }
      }
      if (ownLock) {
        try {
          await unlockOrderAfterProviderSkip(no, "CHECK thủ công hoàn tất");
        } catch (e) {
          log(no, "→ CHECK thủ công: KHÔNG MỞ KHÓA được đơn sau CHECK:", String(e?.message || e));
        }
      }
      manualCheckBusy.delete(no);
    }
  }

  function tryTriggerCheckerUI(no) {
    const candidates = [...document.querySelectorAll("button,span,div")];
    const btn = candidates.find(e =>
      /QUÉT\s*&\s*CHECK/i.test(norm(e.innerText)) &&
      e.offsetParent !== null
    );
    if (btn) {
      log(no, "→ phát hiện nút QUÉT & CHECK, kích hoạt bridge");
      btn.click();
    }
  }

  // XỬ LÝ RACE KHI KHÓA ĐƠN:
  // Sau khi Tool bấm "Khóa", một nhân viên khác có thể vừa khóa đơn trước.
  // Website khi đó hiển thị MessageBox "đang bị khóa bởi một nhân viên bán hàng khác"
  // + nút "Xác nhận". Đây KHÔNG phải lỗi hệ thống và tuyệt đối không được hardStop.
  function findOtherLockConflictDialog(no = "") {
    const selectors = [
      ".el-message-box__wrapper",
      ".el-message-box",
      ".el-dialog__wrapper"
    ];
    const candidates = [];
    for (const sel of selectors) {
      for (const el of document.querySelectorAll(sel)) {
        if (!el || el.offsetParent === null) continue;
        const text = norm(el.innerText || el.textContent || "");
        if (!text) continue;
        if (/đang bị khóa bởi (?:một )?nhân viên bán hàng khác/i.test(text) ||
            /không thể lặp lại thao tác.*làm mới và thử lại/i.test(text)) {
          if (!no || !text.includes(String(no))) return el;
          return el;
        }
      }
    }

    // Fallback: một số phiên bản Element UI render wrapper khác class.
    const all = [...document.querySelectorAll("body *")].filter(el => {
      try { return el.offsetParent !== null; } catch (_) { return false; }
    });
    return all.find(el => {
      const text = norm(el.innerText || el.textContent || "");
      return text &&
        (/đang bị khóa bởi (?:một )?nhân viên bán hàng khác/i.test(text) ||
         /không thể lặp lại thao tác.*làm mới và thử lại/i.test(text)) &&
        (!no || text.includes(String(no)));
    }) || null;
  }

  function clickOtherLockConflictConfirm(dialog) {
    if (!dialog) return false;
    const buttons = [...dialog.querySelectorAll("button,.el-button,[role='button'],span")]
      .filter(el => {
        try { return el.offsetParent !== null; } catch (_) { return false; }
      });

    // Ưu tiên đúng nút Xác nhận nằm trong MessageBox, không quét nút toàn trang.
    const btn = buttons.find(el => lower(el.innerText || el.textContent || "") === "xác nhận") ||
      buttons.find(el => /xác nhận/i.test(norm(el.innerText || el.textContent || "")));
    if (!btn) return false;

    try {
      btn.scrollIntoView({ block: "center", inline: "nearest" });
    } catch (_) {}
    btn.click();
    return true;
  }

  function hasOtherLockConflictMessage(no = "") {
    const bodyText = norm(document.body?.innerText || document.body?.textContent || "");
    if (!bodyText) return false;
    const hasConflict = /đang bị khóa bởi (?:một )?nhân viên bán hàng khác/i.test(bodyText) ||
      /không thể lặp lại thao tác.*làm mới và thử lại/i.test(bodyText);
    if (!hasConflict) return false;
    // Nếu có mã đơn trong trang thì ưu tiên kiểm tra đúng đơn đang xử lý.
    return !no || bodyText.includes(String(no));
  }

  async function dismissOtherLockConflict(no) {
    const dialog = findOtherLockConflictDialog(no);
    if (dialog) {
      await handleOtherLockConflict(no, dialog);
      return true;
    }
    if (hasOtherLockConflictMessage(no)) {
      // Fallback cho Element UI khi wrapper/dialog không có class hoặc không được offsetParent nhận diện.
      const buttons = [...document.querySelectorAll("button,.el-button,[role='button']")].filter(el => {
        try { return el.offsetParent !== null; } catch (_) { return false; }
      });
      const confirmBtn = buttons.find(el => lower(el.innerText || el.textContent || "") === "xác nhận") ||
        buttons.find(el => /xác nhận/i.test(norm(el.innerText || el.textContent || "")));
      if (confirmBtn) {
        try { confirmBtn.click(); } catch (_) {}
      }
      log(no, "→ phát hiện MessageBox: đơn đang bị nhân viên bán hàng khác khóa → SKIP, không dừng Bot");
      healthTouch("Đơn bị người khác khóa");
      return true;
    }
    return false;
  }

  async function handleOtherLockConflict(no, dialog) {
    log(no, "→ WEBSITE: đơn đã bị nhân viên khác khóa trước → xác nhận popup và SKIP đơn");
    healthTouch("Đơn bị người khác khóa");

    const clicked = clickOtherLockConflictConfirm(dialog);
    if (clicked) {
      log(no, "→ đã bấm Xác nhận MessageBox cạnh tranh khóa");
    } else {
      log(no, "→ chưa tìm thấy nút Xác nhận trong MessageBox, tiếp tục chờ DOM đóng popup");
    }

    const end = Date.now() + 3500;
    while (Date.now() < end) {
      await sleep(120);
      const current = findOtherLockConflictDialog(no);
      if (!current) break;
      if (!clicked) clickOtherLockConflictConfirm(current);
    }

    log(no, "→ RACE LOCK = IGNORE đơn này; KHÔNG Bank Check / Provider / Thanh toán / Auto Unlock / hardStop");
    return { status: "SKIP_LOCKED_BY_OTHER" };
  }

  async function lockOne(no) {
    let row = findRow(no);
    if (!row) {
      // Danh sách BO có thể đang tải lại/đổi trang: chờ dòng xuất hiện lại trước khi kết luận.
      const until = Date.now() + 5000;
      while (!row && Date.now() < until) { await sleep(250); row = findRow(no); }
    }
    if (!row) {
      log(no, "→ dòng đơn không còn trong danh sách (BO làm mới/đơn đã đổi) → BỎ QUA lượt này, KHÔNG dừng Bot");
      return { status: "ROW_GONE" };
    }

    if (isLockedBySomeone(row)) {
      log(no, "→ nút đang là Mở khóa, bỏ qua hoàn toàn");
      return { status: "SKIP_LOCKED_BY_OTHER" };
    }

    const b = action(row, "Khóa");
    if (!b) throw new Error("Không thấy nút Khóa");

    b.scrollIntoView({ block: "center" });
    b.click();
    log(no, "→ bấm KHÓA");

    const end = Date.now() + Math.max(250, Number(XNK_CONFIG.actionTimeoutMs) || 8000);
    let attempt = 0;
    while (Date.now() < end) {
      // Race có thể xuất hiện trước khi Vue kịp đổi nút Khóa -> Mở khóa.
      const conflict = findOtherLockConflictDialog(no);
      if (conflict) return await handleOtherLockConflict(no, conflict);

      const current = findRow(no);
      if (current && isLockedBySomeone(current)) {
        log(no, "→ xác nhận nút đã đổi thành Mở khóa = khóa thành công");
        return { status: "LOCKED_BY_TOOL" };
      }

      healthTouch("Chờ trạng thái Mở khóa");
      await sleep(XNK_CONFIG.autoSync === false ? 300 : syncDelay(attempt++));
    }

    // Kiểm tra thêm lần cuối cả DOM dialog lẫn toàn bộ body text. Một số phiên bản BO
    // render MessageBox không có class/wrapper chuẩn nên findOtherLockConflictDialog() có thể bỏ sót.
    if (await dismissOtherLockConflict(no)) {
      return { status: "SKIP_LOCKED_BY_OTHER" };
    }

    // 1.4.155: BO có thể từ chối lệnh Khóa (lỗi/giới hạn tần suất phía BO) hoặc làm mới danh sách.
    // Khi đó Tool CHƯA khóa đơn nào → không có gì để mở khóa, chỉ bỏ qua lượt này, KHÔNG dừng Bot.
    {
      const after = findRow(no);
      if (!after) {
        log(no, "→ sau khi bấm Khóa dòng đơn không còn trong danh sách (BO làm mới) → BỎ QUA lượt này, KHÔNG dừng Bot");
        return { status: "ROW_GONE" };
      }
      if (!isLockedBySomeone(after) && action(after, "Khóa")) {
        log(no, "→ BO không nhận lệnh Khóa (nút vẫn là Khóa) → Tool chưa khóa đơn này → BỎ QUA lượt này, KHÔNG dừng Bot");
        return { status: "LOCK_REJECTED" };
      }
    }

    throw new Error("Bấm Khóa nhưng không xác nhận được Mở khóa");
  }

  async function openProcessing(no) {
    // Sau khi bấm KHÓA, Vue/Element UI có thể render lại cả <tr>.
    // Không được lấy row cũ và kết luận ngay rằng không có "Xem lại chuyển tiền".
    // Chờ DOM ổn định và tìm lại dòng + nút nhiều lần.
    const end = Date.now() + Math.max(XNK_CONFIG.actionTimeoutMs, 8000);
    let clicked = false;

    while (Date.now() < end) {
      const row = findRow(no);
      if (row) {
        let b = action(row, "Xem lại chuyển tiền");
        if (!b) b = findTextButton(row, "Xem lại chuyển tiền");

        if (b) {
          b.scrollIntoView({ block: "center" });
          await sleep(150);
          b.click();
          log(no, "→ đã bấm Xem lại chuyển tiền");
          clicked = true;
          break;
        }
      }

      await sleep(XNK_CONFIG.autoSync === false ? 300 : syncDelay(0));
    }

    if (!clicked) {
      throw new Error("Sau khi khóa, chưa tìm thấy nút Xem lại chuyển tiền sau khi đã chờ DOM cập nhật");
    }

    // Sau khi click, tiếp tục chờ giao diện xử lý xuất hiện.
    // 1.4.155: BO đôi khi nuốt cú bấm ngay sau khi khóa → nếu sau ~3,5 giây cửa sổ chưa mở thì bấm lại (tối đa 2 lần).
    const panelEnd = Date.now() + Math.max(XNK_CONFIG.actionTimeoutMs, 8000) + 4000;
    let panelAttempt = 0, reclicks = 0, lastClickAt = Date.now();
    while (Date.now() < panelEnd) {
      await sleep(XNK_CONFIG.autoSync === false ? 250 : syncDelay(panelAttempt++));
      if (reclicks < 2 && Date.now() - lastClickAt > 3500) {
        try {
          const r2 = findRow(no);
          const b2 = r2 && (action(r2, "Xem lại chuyển tiền") || findTextButton(r2, "Xem lại chuyển tiền"));
          if (b2) { b2.click(); reclicks++; lastClickAt = Date.now(); log(no, "→ cửa sổ xử lý chưa mở → bấm lại Xem lại chuyển tiền (lần " + reclicks + ")"); }
        } catch (_) {}
      }
      const panel = currentPanel();
      if (
        findTextButton(panel, "Xác nhận việc thanh toán") ||
        panel.querySelector('input[placeholder="Chọn Thanh toán rút tiền của bên thứ 3"]') ||
        panel.querySelector('input[placeholder="Chọn Thanh toán rút tiền của bên thứ ba"]') ||
        panel.querySelector('textarea[placeholder*="Ghi chú front-end"]')
      ) {
        log(no, "→ đã mở giao diện xử lý chuyển tiền");
        return true;
      }
    }

    const openErr = new Error("Đã bấm Xem lại chuyển tiền nhưng chưa mở giao diện xử lý");
    openErr.code = "OPEN_PANEL_FAILED";
    throw openErr;
  }

  function buildBankInvalidReason(data, result) {
    // Lý do Bank Check phải rõ ràng trong cả popup và log; không được rơi về
    // thông báo chung "Thông tin không chính xác" khi đã biết nguyên nhân.
    const msg = String(result?.message || "").trim();
    const expected = String(data?.expectedName || "").trim();
    if (result?.reasonCode === "VIETNAM_PHONE_VTB_BIDV_MSB") {
      return `SỐ ĐIỆN THOẠI KHÔNG ĐƯỢC PHÉP | Ngân hàng: ${String(data?.bankName || data?.codeBank || "").trim()} | Số: ${String(data?.bankAccount || data?.account || "").trim()} | VietinBank, BIDV và MSB không được phép dùng số điện thoại Việt Nam làm STK.`;
    }
    const failed = result?.failedBank || {};
    const apiName = String(failed.fullname || "").trim();
    const bank = String(failed.bank || data?.bankName || "").trim();
    const parts = [];

    if (result?.reasonCode === "NAME_MISMATCH" || /tên chủ tài khoản không khớp/i.test(msg)) {
      parts.push("HỌ TÊN KHÔNG KHỚP");
      if (expected) parts.push(`Tên trên đơn: ${expected}`);
      if (apiName) parts.push(`Tên từ API: ${apiName}`);
      if (msg) parts.push(`Chi tiết: ${msg}`);
    } else if (result?.reasonCode === "ACCOUNT_INVALID") {
      parts.push("SỐ TÀI KHOẢN KHÔNG HỢP LỆ");
      if (bank) parts.push(`Ngân hàng: ${bank}`);
      if (failed.account) parts.push(`STK API: ${failed.account}`);
      if (msg) parts.push(`Chi tiết: ${msg}`);
    } else if (result?.reasonCode === "BANK_INVALID") {
      parts.push("NGÂN HÀNG KHÔNG HỢP LỆ");
      if (bank) parts.push(`Ngân hàng: ${bank}`);
      if (msg) parts.push(`Chi tiết: ${msg}`);
    } else if (result?.reasonCode === "ACCOUNT_OR_BANK_INVALID" || /không được xác minh|xác minh hợp lệ|tài khoản|ngân hàng/i.test(msg)) {
      parts.push("TÀI KHOẢN/NGÂN HÀNG KHÔNG ĐƯỢC XÁC MINH");
      if (bank) parts.push(`Ngân hàng: ${bank}`);
      if (failed.account) parts.push(`STK API: ${failed.account}`);
      if (apiName) parts.push(`Tên từ API: ${apiName}`);
      if (msg) parts.push(`Chi tiết: ${msg}`);
    } else {
      parts.push("BANK CHECK KHÔNG XÁC ĐỊNH ĐƯỢC LÝ DO");
      if (msg) parts.push(`Chi tiết: ${msg}`);
      if (bank) parts.push(`Ngân hàng: ${bank}`);
      if (failed.account) parts.push(`STK API: ${failed.account}`);
      if (apiName) parts.push(`Tên từ API: ${apiName}`);
    }
    return parts.join(" | ");
  }

  function adaptiveBankCheckBudgetMs() {
    const configured = Math.max(3000, Number(XNK_CONFIG.bankCheckTimeoutMs) || 15000);
    const apiP90 = percentile(health.apiSamples, 90);
    const apiP95 = percentile(health.apiSamples, 95);
    // AUTO SYNC: khi API thực tế chậm, tự mở rộng ngân sách kiểm tra thay vì
    // kết luận UNKNOWN quá sớm. Vẫn có trần an toàn để một đơn không treo vô hạn.
    const observed = Math.max(Number(apiP90) || 0, Number(apiP95) || 0);
    const adaptive = observed > 0 ? Math.round(observed * 3 + syncDelay(3) * 2) : configured;
    return Math.min(90000, Math.max(configured, adaptive));
  }

  function adaptiveBankRequestTimeoutMs() {
    const configured = Math.max(3000, Number(XNK_CONFIG.bankCheckTimeoutMs) || 15000);
    const apiP90 = percentile(health.apiSamples, 90);
    // Mỗi request có timeout riêng dựa trên tốc độ API đã quan sát; không dùng
    // một timeout cứng cho mọi lần check. Có trần để AbortController không treo.
    const adaptive = Number(apiP90) > 0 ? Math.round(apiP90 * 1.8) : Math.min(configured, 12000);
    return Math.min(45000, Math.max(3000, adaptive));
  }

  function adaptiveBankRetryDelayMs(attempt) {
    const apiP50 = percentile(health.apiSamples, 50);
    const sync = syncDelay(Math.min(8, attempt));
    const apiWait = Number(apiP50) > 0 ? Math.round(apiP50 * 0.25) : 0;
    return Math.min(3500, Math.max(150, sync, apiWait));
  }

  async function waitForBankResult(data, no) {
    // RULE CHỐT:
    // 1) Chỉ VietinBank/VTB + BIDV + MSB/MaritimeBank và STK là số điện thoại VN
    //    mới bị INVALID ngay, không gọi API/retry.
    // 2) Tất cả ngân hàng còn lại (bao gồm VCB/Vietcombank, VB/VietBank, TCB...) đều
    //    phải đi qua Bank Check bình thường.
    // 3) VALID bất kỳ lần nào -> xử lý ngay.
    // 4) INVALID ở ngân hàng bình thường chưa đủ để trả đơn ngay: phải xác nhận lại
    //    nhiều lần liên tiếp. Chỉ khi đủ 5 lần INVALID liên tiếp mới kết luận INVALID.
    //    Nếu có VALID ở bất kỳ lần nào -> xử lý ngay. Nếu kết quả không ổn định hoặc
    //    không đủ bằng chứng sau ngân sách AUTO SYNC -> UNKNOWN -> đóng + MỞ KHÓA + SKIP.
    if (shouldBlockVietnamesePhoneForBank(data?.bankAccount || data?.account || "", data?.bankName || "", data?.codeBank || "")) {
      const blocked = {
        status: "INVALID",
        message: "Số điện thoại Việt Nam không được phép sử dụng làm số tài khoản đối với VietinBank, BIDV và MSB/MaritimeBank.",
        failedBank: { bank: data?.bankName || data?.codeBank || "", account: data?.bankAccount || data?.account || "" },
        reasonCode: "VIETNAM_PHONE_VTB_BIDV_MSB"
      };
      log(no, "BANK PHONE RULE BLOCK (PRE-API, NO RETRY):", blocked);
      showBankPopup(no, data, "INVALID", blocked);
      // 1.4.120: quy tắc số điện thoại là kết luận CHẮC CHẮN (không cần 5 lần gọi API) → phải mang dấu xác nhận
      // để bước xử lý sau chấp nhận Buộc hủy, thay vì coi là "chưa chắc chắn" rồi mở khóa/bỏ qua đơn.
      return { status: "INVALID", confirmedInvalid: true, confirmedInvalidEvidence: "5_CONSECUTIVE_EXPLICIT_INVALID", raw: blocked, reason: blocked.message };
    }

    const startedAt = Date.now();
    const budgetMs = adaptiveBankCheckBudgetMs();
    let attempt = 0;
    let lastResult = null;
    let consecutiveInvalid = 0;
    const INVALID_CONFIRMATIONS_REQUIRED = 5;

    log(no, `BANK CHECK AUTO-RECHECK: ngân sách động ${Math.round(budgetMs / 1000)}s, timeout/request động ~${Math.round(adaptiveBankRequestTimeoutMs() / 1000)}s`);

    while (Date.now() - startedAt < budgetMs) {
      attempt++;
      healthTouch(`Bank Check lần ${attempt}`);
      const remaining = budgetMs - (Date.now() - startedAt);
      const requestTimeout = Math.max(3000, Math.min(adaptiveBankRequestTimeoutMs(), remaining));

      try {
        lastResult = await sendBankCheck(data, no, { requestTimeoutMs: requestTimeout });
      } catch (e) {
        lastResult = { status: "ERROR", message: e?.message || String(e) };
      }

      const status = bankResultStatus(lastResult);
      log(no, `BANK CHECK LẦN ${attempt}:`, status || "UNKNOWN", lastResult);

      if (status === "VALID") {
        showBankPopup(no, data, "VALID", lastResult);
        return { status: "VALID", raw: lastResult, reason: "" };
      }

      if (status === "INVALID") {
        consecutiveInvalid++;

        // Với ngân hàng bình thường, không được trả đơn chỉ vì 1-2 response INVALID.
        // Phải xác nhận INVALID nhiều lần liên tiếp (5 lần). Nếu bất kỳ lần nào VALID
        // thì xử lý ngay; nếu kết quả không ổn định hoặc hết ngân sách thì UNKNOWN → UNLOCK/SKIP.
        if (consecutiveInvalid >= INVALID_CONFIRMATIONS_REQUIRED) {
          showBankPopup(no, data, "INVALID", lastResult);
          return {
            status: "INVALID",
            confirmedInvalid: true,
            confirmedInvalidEvidence: "5_CONSECUTIVE_EXPLICIT_INVALID",
            raw: lastResult,
            reason: buildBankInvalidReason(data, lastResult)
          };
        }

        const elapsed = Date.now() - startedAt;
        const left = budgetMs - elapsed;
        if (left <= 0) break;

        const waitMs = Math.min(adaptiveBankRetryDelayMs(attempt), Math.max(150, left));
        log(no, `BANK CHECK INVALID lần ${consecutiveInvalid}/${INVALID_CONFIRMATIONS_REQUIRED} → chưa trả đơn, giữ khóa và tiếp tục kiểm tra xác nhận sau ${waitMs}ms`);
        showBankPopup(no, data, "ERROR", {
          ...(lastResult || {}),
          message: `Bank Check trả về SAI lần ${consecutiveInvalid}. Tool chưa trả đơn và đang kiểm tra xác nhận lại...`
        });
        await sleep(waitMs);
        continue;
      }

      // UNKNOWN/ERROR làm mất chuỗi INVALID liên tiếp: chưa đủ bằng chứng để trả đơn.
      consecutiveInvalid = 0;

      const elapsed = Date.now() - startedAt;
      const left = budgetMs - elapsed;
      if (left <= 0) break;

      const waitMs = Math.min(adaptiveBankRetryDelayMs(attempt), Math.max(150, left));
      log(no, `BANK CHECK chưa có kết quả chắc chắn → giữ đơn, chờ AUTO SYNC ${waitMs}ms rồi kiểm tra lại (${Math.ceil(left / 1000)}s còn lại)`);
      showBankPopup(no, data, "ERROR", {
        ...(lastResult || {}),
        message: `Bank Check chưa có kết quả chắc chắn. Tool đang kiểm tra lại tự động (lần ${attempt + 1})...`
      });
      await sleep(waitMs);
    }

    // Không đủ bằng chứng VALID/INVALID sau AUTO SYNC: chỉ ĐÓNG + MỞ KHÓA + SKIP; tuyệt đối không Buộc hủy.
    // Caller sẽ đóng giao diện, MỞ KHÓA chính đơn này và SKIP để tránh kẹt đơn.
    const totalMs = Date.now() - startedAt;
    const finalResult = lastResult || { status: "ERROR", message: "Bank Checker không trả kết quả." };
    log(no, `BANK CHECK KẾT THÚC SAU AUTO RECHECK: không đủ kết quả chắc chắn sau ${Math.round(totalMs / 1000)}s`, finalResult);
    showBankPopup(no, data, "ERROR", {
      ...finalResult,
      message: `Bank Check không có kết quả chắc chắn sau ${Math.round(totalMs / 1000)} giây. Tool sẽ mở khóa và bỏ qua đơn.`
    });
    return {
      status: "ERROR",
      raw: finalResult,
      reason: finalResult?.message || "BANK_CHECK_NO_CONFIDENT_RESULT_AFTER_RECHECK"
    };
  }

  function providerItems() {
    // Element UI có thể teleport dropdown ra <body> và trong một số trạng thái
    // offsetParent vẫn là null dù option đang hiển thị. Vì vậy không dùng
    // offsetParent làm điều kiện duy nhất để nhận diện option.
    const visible = el => {
      if (!el) return false;
      const cs = getComputedStyle(el);
      if (cs.display === "none" || cs.visibility === "hidden" || cs.opacity === "0") return false;
      const r = el.getBoundingClientRect();
      return r.width > 0 && r.height > 0;
    };

    const nodes = [
      ...document.querySelectorAll("li.el-select-dropdown__item"),
      ...document.querySelectorAll(".el-select-dropdown .el-select-dropdown__item"),
      ...document.querySelectorAll('[role="option"]')
    ];

    const raw = nodes
      .filter((li, i, arr) => arr.indexOf(li) === i)
      .filter(visible)
      .map(li => {
        const sp = li.querySelector("span[title]") || li.querySelector(".option-custom") || li;
        const title = sp.getAttribute?.("title") || "";
        const text = norm(sp.innerText || li.innerText || li.textContent);
        const name = norm(title || [...sp.childNodes]
          .filter(n => n.nodeType === Node.TEXT_NODE)
          .map(n => norm(n.textContent)).join(""))
          .replace(/\s+\(Số dư:.*$/i, "").trim();
        const fallbackName = name || norm(text).replace(/\s+\(Số dư:.*$/i, "").trim();
        const m = text.match(/Số dư:\s*([0-9,.]+)/i);
        const balance = m ? parseNum(m[1]) : null;
        let logo = "";
        try { const im = li.querySelector("img"); const u = im && (im.currentSrc || im.src || ""); if (/^(https?:|data:image\/)/i.test(u) && u.length < 600) logo = u; } catch (_) {}
        return { li, name: fallbackName, balance, rawText: text, logo };
      }).filter(x => x.name);

    const seen = new Set();
    return raw.filter(x => {
      const key = lower(x.name);
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }

  // Ghi lại số dư từng nhà thứ 3 mỗi khi tool mở ô chọn nhà (chỉ đọc, không đổi luồng chọn nhà).
  function saveProviderBalances(items, currency) {
    const KEY = "AD88_XNK_PROVIDER_BALANCES";
    let store = {};
    try { store = JSON.parse(localStorage.getItem(KEY) || "{}") || {}; } catch { store = {}; }
    const now = Date.now();
    let n = 0;
    for (const it of items || []) {
      if (!it || !it.name || it.balance == null) continue;
      const k = String(it.name).toLowerCase();
      const old = store[k];
      let cur = currency === "USDT" ? "USDT" : "VND";
      try {
        const def = typeof AD88_providerDefinition === "function" ? AD88_providerDefinition(it.name) : null;
        if (def && def.currency) cur = def.currency;
        else if (/\(USDT\)|usdt/i.test(it.name)) cur = "USDT";
      } catch (_) {}
      const rec = { name: it.name, balance: it.balance, currency: cur, ts: now };
      if (it.logo || (old && old.logo)) rec.logo = it.logo || old.logo;
      if (it.off) rec.off = true; // 1.4.170: nhà đang TẮT trên BO (bật lại thì lần quét sau tự bỏ cờ)
      if (old && typeof old.balance === "number") {
        if (old.balance !== it.balance) { rec.delta = it.balance - old.balance; rec.changedAt = now; }
        else { rec.delta = old.delta || 0; rec.changedAt = old.changedAt || 0; }
      }
      store[k] = rec; n++;
    }
    if (!n) return;
    localStorage.setItem(KEY, JSON.stringify(store));
    window.dispatchEvent(new CustomEvent("AD88_PROVIDER_BALANCES_CHANGED"));
  }

  // ===== 1.4.169: TỰ CẬP NHẬT SỐ DƯ NHÀ THỨ 3 (không cần mở trang "Thanh toán rút tiền của bên thứ ba") =====
  // CHỈ ĐỌC: gọi lại đúng yêu cầu mà trang BO dùng để liệt kê nhà thứ 3 (listV2), tối đa 1 lần / 60 giây,
  // rồi ghi số dư vào cùng nơi lưu mà bảng "Số dư nhà thứ 3" đang đọc. Không bấm nút nào, không đổi luồng xử lý đơn.
  const BALFEED_URL = "/api/go-gateway-internal/admin/finance/merchAgentSetting/listV2";
  const BALFEED_AT_KEY = "AD88_XNK_BALFEED_AT";
  const BALFEED_MIN_GAP_MS = 60 * 1000;
  let balFeedBusy = false;
  let balFeedFails = 0;
  let balFeedLogged = false;
  let balFeedLastOkAt = 0;
  // 1.4.171: khi tự cập nhật số dư đang chạy tốt (thành công trong 5 phút gần nhất), Tool KHÔNG đọc/ghi số dư ở bước đẩy đơn nữa
  // (đỡ nặng). Tắt công tắc hoặc BO lỗi >5 phút → tự dùng lại cách đọc theo từng đơn như cũ. Việc chọn nhà thứ 3 KHÔNG đổi.
  // 1.4.172: công tắc "Quét số dư khi đẩy đơn" (mặc định BẬT). Chỉ quét theo đơn khi công tắc BẬT và tự cập nhật không khỏe.
  function balanceScanAllowed() {
    return toolSetting("balanceScan", false) && !toolSetting("balanceRefresh", true); // 1.4.173: công tắc "cũ" chỉ chạy khi công tắc "mới" tắt
  }
  function balanceFeedHealthy() {
    return toolSetting("balanceFeed", true) && !toolSetting("lite", false) && (Date.now() - balFeedLastOkAt) < 5 * 60 * 1000;
  }

  // Trả về null nếu chưa đủ thông tin (vd. chưa đăng nhập) → bỏ qua lượt, không gọi bậy.
  function balanceFeedHeaders() {
    let device = "";
    try { device = String(localStorage.getItem("TOKENID") || "").trim(); } catch (_) {}
    if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(device)) return null;
    const m = String(document.cookie || "").match(/(?:^|;\s*)ws_(\d+)=/);
    if (!m) return null;
    const site = m[1];
    const ver = (String(navigator.userAgent || "").match(/Chrome\/(\d+\.\d+\.\d+\.\d+)/) || [])[1] || "153.0.0.0";
    let rid = "";
    try { rid = crypto.randomUUID(); } catch (_) { rid = String(Date.now()); }
    return {
      "Content-Type": "application/json",
      "Accept": "application/json, text/plain, */*",
      "sitecode": site, "childsitecode": site, "companycode": site,
      "loginbacktype": "3", "device": device, "permtag": "finance_merch_withdraw",
      "language": "vi", "appsystem": "Windows10", "browsertype": "Chrome", "operatingsystem": "Windows",
      "devicebrand": "unknown", "devicemodel": ver, "physicaldevicemodel": "unknown",
      "time-zone": "UTC +7:00", "x-request-id": rid
    };
  }

  // Nhận cả nhà BẬT lẫn TẮT (nhà tắt gắn cờ off); nhà không có số dư dạng số thì bỏ qua (không ghi đè số cũ).
  function parseBalanceFeed(json) {
    const recs = json && json.code === 0 && json.data && Array.isArray(json.data.records) ? json.data.records : null;
    if (!recs) return null;
    const out = [];
    for (const r of recs) {
      if (!r) continue;
      const name = String(r.merchName || "").trim();
      const bal = Number(r.balance);
      if (!name || r.balance == null || r.balance === "" || !Number.isFinite(bal)) continue;
      out.push({ name, id: r.id, balance: bal, off: Number(r.status) !== 1, currency: String(r.payCurrency || "").toUpperCase() === "USDT" ? "USDT" : "VND" });
    }
    return out;
  }

  // ===== 1.4.172: TỰ LÀM MỚI SỐ DƯ THẬT TỪNG NHÀ (giống bấm chữ "Làm mới" nhưng gọi thẳng yêu cầu của BO) =====
  // Mỗi chu kỳ ≥70 giây: lần lượt từng nhà ĐANG BẬT, cách nhau ~2,5 giây. BO trả số dư thật ngay lúc đó.
  // BO báo giới hạn tần suất → bỏ qua nhà đó; lỗi/hết phiên → dừng chu kỳ và giãn ra. Chỉ đọc số dư.
  const BALREFRESH_URL = "/api/finance/thirdWithdraw/refreshBalance";
  const BALREFRESH_AT_KEY = "AD88_XNK_BALREFRESH_AT";
  const BALREFRESH_MIN_GAP_MS = 70 * 1000;
  const BALREFRESH_STEP_MS = 2500;
  let balRefreshBusy = false;
  let balRefreshFails = 0;
  let balRefreshIds = [];
  let balRefreshLogged = false;
  let balRefreshOffLogged = false;
  // 1.4.177: tài khoản BO không có quyền "Làm mới số dư" (BO trả code 119990011) → dùng số dư theo danh sách BO, thử lại sau 30 phút.
  let balRefreshNoPermAt = 0;
  const BALREFRESH_NOPERM_RETRY_MS = 30 * 60 * 1000;
  let balRefreshNoPermLogged = false;
  function balRefreshNoPerm() { return balRefreshNoPermAt && (Date.now() - balRefreshNoPermAt) < BALREFRESH_NOPERM_RETRY_MS; }
  function balRefreshIsNoPerm(j) { return !!j && (Number(j.code) === 119990011 || /quyền|permission/i.test(String(j.msg || ""))); }
  const balRefreshedAt = new Map();

  async function balanceRefreshTick() {
    if (balRefreshBusy) return;
    if (!toolSetting("balanceRefresh", true) || toolSetting("lite", false)) return;
    if (!balRefreshIds.length) return;
    if (balRefreshNoPerm()) return;
    balRefreshBusy = true;
    const got = { VND: [], USDT: [] };
    let hardFail = false, okCount = 0;
    try {
      const gap = BALREFRESH_MIN_GAP_MS * (balRefreshFails >= 3 ? 5 : 1);
      let last = 0;
      try { last = Number(localStorage.getItem(BALREFRESH_AT_KEY)) || 0; } catch (_) {}
      if (Date.now() - last < gap) return;
      try { localStorage.setItem(BALREFRESH_AT_KEY, String(Date.now())); } catch (_) {}
      let limited = 0;
      for (const p of balRefreshIds.slice()) {
        if (!toolSetting("balanceRefresh", true)) break;
        const headers = balanceFeedHeaders();
        if (!headers) { hardFail = true; break; }
        let j = null;
        try {
          const res = await fetch(BALREFRESH_URL + "?merchId=" + encodeURIComponent(p.id), { method: "POST", credentials: "include", headers });
          j = await res.json();
        } catch (_) { hardFail = true; break; }
        if (j && j.code === 0 && typeof j.data === "number" && Number.isFinite(j.data)) {
          got[p.currency === "USDT" ? "USDT" : "VND"].push({ name: p.name, balance: j.data, off: !!p.off });
          balRefreshedAt.set(String(p.name).toLowerCase(), Date.now());
          okCount++; limited = 0;
        } else if (balRefreshIsNoPerm(j)) {
          balRefreshNoPermAt = Date.now();
          if (!balRefreshNoPermLogged) { balRefreshNoPermLogged = true; try { log("LÀM MỚI SỐ DƯ: tài khoản BO này chưa có quyền \"Làm mới số dư\" (code " + j.code + ") → dùng số dư theo danh sách BO, thử lại sau 30 phút. Có thể đăng nhập lại hoặc xin cấp quyền."); } catch (_) {} }
          for (const q of balRefreshIds) if (typeof q.bal === "number") got[q.currency === "USDT" ? "USDT" : "VND"].push({ name: q.name, balance: q.bal, off: !!q.off });
          break;
        } else if (p.off && typeof p.bal === "number") {
          // 1.4.174: BO không cho "Làm mới" nhà đang TẮT → vẫn hiển thị số dư theo danh sách BO, không coi là lỗi chu kỳ.
          got[p.currency === "USDT" ? "USDT" : "VND"].push({ name: p.name, balance: p.bal, off: true });
          if (!balRefreshOffLogged) { balRefreshOffLogged = true; try { log("LÀM MỚI SỐ DƯ: nhà tắt " + p.name + " BO không cho làm mới (code " + (j && j.code) + ": " + String((j && j.msg) || "").slice(0, 60) + ") → dùng số dư theo danh sách BO"); } catch (_) {} }
        } else if (j && /refresh|frequen|minute|too many/i.test(String(j.msg || ""))) {
          if (++limited >= 3) { hardFail = true; break; }
        } else { hardFail = true; break; }
        await sleep(BALREFRESH_STEP_MS);
      }
    } catch (_) {
      hardFail = true;
    } finally {
      try {
        for (const cur of ["VND", "USDT"]) if (got[cur].length) saveProviderBalances(got[cur], cur);
      } catch (_) {}
      if (hardFail) { balRefreshFails++; if (balRefreshFails === 3) { try { log("LÀM MỚI SỐ DƯ: BO không trả số/giới hạn tần suất → giãn lượt, bảng vẫn cập nhật theo danh sách"); } catch (_) {} } }
      else if (okCount) balRefreshFails = 0;
      if (okCount && !balRefreshLogged) { balRefreshLogged = true; try { log("LÀM MỚI SỐ DƯ: đã làm mới " + okCount + " nhà (mỗi ≥70 giây, chỉ đọc)"); } catch (_) {} }
      balRefreshBusy = false;
    }
  }

  async function balanceFeedTick() {
    if (balFeedBusy) return;
    if (!toolSetting("balanceRefresh", true) || toolSetting("lite", false)) return;
    balFeedBusy = true;
    try {
      const gap = BALFEED_MIN_GAP_MS * (balFeedFails >= 3 ? 5 : 1);
      let last = 0;
      try { last = Number(localStorage.getItem(BALFEED_AT_KEY)) || 0; } catch (_) {}
      if (Date.now() - last < gap) return;
      const headers = balanceFeedHeaders();
      if (!headers) return;
      try { localStorage.setItem(BALFEED_AT_KEY, String(Date.now())); } catch (_) {}
      const res = await fetch(BALFEED_URL, { method: "POST", credentials: "include", headers, body: JSON.stringify({ current: 1, size: 100, merchType: 2 }) });
      const json = await res.json();
      const items = parseBalanceFeed(json);
      if (!items) { balFeedFails++; if (balFeedFails === 3) log("SỐ DƯ TỰ ĐỘNG: BO không trả danh sách (code " + (json && json.code) + ") → giãn lượt gọi, vẫn đọc số dư theo từng đơn như cũ"); return; }
      balFeedFails = 0;
      balFeedLastOkAt = Date.now();
      // 1.4.172: nhớ mã nhà đang bật để "làm mới số dư thật" từng nhà.
      balRefreshIds = items.filter(x => x.id != null && x.id !== "").map(x => ({ id: x.id, name: x.name, currency: x.currency, off: !!x.off, bal: x.balance })).sort((a, b) => (a.off ? 1 : 0) - (b.off ? 1 : 0)); // 1.4.173/174: nhà TẮT vẫn được đọc (xếp sau nhà bật); bal = số trong danh sách, dùng khi BO không cho làm mới nhà tắt
      if (balRefreshNoPerm()) {
        // 1.4.177: không có quyền Làm mới → hiển thị số dư theo danh sách BO.
        for (const cur of ["VND", "USDT"]) { const part = items.filter(x => x.currency === cur); if (part.length) saveProviderBalances(part, cur); }
      }
      // 1.4.173: danh sách chỉ dùng để lấy tên/mã/trạng thái nhà; SỐ DƯ chỉ lấy bằng "Làm mới" từng nhà (không dùng số lưu sẵn kiểu F5).
      if (!balFeedLogged) { balFeedLogged = true; log("SỐ DƯ: đã lấy danh sách " + items.length + " nhà từ BO để làm mới số dư (mỗi ≥60 giây, chỉ đọc)"); }
    } catch (_) {
      balFeedFails++;
    } finally {
      balFeedBusy = false;
    }
  }

  // Tự nhận dropdown nhà thứ 3 bất cứ khi nào nó xuất hiện (tool tự mở hoặc nhân viên bấm mở):
  // đọc tên + số dư trực tiếp từ DOM, không có danh sách nhà viết cứng → BO thêm nhà mới là bảng tự có.
  try {
    let balTimer = null;
    new MutationObserver(muts => {
      if (!balanceScanAllowed()) return; // 1.4.171/172: đã có tự cập nhật số dư hoặc đã tắt quét theo đơn → bỏ qua việc dò ô chọn nhà
      let hit = false;
      for (const m of muts) {
        if (m.type === "characterData") {
          const el = m.target.parentElement;
          if (el && el.closest && el.closest(".el-select-dropdown") && /Số dư/i.test(el.closest(".el-select-dropdown__item")?.textContent || "")) { hit = true; break; }
          continue;
        }
        for (const n of m.addedNodes) {
          // Chỉ xét node thuộc dropdown (rẻ, không quét nội dung các bảng lớn của BO).
          if (n.nodeType === 1 && (n.matches?.(".el-select-dropdown, .el-select-dropdown__item, .el-popper") || n.querySelector?.(".el-select-dropdown__item")) && /Số dư:/i.test(n.textContent || "")) { hit = true; break; }
          if (n.nodeType === 3 && /Số dư/i.test(n.textContent || "") && n.parentElement?.closest?.(".el-select-dropdown")) { hit = true; break; }
        }
        if (hit) break;
      }
      if (!hit) return;
      clearTimeout(balTimer);
      balTimer = setTimeout(() => {
        try {
          const items = providerItems();
          if (items.some(x => x.balance != null)) saveProviderBalances(items, /Loại tiền\s*:\s*USDT/i.test(document.body.innerText.slice(0, 4000)) ? "USDT" : "VND");
        } catch (_) {}
      }, 400);
    }).observe(document.documentElement, { childList: true, subtree: true, characterData: true });
  } catch (_) {}

  async function waitForProviderItems(timeoutMs = 3500) {
    const end = Date.now() + timeoutMs;
    let items = providerItems();
    while (!items.length && Date.now() < end) {
      await sleep(120);
      items = providerItems();
    }
    return items;
  }

  function providerConfig(name, amount, currency="VND") {
    const actual = lower(name);
    // Canonical name/alias lấy từ Provider Registry — không hard-code từng nhà thứ 3 trong Core.
    const key = typeof AD88_providerCanonical === "function" ? AD88_providerCanonical(name) : name;
    let uiCfg = null;
    try {
      const saved = JSON.parse(localStorage.getItem("AD88_XNK_PROVIDER_CONFIG") || "{}");
      uiCfg = saved[key] || null;
      if (!uiCfg) {
        for (const v of Object.values(saved)) {
          if (v && v.name && (lower(v.name) === actual ||
              (typeof AD88_providerCanonical === "function" && AD88_providerCanonical(v.name) === key))) { uiCfg = v; break; }
        }
      }
    } catch {}

    const wantedCurrency = currency === "USDT" ? "USDT" : "VND";
    const baseByKey = (XNK_CONFIG.providerFallback || []).find(p => lower(p.name) === lower(key));
    const uiCurrency = baseByKey?.currency || (uiCfg?.currency === "USDT" ? "USDT" : "VND");
    if (uiCfg && uiCurrency !== wantedCurrency) return null;
    // Provider đã biết nhưng thuộc currency khác thì tuyệt đối không coi là provider mới.
    if (baseByKey && (baseByKey.currency || "VND") !== wantedCurrency) return null;
    const base = (XNK_CONFIG.providerFallback || []).find(p => lower(p.name) === actual && (p.currency || "VND") === wantedCurrency) || (baseByKey && (baseByKey.currency || "VND") === wantedCurrency ? baseByKey : null);

    // Provider đang xuất hiện trực tiếp trong BO là nguồn nhận diện thực tế.
    // Với VND, nếu provider chưa có trong Registry/config thì vẫn cho phép
    // chọn và đẩy, dùng MIN/MAX = không giới hạn cho đến khi người vận hành
    // cấu hình riêng. USDT giữ nguyên cơ chế an toàn hiện tại: chỉ dùng các
    // provider USDT đã được Registry nhận diện.
    if (!uiCfg && !base && wantedCurrency !== "VND") return null;

    const min = uiCfg && uiCfg.min !== null && uiCfg.min !== undefined && uiCfg.min !== '' ? Number(uiCfg.min) : (base && base.min !== null && base.min !== undefined ? base.min : (wantedCurrency === "USDT" ? 5 : 50000));
    const max = uiCfg && uiCfg.max !== null && uiCfg.max !== undefined && uiCfg.max !== '' ? Number(uiCfg.max) : (base ? base.max : null);
    // 1.4.129: nhà không có MAX thì mặc định VND ≤ 15.000.000, USDT ≤ 1.000 (người vận hành tự đặt số khác trong Cài đặt).
    const effMax = (max !== null && Number.isFinite(max)) ? max : (wantedCurrency === "USDT" ? 1000 : 15000000);
    if ((min !== null && Number.isFinite(min) && amount < min) || amount > effMax) return null;
    return {name: uiCfg?.name || base?.name || (typeof AD88_providerDefinition === "function" ? (AD88_providerDefinition(name)?.name || name) : name), currency:wantedCurrency, min, max, dynamic:!uiCfg && !base};
  }

  function expectedUsdtFromRow(row) {
    if (!row) return null;

    // USDT phải lấy trực tiếp từ cột "Dự kiến đến nơi (Nạp)" ngoài danh sách đơn.
    // Tuyệt đối không lấy td.money vì đó là "Số tiền rút" theo VND1000:1.
    const table = row.closest(".el-table");
    const headers = table
      ? [...table.querySelectorAll(".el-table__header-wrapper th, thead th")]
      : [];

    let targetIndex = -1;
    for (let i = 0; i < headers.length; i++) {
      const text = norm(headers[i]?.innerText || headers[i]?.textContent || "")
        .replace(/\s+/g, " ")
        .trim();
      if (/Dự\s*kiến\s*đến\s*nơi/i.test(text) && /Nạp/i.test(text)) {
        targetIndex = i;
        break;
      }
    }

    const cells = [...row.querySelectorAll(":scope > td")];
    const cell = targetIndex >= 0 ? cells[targetIndex] : null;
    if (!cell) return null;

    // Trong ô này trang hiện có thể hiển thị nhiều giá trị (17.25 / 0.00 / 17.25...).
    // Giá trị đầu tiên trong các span.label-area là "Dự kiến đến nơi".
    const candidates = [...cell.querySelectorAll("span.label-area, b.label-area, .label-area")]
      .map(el => norm(el.innerText || el.textContent || ""))
      .filter(Boolean);

    for (const text of candidates) {
      if (/USDT/i.test(text)) {
        const n = parseNum(text.replace(/USDT/ig, ""));
        if (n != null) return n;
      }
    }

    // Trường hợp số và chữ USDT nằm ở node khác nhau: cột này trên trang
    // không nhất thiết tự chứa chữ "USDT"; loại tiền nằm ở cột bên cạnh.
    // Vì hàm này chỉ được gọi cho currency === "USDT", số label-area đầu tiên
    // trong đúng cột "Dự kiến đến nơi (Nạp)" là giá trị cần lấy (17.25).
    // Không bao giờ đọc td.money / VND1000 ở đây.
    for (const text of candidates) {
      const n = parseNum(text);
      if (n != null) return n;
    }

    const full = norm(cell.innerText || cell.textContent || "");
    if (!/VND1000/i.test(full)) {
      const m = full.match(/([0-9]+(?:[.,][0-9]+)?)\s*USDT/i);
      if (m) return parseNum(m[1]);
      const first = full.match(/([0-9]+(?:[.,][0-9]+)?)/);
      if (first) return parseNum(first[1]);
    }

    return null;
  }

  function expectedProviderAmount(row, currency="VND") {
    if (currency === "USDT") return expectedUsdtFromRow(row);

    const money = row?.querySelector("td.money");
    if (!money) return null;
    const b = money.querySelector(".copyclip-box button[data-rel], button[data-rel]");
    const raw = b?.getAttribute("data-rel") || money.querySelector("b.label-area")?.innerText || money.innerText;
    const base = parseNum(raw);
    if (base == null) return null;
    const mc = norm(row.querySelector("td.memberCurrency")?.innerText);
    if (/VND1000\s*:\s*1/i.test(mc)) return base * 1000;
    return base;
  }

  function readActualUsdtFromProcessingPanel() {
    // DOM của trang có thể render nhãn theo nhiều dạng:
    // "Nhận thực tế: 17.25 USDT", "Nhận thực tế : 17.25 USDT",
    // hoặc tách nhãn / dấu : / số / USDT thành nhiều span.
    // Tuyệt đối không đọc td.money vì đó là số tiền VND.
    const roots = [];
    const cp = currentPanel();
    if (cp) roots.push(cp);
    // Fallback: popup có thể là một dialog lồng/khác mà currentPanel() không bắt đúng.
    roots.push(...visibleDialogs().filter(x => !roots.includes(x)));
    roots.push(document);

    const clean = v => String(v || "")
      .replace(/\u00a0/g, " ")
      .replace(/[\r\n\t]+/g, " ")
      .replace(/\s+/g, " ")
      .trim();
    const key = v => clean(v)
      .replace(/[\s:：]+/g, "")
      .toLowerCase();
    const numeric = v => {
      const raw = clean(v).replace(/USDT/ig, "");
      const n = parseNum(raw);
      return Number.isFinite(n) ? n : null;
    };
    const validUsdtText = v => /USDT/i.test(clean(v)) && !/VND1000/i.test(clean(v));

    const LABELS = [
      { key: key("Nhận thực tế"), re: /Nhận\s*thực\s*tế\s*[:：]?\s*([0-9][0-9.,]*)\s*USDT/i },
      { key: key("Dự kiến đến nơi"), re: /Dự\s*kiến\s*đến\s*nơi\s*[:：]?\s*([0-9][0-9.,]*)\s*USDT/i }
    ];

    // 1) Ưu tiên tìm trực tiếp trên text của từng vùng nhỏ.
    // Chạy Nhận thực tế trước, sau đó mới fallback Dự kiến đến nơi.
    for (const wanted of LABELS) {
      for (const root of roots) {
        if (!root) continue;
        const candidates = [...root.querySelectorAll("*")].filter(el => {
          try { return el.offsetParent !== null || el === document.body; } catch (_) { return true; }
        });
        for (const el of candidates) {
          const txt = clean(el.innerText || el.textContent);
          if (!txt || txt.length > 500) continue;
          const m = txt.match(wanted.re);
          if (m) {
            const value = numeric(m[1]);
            if (value != null) return value;
          }
        }
      }
    }

    // 2) DOM tách nhãn, số và "USDT" thành nhiều node.
    // Chuẩn hóa cả dấu ':' và khoảng trắng nên "Nhận thực tế :" vẫn khớp.
    for (const wanted of LABELS) {
      for (const root of roots) {
        if (!root) continue;
        const nodes = [...root.querySelectorAll("span,b,strong,em,div,td,label")];
        for (let i = 0; i < nodes.length; i++) {
          const label = nodes[i];
          if (key(label.innerText || label.textContent) !== wanted.key) continue;

          // Tìm trong cùng dòng/container trước.
          let scope = label.parentElement;
          for (let depth = 0; scope && depth < 7; depth++, scope = scope.parentElement) {
            const direct = clean(scope.innerText || scope.textContent);
            const m = direct.match(wanted.re);
            if (m) {
              const value = numeric(m[1]);
              if (value != null) return value;
            }

            const parts = [...scope.querySelectorAll("span,b,strong,em")]
              .map(x => clean(x.innerText || x.textContent))
              .filter(Boolean);
            const labelIndex = parts.findIndex(x => key(x) === wanted.key);
            if (labelIndex >= 0) {
              for (let j = labelIndex + 1; j < Math.min(parts.length, labelIndex + 12); j++) {
                const part = parts[j];
                if (/^[:：]$/.test(part) || !part) continue;
                if (/^USDT$/i.test(part)) continue;
                if (/VND1000/i.test(part)) continue;
                const value = numeric(part);
                if (value != null) {
                  // Nếu node kế tiếp là số, xác nhận gần đó có USDT.
                  const nearby = parts.slice(labelIndex + 1, Math.min(parts.length, labelIndex + 12)).join(" ");
                  if (validUsdtText(nearby) || /USDT/i.test(direct)) return value;
                }
              }
            }
          }
        }
      }
    }

    return null;
  }

  async function waitForActualUsdtFromProcessingPanel(timeoutMs = 2500) {
    const end = Date.now() + timeoutMs;
    while (Date.now() < end) {
      const value = readActualUsdtFromProcessingPanel();
      if (value != null) return value;
      await new Promise(r => setTimeout(r, 100));
    }
    return null;
  }

  // Trường hợp đã mở giao diện xử lý nhưng không còn nhà thứ 3 nào
  // đủ điều kiện (ví dụ tất cả nhà còn lại đều đang TẮT trong Cài đặt):
  // đây là SKIP có chủ đích, không phải lỗi hệ thống và tuyệt đối không hardStop.
  function isNoProviderAvailableError(error) {
    const msg = String(error?.message || error || "");
    // Khi đã mở đúng ô Nhà thứ 3 nhưng dropdown không có option nào,
    // đây cũng được coi là "không có nhà thứ 3 khả dụng" cho đơn hiện tại.
    // Tuyệt đối không dừng toàn bộ AUTO: đóng giao diện và chuyển sang đơn khác.
    return /Không có nhà thứ 3 còn lại đang hiển thị để chọn/i.test(msg)
      || /Đã mở ô nhà thứ 3 nhưng dropdown không có dữ liệu/i.test(msg)
      || /Dropdown nhà thứ 3 không có cổng USDT khả dụng/i.test(msg);
  }

  function providerAutoEnabled(name) {
    try {
      const st = JSON.parse(localStorage.getItem("AD88_XNK_PROVIDER_TOGGLES") || "{}");
      // Canonical name/alias lấy từ Provider Registry.
      const key = typeof AD88_providerCanonical === "function" ? AD88_providerCanonical(name) : name;
      if (st[key] !== undefined) return st[key] !== false;
      try {
        const cfg = JSON.parse(localStorage.getItem("AD88_XNK_PROVIDER_CONFIG") || "{}");
        const entry = Object.entries(cfg).find(([k,v]) => v && v.name && (lower(v.name) === lower(name) ||
          (typeof AD88_providerCanonical === "function" && AD88_providerCanonical(v.name) === key)));
        if (entry) return st[entry[0]] !== false;
      } catch {}
      return true;
    } catch { return true; }
  }

  function providerPrioritySet() {
    try { return new Set(Object.keys(JSON.parse(localStorage.getItem("AD88_XNK_PROVIDER_PRIORITY") || "{}") || {}).filter(k => JSON.parse(localStorage.getItem("AD88_XNK_PROVIDER_PRIORITY"))[k])); }
    catch { return new Set(); }
  }
  function providerPriorityWeight() {
    const w = Number(localStorage.getItem("AD88_XNK_PRIORITY_WEIGHT"));
    return Number.isFinite(w) && w >= 2 && w <= 10 ? Math.round(w) : 3;
  }

  // (Đã bỏ: Tool KHÔNG tự bấm "Làm mới" số dư nữa — BO giới hạn 1 lần/phút và báo lỗi "Refresh every 1 minutes".)

  async function chooseProvider(no, amount, excludeNames = [], randomize = false, currency = "VND") {
    // Trang XNK có thể render ô chọn nhà thứ 3 ở ngoài dialog/drawer.
    // Vì vậy KHÔNG giới hạn tìm kiếm trong currentPanel().
    let panel = currentPanel();

    const findProviderSelect = () => {
      const roots = [panel, document].filter(Boolean);

      // 1) Ưu tiên input có placeholder chính xác, rồi lấy .el-select bao quanh.
      for (const root of roots) {
        const inputs = [...root.querySelectorAll(
          'input[placeholder="Chọn Thanh toán rút tiền của bên thứ ba"], input[placeholder*="Thanh toán rút tiền của bên thứ ba"]'
        )].filter(e => e.offsetParent !== null);
        for (const input of inputs) {
          const select = input.closest('.el-select');
          if (select) return { select, input };
        }
      }

      // 2) Fallback theo title/class/ô merchId.
      const els = [...document.querySelectorAll(
        '.el-select[title="Thanh toán rút tiền của bên thứ ba"], .el-select, td.merchId .el-select'
      )].filter(e => e.offsetParent !== null);
      for (const el of els) {
        const txt = norm(el.getAttribute('title') || el.innerText || '');
        if (/thanh toán rút tiền của bên thứ ba/i.test(txt)) {
          const input = el.querySelector('input.el-input__inner, input');
          if (input) return { select: el, input };
        }
      }
      return null;
    };

    let found = findProviderSelect();
    if (!found) {
      await scrollToBottomOfProcessing(panel);
      await sleep(300);
      panel = currentPanel();
      found = findProviderSelect();
    }

    if (!found) {
      throw new Error("Không tìm thấy ô Thanh toán rút tiền của bên thứ ba sau khi đã cuộn tới khu vực thanh toán");
    }

    const { select, input } = found;
    scrollElementForAction(input);
    await sleep(350);

    // Element UI select là readonly, không phải disabled. Kích hoạt bằng click/focus.
    if (input.disabled) {
      throw new Error("Ô Thanh toán rút tiền của bên thứ ba đang bị vô hiệu hóa");
    }

    input.focus();
    // Kích hoạt cả input và wrapper .el-select. Một số bản Element UI chỉ
    // mở popper khi event đi qua wrapper, không mở khi chỉ input.click().
    input.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, view: window }));
    input.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true, view: window }));
    input.click();
    await sleep(250);
    try {
      select.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, view: window }));
      select.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true, view: window }));
      select.click();
    } catch (_) {}

    let items = await waitForProviderItems(2200);
    // Fallback lần 2 cho Element UI khi popper vừa được tạo sau click.
    if (!items.length) {
      input.click();
      await sleep(250);
      items = await waitForProviderItems(1800);
    }
    if (!items.length) {
      throw new Error("Đã mở ô nhà thứ 3 nhưng dropdown không có dữ liệu");
    }
    try { if (balanceScanAllowed()) saveProviderBalances(items, currency); } catch (_) {} // 1.4.171/172: chỉ ghi khi bật quét theo đơn và tự cập nhật không chạy

    const excluded = new Set((excludeNames || []).map(x => lower(x)));

    // ===== BANK → PROVIDER RESTRICTIONS =====
    // Chỉ lọc nhà thứ 3 theo ngân hàng đã xác định chắc chắn.
    // KHÔNG thay đổi Bank Check/VALID/INVALID/UNKNOWN.
    // Agribank (VARB/970405) không được BB168Pay.
    // MBV (970414) không được FastPay.
    if (currency === "VND") {
      try {
        const activeRow = findRow(no);
        const bankSnapshot = bankDataFromPanel(currentPanel() || panel, activeRow);
        const bankCode = String(bankSnapshot?.codeBank || resolveBankCode(bankSnapshot?.bankName || "")).toUpperCase();
        if (bankCode === "VARB") {
          excluded.add(lower("BB168Pay"));
          log(no, "→ BANK PROVIDER RULE: Agribank/VARB → loại BB168Pay, bắt buộc chọn nhà khác");
        } else if (bankCode === "MBV") {
          excluded.add(lower("FastPay"));
          log(no, "→ BANK PROVIDER RULE: MBV → loại FastPay, bắt buộc chọn nhà khác");
        }
        if (bankCode === "TCB") {
          log(no, "→ BANK MAP TCB: Techcombank/TCB → TCB, BIN 970407; giữ nguyên Bank Check flow của baseline");
        }
      } catch (e) {
        log(no, "→ Không đọc được bank restriction; giữ nguyên danh sách Provider để không ảnh hưởng Bank Check:", String(e?.message || e));
      }
    }

    // ================= USDT: CHỌN CỔNG USDT THỰC TẾ TRƯỚC =================
    // Không để cấu hình VND cũ/localStorage cũ làm USDT bị loại khỏi danh sách.
    // Khi dropdown đã hiển thị U2PAY/RCPAY/WHPAY thì đó là bằng chứng trực tiếp
    // rằng backend đang cho phép chọn cổng đó. Ưu tiên U2PAY, sau đó RCPAY/WHPAY.
    let usdtDirect = null;
    if (currency === "USDT") {
      const usdtPriority = (typeof AD88_usdtProviders === "function"
        ? AD88_usdtProviders().map(p=>p.name)
        : ["U2PAY","RCPAY","WHPAY"]);
      const usable = items.filter(x =>
        !excluded.has(lower(x.name)) &&
        !/bảo trì|maintenance/i.test(x.li.innerText || "") &&
        providerAutoEnabled(x.name) &&
        // Giới hạn số USDT mỗi đơn theo từng nhà (mặc định tối đa 1.000 USDT, chỉnh trong Cài đặt số tiền bên thứ 3).
        !!providerConfig(x.name, amount, "USDT")
      );

      items.forEach(x => {
        if (!providerAutoEnabled(x.name)) {
          log(no, "→ USDT: nhà thứ 3 đang TẮT trong Tool, tuyệt đối không chọn:", x.name);
        }
      });

      for (const wanted of usdtPriority) {
        const wantedKey = lower(wanted).replace(/\s+/g, "");
        const hit = usable.find(x => {
          if (lower(x.name).replace(/\s+/g, "") === wantedKey) return true;
          // Tên trong BO có thể là bí danh (vd "U2Pay2" ↔ U2PAY): so theo tên chuẩn để giữ đúng thứ tự ưu tiên U2PAY → RCPAY → WHPAY.
          try { const canon = typeof AD88_providerCanonical === "function" ? AD88_providerCanonical(x.name) : ""; return !!canon && lower(canon).replace(/\s+/g, "") === wantedKey; } catch (_) { return false; }
        });
        if (hit) { usdtDirect = hit; break; }
      }

      // Fallback theo alias/canonical registry để provider mới không cần sửa Core.
      if (!usdtDirect) {
        usdtDirect = usable.find(x => {
          const def = typeof AD88_providerDefinition === "function" ? AD88_providerDefinition(x.name) : null;
          return def?.currency === "USDT";
        });
      }

      if (usdtDirect) {
        log(no, "→ USDT: phát hiện cổng nhà thứ 3 trực tiếp trong dropdown:", usdtDirect.name, "→ ưu tiên chọn");
      } else {
        log(no, "→ USDT: dropdown hiện tại KHÔNG có U2PAY/RCPAY/WHPAY; không chọn nhầm cổng VND");
        throw new Error("Dropdown nhà thứ 3 không có cổng USDT khả dụng (U2PAY/RCPAY/WHPAY)");
      }
    }

    // Với VND: provider đã biết dùng MIN/MAX cấu hình; provider mới xuất hiện trong BO được nhận diện động và chỉ bị giới hạn nếu đã có cấu hình MIN/MAX.
    const eligible = currency === "USDT" ? [usdtDirect] : items.filter(x => {
      if (/bảo trì|maintenance/i.test(x.li.innerText || "")) return false;
      if (excluded.has(lower(x.name))) return false;
      if (!providerAutoEnabled(x.name)) { log(no, "→ nhà thứ 3 đang TẮT trong Tool, bỏ qua:", x.name); return false; }
      return !!providerConfig(x.name, amount, currency);
    });
    log(no, currency === "USDT"
      ? "→ USDT: bỏ qua bộ lọc VND/MIN/MAX cũ, dùng đúng cổng USDT đang hiển thị"
      : "→ đã áp dụng MIN/MAX từ cấu hình Tool; không kiểm tra số dư");

    // 1.4.154: nhật ký chẩn đoán (chỉ ghi log, KHÔNG đổi cách chọn nhà): BO đưa ra nhà nào, nhà nào bị loại và vì sao, nhà nào đang Ưu tiên.
    try {
      if (currency !== "USDT") {
        const why = items.map(x => {
          const r = [];
          if (/bảo trì|maintenance/i.test(x.li.innerText || "")) r.push("bảo trì");
          if (excluded.has(lower(x.name))) r.push("đã loại");
          if (!providerAutoEnabled(x.name)) r.push("TẮT");
          if (!providerConfig(x.name, amount, currency)) r.push("ngoài MIN/MAX");
          return x.name + (r.length ? " ✗(" + r.join(", ") + ")" : " ✓");
        });
        log(no, "→ BO ĐƯA RA " + items.length + " nhà:", why.join(" | "));
        const priList = [...providerPrioritySet()];
        const priInBo = priList.filter(k => items.some(x => lower(x.name) === k));
        log(no, "→ Nhà đang bấm Ưu tiên:", priList.length ? priList.join(", ") : "(không có)",
          priList.length && !priInBo.length ? "→ KHÔNG nhà ưu tiên nào có trong danh sách BO của đơn này → xoay vòng các nhà còn lại" : "");
      }
    } catch (_) {}

    if (!eligible.length) {
      throw new Error("Không có nhà thứ 3 còn lại đang hiển thị để chọn");
    }

    let chosen;
    if (currency === "USDT") {
      chosen = usdtDirect;
    } else {
      // ƯU TIÊN (1.4.148): có nhà được bấm "Ưu tiên" và nhà đó phù hợp MIN/MAX/đang bật/chưa bị loại
      // → CHỈ đẩy vào các nhà ưu tiên (1 nhà = đẩy riêng nhà đó; nhiều nhà = chia đều xoay vòng).
      // Nhà ưu tiên không phù hợp đơn này (ngoài MIN/MAX, tắt, bảo trì, đã thử lỗi) → quay về xoay vòng tất cả như cũ.
      const pri = providerPrioritySet();
      const priEligible = eligible.filter(x => pri.has(lower(x.name)));
      const cycle = priEligible.length ? priEligible : eligible;
      if (randomize) {
        const idx = (typeof crypto !== "undefined" && crypto.getRandomValues)
          ? crypto.getRandomValues(new Uint32Array(1))[0] % cycle.length
          : Math.floor(Math.random() * cycle.length);
        chosen = cycle[idx];
      } else {
        chosen = cycle[providerCursor % cycle.length];
        providerCursor++;
      }
      if (cycle !== eligible) log(no, "→ ƯU TIÊN nhà thứ 3: chỉ đẩy", cycle.map(x => x.name).join(" › "), cycle.length > 1 ? "(chia đều)" : "");
    }

    scrollElementForAction(chosen.li);
    const target = chosen.li.querySelector("span[title]") ||
      chosen.li.querySelector(".option-custom") || chosen.li;

    target.click();
    await sleep(300);

    // Chờ Vue/Element UI cập nhật model + input value.
    const end = Date.now() + 3000;
    let selected = "";
    while (Date.now() < end) {
      await sleep(150);
      selected = norm(
        input.value ||
        select.querySelector("input.el-input__inner")?.value ||
        select.innerText
      );
      if (selected.toLowerCase().includes(chosen.name.toLowerCase())) break;
    }

    if (!selected.toLowerCase().includes(chosen.name.toLowerCase())) {
      throw new Error("Đã click nhưng ô nhà thứ 3 chưa nhận giá trị: " + chosen.name);
    }

    const cfg = providerConfig(chosen.name, amount, currency);
    log(no, "→ đã chọn nhà thứ 3:", chosen.name,
      "| tiền:", amount, currency,
      "| khoảng:", cfg ? `${cfg.min ?? "∞"}-${cfg.max ?? "∞"}` : "không cấu hình",
      "| số dư hiển thị:", chosen.balance);

    // Bắt buộc xác nhận rằng dropdown đã thực sự nhận đúng nhà thứ 3
    // trước khi cho phép đi tới nút Xác nhận việc thanh toán.
    const finalInput = select.querySelector('input.el-input__inner') || input;
    const finalSelected = norm(finalInput?.value || input?.value || select.innerText);
    if (!finalSelected || !finalSelected.toLowerCase().includes(chosen.name.toLowerCase())) {
      throw new Error("Nhà thứ 3 chưa được chọn thành công, không được bấm Xác nhận việc thanh toán");
    }
    log(no, "→ xác nhận dropdown đã nhận nhà thứ 3:", finalSelected);

    return chosen.name;
  }

  function textLooksSuccessful(root) {
    const text = lower(root?.innerText || "");
    return /đã thanh toán|thanh toán thành công|đã chuyển|chuyển khoản thành công|hoàn tất/.test(text);
  }

  // ===== TÍN HIỆU THÀNH CÔNG CHÍNH THỨC CỦA BO =====
  function hasPaymentSuccessToast() {
    const nodes = [...document.querySelectorAll(
      ".el-message, .el-message-box, .el-notification, [role=alert], .el-alert, body > div"
    )];
    return nodes.some(el => {
      if (!el) return false;
      const t = norm(el.innerText || el.textContent || "");
      if (!/thao tác thành công|thao tac thanh cong/i.test(t)) return false;
      try {
        const cs = getComputedStyle(el);
        const r = el.getBoundingClientRect();
        return (
          (cs.display !== "none" && cs.visibility !== "hidden" && cs.opacity !== "0" &&
           r.width > 0 && r.height > 0) ||
          cs.position === "fixed"
        );
      } catch (_) {
        return true;
      }
    });
  }

  async function confirmPayment(no) {
    // 1.4.167: nếu bộ canh khóa đã mở khóa đơn này (Tool bị treo >2 phút) thì KHÔNG đẩy tiếp, kết thúc êm như đơn đã trả lại.
    if (watchdogReleased.has(String(no))) {
      log(no, "→ đơn đã được BỘ CANH KHÓA mở khóa → KHÔNG xác nhận thanh toán, bỏ qua đơn này");
      return { status: "QUOTA_HANDLED", watchdog: true };
    }
    const panelBefore = currentPanel();

    // Website dùng đúng button:
    // <button class="el-button el-button--primary el-button--small">
    //   <span>Xác nhận việc thanh toán</span>
    // </button>
    // Ưu tiên tìm BUTTON thật, không click span con.
    const findConfirmPaymentButton = (scope) => {
      const buttons = [...(scope || document).querySelectorAll(
        'button.el-button, button[type="button"], button'
      )].filter(el => {
        if (!el || el.disabled || el.offsetParent === null) return false;
        const txt = norm(el.innerText || el.textContent || "");
        return /^xác nhận việc thanh toán$/i.test(txt);
      });
      return buttons[buttons.length - 1] || null;
    };

    const b = findConfirmPaymentButton(panelBefore) || findConfirmPaymentButton(document);
    if (!b) throw new Error("Không tìm thấy NÚT Xác nhận việc thanh toán đang hiển thị");
    markPushStarted(no); // 1.4.167: từ đây đơn coi như ĐÃ ĐẨY → bộ canh khóa không được mở

    scrollElementForAction(b);
    await sleep(150);

    // Gửi đầy đủ chuỗi sự kiện chuột vào CHÍNH BUTTON để tương thích Element UI/Vue.
    b.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, cancelable: true, view: window }));
    b.dispatchEvent(new MouseEvent("mouseup", { bubbles: true, cancelable: true, view: window }));
    b.click();
    log(no, "→ đã bấm CHÍNH BUTTON: Xác nhận việc thanh toán");

    // QUAN TRỌNG: MessageBox hạn ngạch có thể xuất hiện ngay sau click,
    // trước khi trạng thái thanh toán được cập nhật. Phải kiểm tra song song,
    // không được chờ confirmPayment timeout rồi mới kiểm tra.
    const end = Date.now() + XNK_CONFIG.actionTimeoutMs * 2;

    while (Date.now() < end) {
      await sleep(250);
      if (hasPaymentSuccessToast()) {
        log(no, "→ phát hiện thông báo chính thức: Thao tác thành công → XÁC NHẬN thanh toán thành công");
        return { status: "SUCCESS" };
      }


      // Website có thể trả về MessageBox/toast "Thao tác thành công" và đồng thời
      // làm rỗng danh sách/đóng dialog rất nhanh. Đây là tín hiệu SUCCESS chính thức
      // của thao tác thanh toán; không được coi là timeout và không được hard-stop bot.
      const successMessages = [...document.querySelectorAll(
        ".el-message-box, .el-message, .el-notification, [role=alert], .el-alert"
      )].filter(el => {
        if (!el || el.offsetParent === null) return false;
        const t = norm(el.innerText || el.textContent || "");
        return /thao tác thành công|thao tac thanh cong/i.test(t);
      });
      if (successMessages.length) {
        log(no, "→ phát hiện thông báo chính thức: Thao tác thành công → XÁC NHẬN thanh toán thành công");
        return { status: "SUCCESS" };
      }

      // Ưu tiên bắt lỗi hạn ngạch trước mọi kiểm tra thành công/timeout.
      if (visibleQuotaErrorBox()) {
        log(no, "→ confirmPayment: phát hiện ngay MessageBox hạn ngạch");
        const handled = await handleQuotaErrorIfPresent(no);
        if (!handled) throw new Error("Đã phát hiện hộp hạn ngạch nhưng xử lý không thành công");

        const closed = await closeProcessingPanel(no);
        if (!closed) {
          log(no, "→ đã xác nhận lỗi hạn ngạch nhưng giao diện chưa đóng sau nhiều lần bấm X; tiếp tục AUTO để không khóa toàn bộ Tool");
        }

        done.add(no);
        log(no, "→ QUOTA ERROR: Xác nhận cảnh báo + đóng/thoát giao diện → chuyển đơn tiếp theo");
        return { status: "QUOTA_HANDLED" };
      }

      const panel = visibleDialogs().length ? currentPanel() : null;
      const row = findRow(no);

      if (!panel) {
        if (row && textLooksSuccessful(row)) {
          log(no, "→ giao diện đã đóng + dòng có trạng thái hoàn tất");
          return { status: "SUCCESS" };
        }
      }

      if (panel && textLooksSuccessful(panel)) {
        log(no, "→ phát hiện trạng thái thanh toán thành công rõ ràng");
        return { status: "SUCCESS" };
      }

      const stillButton = findTextButton(
        panel || document,
        "Xác nhận việc thanh toán"
      );
      if (!stillButton && row && textLooksSuccessful(row)) {
        log(no, "→ nút xác nhận biến mất + dòng hoàn tất");
        return { status: "SUCCESS" };
      }
    }

    if (hasPaymentSuccessToast()) {
      log(no, "→ xác nhận lần cuối: Thao tác thành công → SUCCESS");
      return { status: "SUCCESS" };
    }

    // Kiểm tra thêm lần cuối trước khi báo UNKNOWN.
    const finalSuccessMessages = [...document.querySelectorAll(
      ".el-message-box, .el-message, .el-notification, [role=alert], .el-alert"
    )].filter(el => {
      if (!el || el.offsetParent === null) return false;
      const t = norm(el.innerText || el.textContent || "");
      return /thao tác thành công|thao tac thanh cong/i.test(t);
    });
    if (finalSuccessMessages.length) {
      log(no, "→ xác nhận lần cuối: thông báo Thao tác thành công → SUCCESS");
      return { status: "SUCCESS" };
    }

    if (visibleQuotaErrorBox()) {
      const handled = await handleQuotaErrorIfPresent(no);
      if (handled) {
        const closed = await closeProcessingPanel(no);
        if (!closed) log(no, "→ QUOTA ERROR cuối vòng: đã xác nhận; giao diện chưa đóng hoàn toàn nhưng không hardStop");
        done.add(no);
        log(no, "→ QUOTA ERROR cuối vòng: Xác nhận + đóng/thoát giao diện → chuyển đơn tiếp theo");
        return { status: "QUOTA_HANDLED" };
      }
    }

    throw new Error(
      "Đã bấm Xác nhận việc thanh toán nhưng chưa xác nhận được đơn hoàn tất"
    );
  }

  async function fillFrontNoteAndCancel(panel, no, isUsdt = false) {
    let root = panel || currentPanel();
    const note = isUsdt === "ERC20" ? XNK_CONFIG.invalidUsdtErc20Note : isUsdt ? XNK_CONFIG.invalidUsdtNote : XNK_CONFIG.invalidBankNote;

    const visible = (el) => {
      if (!el || el.disabled) return false;
      try {
        const cs = getComputedStyle(el);
        const r = el.getBoundingClientRect();
        return el.offsetParent !== null && cs.display !== "none" && cs.visibility !== "hidden" && r.width > 0 && r.height > 0;
      } catch (_) { return false; }
    };

    const setTextareaVerified = async (ta, text, label) => {
      if (!ta) throw new Error(`Không tìm thấy ô ${label}`);
      scrollElementForAction(ta);
      await sleep(180);

      for (let attempt = 1; attempt <= 3; attempt++) {
        ta.focus();
        try {
          const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, "value")?.set;
          if (setter) setter.call(ta, text);
          else ta.value = text;
        } catch (_) {
          ta.value = text;
        }

        ta.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: text }));
        ta.dispatchEvent(new Event("change", { bubbles: true }));
        ta.dispatchEvent(new Event("blur", { bubbles: true }));
        await sleep(250);

        const actual = String(ta.value || "").trim();
        if (actual === String(text).trim()) {
          log(no, `→ ${label} đã nhận đủ nội dung (lần ${attempt})`);
          return true;
        }
        log(no, `→ ${label} chưa nhận đủ nội dung (lần ${attempt}/3) → retry`);
        await sleep(180);
      }

      throw new Error(`${label} không nhận đủ nội dung sau 3 lần thử`);
    };

    // NOTE 1: Ghi chú front-end của đơn.
    let ta = [...root.querySelectorAll("textarea")].find(e =>
      /Nhập nội dung Ghi chú front-end/i.test(e.getAttribute("placeholder") || "")
    );

    if (!ta) {
      await scrollToBottomOfProcessing(root);
      root = currentPanel();
      ta = [...root.querySelectorAll("textarea")].find(e =>
        /Nhập nội dung Ghi chú front-end/i.test(e.getAttribute("placeholder") || "")
      ) || [...document.querySelectorAll('textarea[placeholder*="Ghi chú front-end"]')]
        .find(visible);
    }

    await setTextareaVerified(ta, note, "Ghi chú Front-end");
    log(no, "→ NOTE 1 hoàn tất: Ghi chú Front-end");

    const findVisibleCancelButton = (scope) => {
      const nodes = [...(scope || document).querySelectorAll(
        "button.el-button, button.private-button.text, .el-button.private-button.text, button"
      )].filter(visible);
      return nodes.find(e => lower(e.innerText).replace(/\s+/g, " ").trim() === "buộc hủy bỏ") || null;
    };

    let cancel = findVisibleCancelButton(root) || findVisibleCancelButton(document);
    if (!cancel) throw new Error("Không tìm thấy nút Buộc hủy bỏ đang hiển thị");

    scrollElementForAction(cancel);
    await sleep(250);
    cancel.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, cancelable: true, view: window }));
    cancel.dispatchEvent(new MouseEvent("mouseup", { bubbles: true, cancelable: true, view: window }));
    cancel.click();
    log(no, "→ đã bấm nút Buộc hủy bỏ → chờ popup nhập lý do");

    // NOTE 2: Popup "Buộc hủy bỏ" phải được mở thành công trước khi tiếp tục.
    const end = Date.now() + XNK_CONFIG.actionTimeoutMs * 2;
    let reasonTa = null;
    let cancelDialog = null;

    while (Date.now() < end) {
      await sleep(220);
      const dialogs = [...document.querySelectorAll(".el-dialog, .el-message-box, .el-message-box__wrapper")]
        .filter(visible);

      // Ưu tiên popup có tiêu đề/placeholder đúng với thao tác hủy.
      for (const d of dialogs.reverse()) {
        const ta2 = [...d.querySelectorAll("textarea")].find(e =>
          /Vui lòng nhập Lý do hủy quầy lễ tân/i.test(e.getAttribute("placeholder") || "")
        );
        if (ta2) {
          reasonTa = ta2;
          cancelDialog = d;
          break;
        }
      }
      if (reasonTa) break;
    }

    if (!reasonTa) {
      throw new Error("Đã bấm Buộc hủy bỏ nhưng không tìm thấy ô Lý do hủy quầy lễ tân");
    }

    await setTextareaVerified(reasonTa, note, "Lý do hủy quầy lễ tân");
    log(no, "→ NOTE 2 hoàn tất: Lý do hủy quầy lễ tân");

    // Chỉ sau khi NOTE 2 đã được xác minh mới được phép bấm Xác nhận.
    const confirmEnd = Date.now() + XNK_CONFIG.actionTimeoutMs * 2;
    let confirm = null;
    while (Date.now() < confirmEnd) {
      const scope = cancelDialog || currentPanel();
      const buttons = [...scope.querySelectorAll("button.el-button, button, .el-button")]
        .filter(visible);
      confirm = buttons.find(e => lower(e.innerText).replace(/\s+/g, " ").trim() === "xác nhận") || null;
      if (confirm) break;
      await sleep(180);
    }

    if (!confirm) throw new Error("NOTE 2 đã nhập nhưng không tìm thấy nút Xác nhận trong popup Buộc hủy bỏ");

    // Chốt lần cuối: tuyệt đối không xác nhận nếu textarea đã bị thay đổi/xóa.
    if (String(reasonTa.value || "").trim() !== String(note).trim()) {
      throw new Error("Nội dung Lý do hủy quầy lễ tân đã thay đổi trước khi Xác nhận");
    }

    scrollElementForAction(confirm);
    await sleep(150);
    confirm.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, cancelable: true, view: window }));
    confirm.dispatchEvent(new MouseEvent("mouseup", { bubbles: true, cancelable: true, view: window }));
    confirm.click();
    log(no, "→ NOTE 2 đã được xác minh → đã bấm Xác nhận hủy");
    return true;
  }

  async function verifyCancellation(no) {
    const end = Date.now() + XNK_CONFIG.actionTimeoutMs * 3;
    let confirmSeen = false;

    let attempt = 0;
    while (Date.now() < end) {
      await sleep(XNK_CONFIG.autoSync === false ? 400 : syncDelay(attempt++));
      const row = findRow(no);
      const panel = visibleDialogs().length ? currentPanel() : null;

      const hasCancel = !!(panel && findTextButton(panel, "Buộc hủy bỏ"));
      const hasConfirm = [...document.querySelectorAll(
        ".el-message-box button,.el-message-box .el-button"
      )].some(e => e.offsetParent !== null && lower(e.innerText) === "xác nhận");

      if (!hasConfirm) confirmSeen = true;

      if (row) {
        const txt = lower(row.innerText);
        if (/đã hủy|hủy bỏ|đã trả|trả đơn|hoàn trả/.test(txt)) {
          log(no, "→ xác nhận đơn đã trả/hủy thành công");
          return true;
        }
      }

      if (panel) {
        const txt = lower(panel.innerText);
        if (/đã hủy|hủy bỏ thành công|trả đơn thành công|hoàn trả thành công/.test(txt)) {
          log(no, "→ xác nhận hủy thành công trong giao diện");
          return true;
        }
      }

      // If the confirmation dialog disappeared and the cancellation control is gone,
      // treat the UI operation as completed. This is preferable to locking another order
      // while the current one is still visibly cancellable.
      if (confirmSeen && !hasCancel) {
        log(no, "→ hộp Xác nhận đã đóng + nút Buộc hủy bỏ đã biến mất");
        return true;
      }
    }

    throw new Error("Đã xác nhận hủy nhưng chưa xác minh được đơn đã trả/hủy");
  }

  async function closeProcessingPanel(no) {
    // Đóng thật sự giao diện xử lý. Đặc biệt sau lỗi hạn ngạch, website
    // thường đóng MessageBox trước nhưng dialog đơn vẫn còn mở.
    // Ưu tiên đúng nút X có class Element UI mà người dùng đã cung cấp:
    // <i class="el-dialog__close el-icon el-icon-close"></i>
    for (let attempt = 0; attempt < 4; attempt++) {
      const panel = currentPanel();
      if (!panel || panel === document) {
        log(no, '→ giao diện xử lý đã đóng');
        return true;
      }

      const scoped = [
        ...panel.querySelectorAll(
          '.el-dialog__close, .el-dialog__headerbtn, .el-drawer__close-btn, button[aria-label="Close"], button[title="Close"]'
        )
      ].filter(e => isActuallyVisible(e) && !e.disabled);

      // Nếu nút X là <i>, click trực tiếp vào nó; nếu là header button thì
      // click button. Lấy phần tử cuối cùng để ưu tiên dialog đang nằm trên cùng.
      let closeBtn = scoped[scoped.length - 1];

      // Fallback toàn trang: một số Vue/Element UI render nút X ngoài node
      // mà currentPanel() trả về.
      if (!closeBtn) {
        const globalClose = [...document.querySelectorAll(
          '.el-dialog__close, .el-dialog__headerbtn, .el-drawer__close-btn'
        )].filter(e => isActuallyVisible(e) && !e.disabled);
        closeBtn = globalClose[globalClose.length - 1];
      }

      if (!closeBtn) {
        const header = panel.querySelector('.el-dialog__header, .el-drawer__header');
        closeBtn = header && [...header.querySelectorAll('button,span,i')]
          .filter(e => isActuallyVisible(e))
          .find(e => /^(×|x|close|đóng)$/i.test(
            norm(e.innerText || e.getAttribute('aria-label') || e.getAttribute('title') || '')
          ));
      }

      if (closeBtn) {
        try {
          closeBtn.scrollIntoView({ block: 'center' });
        } catch (_) {}
        await sleep(100);
        closeBtn.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, view: window }));
        closeBtn.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true, view: window }));
        closeBtn.click();
        log(no, `→ đã bấm dấu X đóng giao diện đơn (lần ${attempt + 1})`);
      } else {
        log(no, `→ chưa tìm thấy dấu X đóng giao diện (lần ${attempt + 1})`);
      }

      await sleep(350);
      if (!visibleDialogs().length) {
        log(no, '→ đã đóng giao diện xử lý, quay lại danh sách');
        return true;
      }
    }

    return !visibleDialogs().length;
  }

  function rowLooksCanceled(row) {
    if (!row) return false;
    const t = lower(row.innerText);
    return /đã hủy|hủy bỏ|trả đơn|đã trả|hoàn trả|trả lại/.test(t);
  }

  function rowLooksCompleted(row) {
    if (!row) return false;
    const t = lower(row.innerText);
    return /đã thanh toán|thanh toán thành công|đã chuyển|chuyển khoản thành công|hoàn tất|đã hoàn thành/.test(t);
  }

  async function waitAfterCancel(no) {
    const end = Date.now() + 12000;
    let attempt = 0;
    while (Date.now() < end) {
      await sleep(XNK_CONFIG.autoSync === false ? 400 : syncDelay(attempt++));
      const row = findRow(no);
      const panel = visibleDialogs().length ? currentPanel() : null;
      if (rowLooksCanceled(row)) return true;
      if (!panel && !row) return true;
      if (panel) {
        const t = lower(panel.innerText);
        if (/trả đơn thành công|hủy bỏ thành công|đã hủy|đã trả|hoàn trả thành công/.test(t)) return true;
      }
    }
    return false;
  }

  async function waitAfterPayment(no) {
    const end = Date.now() + 12000;
    while (Date.now() < end) {
      await sleep(400);
      const row = findRow(no);
      const panel = visibleDialogs().length ? currentPanel() : null;
      if (rowLooksCompleted(row)) return true;
      if (panel) {
        const t = lower(panel.innerText);
        if (/đã thanh toán|thanh toán thành công|đã chuyển|chuyển khoản thành công|hoàn tất|đã hoàn thành/.test(t)) return true;
      }
      if (!panel && row && !isLockedBySomeone(row)) return true;
    }
    return false;
  }

  function currentProviderFromRow(row) {
    if (!row) return "";
    const input = row.querySelector(
      'td.merchId input[placeholder*="Thanh toán rút tiền của bên thứ ba"], td.merchId input.el-input__inner'
    );
    if (input && norm(input.value)) return norm(input.value);

    const cell = row.querySelector("td.merchId");
    if (cell) {
      const text = norm(cell.innerText);
      const names = Object.keys(XNK_CONFIG.providerFallback || {});
      const known = names.find(n => text.toLowerCase().includes(String(n).toLowerCase()));
      if (known) return known;
    }
    return "";
  }

  // QUY TẮC CỐ ĐỊNH:
  // Nếu CÙNG MỘT DÒNG ĐƠN có nút "mở khóa" + "Hoàn trả" thì
  // đây là đơn phải BỎ QUA HOÀN TOÀN. Không được mở Hoàn trả,
  // không chọn nhà thứ 3, không thanh toán và không hardStop.
  // Đọc trực tiếp trong ô thao tác của chính dòng đơn để tránh
  // bỏ sót trường hợp giao diện đổi wrapper/button/span.
  function isLockedAndReturned(row) {
    if (!row) return false;
    const op = row.querySelector("td.operation");
    if (!op) return false;
    const text = lower(norm(op.innerText || op.textContent || ""));
    return text.includes("mở khóa") && text.includes("hoàn trả");
  }

  function returnedButton(row) {
    return action(row, "Hoàn trả") || findTextButton(row, "Hoàn trả");
  }

  async function openReturnedProcessing(no) {
    const row = findRow(no);
    if (!row) throw new Error("Không tìm thấy đơn Hoàn trả " + no);
    const b = returnedButton(row);
    if (!b) throw new Error("Không thấy nút Hoàn trả trên đơn");

    b.scrollIntoView({ block: "center" });
    b.click();
    log(no, "→ phát hiện đơn đã trả về, đã bấm Hoàn trả");

    const end = Date.now() + XNK_CONFIG.actionTimeoutMs;
    while (Date.now() < end) {
      await sleep(250);
      const panel = currentPanel();
      if (!panel) continue;
      const manual = [...panel.querySelectorAll(".el-radio__label, label, span")]
        .find(e => norm(e.innerText) === "Thanh toán thủ công" && e.offsetParent !== null);
      const select = [...panel.querySelectorAll(
        'input[placeholder="Chọn Thanh toán rút tiền của bên thứ ba"], input[placeholder*="Thanh toán rút tiền của bên thứ ba"]'
      )].find(e => e.offsetParent !== null);
      if (manual || select) {
        log(no, "→ đã mở giao diện Hoàn trả");
        return true;
      }
    }
    throw new Error("Đã bấm Hoàn trả nhưng chưa mở giao diện lựa chọn chế độ thanh toán");
  }

  async function selectManualPaymentMode(no) {
    const panel = currentPanel();
    if (!panel) throw new Error("Không tìm thấy giao diện Hoàn trả");

    const label = [...panel.querySelectorAll(".el-radio__label, label, span")]
      .find(e => norm(e.innerText) === "Thanh toán thủ công" && e.offsetParent !== null);
    if (!label) throw new Error("Không tìm thấy lựa chọn Thanh toán thủ công");

    const radio = label.closest("label.el-radio, .el-radio")?.querySelector('input[type="radio"]');
    if (radio && !radio.disabled) {
      radio.click();
    } else {
      label.click();
    }

    const end = Date.now() + XNK_CONFIG.actionTimeoutMs;
    while (Date.now() < end) {
      await sleep(200);
      const p = currentPanel();
      const selected = p && [...p.querySelectorAll(".el-radio")].some(r =>
        /Thanh toán thủ công/i.test(r.innerText || "") && r.classList.contains("is-checked")
      );
      const input = p && [...p.querySelectorAll(
        'input[placeholder="Chọn Thanh toán rút tiền của bên thứ ba"], input[placeholder*="Thanh toán rút tiền của bên thứ ba"]'
      )].find(e => e.offsetParent !== null && !e.disabled);
      if (selected || input) {
        log(no, "→ đã chọn chế độ Thanh toán thủ công");
        return true;
      }
    }
    throw new Error("Đã chọn Thanh toán thủ công nhưng chưa xuất hiện Select nhà thứ 3");
  }

  function isActuallyVisible(el) {
    if (!el) return false;
    const cs = getComputedStyle(el);
    const r = el.getBoundingClientRect();
    return cs.display !== "none" && cs.visibility !== "hidden" && cs.opacity !== "0" && r.width > 0 && r.height > 0;
  }

  function visibleQuotaErrorBox() {
    const candidates = [...document.querySelectorAll(
      'body .el-message-box, body .el-message-box__wrapper, body .el-message-box__content, body .el-dialog'
    )];
    const box = candidates.find(e =>
      isActuallyVisible(e) &&
      /vnd\s*-?\s*rút tiền của bạn vẫn không đủ/i.test(norm(e.innerText || ''))
    );
    return box || null;
  }

  async function handleQuotaErrorIfPresent(no) {
    const end = Date.now() + 5000;
    while (Date.now() < end) {
      const box = visibleQuotaErrorBox();
      if (box) {
        log(no, '→ PHÁT HIỆN HỘP LỖI HẠN NGẠCH: VND-Rút tiền của bạn vẫn không đủ');
        const buttons = [...box.querySelectorAll('button.el-button, button, .el-button')]
          .filter(e => isActuallyVisible(e) && !e.disabled);
        const confirm = buttons.find(e => norm(e.innerText).toLowerCase() === 'xác nhận') ||
          [...document.querySelectorAll('body button.el-button, body button')]
            .find(e => isActuallyVisible(e) && !e.disabled && norm(e.innerText).toLowerCase() === 'xác nhận');
        if (!confirm) throw new Error('Phát hiện hộp lỗi hạn ngạch nhưng không thấy nút Xác nhận');
        scrollElementForAction(confirm);
        await sleep(150);
        confirm.click();
        log(no, '→ đã bấm Xác nhận hộp lỗi hạn ngạch');

        const closeEnd = Date.now() + 5000;
        while (Date.now() < closeEnd) {
          await sleep(250);
          if (!visibleQuotaErrorBox()) {
            log(no, '→ hộp lỗi hạn ngạch đã đóng');
            return true;
          }
        }
        throw new Error('Đã bấm Xác nhận lỗi hạn ngạch nhưng hộp lỗi chưa đóng');
      }
      await sleep(200);
    }
    return false;
  }

  async function unlockOrderAfterProviderSkip(no, reason = "") {
    // Khi đơn đã bị Tool khóa nhưng không thể tiếp tục vì không có nhà thứ 3
    // hoặc provider báo hết hạn ngạch, sau khi đóng giao diện phải trả lại
    // trạng thái đơn bằng đúng nút "mở khóa" trong CHÍNH DÒNG ĐƠN đó.
    const end = Date.now() + 8000;
    let lastReason = reason || "provider skip";
    let sawRow = false;

    while (Date.now() < end) {
      const row = findRow(no);
      if (!row) {
        await sleep(300);
        continue;
      }
      sawRow = true;

      // Chỉ thao tác trên nút hành động "Mở khóa" của chính dòng đơn.
      // Không dùng text trạng thái/ô khác để tránh mở nhầm đơn.
      const unlock = action(row, "Mở khóa");
      if (unlock && isActuallyVisible(unlock) && !unlock.disabled) {
        try {
          unlock.scrollIntoView({ block: "center" });
        } catch (_) {}
        await sleep(120);
        unlock.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, cancelable: true, view: window }));
        unlock.dispatchEvent(new MouseEvent("mouseup", { bubbles: true, cancelable: true, view: window }));
        unlock.click();
        log(no, `→ ${lastReason} → đã bấm Mở khóa đơn`);

        // Xác nhận nút đã đổi khỏi "Mở khóa" và đơn trở lại trạng thái có thể khóa.
        const verifyEnd = Date.now() + 5000;
        while (Date.now() < verifyEnd) {
          await sleep(250);
          const current = findRow(no);
          if (!current) return true;
          if (!action(current, "Mở khóa")) {
            log(no, "→ xác nhận Mở khóa thành công: nút Mở khóa đã biến mất");
            return true;
          }
        }

        log(no, "→ đã bấm Mở khóa nhưng chưa xác nhận được trạng thái đơn");
      } else if (!action(row, "Mở khóa")) {
        // Đơn có thể đã tự mở khóa trong lúc website refresh.
        log(no, `→ ${lastReason} → đơn hiện không còn nút Mở khóa, coi như đã mở khóa`);
        return true;
      }

      await sleep(300);
    }

    // 1.4.155: dòng đơn KHÔNG xuất hiện trong suốt thời gian chờ (BO làm mới/đổi bộ lọc/đơn đã chuyển đi)
    // → không còn gì để bấm. Dừng cả Bot cũng không mở khóa được, nên chỉ ghi log và cho Bot đi tiếp.
    if (!sawRow) {
      log(no, `→ ${lastReason} → dòng đơn không còn trong danh sách sau 8 giây, không thể bấm Mở khóa → KHÔNG dừng Bot (nếu đơn còn bị khóa, hãy mở khóa tay)`);
      return true;
    }

    // 1.4.156: thấy dòng đơn nhưng thử nhiều lần vẫn không mở khóa được → KHÔNG dừng Bot (dừng cũng không mở khóa được
    // và làm kẹt cả hàng đơn phía sau). Ghi nhận đơn "kẹt khóa", báo nhẹ không chặn, rồi đi tiếp đơn khác.
    log(no, `→ ${lastReason} → đã thử nhiều lần nhưng KHÔNG mở khóa được đơn → ghi nhận ĐƠN KẸT KHÓA, KHÔNG dừng Bot, tiếp tục đơn khác (cần mở khóa tay)`);
    try { manual.add(no); } catch (_) {}
    try { showStuckLockNotice(no); } catch (_) {}
    return false;
  }

  async function finishQuotaErrorOrder(no) {
    const handled = await handleQuotaErrorIfPresent(no);
    if (!handled) return false;
    const closed = await closeProcessingPanel(no);
    if (!closed) throw new Error("Đã xác nhận lỗi hạn ngạch nhưng chưa đóng được giao diện đơn");
    await unlockOrderAfterProviderSkip(no, "lỗi hạn ngạch");
    done.add(no);
    log(no, '→ lỗi hạn ngạch: Xác nhận + đóng giao diện + Mở khóa đơn → chuyển đơn tiếp theo');
    return true;
  }

  async function processReturnedOne(row) {
    const no = orderNo(row);
    if (!no) return { state: "SKIP" };
    if (done.has(no) || failed.has(no)) return { state: "SKIP" };

    if (isUsdtRow(row)) {
      log(no, "→ nhận diện đơn USDT HOÀN TRẢ → BỎ QUA, không mở giao diện, không Check Bank, không Provider, không Payment");
      done.add(no);
      return { state: "SKIP", reason: "USDT_DISABLED" };
    }

    log("===== PHÁT HIỆN ĐƠN HOÀN TRẢ:", no, "=====");
    try {
      const previous = providerHistory.get(no) || [];
      const rowProvider = currentProviderFromRow(row);
      const exclude = [...new Set([...previous, rowProvider].filter(Boolean))];
      log(no, "→ nhà thứ 3 đã dùng, loại khỏi lượt mới:", exclude);

      await openReturnedProcessing(no);
      await selectManualPaymentMode(no);

      const currentRow = findRow(no) || row;
      const amount = expectedVnd(currentRow);
      if (amount == null) throw new Error("Không đọc được Số tiền dự kiến đến người cho đơn Hoàn trả");

      const chosenProvider = await chooseProvider(no, amount, exclude, true);
      const confirmResult = await confirmPayment(no);
      if (confirmResult?.status === "QUOTA_HANDLED") {
        await unlockOrderAfterProviderSkip(no, "lỗi hạn ngạch");
        done.add(no);
        return { state: "DONE" };
      }

      const paymentDone = confirmResult?.status === "SUCCESS" ? true : await waitAfterPayment(no);
      if (!paymentDone) {
        throw new Error("Đã xác nhận nhà thứ 3 sau Hoàn trả nhưng chưa xác nhận được trạng thái hoàn tất");
      }

      const history = providerHistory.get(no) || [];
      if (!history.some(x => lower(x) === lower(chosenProvider))) history.push(chosenProvider);
      providerHistory.set(no, history);

      await closeProcessingPanel(no);
      done.add(no);
      log(no, "===== HOÀN TẤT: HOÀN TRẢ → THỦ CÔNG → NHÀ KHÁC =====");
      return { state: "DONE" };
    } catch (e) {
      // Không còn nhà thứ 3 khả dụng chỉ là SKIP của đơn hiện tại.
      // Đóng giao diện nếu còn mở rồi để AUTO tiếp tục tìm đơn khác; không hardStop.
      if (isNoProviderAvailableError(e)) {
        // Không có nhà thứ 3 khả dụng (kể cả dropdown không có dữ liệu)
        // chỉ là SKIP của đơn hiện tại. Không hardStop AUTO.
        log(no, "→ không có nhà thứ 3 khả dụng / dropdown không có dữ liệu → đóng giao diện, BỎ QUA đơn hiện tại và tiếp tục tìm đơn khác");
        try { await closeProcessingPanel(no); } catch (closeErr) {
          log(no, "→ không đóng được giao diện sau khi SKIP nhà thứ 3:", String(closeErr?.message || closeErr));
        }
        done.add(no);
        return { state: "SKIP", reason: "NO_PROVIDER_AVAILABLE" };
      }

      healthError(e, /timeout|chờ|không xác nhận/i.test(String(e?.message||"")));
      failed.add(no);
      hardStop = true;
      console.error(TAG, no, "→ DỪNG TOÀN BỘ BOT Ở NHÁNH HOÀN TRẢ:", e);
      showBotStopPopup(no, String(e?.message || e));
      return { state: "STOP", error: e };
    }
  }

  function shouldSkipLockedReturnedNoReview(no) {
    const r = findRow(no);
    if (!r) return false;
    const locked = isLockedBySomeone(r);
    const returned = returnedButton(r);
    if (!locked || !returned) return false;
    const review = action(r, "Xem lại chuyển tiền") || findTextButton(r, "Xem lại chuyển tiền");
    return !review;
  }

  // ===== 1.4.162: THÀNH VIÊN VỪA BỊ TRẢ ĐƠN VÌ SAI THÔNG TIN NGÂN HÀNG (BANK CHECK) → BỎ QUA 180 PHÚT =====
  // Chỉ ghi nhớ khi Tool đã Buộc hủy đơn vì Bank Check xác nhận sai thông tin ngân hàng.
  // KHÔNG áp dụng: số điện thoại VietinBank/BIDV/MSB (luật riêng), USDT, mọi lý do khác.
  // Trong thời gian nhớ, đơn của thành viên đó bị bỏ qua TRƯỚC khi khóa (không đụng tới đơn, không cần mở khóa).
  const BANKBAD_KEY = "AD88_XNK_BANKBAD_MEMBERS";
  const BANKBAD_TTL_MS = 180 * 60 * 1000;
  const bankBadLogged = new Set();

  function readBankBadMembers() {
    try {
      const v = JSON.parse(localStorage.getItem(BANKBAD_KEY) || "{}");
      return v && typeof v === "object" ? v : {};
    } catch { return {}; }
  }
  function markBankBadMember(name) {
    const key = String(name || "").trim().toLowerCase();
    if (!key) return false;
    const o = readBankBadMembers(), now = Date.now();
    o[key] = now;
    for (const k of Object.keys(o)) if (now - Number(o[k]) > BANKBAD_TTL_MS) delete o[k];
    try { localStorage.setItem(BANKBAD_KEY, JSON.stringify(o)); return true; } catch (_) { return false; }
  }
  function bankBadMemberLeftMs(name) {
    const key = String(name || "").trim().toLowerCase();
    if (!key) return 0;
    const t = Number(readBankBadMembers()[key]);
    if (!Number.isFinite(t)) return 0;
    return Math.max(0, BANKBAD_TTL_MS - (Date.now() - t));
  }

  // Tên tài khoản thành viên trong danh sách (cột "Tài khoản thành viên"), ví dụ "congdinhd98".
  function memberNameFromRow(row) {
    try {
      if (!row) return "";
      const tds = [...row.querySelectorAll("td")];
      let idx = -1;
      const tableWrap = row.closest(".el-table") || document;
      const ths = [...tableWrap.querySelectorAll("th")];
      const hi = ths.findIndex(th => /tài khoản thành viên/i.test(norm(th.textContent || "")));
      if (hi >= 0) idx = hi;
      const cands = idx >= 0 && tds[idx] ? [tds[idx]] : [];
      if (tds[3] && !cands.includes(tds[3])) cands.push(tds[3]);
      for (const cell of cands) {
        const leafs = [...cell.querySelectorAll("span, a, div")].filter(el => el.children.length === 0);
        for (const el of leafs) {
          const t = norm(el.textContent || "");
          if (/^[A-Za-z0-9_.\-@]{3,40}$/.test(t) && !/^(vip\d*|nd|m|new)$/i.test(t)) return t;
        }
        const first = String(cell.innerText || "").split(/[\n\r]+/).map(norm).find(x => /^[A-Za-z0-9_.\-@]{3,40}$/.test(x) && !/^(vip\d*|nd|m|new)$/i.test(x));
        if (first) return first;
      }
    } catch (_) {}
    return "";
  }

  // Dự phòng: tên thành viên trong cửa sổ chi tiết rút tiền (ô có chữ "thành viên").
  function memberNameFromPanel(panel) {
    try {
      const items = [...(panel || document).querySelectorAll(".el-form-item")];
      for (const it of items) {
        const label = norm(it.querySelector(".el-form-item__label")?.textContent || "");
        if (!/thành viên|member/i.test(label)) continue;
        const v = it.querySelector(".private-button.text, .el-form-item__content span");
        const t = norm(v?.textContent || "");
        if (/^[A-Za-z0-9_.\-@]{3,40}$/.test(t)) return t;
      }
    } catch (_) {}
    return "";
  }

  // ===== 1.4.157: ĐƠN NHÀ THỨ 3 TRẢ VỀ ("Thanh toán không thành công" chữ đỏ) =====
  // Chỉ mở khóa khi: (1) dòng đơn có chữ ĐỎ "Thanh toán không thành công", (2) "Người thao tác" của dòng đúng là tài khoản
  // của Tool, (3) Tool có nhật ký đã đẩy đơn đó. Đơn của người khác tuyệt đối không đụng tới.
  // Sau khi mở khóa, đơn được ghi nhớ (24 giờ) để Tool KHÔNG tự đẩy lại đơn đó.
  const PROVIDER_RETURNED_KEY = "AD88_XNK_PROVIDER_RETURNED";
  const PROVIDER_RETURNED_TTL_MS = 24 * 60 * 60 * 1000;
  const returnedDiagLogged = new Set();
  const bankOffLogged = new Set();
  let lastReturnedScanAt = 0;

  function readProviderReturned() {
    try {
      const v = JSON.parse(localStorage.getItem(PROVIDER_RETURNED_KEY) || "{}");
      return v && typeof v === "object" ? v : {};
    } catch { return {}; }
  }
  function markProviderReturned(no) {
    const o = readProviderReturned();
    const now = Date.now();
    o[String(no)] = now;
    for (const k of Object.keys(o)) if (now - Number(o[k]) > PROVIDER_RETURNED_TTL_MS) delete o[k];
    try { localStorage.setItem(PROVIDER_RETURNED_KEY, JSON.stringify(o)); } catch (_) {}
  }
  function isProviderReturned(no) {
    const t = Number(readProviderReturned()[String(no)]);
    return Number.isFinite(t) && Date.now() - t <= PROVIDER_RETURNED_TTL_MS;
  }

  function providerFailedMark(row) {
    if (!row) return null;
    let els = [];
    try { els = [...row.querySelectorAll(".red, .tags span")]; } catch (_) { return null; }
    return els.find(el => {
      if (!/thanh toán không thành công/i.test(norm(el.textContent || ""))) return false;
      try { if (el.classList && el.classList.contains("red")) return true; } catch (_) {}
      try {
        const m = String(getComputedStyle(el).color || "").match(/(\d+)\D+(\d+)\D+(\d+)/);
        return !!m && Number(m[1]) >= 150 && Number(m[2]) <= 110 && Number(m[3]) <= 110;
      } catch (_) { return false; }
    }) || null;
  }

  // Đơn nhà thứ 3 trả về luôn có thêm chữ "Chi tiết lỗi" (div.error-but) trong dòng.
  function rowHasErrorDetail(row) {
    try {
      return [...row.querySelectorAll(".error-but, div, span, a")].some(el =>
        el.children.length === 0 && /^chi tiết lỗi$/i.test(norm(el.textContent || "")));
    } catch (_) { return false; }
  }

  function rowOperatorIsTool(row, mark) {
    const me = cleanOperatorText(getCurrentOperatorName() || currentOperatorName).toLowerCase();
    if (!me) return false;
    const cell = (mark && mark.closest && mark.closest("td")) || row;
    const lines = String(cell?.innerText || cell?.textContent || "").split(/[\n\r]+/).map(x => cleanOperatorText(x).toLowerCase()).filter(Boolean);
    return lines.includes(me);
  }

  function toolPushedOrder(no) {
    const me = cleanOperatorText(getCurrentOperatorName() || currentOperatorName).toLowerCase();
    return readOrderLogs().some(l => String(l.order) === String(no) && l.state === "DONE" &&
      (!l.operator || !me || cleanOperatorText(l.operator).toLowerCase() === me));
  }

  // Trả về null = không liên quan (xử lý bình thường); trả về kết quả = đã xử lý/chặn, processOne dừng ở đây.
  async function handleProviderReturnedOrder(row, no) {
    if (!toolSetting("returnUnlock", true)) return null;
    let mark = providerFailedMark(row);
    // Bắt buộc có CẢ chữ đỏ "Thanh toán không thành công" VÀ "Chi tiết lỗi"; thiếu một thì coi như đơn thường.
    if (mark && !rowHasErrorDetail(row)) mark = null;
    if (!mark) {
      // Đơn đã được Tool mở khóa vì nhà thứ 3 trả về: không tự đẩy lại (để nhân viên xử lý).
      if (isProviderReturned(no)) return { state: "IGNORE", reason: "PROVIDER_RETURNED_NO_REPUSH" };
      return null;
    }
    if (isProviderReturned(no)) return { state: "IGNORE", reason: "PROVIDER_RETURNED_NO_REPUSH" };

    const opOk = rowOperatorIsTool(row, mark), pushedOk = toolPushedOrder(no);
    const own = opOk && pushedOk;
    if (!own) {
      if (!returnedDiagLogged.has(no)) {
        returnedDiagLogged.add(no);
        log(no, "→ thấy đơn 'Thanh toán không thành công' nhưng KHÔNG mở khóa: " + (opOk ? "" : "[người thao tác trên dòng ≠ tài khoản Tool '" + (getCurrentOperatorName() || "?") + "'] ") + (pushedOk ? "" : "[Tool không có nhật ký đã đẩy đơn này]"));
      }
      return { state: "IGNORE", reason: "PROVIDER_FAILED_NOT_TOOL_ORDER" };
    }

    log(no, "→ NHÀ THỨ 3 TRẢ ĐƠN VỀ (Thanh toán không thành công) + đơn do Tool xử lý → mở khóa, KHÔNG đẩy lại");
    if (!action(row, "Mở khóa")) {
      log(no, "→ dòng đơn không có nút Mở khóa (đơn đã mở khóa) → chỉ đánh dấu KHÔNG đẩy lại");
      markProviderReturned(no);
      done.add(no);
      return { state: "IGNORE", reason: "PROVIDER_RETURNED_ALREADY_UNLOCKED" };
    }
    const ok = await unlockOrderAfterProviderSkip(no, "nhà thứ 3 trả đơn về");
    markProviderReturned(no);
    done.add(no);
    return {
      state: "SKIP",
      reason: ok === false
        ? "Nhà thứ 3 trả đơn về; Tool KHÔNG mở khóa được (cần mở khóa tay), không đẩy lại"
        : "Nhà thứ 3 trả đơn về (Thanh toán không thành công) → Tool đã mở khóa, không đẩy lại"
    };
  }

  // ===== 1.4.167: BỘ CANH KHÓA =====
  // Đơn do CHÍNH Tool khóa nhưng quá 2 phút vẫn chưa đẩy sang nhà thứ 3 (lag, tab bị Chrome làm chậm, Bot dừng/tải lại trang,
  // lỗi giữa chừng...) → tự mở khóa trả đơn. KHÔNG đụng đơn người khác khóa, KHÔNG mở đơn đã bấm "Xác nhận việc thanh toán".
  const LOCKED_AT_KEY = "AD88_XNK_LOCKED_AT";
  const LOCK_WATCHDOG_MS = 2 * 60 * 1000;
  const watchdogReleased = new Set();
  let lockWatchdogBusy = false;

  function readLockedAt() {
    try {
      const o = JSON.parse(localStorage.getItem(LOCKED_AT_KEY) || "{}");
      return o && typeof o === "object" && !Array.isArray(o) ? o : {};
    } catch (_) { return {}; }
  }
  function writeLockedAt(o) {
    try { localStorage.setItem(LOCKED_AT_KEY, JSON.stringify(o)); } catch (_) {}
  }
  function stampToolLock(no) {
    if (!no) return;
    const o = readLockedAt();
    const now = Date.now();
    for (const k of Object.keys(o)) if (!o[k] || now - Number(o[k].t || 0) > 24 * 3600 * 1000) delete o[k];
    o[String(no)] = { t: now, op: cleanOperatorText(getCurrentOperatorName() || currentOperatorName || ""), pushed: false };
    writeLockedAt(o);
  }
  function clearToolLockStamp(no) {
    const o = readLockedAt();
    if (o[String(no)]) { delete o[String(no)]; writeLockedAt(o); }
  }
  // Gọi NGAY trước khi bấm "Xác nhận việc thanh toán": từ lúc này đơn coi như đã đẩy, bộ canh khóa không được mở.
  function markPushStarted(no) {
    const o = readLockedAt();
    const k = String(no);
    if (!o[k]) o[k] = { t: Date.now(), op: "", pushed: true };
    o[k].pushed = true;
    writeLockedAt(o);
  }

  // 1.4.178: đơn đang do CHÍNH tài khoản Tool giữ nhưng Tool không có dấu khóa (khóa từ trước khi tải lại trang, từ tab/profile khác
  // dùng cùng tài khoản, hoặc dấu bị mất) → tự "nhận" để bộ canh đếm 2 phút. Chỉ nhận khi dòng đơn cho thấy CHƯA đẩy nhà thứ 3
  // ("Thanh toán 0 lần"), chưa có nhật ký DONE, chưa nằm trong danh sách đã xử lý. Đã đẩy / đang người khác giữ → không đụng.
  function adoptOwnLocks() {
    const me = cleanOperatorText(getCurrentOperatorName() || currentOperatorName || "");
    if (!me) return;
    const stamps = readLockedAt();
    let changed = false;
    for (const row of rows()) {
      const no = orderNo(row);
      if (!no || stamps[String(no)]) continue;
      if (done.has(no) || watchdogReleased.has(String(no))) continue;
      if (!isLockedBySomeone(row) || !rowOperatorIsTool(row, null)) continue;
      if (toolPushedOrder(no)) continue;
      const txt = String(row.innerText || row.textContent || "").replace(/\s+/g, " ");
      if (!/thanh toán\s*0\s*lần/i.test(txt)) continue;
      stamps[String(no)] = { t: Date.now(), op: me, pushed: false, adopted: true };
      changed = true;
      try { log(no, "→ BỘ CANH KHÓA: thấy đơn do tài khoản Tool giữ nhưng chưa đẩy nhà thứ 3 → bắt đầu đếm 2 phút, quá hạn sẽ tự mở khóa"); } catch (_) {}
    }
    if (changed) writeLockedAt(stamps);
  }

  async function lockWatchdogTick() {
    if (lockWatchdogBusy) return;
    if (!toolSetting("lockWatchdog", true)) return;
    if (!onTargetPage()) return;
    try { adoptOwnLocks(); } catch (_) {}
    const stamps = readLockedAt();
    const keys = Object.keys(stamps);
    if (!keys.length) return;
    lockWatchdogBusy = true;
    try {
      const me = cleanOperatorText(getCurrentOperatorName() || currentOperatorName || "").toLowerCase();
      for (const no of keys) {
        const st = stamps[no] || {};
        const age = Date.now() - Number(st.t || 0);
        if (age < LOCK_WATCHDOG_MS) continue;

        // Đã đẩy / đã hoàn tất → tuyệt đối không mở.
        if (st.pushed || toolPushedOrder(no)) { clearToolLockStamp(no); continue; }
        // Khóa bởi tài khoản khác (đổi tài khoản BO trên cùng trình duyệt) → không đụng.
        if (st.op && me && cleanOperatorText(st.op).toLowerCase() !== me) { clearToolLockStamp(no); continue; }

        const row = findRow(no);
        if (!row) continue; // dòng chưa hiển thị (BO đang lọc/làm mới) → để lượt sau
        if (!isLockedBySomeone(row)) { clearToolLockStamp(no); continue; } // đã được mở khóa rồi
        if (!rowOperatorIsTool(row, null)) { clearToolLockStamp(no); continue; } // người khác đang giữ → không mở

        // Tool đang thực sự xử lý đúng đơn này và vẫn còn nhịp hoạt động gần đây → chưa phải kẹt.
        const activeNow = running && currentOrder === String(no);
        if (activeNow && Date.now() - Number(health.lastHeartbeatAt || 0) < LOCK_WATCHDOG_MS) continue;

        log(no, `→ BỘ CANH KHÓA: Tool khóa đơn ${Math.round(age / 1000)} giây mà CHƯA đẩy sang nhà thứ 3 → tự Mở khóa trả đơn`);
        watchdogReleased.add(String(no));
        // Chỉ đóng giao diện khi nó thuộc đơn này (không đóng nhầm giao diện của đơn khác đang xử lý).
        if (!running || activeNow) { try { await closeProcessingPanel(no); } catch (_) {} }
        const ok = await unlockOrderAfterProviderSkip(no, "BỘ CANH KHÓA (khóa >2 phút chưa đẩy)");
        if (ok) {
          clearToolLockStamp(no);
          try { recordOrderLog(no, "SKIP", "Bộ canh khóa: khóa >2 phút chưa đẩy nhà thứ 3 → đã mở khóa", findRow(no)); } catch (_) {}
        }
      }
    } catch (e) {
      try { log("BỘ CANH KHÓA lỗi nhẹ (bỏ qua):", e?.message || e); } catch (_) {}
    } finally {
      lockWatchdogBusy = false;
    }
  }

  async function processOne(row) {
    const no = orderNo(row);
    if (!no) return { state: "SKIP" };
    currentOrder = no;
    healthStartOrder(no);
    if (done.has(no) || failed.has(no)) return { state: "SKIP" };

    {
      const returnedResult = await handleProviderReturnedOrder(row, no);
      if (returnedResult) return returnedResult;
    }

    // 1.4.162: thành viên vừa bị Tool trả đơn vì sai thông tin ngân hàng → bỏ qua, không khóa.
    if (toolSetting("bankBadSkip", true)) {
      const member = memberNameFromRow(row);
      const leftMs = bankBadMemberLeftMs(member);
      if (member && leftMs > 0) {
        if (!bankBadLogged.has(no)) {
          bankBadLogged.add(no);
          log(no, "→ thành viên '" + member + "' vừa bị trả đơn SAI THÔNG TIN NGÂN HÀNG → BỎ QUA đơn (không khóa), còn " + Math.ceil(leftMs / 60000) + " phút");
        }
        return { state: "IGNORE", reason: "BANK_BAD_MEMBER_COOLDOWN" };
      }
    }

    log("===== BẮT ĐẦU 1 ĐƠN DUY NHẤT:", no, "=====");

    // Giữ eligibility ở scope của cả try/catch để khi DIRECT_PROVIDER gặp lỗi
    // có thể bắt buộc đóng giao diện + Mở khóa chính đơn vừa khóa trước khi sang đơn khác.
    let eligibility = null;
    let usdtFlow = false; // đã vào nhánh USDT sau khi khóa đơn → mọi lỗi đều phải mở khóa rồi bỏ qua

    try {
      // GATE ĐIỀU KIỆN: M / Mới / Thành viên chưa rút tiền mặt là nhóm Check Bank.
      // Marker "Việc rút tiền được thực hiện lần ..." và các trạng thái khác
      // được bắt đơn nhưng đi thẳng nhà thứ 3, KHÔNG Check Bank.
      eligibility = classifyOrderEligibility(row);
      if (!eligibility.eligible) {
        log(no, "→ KHÔNG NHẬN ĐƠN THEO RULE: ", eligibility.reason || "NOT_ELIGIBLE");
        return { state: "SKIP", reason: eligibility.reason || "NOT_ELIGIBLE" };
      }
      if (eligibility.mode === "FIRST_WITHDRAWAL") {
        log(no, "→ ĐƠN M / Mới / Thành viên chưa rút tiền mặt → CHECK BANK → ĐẨY NHÀ 3");
      } else if (eligibility.mode === "DIRECT_PROVIDER") {
        if (eligibility.reason === "WITHDRAWAL_ATTEMPT_DIRECT_PROVIDER") {
          log(no, "→ ĐƠN " + "Việc rút tiền được thực hiện lần ..." + " → BẮT ĐƠN → BỎ QUA CHECK BANK → KHÓA → ĐẨY THẲNG NHÀ 3");
        } else {
          log(no, "→ ĐƠN KHÔNG THUỘC M / Mới / Thành viên chưa rút tiền mặt → BỎ QUA CHECK BANK → KHÓA → ĐẨY THẲNG NHÀ 3");
        }
      }

      // USDT: chỉ xử lý đơn TRC20 và ERC20 (và chỉ khi công tắc "Xử lý đơn USDT" đang BẬT).
      // Các loại USDT khác, hoặc công tắc TẮT → BỎ QUA trước khi khóa, không Check Bank / Provider / Payment.
      if (isUsdtRow(row)) {
        const net = usdtNetworkFromRow(row);
        if (!net) {
          log(no, "→ NHẬN DIỆN ĐƠN USDT KHÔNG PHẢI TRC20/ERC20 → BỎ QUA, KHÔNG KHÓA, KHÔNG CHECK BANK, KHÔNG PROVIDER, KHÔNG PAYMENT");
          done.add(no);
          return { state: "SKIP", reason: "USDT_UNSUPPORTED_NETWORK" };
        }
        if (!toolSetting("usdt", true)) {
          log(no, "→ ĐƠN USDT-" + net + " nhưng công tắc Xử lý đơn USDT đang TẮT → BỎ QUA, KHÔNG KHÓA");
          done.add(no);
          return { state: "SKIP", reason: "USDT_DISABLED" };
        }
      }

      // 1.4.166: công tắc "Tự động kiểm tra Bank" TẮT → đơn M/Mới (bắt buộc Check Bank) bị bỏ qua TRƯỚC khi khóa,
      // không đụng tới đơn (trước đây khóa rồi mới bỏ qua nên đơn kẹt khóa). Không đánh dấu done: bật lại là xử lý.
      if (eligibility.mode === "FIRST_WITHDRAWAL" && !toolSetting("bank", true)) {
        if (!bankOffLogged.has(no)) {
          bankOffLogged.add(no);
          log(no, "→ Tự động kiểm tra Bank đang TẮT → bỏ qua đơn M/Mới ngay từ đầu (KHÔNG khóa), tìm đơn khác");
        }
        return { state: "IGNORE", reason: "BANK_CHECK_DISABLED_NOT_LOCKED" };
      }

      if (isLockedAndReturned(row)) {
        log(no, "→ đơn đang bị người khác khóa + Hoàn trả → KHÔNG TÍNH BỎ QUA, chỉ bỏ qua lượt quét và tìm đơn phù hợp khác");
        return { state: "IGNORE", reason: "LOCKED_RETURN" };
      }
      if (isRefreshRecall(row)) {
        log(no, "→ phát hiện nút Làm mới gọi lại → bỏ qua hoàn toàn đơn này, chuyển sang đơn tiếp theo");
        return { state: "SKIP", reason: "REFRESH_RECALL" };
      }
      if (isLockedBySomeone(row)) {
        // Đơn đã bị người khác khóa không phải là đơn Tool chủ động bỏ qua.
        // Chỉ bỏ qua trong lượt quét, tuyệt đối không đưa vào thống kê "Đơn bỏ qua".
        log(no, "→ đơn đang bị người khác khóa → KHÔNG THỐNG KÊ BỎ QUA, tiếp tục tìm đơn khác");
        return { state: "IGNORE", reason: "LOCKED_BY_SOMEONE" };
      }
      if (!isAvailableToLock(row)) {
        log(no, "→ không có nút Khóa, bỏ qua");
        return { state: "SKIP" };
      }

      // Nếu tắt Tự động mở khóa/khóa trong Cài đặt, không tự chiếm đơn.
      // Đơn được giữ nguyên để nhân sự xử lý thủ công.
      if (!toolSetting("unlock", true)) {
        log(no, "→ Tự động mở khóa đang TẮT → không tự khóa đơn, bỏ qua để xử lý thủ công");
        done.add(no);
        return { state: "SKIP", reason: "AUTO_LOCK_DISABLED" };
      }

      healthTouch("Khóa đơn");
      const lockResult = await lockOne(no);
      if (lockResult?.status === "LOCKED_BY_TOOL") stampToolLock(no);
      if (lockResult?.status === "ROW_GONE") {
        return { state: "IGNORE", reason: "ROW_GONE" };
      }
      if (lockResult?.status === "LOCK_REJECTED") {
        return { state: "IGNORE", reason: "LOCK_REJECTED" };
      }
      if (lockResult?.status === "SKIP_LOCKED_BY_OTHER") {
        log(no, "→ đơn bị nhân viên khác khóa → SKIP lượt này, không xử lý tiếp và không dừng Bot");
        done.add(no);
        return { state: "IGNORE", reason: "LOCKED_BY_OTHER_RACE" };
      }

      // Sau khi khóa, kiểm tra lại ngay vì trạng thái thao tác có thể thay đổi.
      // Nếu xuất hiện "Làm mới gọi lại" thì đây vẫn là SKIP, không được xử lý tiếp.
      {
        const afterLockRow = findRow(no);
        if (afterLockRow && isRefreshRecall(afterLockRow)) {
          log(no, "→ sau khi khóa phát hiện nút Làm mới gọi lại → đóng giao diện + Mở khóa đơn trước khi bỏ qua");
          await closeProcessingPanel(no);
          await unlockOrderAfterProviderSkip(no, "REFRESH_RECALL_AFTER_LOCK");
          done.add(no);
          return { state: "SKIP", reason: "REFRESH_RECALL_AFTER_LOCK_UNLOCKED" };
        }
      }

      // Sau khi chính bot vừa khóa đơn, hậu đài có thể cập nhật dòng đơn thành:
      // "mở khóa" + chỉ còn "Hoàn trả" (không có "Xem lại chuyển tiền").
      // Đây là đơn đã ở trạng thái trả về/không thể tiếp tục theo flow thường.
      // Không được gọi openProcessing() rồi hardStop; phải bỏ qua đơn và sang đơn khác.
      {
        const afterLockRow = findRow(no);
        if (afterLockRow && isLockedBySomeone(afterLockRow) && returnedButton(afterLockRow)) {
          const review = action(afterLockRow, "Xem lại chuyển tiền") || findTextButton(afterLockRow, "Xem lại chuyển tiền");
          if (!review) {
            log(no, "→ sau khi khóa, đơn đang Mở khóa + chỉ có Hoàn trả, không có Xem lại chuyển tiền → Mở khóa/xác nhận rồi mới bỏ qua");
            await closeProcessingPanel(no);
            await unlockOrderAfterProviderSkip(no, "LOCKED_RETURN_NO_REVIEW_AFTER_LOCK");
            done.add(no);
            return { state: "SKIP", reason: "LOCKED_RETURN_NO_REVIEW_UNLOCKED" };
          }
        }
      }

      // Đọc + xác minh USDT NGAY TRÊN DÒNG ĐƠN, trước khi mở "Xem lại chuyển tiền".
      // Chỉ khi ví TRC20 hợp lệ mới được phép đi vào giao diện thanh toán và đẩy nhà thứ 3.
      // Nếu ví sai, chỉ mở giao diện sau đó để thực hiện Buộc hủy bỏ.
      const lockedRow = findRow(no) || row;
      // Cập nhật ngay thông tin đơn đang xử lý để Dashboard hiển thị đúng mã + số tiền.
      const detectedUsdt = paymentInfoFromRow(lockedRow);
      // USDT lấy trực tiếp từ cột "Dự kiến đến nơi (Nạp)" ngoài danh sách đơn.
      // Không lấy td.money / Số tiền rút VND và không cần mở popup chỉ để đọc tiền.
      const previewAmount = detectedUsdt.isUsdt
        ? expectedProviderAmount(lockedRow, "USDT")
        : expectedVnd(lockedRow);
      healthSetOrderMeta(previewAmount, "", detectedUsdt.isUsdt ? "USDT" : "VND");
      healthTouch("Đọc thông tin thanh toán");
      const paymentInfo = detectedUsdt;

      if (paymentInfo.isUsdt) {
        usdtFlow = true;
        const net = paymentInfo.usdtNetwork;
        if (!paymentInfo.walletAddress) {
          throw new Error("Đã nhận diện USDT-" + net + " nhưng không đọc được Tài khoản/Địa chỉ ví trong chính dòng đơn");
        }

        log(no, "===== PRE-CHECK USDT " + net + " NGOÀI GIAO DIỆN XỬ LÝ (áp dụng cả đơn M / Mới / chưa rút tiền mặt) =====");
        log(no, "Loại thanh toán:", paymentInfo.paymentType);
        log(no, "Wallet " + net + ":", paymentInfo.walletAddress);

        const usdtResult = net === "ERC20"
          ? validateUsdtErc20Address(paymentInfo.walletAddress, no)
          : await validateUsdtTrc20Address(paymentInfo.walletAddress, no);

        if (usdtResult.status === "INVALID") {
          // Ví sai: chỉ sau khi đã xác định sai mới mở Xem lại chuyển tiền để trả/hủy đơn.
          log(no, "→ ĐỊA CHỈ USDT " + net + " KHÔNG HỢP LỆ → MỞ XEM LẠI CHUYỂN TIỀN ĐỂ BUỘC HỦY");
          healthTouch("Mở giao diện xử lý");
         await openProcessing(no);
          const invalidUsdtActual = await waitForActualUsdtFromProcessingPanel();
          if (invalidUsdtActual != null) actualUsdtByOrder.set(String(no), invalidUsdtActual);
          await fillFrontNoteAndCancel(currentPanel(), no, net === "ERC20" ? "ERC20" : true);

          const canceled = await waitAfterCancel(no);
          if (!canceled) throw new Error("Đã buộc hủy đơn USDT nhưng chưa xác minh được đơn đã trả/hủy");

          healthTouch("Đóng giao diện");
         await closeProcessingPanel(no);
          done.add(no);
          log(no, "===== ĐƠN USDT HOÀN TẤT: PRE-CHECK INVALID → BUỘC HỦY → TRẢ LẠI =====");
          return { state: "RETURN", reason: "USDT_INVALID" };
        }

        // PRE-CHECK VALID: bây giờ mới mở Xem lại chuyển tiền.
        log(no, "→ ĐỊA CHỈ USDT " + net + " HỢP LỆ → MỞ XEM LẠI CHUYỂN TIỀN");
        await openProcessing(no);

        // VALID: số USDT đã được đọc trực tiếp ngoài danh sách đơn, trước khi mở popup.
        // Popup chỉ dùng cho các bước xử lý tiếp theo, không còn dùng để lấy số tiền.
        const amount = expectedProviderAmount(lockedRow, "USDT");
        if (amount == null) {
          throw new Error("Không đọc được số USDT tại cột Dự kiến đến nơi (Nạp) ngoài danh sách đơn");
        }
        healthSetOrderMeta(amount, "", "USDT");
        log(no, "→ ĐÃ ĐỌC SỐ USDT NGOÀI DANH SÁCH - CỘT DỰ KIẾN ĐẾN NƠI (NẠP):", amount, "USDT");
        log(no, "→ đã vào Xem lại chuyển tiền, bắt đầu chọn Thanh toán rút tiền bên thứ 3");
        const chosenProvider = await chooseProvider(no, amount, [], false, "USDT");
        providerHistory.set(no, [chosenProvider]);
        healthSetOrderMeta(amount, chosenProvider, "USDT");
        log(no, "→ ĐỦ ĐIỀU KIỆN USDT + ĐÃ CHỌN NHÀ THỨ 3:", chosenProvider);
        log(no, "→ BƯỚC TIẾP THEO: bấm nút Xác nhận việc thanh toán");
        const confirmResult = await confirmPayment(no);
        if (confirmResult?.status === "QUOTA_HANDLED") {
          await unlockOrderAfterProviderSkip(no, "lỗi hạn ngạch");
          done.add(no);
          return { state: "DONE" };
        }

        const paymentDone = confirmResult?.status === "SUCCESS" ? true : await waitAfterPayment(no);
        if (!paymentDone) throw new Error("Đã thao tác đẩy nhà thứ 3 cho đơn USDT nhưng chưa xác nhận được trạng thái hoàn tất");

        // KHÔNG bấm dấu X ở nhánh USDT sau khi đã xác nhận thanh toán.
        // Bước cuối của flow USDT là chính nút "Xác nhận việc thanh toán";
        // để website tự cập nhật/đóng giao diện nếu backend yêu cầu.
        done.add(no);
        log(no, "===== ĐƠN USDT HOÀN TẤT: VALID → ĐẨY NHÀ THỨ 3 =====");
        return { state: "DONE" };
      }

      // Đơn BANK: FIRST_WITHDRAWAL mới chạy Bank Checker.
      // DIRECT_PROVIDER (Mặc định / NHOMTHU) bỏ qua hoàn toàn Bank Check và đi thẳng nhà thứ 3.
      if (!eligibility.checkBank) {
        // DIRECT_PROVIDER vẫn cần mở giao diện Xem lại chuyển tiền để chọn nhà thứ 3
        // và bấm Xác nhận việc thanh toán; chỉ bỏ qua riêng bước Bank Check.
        await openProcessing(no);
        const amount = expectedVnd(lockedRow);
        if (amount == null) throw new Error("Không đọc được Số tiền dự kiến đến người");

        healthSetOrderMeta(amount, "", "VND");
        log(no, "→ DIRECT_PROVIDER: bỏ qua Bank Check → Số tiền:", amount, "VND");
        const chosenProvider = await chooseProvider(no, amount, [], false, "VND");
        providerHistory.set(no, [chosenProvider]);
        healthSetOrderMeta(amount, chosenProvider, "VND");

        log(no, "→ DIRECT_PROVIDER: đã chọn nhà thứ 3:", chosenProvider);
        const confirmResult = await confirmPayment(no);
        if (confirmResult?.status === "QUOTA_HANDLED") {
          await unlockOrderAfterProviderSkip(no, "lỗi hạn ngạch");
          done.add(no);
          return { state: "DONE" };
        }

        const paymentDone = confirmResult?.status === "SUCCESS" ? true : await waitAfterPayment(no);
        if (!paymentDone) throw new Error("Đã thao tác đẩy nhà thứ 3 nhưng chưa xác nhận được trạng thái hoàn tất");

        await closeProcessingPanel(no);
        done.add(no);
        log(no, "===== ĐƠN HOÀN TẤT: DIRECT_PROVIDER → ĐẨY NHÀ THỨ 3 =====");
        return { state: "DONE" };
      }

      // FIRST_WITHDRAWAL: bắt buộc Bank Check.
      // Khi tắt Tự động kiểm tra Bank, không tự mở giao diện/không thanh toán; giữ đơn cho xử lý thủ công.
      if (!toolSetting("bank", true)) {
        log(no, "→ Tự động kiểm tra Bank đang TẮT → bỏ qua đơn BANK để xử lý thủ công");
        done.add(no);
        return { state: "SKIP", reason: "BANK_CHECK_DISABLED" };
      }
      await openProcessing(no);
      const panel = currentPanel();
      const data = bankDataFromPanel(panel, lockedRow);

      if (!data.expectedName || !data.bankAccount || !data.bankName) {
        throw new Error("Không đọc đủ Họ tên + STK + Ngân hàng trong giao diện Xem lại chuyển tiền");
      }

      log(no, "BANK DATA ĐỌC TRỰC TIẾP TRONG ĐƠN:", data);
      const result = await waitForBankResult(data, no);

      if (result.status === "VALID") {
        const amount = expectedVnd(lockedRow);
        if (amount == null) throw new Error("Không đọc được Số tiền dự kiến đến người");

        log(no, "→ SỐ TIỀN DỰ KIẾN ĐẾN NGƯỜI:", amount, "VND");
        const chosenProvider = await chooseProvider(no, amount, [], false, "VND");
        providerHistory.set(no, [chosenProvider]);
        healthSetOrderMeta(amount, chosenProvider, "VND");
        const confirmResult = await confirmPayment(no);
        if (confirmResult?.status === "QUOTA_HANDLED") {
          await unlockOrderAfterProviderSkip(no, "lỗi hạn ngạch");
          done.add(no);
          return { state: "DONE" };
        }

        const paymentDone = confirmResult?.status === "SUCCESS" ? true : await waitAfterPayment(no);
        if (!paymentDone) throw new Error("Đã thao tác đẩy nhà thứ 3 nhưng chưa xác nhận được trạng thái hoàn tất");

        await closeProcessingPanel(no);
        done.add(no);
        log(no, "===== ĐƠN HOÀN TẤT: VALID → ĐẨY NHÀ THỨ 3 =====");
        return { state: "DONE" };
      }

      if (result.status === "INVALID") {
        // HARD SAFETY: Chỉ được Buộc hủy khi waitForBankResult đã xác nhận INVALID
        // bằng bằng chứng chắc chắn (confirmedInvalid=true). Mọi trạng thái không
        // chắc chắn/thiếu dữ liệu phải đi xuống nhánh UNKNOWN/ERROR: đóng giao diện,
        // mở khóa chính đơn và SKIP; tuyệt đối không Buộc hủy.
        if (result.confirmedInvalid !== true || result.confirmedInvalidEvidence !== "5_CONSECUTIVE_EXPLICIT_INVALID") {
          log(no, "→ BANK INVALID NHƯNG CHƯA CÓ BẰNG CHỨNG CHẮC CHẮN → CẤM BUỘC HỦY; đóng giao diện + Mở khóa + SKIP");
          const closed = await closeProcessingPanel(no);
          if (!closed) throw new Error("BANK CHECK không chắc chắn và chưa đóng được giao diện xử lý");
          const bankPopup = document.getElementById("ad88-bank-result");
          if (bankPopup) bankPopup.remove();
          await unlockOrderAfterProviderSkip(no, "BANK INVALID WITHOUT CONFIRMED EVIDENCE");
          done.add(no);
          return { state: "SKIP", reason: "BANK_NOT_CONFIRMED" };
        }
        log(no, "→ BANK INVALID ĐÃ XÁC NHẬN → ghi Front-end + Buộc hủy + Xác nhận");
        // 1.4.162: đọc tên thành viên TRƯỚC khi hủy (dòng đơn còn trên danh sách). Số điện thoại VTB/BIDV/MSB không áp dụng.
        const isPhoneRuleInvalid = (result?.raw?.reasonCode || result?.reasonCode) === "VIETNAM_PHONE_VTB_BIDV_MSB" ||
          /Số điện thoại Việt Nam không được phép/i.test(String(result?.reason || result?.message || ""));
        const badMember = isPhoneRuleInvalid ? "" : (memberNameFromRow(findRow(no)) || memberNameFromPanel(currentPanel()));
        await fillFrontNoteAndCancel(currentPanel(), no);

        const canceled = await waitAfterCancel(no);
        if (!canceled) throw new Error("Đã xác nhận Buộc hủy bỏ nhưng chưa xác minh được đơn đã trả/hủy");

        await closeProcessingPanel(no);
        done.add(no);
        // Buộc hủy thành công là "ĐƠN TRẢ LẠI", không phải "ĐÃ XỬ LÝ".
        log(no, "===== ĐƠN HOÀN TẤT: INVALID → BUỘC HỦY → ĐƠN TRẢ LẠI =====");
        if (badMember && toolSetting("bankBadSkip", true) && markBankBadMember(badMember)) {
          log(no, "→ ĐÃ GHI NHỚ thành viên '" + badMember + "' trả sai thông tin ngân hàng: bỏ qua đơn của thành viên này trong 180 phút");
        } else if (!isPhoneRuleInvalid && !badMember) {
          log(no, "→ không đọc được tên tài khoản thành viên → không ghi nhớ (đơn sau vẫn check bình thường)");
        }
        return { state: "RETURN", reason: result.reason || "BANK_INVALID" };
      }

      // BANK CHECK vẫn chưa có kết quả chắc chắn sau AUTO RECHECK:
      // lúc này mới đóng giao diện, MỞ KHÓA chính đơn Tool vừa khóa, rồi SKIP.
      // Trước thời điểm này tuyệt đối không unlock/skip.
      log(no, "→ BANK CHECK đã AUTO RECHECK nhưng vẫn chưa có kết quả chắc chắn → bấm X đóng giao diện → Mở khóa đơn → SKIP → tiếp tục đơn khác");
      const closed = await closeProcessingPanel(no);
      if (!closed) {
        throw new Error("BANK CHECK chưa có kết quả chắc chắn và chưa đóng được giao diện xử lý");
      }
      const bankPopup = document.getElementById("ad88-bank-result");
      if (bankPopup) bankPopup.remove();

      // Chỉ mở khóa đơn do Tool vừa khóa. Nếu không xác nhận được mở khóa,
      // không được âm thầm bỏ qua vì có thể để lại đơn ở trạng thái bị khóa.
      await unlockOrderAfterProviderSkip(no, "BANK CHECK UNKNOWN/ERROR AFTER AUTO RECHECK");
      done.add(no);
      log(no, "→ BANK CHECK UNKNOWN/ERROR → đã đóng giao diện + Mở khóa đơn → bỏ qua đơn → tiếp tục AUTO");
      return { state: "SKIP", reason: "BANK_UNKNOWN" };
    } catch (e) {
      // DIRECT_PROVIDER: đơn đã khóa nhưng đẩy nhà thứ 3 không hoàn tất.
      // BẮT BUỘC đóng giao diện + Mở khóa chính đơn đó + xác nhận đã mở khóa
      // rồi mới cho AUTO chuyển sang đơn khác. Không được để lại đơn bị khóa.
      if (eligibility?.mode === "DIRECT_PROVIDER" || usdtFlow) {
        // RULE CỨNG: Direct Provider gặp BẤT KỲ lỗi nào sau khi Tool đã khóa đơn
        // thì phải cố gắng đóng giao diện (nếu còn mở), SAU ĐÓ bắt buộc Mở khóa
        // chính đơn vừa xử lý và xác nhận lại trạng thái. Chỉ khi xác nhận Mở khóa
        // thành công mới được chuyển sang đơn kế tiếp.
        let closeErr = null;
        try {
          log(no, "→ DIRECT_PROVIDER GẶP LỖI → bắt buộc MỞ KHÓA đơn vừa khóa trước khi sang đơn khác");
          try {
            const closed = await closeProcessingPanel(no);
            if (!closed) closeErr = new Error("Không đóng được giao diện sau lỗi DIRECT_PROVIDER");
          } catch (eClose) {
            closeErr = eClose;
            console.warn(TAG, no, "→ DIRECT_PROVIDER lỗi: đóng giao diện thất bại, vẫn tiếp tục bước Mở khóa", eClose);
          }

          // Không được bỏ qua bước này dù đóng giao diện có lỗi.
          const unlockedOk = await unlockOrderAfterProviderSkip(no, "DIRECT_PROVIDER xử lý không thành công");
          done.add(no);
          log(no, unlockedOk === false
            ? "→ DIRECT_PROVIDER LỖI → KHÔNG mở khóa được (đơn kẹt khóa, cần mở tay) → SKIP → tiếp tục đơn khác"
            : "→ DIRECT_PROVIDER LỖI → đã MỞ KHÓA + xác nhận trạng thái → SKIP → tiếp tục đơn khác");
          return { state: "SKIP", reason: "DIRECT_PROVIDER_FAILED_UNLOCKED", closeError: closeErr ? String(closeErr.message || closeErr) : null };
        } catch (unlockErr) {
          healthError(unlockErr, /timeout|chờ|không xác nhận/i.test(String(unlockErr?.message||"")));
          failed.add(no);
          hardStop = true;
          console.error(TAG, no, "→ DỪNG BOT: DIRECT_PROVIDER lỗi và không thể xác nhận Mở khóa đơn", unlockErr);
          showBotStopPopup(no, String(unlockErr?.message || unlockErr));
          return { state: "STOP", error: unlockErr };
        }
      }

      // Không còn nhà thứ 3 khả dụng là tình huống cấu hình hợp lệ:
      // ví dụ U2Pay bị TẮT và không còn provider nào khác phù hợp với đơn.
      // Chỉ SKIP đơn hiện tại, tuyệt đối không dừng toàn bộ AUTO.
      if (isNoProviderAvailableError(e)) {
        // Tất cả loại đơn (VND/USDT) đều áp dụng cùng một nguyên tắc:
        // nếu đã khóa đơn nhưng không có nhà thứ 3 khả dụng thì đóng giao diện,
        // Mở khóa chính đơn đó rồi bỏ qua để AUTO tiếp tục đơn khác.
        log(no, "→ không còn nhà thứ 3 khả dụng → đóng giao diện, Mở khóa đơn rồi BỎ QUA đơn hiện tại");
        const closed = await closeProcessingPanel(no);
        if (!closed) throw new Error("Không thể đóng giao diện sau khi không có nhà thứ 3 khả dụng");
        await unlockOrderAfterProviderSkip(no, "không có nhà thứ 3 khả dụng");
        done.add(no);
        return { state: "SKIP", reason: "NO_PROVIDER_AVAILABLE" };
      }

      // 1.4.155: không mở được cửa sổ xử lý (đã bấm lại nhiều lần). Lỗi xảy ra TRƯỚC Bank Check/Thanh toán nên an toàn:
      // đóng giao diện (nếu có) + Mở khóa chính đơn + SKIP. Chỉ khi không mở khóa được mới dừng Bot như cũ.
      if (e && e.code === "OPEN_PANEL_FAILED") {
        log(no, "→ không mở được cửa sổ xử lý chuyển tiền → đóng giao diện (nếu có) + Mở khóa đơn + SKIP, tiếp tục đơn khác");
        try { await closeProcessingPanel(no); } catch (_) {}
        try {
          await unlockOrderAfterProviderSkip(no, "không mở được cửa sổ xử lý");
          done.add(no);
          return { state: "SKIP", reason: "OPEN_PANEL_FAILED_UNLOCKED" };
        } catch (unlockErr) {
          healthError(unlockErr, true);
          failed.add(no);
          hardStop = true;
          console.error(TAG, no, "→ DỪNG BOT: không mở được cửa sổ xử lý và không xác nhận được Mở khóa", unlockErr);
          showBotStopPopup(no, String(unlockErr?.message || unlockErr));
          return { state: "STOP", error: unlockErr };
        }
      }

      // Đây là trường hợp SKIP có chủ đích, không phải lỗi hệ thống:
      // đơn đang Mở khóa + có Hoàn trả nhưng không có Xem lại chuyển tiền.
      // Tuyệt đối không hardStop; đánh dấu SKIPPED và để AUTO tiếp tục đơn khác.
      if (shouldSkipLockedReturnedNoReview(no)) {
        log(no, "→ bắt được lỗi trong lúc tìm nút, nhưng DOM xác nhận Mở khóa + Hoàn trả + không có Xem lại chuyển tiền → SKIP, KHÔNG DỪNG BOT");
        done.add(no);
        return { state: "SKIP", reason: "LOCKED_RETURN_NO_REVIEW" };
      }

      const latestRow = findRow(no);
      if (latestRow && isRefreshRecall(latestRow)) {
        log(no, "→ bắt được lỗi nhưng DOM xác nhận có nút Làm mới gọi lại → SKIP, KHÔNG DỪNG BOT");
        done.add(no);
        return { state: "SKIP", reason: "REFRESH_RECALL" };
      }

      // Nếu BO báo đơn đã bị nhân viên khác khóa, đây là trạng thái cạnh tranh bình thường,
      // tuyệt đối không được coi là lỗi nghiêm trọng và không được hard-stop Bot.
      if (await dismissOtherLockConflict(no)) {
        done.add(no);
        log(no, "→ LOCK CONFLICT phát hiện trong catch → SKIP đơn hiện tại, tiếp tục tìm đơn khác");
        return { state: "IGNORE", reason: "LOCKED_BY_OTHER_RACE" };
      }

      // 1.4.158: đã bấm Xác nhận thanh toán nhưng chưa thấy BO báo hoàn tất → KHÔNG dừng Bot.
      // Tiền có thể đã đi nên TUYỆT ĐỐI không đẩy lại và không mở khóa; chỉ ghi nhận, báo nhẹ và đi tiếp.
      if (/chưa xác nhận được đơn hoàn tất/i.test(String(e?.message || ""))) {
        try { await closeProcessingPanel(no); } catch (_) {}
        done.add(no);
        manual.add(no);
        try { markProviderReturned(no); } catch (_) {}
        try { recordOrderLog(no, "UNKNOWN", "Đã bấm Xác nhận thanh toán nhưng chưa xác nhận hoàn tất — cần kiểm tra tay, Tool KHÔNG đẩy lại", findRow(no)); } catch (_) {}
        log(no, "→ ĐÃ BẤM XÁC NHẬN nhưng chưa xác nhận hoàn tất → KHÔNG đẩy lại, KHÔNG mở khóa, ghi nhận kiểm tra tay → TIẾP TỤC các đơn khác");
        try { showStuckLockNotice(no, "Đã bấm Xác nhận thanh toán nhưng chưa thấy hoàn tất — kiểm tra tay (Tool không đẩy lại)"); } catch (_) {}
        return { state: "SKIP", reason: "CONFIRM_UNVERIFIED_CONTINUE" };
      }

      healthError(e, /timeout|chờ|không xác nhận/i.test(String(e?.message||"")));
      failed.add(no);
      hardStop = true;
      console.error(TAG, no, "→ DỪNG TOÀN BỘ BOT:", e);
      showBotStopPopup(no, String(e?.message || e));
      return { state: "STOP", error: e };
    }
  }

  async function runOnce() {
    try {
      if (window.AD88_LICENSE?.getStatus) {
        const lic = await window.AD88_LICENSE.getStatus();
        if (!lic.ok) {
          log("LICENSE: " + (lic.message || "Chưa kích hoạt License") + ".");
          return false;
        }
      }
    } catch (e) {
      log("LICENSE: Không thể xác minh License.");
      return false;
    }
    if (running || hardStop) return;

    running = true;
    stopRequested = false;

    try {
      const list = rows().filter(r => orderNo(r));
      log("Tìm thấy", list.length, "đơn trên danh sách. Chỉ xử lý 1 đơn.");

      // ĐÃ TẮT HOÀN TOÀN NHÁNH XỬ LÝ "Hoàn trả".
      // Ngoài ra, đơn có "Làm mới gọi lại" cũng là SKIP tuyệt đối.
      // processOne() nhận diện và bỏ qua, sau đó AUTO tiếp tục đơn khác.

      // 1.4.161: ƯU TIÊN mở khóa đơn nhà thứ 3 trả về TRƯỚC khi xử lý đơn mới (quét cả danh sách, nhẹ, tối đa 3 giây/lần).
      if (toolSetting("returnUnlock", true) && Date.now() - lastReturnedScanAt >= 3000) {
        lastReturnedScanAt = Date.now();
        for (const row of list) {
          if (stopRequested || hardStop) break;
          try {
            if (!providerFailedMark(row)) continue;
            const no = orderNo(row);
            const rr = await handleProviderReturnedOrder(row, no);
            if (rr && rr.state === "SKIP") {
              skipped.add(no);
              recordOrderLog(no, "SKIP", rr.reason || "Nhà thứ 3 trả đơn về", row);
              currentOrder = "";
            }
          } catch (eRet) {
            console.warn(TAG, "→ lỗi khi quét đơn nhà thứ 3 trả về (bỏ qua, Bot vẫn chạy)", eRet);
          }
        }
      }

      for (const row of list) {
        if (stopRequested || hardStop) break;

        const no = orderNo(row);

        // 1.4.159: đơn nhà thứ 3 trả về phải được xét TRƯỚC kiểm tra done/failed, vì đơn Tool đã đẩy
        // thì luôn nằm trong done → trước đây bị bỏ qua nên không bao giờ được mở khóa.
        if (!done.has(no) || providerFailedMark(row)) {
          try {
            if (providerFailedMark(row)) {
              const rr = await handleProviderReturnedOrder(row, no);
              if (rr) {
                if (rr.state === "SKIP") {
                  skipped.add(no);
                  recordOrderLog(no, "SKIP", rr.reason || "Nhà thứ 3 trả đơn về", row);
                }
                currentOrder = "";
                continue;
              }
            }
          } catch (eRet) {
            console.warn(TAG, no, "→ lỗi khi xử lý đơn nhà thứ 3 trả về (bỏ qua, Bot vẫn chạy)", eRet);
            continue;
          }
        }

        if (done.has(no) || failed.has(no)) continue;

        const processStartedAt = Date.now();
        const result = await processOne(row);
        const processElapsed = Date.now() - processStartedAt;
        health.actionSamples.push(processElapsed);
        if (health.actionSamples.length > HEALTH_MAX_SAMPLES) health.actionSamples.shift();
        healthFinishOrder(result.state, no);

        // Thống kê UI được phân loại theo kết quả cuối cùng của processOne:
        // DONE = Đã xử lý, SKIP = Bỏ qua, STOP = Cần kiểm tra.
        if (result.state === "IGNORE") {
          // IGNORE không phải kết quả xử lý. Không cộng vào Bỏ qua, không ghi Journal.
          currentOrder = "";
          continue;
        }

        if (result.state === "DONE") {
          processed.add(no);
          recordOrderLog(no, "DONE", result.reason || "", row);
          currentOrder = "";
          // Đơn đã thành công: không dừng AUTO. Tiếp tục ngay với đơn kế tiếp
          // trong cùng lượt; mỗi đơn vẫn được xử lý tuần tự, không chạy song song.
          continue;
        }

        if (result.state === "RETURN") {
          returned.add(no);
          recordOrderLog(no, "RETURN", result.reason || "Đơn đã buộc hủy và trả lại", row);
          currentOrder = "";
          // Đơn trả lại đã kết thúc, chuyển sang đơn khác.
        }

        if (result.state === "STOP") {
          manual.add(no);
          recordOrderLog(no, "STOP", result.reason || result.error?.message || "Cần kiểm tra thủ công", row);
          currentOrder = no;
          stopAuto();
          break;
        }

        if (result.state === "SKIP") {
          skipped.add(no);
          recordOrderLog(no, "SKIP", result.reason || "Đơn được bỏ qua theo quy tắc", row);
          currentOrder = "";
        }

        // SKIP → tìm một đơn khác chưa khóa bởi người khác.
      }
    } finally {
      running = false;
    }
  }

  function onTargetPage() {
    return /\/financialManagementNew\//i.test(location.pathname) &&
      /activeName=finance_withdraw_audit/i.test(location.search);
  }

  let autoTimer = null;
  let autoNextTimer = null;

  // 1.4.167: rà khóa định kỳ (chạy cả khi Bot đang dừng; Chrome có thể làm chậm tab ẩn nhưng vẫn chạy ~1 phút/lần).
  setInterval(() => { lockWatchdogTick().catch(() => {}); }, 30000);
  // 1.4.169: tự cập nhật số dư nhà thứ 3 (≥60 giây/lần, chỉ đọc).
  setTimeout(() => { balanceFeedTick().catch(() => {}); }, 5000);
  setTimeout(() => { balanceRefreshTick().catch(() => {}); }, 12000);
  setInterval(() => { balanceRefreshTick().catch(() => {}); }, 20000);
  setInterval(() => { balanceFeedTick().catch(() => {}); }, 20000);

  function nextDelayMs() {
    const min = Math.max(100, Number(XNK_CONFIG.nextOrderDelayMinMs) || 350);
    const max = Math.max(min, Number(XNK_CONFIG.nextOrderDelayMaxMs) || 3000);
    const base = Math.max(min, Math.min(max, Number(XNK_CONFIG.nextOrderDelayMs) || 2200));
    const queue = healthQueueCount();
    const p50 = percentile(health.processSamples,50) || null;
    if (XNK_CONFIG.autoSync === false) return base;
    // Khi hàng đợi đang có nhiều đơn và đơn vừa rồi đã hoàn tất sạch,
    // giảm cooldown; khi không có hàng đợi thì giữ mức cơ sở.
    if (queue >= 5 && p50 != null && p50 < 30000) return min;
    if (queue >= 2 && p50 != null && p50 < 15000) return Math.max(min, Math.round(base * 0.55));
    return Math.min(max, Math.max(min, Math.round(base * 0.75)));
  }

  function scheduleNext() {
    if (!autoTimer || hardStop || stopRequested) return;
    clearTimeout(autoNextTimer);
    autoNextTimer = setTimeout(async () => {
      autoNextTimer = null;
      if (!onTargetPage() || running || hardStop || stopRequested) {
        if (autoTimer && !hardStop && !stopRequested) scheduleNext();
        return;
      }
      await runOnce();
      if (autoTimer && !hardStop && !stopRequested) scheduleNext();
    }, nextDelayMs());
  }

  async function startAuto() {
    if (autoTimer || hardStop) return;
    log("AUTO: bắt đầu. Quy tắc: 1 đơn → xử lý xong → mới sang đơn tiếp.");
    autoTimer = true;
    stopRequested = false;
    await runOnce();
    if (autoTimer && !hardStop && !stopRequested) scheduleNext();
  }

  function stopAuto() {
    clearTimeout(autoNextTimer);
    autoNextTimer = null;
    autoTimer = null;
    stopRequested = true;
    log("AUTO: đã dừng.");
  }

  function showBotStopPopup(no, message) {
    const old = document.getElementById("ad88-xnk-stop-popup");
    if (old) old.remove();

    const box = document.createElement("div");
    box.id = "ad88-xnk-stop-popup";
    box.style.cssText = `
      position:fixed;left:50%;bottom:110px;transform:translateX(-50%);
      z-index:2147483647;width:430px;background:#fff3cd;border:2px solid #d39e00;
      border-radius:10px;padding:14px 16px;box-shadow:0 8px 28px rgba(0,0,0,.25);
      font:14px Arial,sans-serif
    `;
    box.innerHTML = `
      <b style="color:#856404">AD88 XNK BOT ĐÃ DỪNG</b>
      <div style="margin-top:7px"><b>Đơn:</b> ${no}</div>
      <div style="margin-top:5px">${message}</div>
      <div style="margin-top:7px;color:#856404">
        Không khóa đơn tiếp theo cho đến khi bạn kiểm tra lỗi.
      </div>
    `;
    document.body.appendChild(box);
  }

  // 1.4.156: báo nhẹ, KHÔNG chặn thao tác: danh sách đơn kẹt khóa cần mở khóa tay (Bot vẫn chạy tiếp).
  const stuckLockOrders = [];
  function showStuckLockNotice(no, title) {
    if (!stuckLockOrders.includes(no)) stuckLockOrders.push(no);
    let box = document.getElementById("ad88-xnk-stuck-popup");
    if (!box) {
      box = document.createElement("div");
      box.id = "ad88-xnk-stuck-popup";
      box.style.cssText = "position:fixed;left:16px;bottom:110px;z-index:2147483646;width:330px;background:#fff3cd;border:2px solid #d39e00;border-radius:10px;padding:10px 12px;box-shadow:0 8px 28px rgba(0,0,0,.25);font:13px Arial,sans-serif;color:#533f03";
      document.body.appendChild(box);
    }
    const shown = stuckLockOrders.slice(-5);
    box.innerHTML = '<b>' + String(title || "Đơn kẹt khóa — cần mở khóa tay").replace(/[<>&]/g, "") + '</b> <span id="ad88-xnk-stuck-x" style="float:right;cursor:pointer;font-weight:700">×</span>' +
      '<div style="margin-top:6px;word-break:break-all">' + shown.map(x => String(x).replace(/[<>&"]/g, "")).join("<br>") + '</div>' +
      '<div style="margin-top:6px;color:#856404">Bot vẫn đang chạy tiếp các đơn khác.</div>';
    const x = document.getElementById("ad88-xnk-stuck-x");
    if (x) x.onclick = () => { try { box.remove(); stuckLockOrders.length = 0; } catch (_) {} };
  }

  function makeUI() {
    if (document.getElementById("ad88-xnk-bot")) return;

    const box = document.createElement("div");
    box.id = "ad88-xnk-bot";
    box.innerHTML = `
      <div id="ad88-xnk-bot-title">AWEI — AD88 XNK BOT v0.6.5 ALL-IN-ONE — TEST</div>
      <div id="ad88-xnk-bot-status">
        1 đơn → xử lý xong → mới khóa đơn tiếp theo
      </div>
      <div style="margin-top:8px;display:flex;gap:6px">
        <button id="ad88-xnk-start" style="cursor:pointer">▶ Chạy</button>
        <button id="ad88-xnk-stop" style="cursor:pointer">■ Dừng</button>
      </div>
      <div style="font-size:11px;margin-top:6px">
        VALID → đẩy nhà thứ 3. INVALID → ghi chú + trả lại.
        Lỗi/không rõ kết quả → dừng toàn bộ.
      </div>
    `;

    document.body.appendChild(box);
    // Nút CHECK được gắn trực tiếp cạnh mã lệnh và tự gắn lại sau mỗi lần Vue rerender.
    installManualCheckButtons();

    box.querySelector("#ad88-xnk-start").onclick = () => {
      hardStop = false;
      stopRequested = false;
      const st = box.querySelector("#ad88-xnk-bot-status");
      if (st) st.textContent = "ĐANG CHẠY — 1 đơn → xử lý xong → mới khóa đơn tiếp theo";
      startAuto();
    };

    box.querySelector("#ad88-xnk-stop").onclick = () => {
      stopAuto();
      const st = box.querySelector("#ad88-xnk-bot-status");
      if (st) st.textContent = "ĐÃ DỪNG — bấm Chạy để tiếp tục";
    };

    // TEST: tự bắt đầu sau khi giao diện đã dựng xong.
    // Vẫn giữ nút Chạy/Dừng để người dùng kiểm soát.
    if (onTargetPage()) {
      setTimeout(() => {
        if (!hardStop && !autoTimer) {
          const st = box.querySelector("#ad88-xnk-bot-status");
          if (st) st.textContent = "ĐANG KHỞI ĐỘNG…";
          startAuto();
          setTimeout(() => {
            const st2 = box.querySelector("#ad88-xnk-bot-status");
            if (st2 && autoTimer) st2.textContent = "ĐANG CHẠY — 1 đơn → xử lý xong → mới khóa đơn tiếp theo";
          }, 300);
        }
      }, 700);
    }
  }

  window.AD88_XNK_BOT = {
    runOnce,
    start: startAuto,
    stop: stopAuto,
    reset: () => {
      done.clear();
      failed.clear();
      processed.clear();
      skipped.clear();
      manual.clear();
      returned.clear();
      clearOrderLogs();
      currentOrder = "";
      health.startedAt = Date.now();
      health.lastHeartbeatAt = Date.now();
      health.lastActionAt = 0;
      health.currentStartedAt = 0;
      health.currentStep = "Sẵn sàng";
      health.processSamples = [];
      health.actionSamples = [];
      health.apiSamples = [];
      health.errors = 0;
      health.timeouts = 0;
      health.completed = 0;
      health.skipped = 0;
      health.manual = 0;
      health.lastError = "";
      health.lastErrorAt = 0;
      providerCursor = 0;
      providerHistory.clear();
      hardStop = false;
      stopRequested = false;
      log("đã reset lịch sử phiên");
    },
    status: () => ({
      running,
      auto: !!autoTimer,
      hardStop,
      currentOrder,
      done: [...done],
      failed: [...failed],
      processed: [...processed],
      skipped: [...skipped],
      manual: [...manual],
      returned: [...returned],
      orderLogs: readOrderLogs(),
      health: healthSnapshot()
    })
  };

  // UI cũ được thay bằng AWEI XNK TOOL UI riêng. Core xử lý đơn giữ nguyên.
  log("Đã khởi động v0.6.5 ALL-IN-ONE TEST.");
})();
