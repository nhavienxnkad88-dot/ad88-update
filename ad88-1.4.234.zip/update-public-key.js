// AD88 XNK TOOL — khóa CÔNG KHAI kiểm tra chữ ký bản cập nhật (an toàn để phát hành).
// 1.4.232: con dấu mới (con dấu cũ bị mất). Bản cài tay 1 lần.
window.AD88_UPDATE_PUBLIC_KEY = {"kty": "EC", "crv": "P-256", "x": "yZjKr8hcvGSLhFxxWTH-tM9z4xy24rwItBNV64Qo_eM", "y": "HaY3Gf1LdEUSjgpSno4K-8NqMQ-hOgLhYjj3LlJ-luE"};
