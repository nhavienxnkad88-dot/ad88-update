// AD88 XNK TOOL — UI shell. Core order-processing remains in content.js.
(() => {
  'use strict';
  const S={running:false,processed:0,skipped:0,manual:0,lastOrder:'—',speedHistory:[]};
  const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const q=(sel,root=document)=>root.querySelector(sel);
  const formatAmountInput=(v,currency='VND')=>{
    if(currency==='USDT'){
      let s=String(v??'').replace(/,/g,'.').replace(/[^0-9.]/g,'');
      const parts=s.split('.');
      if(parts.length>2)s=parts[0]+'.'+parts.slice(1).join('');
      return s;
    }
    const d=String(v??'').replace(/[^0-9]/g,'');
    return d?d.replace(/\B(?=(\d{3})+(?!\d))/g,'.'):'';
  };
  const parseAmountInput=(v,currency='VND')=>{
    if(currency==='USDT'){
      const s=String(v??'').replace(/,/g,'.').trim();
      if(s==='')return null;
      const n=Number(s);
      return Number.isFinite(n)?n:null;
    }
    const d=String(v??'').replace(/[^0-9]/g,'');
    return d===''?null:Number(d);
  };
  function getProviderConfigState(){
    let saved={};
    try{saved=JSON.parse(localStorage.getItem('AD88_XNK_PROVIDER_CONFIG')||'{}')||{};}catch{saved={};}
    const out={};
    for(const key of PROVIDERS){
      const def=PROVIDER_CONFIG_DEFAULTS[key]||{};
      let item=saved[key];
      if(!item && typeof AD88_providerCanonical==='function'){
        for(const [savedKey,v] of Object.entries(saved)){
          const canonical=AD88_providerCanonical(savedKey);
          if(canonical===key){item=v;break;}
          if(v && AD88_providerCanonical(v.name||'')===key){item=v;break;}
        }
      }
      out[key]={
        name:def.name||key,
        currency:def.currency||'VND',
        min:item && item.min!==undefined && item.min!==null && item.min!=='' ? item.min : (def.min??null),
        max:item && item.max!==undefined && item.max!==null && item.max!=='' ? item.max : (def.max??null)
      };
    }
    return out;
  }
  function setProviderConfigState(state){
    const out={};
    for(const key of PROVIDERS){
      const def=PROVIDER_CONFIG_DEFAULTS[key]||{};
      const x=state?.[key]||{};
      out[key]={
        name:def.name||key,
        currency:def.currency||'VND',
        min:x.min===undefined?null:x.min,
        max:x.max===undefined?null:x.max
      };
    }
    localStorage.setItem('AD88_XNK_PROVIDER_CONFIG',JSON.stringify(out));
    window.dispatchEvent(new CustomEvent('AD88_PROVIDER_CONFIG_CHANGED',{detail:out}));
  }
  // Provider Registry: toàn bộ tên/currency/MIN/MAX/alias lấy từ provider-registry.js.
  const PROVIDERS = typeof AD88_providerNames === 'function' ? AD88_providerNames() : [];
  const PROVIDER_CONFIG_DEFAULTS = typeof AD88_providerDefinition === 'function'
    ? Object.fromEntries(PROVIDERS.map(k => { const p=AD88_providerDefinition(k)||{}; return [k,{name:p.name||k,currency:p.currency||'VND',min:p.min??null,max:p.max??null}]; }))
    : {};

  const LED_COLORS=[
    {name:'Xanh AD88',value:'#2DB38D'},
    {name:'Cyan',value:'#00E5FF'},
    {name:'Xanh dương',value:'#2196FF'},
    {name:'Tím',value:'#9C5CFF'},
    {name:'Hồng',value:'#FF4FA3'},
    {name:'Đỏ',value:'#FF4D6D'},
    {name:'Cam',value:'#FF9D3D'},
    {name:'Vàng',value:'#FFD43B'},
    {name:'Xanh lá',value:'#35E07F'},
    {name:'Trắng',value:'#F4FAFF'},
    {name:'Xanh băng',value:'#7DD3FC'},
    {name:'Tím hồng',value:'#D946EF'}
  ];
  function getProviderState(){
    try{return JSON.parse(localStorage.getItem('AD88_XNK_PROVIDER_TOGGLES')||'{}')}catch{return {}}
  }
  function setProviderState(s){localStorage.setItem('AD88_XNK_PROVIDER_TOGGLES',JSON.stringify(s));window.dispatchEvent(new CustomEvent('AD88_PROVIDER_TOGGLES_CHANGED',{detail:s}));}
  function getLedColor(){return localStorage.getItem('AD88_XNK_LED_COLOR')||'#2DB38D'}
  function setLedColor(c){localStorage.setItem('AD88_XNK_LED_COLOR',c);document.documentElement.style.setProperty('--ad88-led',c);window.dispatchEvent(new CustomEvent('AD88_LED_COLOR_CHANGED',{detail:c}));}
  function getLedSettings(){
    const num=(k,d)=>{const v=Number(localStorage.getItem(k));return Number.isFinite(v)?v:d};
    return {brightness:num('AD88_XNK_LED_BRIGHTNESS',90),speed:num('AD88_XNK_LED_SPEED',50),effect:localStorage.getItem('AD88_XNK_LED_EFFECT')||'single',enabled:localStorage.getItem('AD88_XNK_LED_ENABLED')!=='0',thick:num('AD88_XNK_LED_THICK',60)};
  }
  function setLedSetting(k,v){localStorage.setItem(k,String(v));window.dispatchEvent(new CustomEvent('AD88_LED_SETTINGS_CHANGED',{detail:{key:k,value:v}}));}
  const TOOL_SETTINGS_DEFAULTS={auto:true,bank:true,unlock:true,sound:true,returnReasonLog:true};
  function getToolSettings(){
    const out={};
    for(const [k,d] of Object.entries(TOOL_SETTINGS_DEFAULTS)){
      const raw=localStorage.getItem('AD88_XNK_SETTING_'+k);
      out[k]=raw===null?d:raw==='true';
    }
    return out;
  }
  function getToolPanelOpen(){
    const raw=localStorage.getItem('AD88_XNK_TOOL_PANEL_OPEN');
    return raw===null ? true : raw==='true';
  }
  function setToolPanelOpen(v){
    localStorage.setItem('AD88_XNK_TOOL_PANEL_OPEN',String(!!v));
  }
  function setToolSetting(k,v){
    localStorage.setItem('AD88_XNK_SETTING_'+k,String(!!v));
    window.dispatchEvent(new CustomEvent('AD88_TOOL_SETTING_CHANGED',{detail:{key:k,value:!!v}}));
  }
  function playNotice(){
    try{
      if(!getToolSettings().sound)return;
      const Ctx=window.AudioContext||window.webkitAudioContext;
      if(!Ctx)return;
      const ctx=new Ctx(); const osc=ctx.createOscillator(); const gain=ctx.createGain();
      osc.type='sine'; osc.frequency.value=880; gain.gain.setValueAtTime(.045,ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(.001,ctx.currentTime+.16); osc.connect(gain);gain.connect(ctx.destination);
      osc.start();osc.stop(ctx.currentTime+.16);
    }catch{}
  }

  function healthStatus(){
    try{return window.AD88_XNK_BOT?.status?.()?.health||{};}catch{return {}}
  }
  function fmtMs(v){
    const n=Number(v);
    if(!Number.isFinite(n)) return '—';
    if(n<1000) return Math.round(n)+'ms';
    return (n/1000).toFixed(n>=10000?0:1)+'s';
  }
  function fmtUptime(v){
    const n=Math.max(0,Math.floor(Number(v)||0)/1000);
    const s=Math.floor(n%60), m=Math.floor(n/60)%60, h=Math.floor(n/3600);
    return [h,m,s].map((x,i)=>i===0?String(x).padStart(2,'0'):String(x).padStart(2,'0')).join(':');
  }
  function healthTone(h){
    if(h.state==='ERROR') return ['bad','LỖI'];
    if(h.state==='WARNING') return ['warn','CẢNH BÁO'];
    if(h.state==='IDLE') return ['idle','ĐANG CHỜ'];
    return ['good','TỐT'];
  }
  function renderHealthPage(el){
    const h=healthStatus(), [tone,label]=healthTone(h), avg=fmtMs(h.avgProcessMs), p95=fmtMs(h.p95Ms), p99=fmtMs(h.p99Ms);
    el.innerHTML=head('Sức khỏe & tốc độ')+`<div class="ad88-health-page ad88-detail-page"><div class="health-hero ${tone}"><span class="health-pulse"></span><div><b>${label}</b><small>${h.auto?'Tool đang tự động xử lý':'Tool chưa chạy tự động'}</small></div><strong>${h.queue||0}<small>đơn chờ</small></strong></div><div class="health-grid ad88-detail-grid"><div><span>Heartbeat</span><b>${fmtMs(h.heartbeatMs)}</b></div><div><span>Last action</span><b>${fmtMs(h.lastActionMs)}</b></div><div><span>Website / DOM</span><b>${h.currentStep||'Ready'}</b></div><div><span>API TB</span><b>${fmtMs(h.avgApiMs)}</b></div><div><span>Lỗi</span><b class="${h.errors?'bad-t':''}">${h.errors||0}</b></div><div><span>Timeout</span><b class="${h.timeouts?'bad-t':''}">${h.timeouts||0}</b></div></div><div class="health-section-title ad88-detail-section-title">TỐC ĐỘ XỬ LÝ</div><div class="speed-grid ad88-detail-grid"><div><span>Trung bình</span><b>${avg}</b></div><div><span>P50</span><b>${fmtMs(h.p50Ms)}</b></div><div><span>P95</span><b>${p95}</b></div><div><span>P99</span><b>${p99}</b></div><div><span>Nhanh nhất</span><b>${fmtMs(h.fastestMs)}</b></div><div><span>Chậm nhất</span><b>${fmtMs(h.slowestMs)}</b></div></div><div class="health-current ad88-detail-current"><div><span>Đơn hiện tại</span><b>${esc(h.currentOrder||'—')}</b></div><div><span>Bước hiện tại</span><b>${esc(h.currentStep||'Sẵn sàng')}</b></div><div><span>Thời gian đơn</span><b>${fmtMs(h.currentElapsedMs)}</b></div><div><span>Uptime</span><b>${fmtUptime(h.uptimeMs)}</b></div></div>${h.lastError?`<div class="health-error">⚠ ${esc(h.lastError)}</div>`:''}<div class="health-note ad88-detail-note">Đánh giá dựa trên tiến trình thực tế, thời gian xử lý, heartbeat, API, timeout và trạng thái DOM.</div></div>`;
    q('[data-back]',el).onclick=back;
  }

  function create(){
    if(q('#ad88-xnk-tool-root')) return;
    const savedAction=Number(localStorage.getItem('AD88_XNK_CFG_ACTION_TIMEOUT'));
    const savedBank=Number(localStorage.getItem('AD88_XNK_CFG_BANK_TIMEOUT'));
    const savedDelay=Number(localStorage.getItem('AD88_XNK_CFG_NEXT_DELAY'));
    if(window.XNK_CONFIG){
      if(Number.isFinite(savedAction)&&savedAction>0) window.XNK_CONFIG.actionTimeoutMs=savedAction;
      if(Number.isFinite(savedBank)&&savedBank>0) window.XNK_CONFIG.bankCheckTimeoutMs=savedBank;
      if(Number.isFinite(savedDelay)&&savedDelay>0) window.XNK_CONFIG.nextOrderDelayMs=savedDelay;
      const bool=(k,d)=>{const v=localStorage.getItem(k);return v===null?d:v==='true'};
      const num=(k,d)=>{const v=Number(localStorage.getItem(k));return Number.isFinite(v)?v:d};
      window.XNK_CONFIG.autoSync=bool('AD88_XNK_AUTO_SYNC',window.XNK_CONFIG.autoSync!==false);
      window.XNK_CONFIG.pollMinMs=num('AD88_XNK_POLL_MIN',window.XNK_CONFIG.pollMinMs||100);
      window.XNK_CONFIG.pollMaxMs=num('AD88_XNK_POLL_MAX',window.XNK_CONFIG.pollMaxMs||650);
      window.XNK_CONFIG.nextOrderDelayMinMs=num('AD88_XNK_DELAY_MIN',window.XNK_CONFIG.nextOrderDelayMinMs||350);
      window.XNK_CONFIG.nextOrderDelayMaxMs=num('AD88_XNK_DELAY_MAX',window.XNK_CONFIG.nextOrderDelayMaxMs||3000);
    }
    document.documentElement.style.setProperty('--ad88-led',getLedColor());
    const root=document.createElement('div');root.id='ad88-xnk-tool-root';root.dataset.ui='new';
    root.innerHTML=`
      <button id="ad88-tool-fab" title="AD88 XNK TOOL"><span>AD88</span><small>TOOL</small></button>
      <section id="ad88-tool-panel" class="${getToolPanelOpen()?'':'ad88-hidden'}">
        <div class="ad88-resize-handle ad88-resize-br" id="ad88-resize-handle"></div><div class="ad88-resize-handle ad88-resize-tl" id="ad88-resize-handle-tl"></div>
        <header class="ad88-head new-head" style="--ad88-head-art:url('${chrome.runtime.getURL('assets/ad88-header-christmas.svg')}');--ad88-logo:url('${chrome.runtime.getURL('assets/ad88-logo.png')}')">
          <div class="ad88-brand new-brand"><strong class="ad88-logo-text"><i>AD</i><b>88</b></strong><span><b>XNK TOOL</b><small>v${AD88_VERSION}</small></span></div>
          <div class="new-head-status"><span class="status-dot"></span><div><b id="tool-run-status">Đang chạy</b><small id="tool-runtime">00:00:00</small></div></div>
          <div class="ad88-head-actions"><button data-act="min" title="Thu gọn">−</button><button data-act="close" title="Đóng">×</button></div>
        <div class="ad88-snow" aria-hidden="true"><i></i><i></i><i></i></div></header>
        <div id="ad88-led-palette" class="ad88-led-palette ad88-hidden"><div class="ad88-led-palette-title">MÀU ĐÈN LED</div><div class="ad88-led-swatches">${LED_COLORS.map(c=>`<button type="button" data-led="${c.value}" title="${c.name}" aria-label="${c.name}" style="--c:${c.value}"><span></span></button>`).join('')}</div></div>
        <main id="ad88-tool-main" class="new-main">
          <div class="new-actions"><button class="run" data-act="run" type="button"><span>▶</span><b>CHẠY</b></button><button class="stop" data-act="stop" type="button"><span>■</span><b>DỪNG</b></button><button data-page="settings" title="Cài đặt"><span>⚙</span><small>Cài đặt</small></button><button data-page="log" title="Nhật ký"><span>▤</span><small>Nhật ký</small></button><button data-act="stats" title="Thống kê"><span>▥</span><small>THỐNG KÊ</small></button></div>
          <div class="new-home-content" id="ad88-home-content">
          <div class="new-dashboard">
            <section class="new-card health-card"><div class="new-card-title"><span>❤</span><b>BẢNG SỨC KHỎE</b><i>?</i><strong id="tool-health-label">TỐT</strong></div>
              <div class="health-list">
                <div><span>▣</span><label>Tool</label><b id="new-health-tool">Đang chạy</b></div>
                <div><span>◎</span><label>Kết nối website</label><b id="new-health-web">Ổn định</b></div>
                <div><span>▣</span><label>API</label><b id="new-health-api">—</b></div>
                <div><span>▣</span><label>DOM</label><b id="new-health-dom">Ready</b></div>
                <div><span>◉</span><label>Queue</label><b id="new-health-queue">0 đơn</b></div>
                <div><span>↻</span><label>Đang xử lý</label><b id="new-health-order">—</b></div>
                <div><span>»</span><label>Bước hiện tại</label><b id="new-health-step">Sẵn sàng</b></div>
                <div><span>◷</span><label>Last action</label><b id="new-health-last">—</b></div>
                <div><span>△</span><label>Lỗi / Timeout</label><b id="new-health-errors">0 / 0</b></div>
              </div>
            </section>
            <section class="new-card speed-card"><div class="new-card-title"><span>◔</span><b>TỐC ĐỘ XỬ LÝ</b><i>?</i><select id="new-speed-window"><option>10 phút gần nhất</option><option>30 phút gần nhất</option><option>Hôm nay</option></select></div>
              <div class="speed-chart-wrap"><div class="speed-axis">Đơn/phút</div><svg id="tool-speed-chart" viewBox="0 0 220 92" preserveAspectRatio="none" aria-label="Biểu đồ tốc độ"><defs><linearGradient id="speedFill" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stop-color="#2DB38D" stop-opacity=".42"/><stop offset="1" stop-color="#2DB38D" stop-opacity="0"/></linearGradient></defs><path id="speed-area" fill="url(#speedFill)" d="M0 80 L0 80 L220 80 Z"></path><polyline id="speed-line" fill="none" stroke="#2DB38D" stroke-width="2" points="0,80 220,80"></polyline><g id="speed-dots"></g></svg><div class="speed-times"><span>10:40</span><span>10:42</span><span>10:44</span><span>10:46</span><span>10:48</span><span>10:50</span></div></div>
              <div class="speed-metrics"><div><span>⚡</span><b id="tool-speed">—</b><small>đơn/phút</small></div><div><span>◷</span><b id="tool-avg">—</b><small>TB mỗi đơn</small></div><div><span>▶</span><b id="tool-fastest">—</b><small>Nhanh nhất</small></div><div><span>⌛</span><b id="tool-slowest">—</b><small>Chậm nhất</small></div></div>
            </section>
          </div>
          <section class="new-card current-card"><div class="new-card-title"><span>◌</span><b>ĐƠN HIỆN TẠI</b><button data-page="health">Chi tiết <em>›</em></button></div><div class="current-grid"><div><small>Mã đơn</small><b id="new-order-id">—</b></div><div><small>Số tiền</small><b id="new-order-amount">—</b><em id="new-order-currency">VNĐ</em></div><div><small>Nhà thứ ba</small><b id="new-order-provider">—</b></div><div><small>Thời gian</small><b id="new-order-time">00:00</b></div><div><small>Trạng thái</small><b class="current-status" id="new-order-status">Đang kiểm tra</b></div></div></section>
          <div class="new-hidden-stats" aria-hidden="true"><span id="tool-order">—</span><span id="tool-done">0</span><span id="tool-skip">0</span><span id="tool-manual">0</span></div>
          </div>
          <section id="ad88-stats-view" class="ad88-stats-view ad88-hidden" aria-label="Thống kê xử lý"></section>
          <div class="new-mini-footer"><button data-page="providers">Nhà thứ 3</button><button data-page="about">Thông tin Tool</button><span>v${AD88_VERSION}</span></div>
        </main>
        <section id="ad88-tool-sub" class="ad88-hidden"></section>
      </section>`;
    document.body.appendChild(root);
    ensureLedFrame(q('#ad88-tool-panel',root));
    restorePosition(root);bind(root);refreshCore();
    const panel=q('#ad88-tool-panel',root);
    if(panel && 'ResizeObserver' in window){const ro=new ResizeObserver(()=>{updateNewUiScale(panel);updateLedFrame(panel);});ro.observe(panel);}
    window.addEventListener('AD88_LED_COLOR_CHANGED',()=>updateLedFrame(panel));
    window.addEventListener('AD88_LED_SETTINGS_CHANGED',()=>updateLedFrame(panel));
    window.addEventListener('resize',()=>{updateNewLayout(panel);updateLedFrame(panel);clampRootToViewport(root,true);savePosition(root);});
  }
  function ensureLedFrame(panel){
    if(!panel || panel.querySelector('.ad88-led-frame')) return;
    const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');
    svg.classList.add('ad88-led-frame');
    svg.setAttribute('aria-hidden','true');
    panel.appendChild(svg);
    updateLedFrame(panel);
  }
  // LED viền v2: nét sắc (không dùng blur filter nên không bị lem), đuôi sao chổi chuyển mờ dần,
  // vầng sáng bằng lớp nét rộng trong suốt. Mỗi hiệu ứng được dựng riêng.
  function buildLedMarkup(w,h,r,ls){
    const bright=Math.max(.1,Math.min(5,ls.brightness/100));
    const clip=v=>Math.max(0,Math.min(1,v));
    const D=Math.max(1.2,5.5-(Math.max(10,Math.min(100,ls.speed))/100)*4.5);
    const sw=(2.6+Math.min(bright,2)*.4).toFixed(2);
    const geo=`x="1.5" y="1.5" width="${Math.max(1,w-3)}" height="${Math.max(1,h-3)}" rx="${Math.max(1,r-1)}" ry="${Math.max(1,r-1)}" pathLength="1000" fill="none" vector-effect="non-scaling-stroke"`;
    const rect=(cls,extra,style)=>`<rect class="led-seg ${cls}" ${geo} ${extra} style="${style}"/>`;
    let out='';
    const track=op=>rect('led-track',`stroke-width="1"`,`stroke:currentColor;opacity:${clip(op*bright).toFixed(2)}`);
    const comet=(scale,dur,delay,rev,pieces,glow,col)=>{const C=col||'currentColor';
      const L=[260,190,130,85,50,24].slice(6-pieces).map(v=>Math.round(v*scale));
      const O=[.16,.26,.4,.58,.8,1].slice(6-pieces);
      let m='';
      L.forEach((len,i)=>{
        const o=rev?0:len, anim=rev?'led-run-rev':'led-run';
        const st=`stroke:${C};stroke-dasharray:${len} ${1000-len};--o:${o}px;animation:${anim} ${dur}s linear ${-delay}s infinite`;
        if(glow) m+=rect('led-glow',`stroke-width="9" stroke-linecap="round"`,st+`;opacity:${clip(O[i]*.22*bright).toFixed(2)}`);
        m+=rect('led-core',`stroke-width="${sw}" stroke-linecap="round"`,st+`;opacity:${clip(O[i]*(.55+.45*bright)).toFixed(2)}`);
      });
      const hl=Math.max(4,Math.round(12*scale));
      m+=rect('led-head',`stroke-width="1.6" stroke-linecap="round"`,`stroke:#fff;stroke-dasharray:${hl} ${1000-hl};--o:${hl}px;animation:led-run ${dur}s linear ${-delay}s infinite;opacity:${clip(.9*Math.min(1,bright)).toFixed(2)}`);
      return m;
    };
    switch(ls.effect==='two'?'two-way':ls.effect){
      case 'two-way': out=track(.16)+comet(.8,D,0,false,6,true)+comet(.8,D,D/2,true,6,true);break;
      case 'multi': out=track(.16)+[0,1,2,3].map(i=>comet(.42,D*1.15,D*1.15*i/4,false,4,false)).join('');break;
      case 'comet': out=track(.14)+comet(1.9,D*1.25,0,false,6,true);break;
      case 'pulse': out=rect('led-glow',`stroke-width="7"`,`stroke:currentColor;opacity:${clip(.2*bright)};animation:led-breathe ${Math.max(1.2,D*.6)}s ease-in-out infinite`)+rect('led-core',`stroke-width="${sw}"`,`stroke:currentColor;animation:led-breathe ${Math.max(1.2,D*.6)}s ease-in-out infinite`);break;
      case 'rainbow': {
        const N=12,len=1000/N;
        out=Array.from({length:N},(_,i)=>rect('led-core',`stroke-width="${sw}"`,`stroke:hsl(${i*360/N},95%,${Math.round(52+Math.min(bright,1.5)*6)}%);stroke-dasharray:${len+2} ${1000-len-2};--o:${-i*len}px;animation:led-run ${D*1.6}s linear infinite;opacity:${clip(.55+.45*bright)}`)).join('');
        out=track(.10)+out;break;}
      case 'wave': {
        const N=14,len=1000/N;
        out=track(.10)+Array.from({length:N},(_,i)=>rect('led-core',`stroke-width="${sw}"`,`stroke:currentColor;stroke-dasharray:${len-3} ${1000-len+3};stroke-dashoffset:${-i*len}px;animation:led-wave ${D*.9}s ease-in-out ${-(i/N)*D*.9}s infinite`)).join('');break;}
      case 'spark': {
        const cfg=[[1,0,false],[1.35,.4,true],[.8,.7,false]];
        out=track(.14)+cfg.map(([k,d,rev])=>{const len=14,dur=D*k*1.1;const st=`stroke:currentColor;stroke-dasharray:${len} ${1000-len};--o:${rev?0:len}px;animation:${rev?'led-run-rev':'led-run'} ${dur}s linear ${-d*dur}s infinite`;
          return rect('led-glow',`stroke-width="8" stroke-linecap="round"`,st+`;opacity:${clip(.3*bright)}`)+rect('led-core',`stroke-width="${sw}" stroke-linecap="round"`,st)+rect('led-head',`stroke-width="1.2" stroke-linecap="round"`,`stroke:#fff;stroke-dasharray:5 995;--o:${rev?0:5}px;animation:${rev?'led-run-rev':'led-run'} ${dur}s linear ${-d*dur}s infinite`);}).join('');break;}
      case 'chase': out=track(.14)+['#ff4d6d','#ffd34a','#35c6ff'].map((c,i)=>comet(.7,D*1.2,D*1.2*i/3,false,5,true,c)).join('');break;
      case 'dual': out=track(.14)+comet(.9,D,0,false,6,true)+comet(.9,D,D/2,true,6,true,'#ff4d9a');break;
      case 'snake': out=track(.14)+comet(3.2,D*1.5,0,false,6,true);break;
      case 'fire': out=track(.12)+comet(1.3,D*.9,0,false,6,true,'#ff4a1c')+comet(.85,D*.9,D*.22,false,5,true,'#ffa526')+comet(.5,D*.9,D*.4,false,4,true,'#ffe27a');break;
      case 'marquee': {const g=`stroke-linecap="round" stroke-width="3.4"`;out=track(.12)+rect('led-glow',`stroke-linecap="round" stroke-width="8"`,`stroke:currentColor;stroke-dasharray:0.1 8.9;opacity:${clip(.25*bright)};animation:led-march ${D*.5}s linear infinite`)+rect('led-core',g,`stroke:currentColor;stroke-dasharray:0.1 8.9;animation:led-march ${D*.5}s linear infinite;opacity:${clip(.6+.4*bright)}`);break;}
      case 'xmas': {const cols=['#ff3b3b','#ffd34a','#3be07a','#35c6ff'];out=track(.12)+cols.map((c,i)=>rect('led-core',`stroke-linecap="round" stroke-width="4"`,`stroke:${c};stroke-dasharray:0.1 35.9;stroke-dashoffset:${-i*9}px;filter:none;animation:led-xblink ${D*.5}s ease-in-out ${-i*D*.125}s infinite`)+rect('led-glow',`stroke-linecap="round" stroke-width="9"`,`stroke:${c};stroke-dasharray:0.1 35.9;stroke-dashoffset:${-i*9}px;opacity:.28;animation:led-xblink ${D*.5}s ease-in-out ${-i*D*.125}s infinite`)).join('');break;}
      case 'heart': out=rect('led-glow',`stroke-width="8"`,`stroke:currentColor;opacity:${clip(.22*bright)};animation:led-beat ${D*.5}s ease-in-out infinite`)+rect('led-core',`stroke-width="${sw}"`,`stroke:currentColor;animation:led-beat ${D*.5}s ease-in-out infinite`);break;
      case 'corner': {const per=2*(w+h);const pos=[(w)/per,(w+h)/per,(2*w+h)/per,1];out=track(.14)+pos.map((q,i)=>{const len=90,off=-(q*1000-len/2);const st=`stroke:currentColor;stroke-dasharray:${len} ${1000-len};stroke-dashoffset:${off}px;animation:led-corner ${D*.9}s ease-in-out ${-i*D*.9/4}s infinite`;return rect('led-glow',`stroke-width="9" stroke-linecap="round"`,st+`;opacity:0`)+rect('led-core',`stroke-width="${sw}" stroke-linecap="round"`,st);}).join('');break;}
      case 'static': out=rect('led-glow',`stroke-width="7"`,`stroke:currentColor;opacity:${clip(.16*bright)}`)+rect('led-core',`stroke-width="${sw}"`,`stroke:currentColor;opacity:${clip(.55+.45*bright)}`);break;
      default: out=track(.16)+comet(1,D,0,false,6,true);
    }
    const T=Math.max(.3,Math.min(2,(ls.thick||60)/100));
    return out.replace(/stroke-width="([\d.]+)"/g,(m,v)=>`stroke-width="${Math.max(.5,v*T).toFixed(2)}"`);
  }
  function updateLedFrame(panel){
    if(!panel) return;
    const svg=panel.querySelector('.ad88-led-frame');
    if(!svg) return;
    const w=Math.max(20,panel.clientWidth),h=Math.max(20,panel.clientHeight);
    const radius=Math.min(14,Math.max(8,parseFloat(getComputedStyle(panel).borderRadius)||12));
    const ls=getLedSettings();
    const color=getComputedStyle(document.documentElement).getPropertyValue('--ad88-led').trim()||getLedColor();
    const key=[w,h,radius,ls.brightness,ls.speed,ls.effect,color,ls.enabled,ls.thick].join('|');
    svg.setAttribute('viewBox',`0 0 ${w} ${h}`);svg.setAttribute('width',w);svg.setAttribute('height',h);
    if(svg.dataset.key===key) return;
    svg.dataset.key=key;
    svg.style.color=color;
    { const b=Math.max(.1,Math.min(3,ls.brightness/100)); svg.style.filter=b>1?`brightness(${(1+(b-1)*.45).toFixed(2)}) saturate(${(1+(b-1)*.3).toFixed(2)}) drop-shadow(0 0 ${((b-1)*2.2).toFixed(1)}px ${color})`:''; }
    svg.style.display=ls.enabled?'':'none';
    svg.innerHTML=ls.enabled?buildLedMarkup(w,h,radius,ls):'';
  }

  function clampRootToViewport(root, preferPanel=false){
    const panel=q('#ad88-tool-panel',root);
    const fab=q('#ad88-tool-fab',root);
    const target=preferPanel && panel && !panel.classList.contains('ad88-hidden') ? panel : (panel && !panel.classList.contains('ad88-hidden') ? panel : fab);
    if(!target)return;
    const rr=root.getBoundingClientRect();
    const tr=target.getBoundingClientRect();
    let dx=0,dy=0;
    const margin=6;
    if(tr.left < margin) dx=margin-tr.left;
    else if(tr.right > window.innerWidth-margin) dx=(window.innerWidth-margin)-tr.right;
    if(tr.top < margin) dy=margin-tr.top;
    else if(tr.bottom > window.innerHeight-margin) dy=(window.innerHeight-margin)-tr.bottom;
    if(dx||dy){
      const x=Math.max(0,Math.min(rr.left+dx,window.innerWidth-rr.width));
      const y=Math.max(0,Math.min(rr.top+dy,window.innerHeight-rr.height));
      root.style.left=x+'px';root.style.top=y+'px';root.style.right='auto';root.style.bottom='auto';
    }
  }
  function restorePosition(root){
    let saved=null;
    try{ saved=JSON.parse(localStorage.getItem('AD88_XNK_TOOL_POSITION')||'null'); }catch{}
    const apply=()=>{
      const panel=q('#ad88-tool-panel',root);
      const target=panel && !panel.classList.contains('ad88-hidden') ? panel : q('#ad88-tool-fab',root);
      const r=target?.getBoundingClientRect();
      const w=r?.width||54, h=r?.height||54;
      const sx=Number.isFinite(saved?.x)?saved.x:(window.innerWidth-w-10);
      const sy=Number.isFinite(saved?.y)?saved.y:(window.innerHeight-h-10);
      const x=Math.max(4,Math.min(sx,window.innerWidth-w-4));
      const y=Math.max(4,Math.min(sy,window.innerHeight-h-4));
      root.style.left=x+'px';root.style.top=y+'px';root.style.right='auto';root.style.bottom='auto';
      clampRootToViewport(root);
    };
    requestAnimationFrame(()=>requestAnimationFrame(apply));
  }
  function savePosition(root){
    const r=root.getBoundingClientRect();
    try{localStorage.setItem('AD88_XNK_TOOL_POSITION',JSON.stringify({x:Math.round(r.left),y:Math.round(r.top)}));}catch{}
  }
  function makeDraggable(root){
    const handles=[q('#ad88-tool-fab',root),q('.ad88-head',root)].filter(Boolean);
    handles.forEach(handle=>{
      let drag=null;
      handle.addEventListener('pointerdown',e=>{
        // FAB itself is the drag handle; header buttons are excluded.
        // The previous guard rejected the FAB because the FAB is a <button>,
        // making it impossible to drag the collapsed Tool.
        if(e.button!==0) return;
        if(handle !== q('#ad88-tool-fab',root) && e.target.closest('button')) return;
        const r=root.getBoundingClientRect();
        drag={sx:e.clientX,sy:e.clientY,x:r.left,y:r.top,moved:false};
        handle.setPointerCapture?.(e.pointerId);
        e.preventDefault();
      });
      handle.addEventListener('pointermove',e=>{
        if(!drag)return;
        const dx=e.clientX-drag.sx,dy=e.clientY-drag.sy;
        if(Math.abs(dx)+Math.abs(dy)>4)drag.moved=true;
        if(!drag.moved)return;
        const r=root.getBoundingClientRect();
        const x=Math.max(4,Math.min(drag.x+dx,window.innerWidth-r.width-4));
        const y=Math.max(4,Math.min(drag.y+dy,window.innerHeight-r.height-4));
        root.style.left=x+'px';root.style.top=y+'px';root.style.right='auto';root.style.bottom='auto';
      });
      handle.addEventListener('pointerup',()=>{
        if(drag?.moved){savePosition(root);root.dataset.ad88Dragged='1';}
        drag=null;
      });
      handle.addEventListener('pointercancel',()=>{if(drag?.moved)savePosition(root);drag=null;});
    });
  }
  function bind(root){
    q('#ad88-tool-fab',root).onclick=()=>{
      if(root.dataset.ad88Dragged==='1'){delete root.dataset.ad88Dragged;return;}
      const panel=q('#ad88-tool-panel',root);const open=panel.classList.toggle('ad88-hidden')===false;setToolPanelOpen(open);requestAnimationFrame(()=>{clampRootToViewport(root,true);savePosition(root);updateLedFrame(panel);});
    };
    makeDraggable(root);
    makeResizable(root);
    window.addEventListener('keydown',e=>{
      if(e.ctrlKey && e.shiftKey && e.code==='KeyA'){
        e.preventDefault();
        const panel=q('#ad88-tool-panel',root);
        const w=panel?.getBoundingClientRect().width||282, h=panel?.getBoundingClientRect().height||420;
        const x=Math.max(6,(window.innerWidth-w)/2), y=Math.max(6,(window.innerHeight-h)/2);
        root.style.left=x+'px';root.style.top=y+'px';root.style.right='auto';root.style.bottom='auto';
        savePosition(root);
        panel?.classList.remove('ad88-hidden');
        setToolPanelOpen(true);
        requestAnimationFrame(()=>{clampRootToViewport(root,true);savePosition(root);});
      }
    });
    root.addEventListener('click',e=>{
      const b=e.target.closest('button');if(!b)return;const act=b.dataset.act,page=b.dataset.page;
      if(b.dataset.led){setLedColor(b.dataset.led);return;}
      if(act==='min'){q('#ad88-tool-panel',root).classList.add('ad88-hidden');setToolPanelOpen(false);savePosition(root);return;}
      if(act==='stats'){toggleStatsView(root);return;}
      if(act==='home'){
        const home=q('#ad88-home-content',root), stats=q('#ad88-stats-view',root), main=q('#ad88-tool-main',root);
        if(stats&&home&&main){stats.classList.add('ad88-hidden');home.classList.remove('ad88-hidden');main.classList.remove('stats-mode');}
        const sb=q('[data-act="stats"]',root);if(sb)sb.classList.remove('is-active');
        return;
      }
      if(act==='close'){q('#ad88-tool-panel',root).classList.add('ad88-hidden');setToolPanelOpen(false);savePosition(root);return;}
      if(act==='run'){
        window.AD88_LICENSE?.getStatus?.().then(lic=>{
          if(!lic?.ok){ alert('🔒 ' + (lic?.message || 'Vui lòng kích hoạt License trong Cài đặt → Mở khóa Key.')); openPage('license'); return; }
          window.AD88_XNK_BOT?.start?.(); renderStatus();
        }); return;
      }
      if(act==='stop'){window.AD88_XNK_BOT?.stop?.();renderStatus();return;}
      if(page==='provider-amount'){openPage('provider-amount');return;}
      if(page)openPage(page);
    });
  }

  function getPanelSize(){
    const panel=q('#ad88-tool-panel');
    const r=panel?.getBoundingClientRect();
    return {w:r?.width||282,h:r?.height||420};
  }
  function saveSize(panel){
    const r=panel.getBoundingClientRect();
    const isNew=panel.closest('#ad88-xnk-tool-root')?.dataset.ui==='new';
    const key=isNew?'AD88_XNK_TOOL_SIZE_NEWUI':'AD88_XNK_TOOL_SIZE';
    try{localStorage.setItem(key,JSON.stringify({w:Math.round(r.width),h:Math.round(r.height)}));}catch{}
  }
  function restoreSize(panel){
    let saved=null;
    const isNew=panel.closest('#ad88-xnk-tool-root')?.dataset.ui==='new';
    const key=isNew?'AD88_XNK_TOOL_SIZE_NEWUI':'AD88_XNK_TOOL_SIZE';
    try{saved=JSON.parse(localStorage.getItem(key)||'null');}catch{}
    if(!saved)return;
    const defaultW=isNew?460:282, defaultH=isNew?375:420;
    const sw=(isNew && saved && saved.w<390)?defaultW:(saved?.w||defaultW);
    const sh=(isNew && saved && saved.h<330)?defaultH:(saved?.h||defaultH);
    const w=Math.max(isNew?460:240,Math.min(sw,isNew?1000:520));
    const h=Math.max(isNew?260:300,Math.min(sh,isNew?850:window.innerHeight-8));
    panel.style.width=w+'px';
    panel.style.height=h+'px';
  }
  function updateNewLayout(panel){
    if(!panel || panel.closest('#ad88-xnk-tool-root')?.dataset.ui!=='new') return;
    const main=q('#ad88-tool-main',panel.parentElement);
    const actions=q('.new-actions',main);
    const dash=q('.new-dashboard',main);
    const current=q('.current-card',main);
    if(!main||!actions||!dash||!current)return;
    const cs=getComputedStyle(main);
    const padY=(parseFloat(cs.paddingTop)||0)+(parseFloat(cs.paddingBottom)||0);
    const available=Math.max(0,main.clientHeight-padY);
    const actionH=actions.offsetHeight;
    const currentH=92;
    const gap=8;
    const minDash=300;
    const target=Math.max(minDash,available-actionH-currentH-gap);
    dash.style.height=Math.round(target)+'px';
    dash.style.minHeight=minDash+'px';
  }

  function updateNewUiScale(panel){
    /* 1.4.6: typography stays at a fixed readable size.
       Resizing changes the viewport only; short panels scroll vertically. */
    if(!panel)return;
    panel.style.setProperty('--new-ui-scale','1');
  }
  function makeResizable(root){
    const panel=q('#ad88-tool-panel',root),br=q('#ad88-resize-handle',root),tl=q('#ad88-resize-handle-tl',root);
    if(!panel||!br)return;
    restoreSize(panel);
    updateNewUiScale(panel);updateNewLayout(panel);
    let resize=null;
    const start=(handle,e,corner)=>{
      if(e.button!==0)return;
      const r=panel.getBoundingClientRect(), rr=root.getBoundingClientRect();
      resize={sx:e.clientX,sy:e.clientY,w:r.width,h:r.height,rootX:rr.left,rootY:rr.top,moved:false,corner};
      handle.setPointerCapture?.(e.pointerId);
      e.preventDefault();e.stopPropagation();
    };
    const move=e=>{
      if(!resize)return;
      const dx=e.clientX-resize.sx,dy=e.clientY-resize.sy;
      const isNew=root.dataset.ui==='new';
      const minW=isNew?460:240,minH=isNew?260:300;
      const maxW=Math.min(isNew?1000:520,window.innerWidth-8);
      const maxH=Math.min(isNew?850:820,window.innerHeight-8);
      let w,h;
      if(resize.corner==='tl'){
        w=Math.max(minW,Math.min(maxW,resize.w-dx));
        h=Math.max(minH,Math.min(maxH,resize.h-dy));
        root.style.left=Math.max(4,resize.rootX+(resize.w-w))+'px';
        root.style.top=Math.max(4,resize.rootY+(resize.h-h))+'px';
      }else{
        w=Math.max(minW,Math.min(maxW,resize.w+dx));
        h=Math.max(minH,Math.min(maxH,resize.h+dy));
      }
      panel.style.width=w+'px';panel.style.height=h+'px';
      resize.moved=true;
      updateNewUiScale(panel);updateNewLayout(panel);updateLedFrame(panel);
    };
    const finish=()=>{if(!resize)return;if(resize.moved){saveSize(panel);savePosition(root);}resize=null;};
    br.addEventListener('pointerdown',e=>start(br,e,'br'));
    br.addEventListener('pointermove',move);br.addEventListener('pointerup',finish);br.addEventListener('pointercancel',finish);
    if(tl){tl.addEventListener('pointerdown',e=>start(tl,e,'tl'));tl.addEventListener('pointermove',move);tl.addEventListener('pointerup',finish);tl.addEventListener('pointercancel',finish);}
  }
  function renderStatus(){
    const st=window.AD88_XNK_BOT?.status?.()||{};S.running=!!st.auto;
    const h=st.health||healthStatus();
    const set=(id,v)=>{const e=q('#'+id);if(e)e.textContent=v};
    set('tool-run-status',S.running?'ĐANG CHẠY':'ĐÃ DỪNG');
    const now=new Date();
    set('tool-runtime',now.toLocaleTimeString('vi-VN',{hour12:false,hour:'2-digit',minute:'2-digit',second:'2-digit'}));
    const runBtn=q('.new-actions .run,.ad88-runrow .run'), stopBtn=q('.new-actions .stop,.ad88-runrow .stop');
    if(runBtn&&stopBtn){runBtn.classList.toggle('is-active',!S.running);runBtn.classList.toggle('is-inactive',S.running);stopBtn.classList.toggle('is-active',S.running);stopBtn.classList.toggle('is-inactive',!S.running);}
    set('tool-order',st.currentOrder||h.currentOrder||'—');
    set('tool-done',st.processed?.length||h.processed||0);
    set('tool-skip',st.skipped?.length||h.skipped||0);
    set('tool-manual',st.manual?.length||h.manual||0);
    const [tone,label]=healthTone(h);
    set('tool-health-label',label);
    const speed=h.avgProcessMs ? ((60000/h.avgProcessMs).toFixed(1)+' đơn/phút') : '—';
    set('tool-speed',speed);
    set('tool-avg',fmtMs(h.avgProcessMs));
    set('new-health-tool',S.running?'Đang chạy':'Đã dừng');
    set('new-health-web',h.heartbeatMs!=null && h.heartbeatMs<5000?'Ổn định':(h.heartbeatMs<10000?'Chậm':'Mất kết nối'));
    set('new-health-api',h.avgApiMs!=null?fmtMs(h.avgApiMs):'—');
    set('new-health-dom',h.currentStep&&h.currentStep!=='Sẵn sàng'?'Ready':'Ready');
    set('new-health-queue',String(h.queue||0)+' đơn');
    set('new-health-order',h.currentOrder||'—');
    set('new-health-step',h.currentStep||'Sẵn sàng');
    set('new-health-last',fmtMs(h.lastActionMs));
    set('new-health-errors',String(h.errors||0)+' / '+String(h.timeouts||0));
    const setStatusTone=(id,cls)=>{const e=q('#'+id);if(e)e.className=cls};
    setStatusTone('new-health-tool',S.running?'status-green':'status-red');
    setStatusTone('new-health-web',h.heartbeatMs!=null&&h.heartbeatMs<5000?'status-green':(h.heartbeatMs<10000?'status-amber':'status-red'));
    setStatusTone('new-health-api','status-blue');
    setStatusTone('new-health-dom','status-green');
    setStatusTone('new-health-queue','status-blue');
    setStatusTone('new-health-order','status-blue');
    setStatusTone('new-health-step','status-amber');
    setStatusTone('new-health-last','status-blue');
    setStatusTone('new-health-errors',(Number(h.errors||0)+Number(h.timeouts||0))===0?'status-green':'status-red');
    set('new-order-id',h.currentOrder||'—');
    set('new-order-amount', h.currentAmount!=null ? Number(h.currentAmount).toLocaleString('vi-VN') : '—');
    set('new-order-currency', h.currentCurrency || 'VNĐ');
    set('new-order-provider', h.currentProvider || 'Đang chọn...');
    set('new-order-time',h.currentElapsedMs?Math.floor(h.currentElapsedMs/1000).toString().padStart(2,'0')+'s':'00:00');
    set('new-order-status',S.running?(h.currentStep||'Đang kiểm tra'):'Đã dừng');
    set('tool-fastest',fmtMs(h.fastestMs));
    set('tool-slowest',fmtMs(h.slowestMs));
    const avgSpeed=h.avgProcessMs ? 60000/h.avgProcessMs : null;
    if(Number.isFinite(avgSpeed)){S.speedHistory.push(avgSpeed);if(S.speedHistory.length>24)S.speedHistory.shift();}
    const svg=q('#tool-speed-chart');
    if(svg && S.speedHistory.length){
      const vals=S.speedHistory, max=Math.max(1,...vals), min=0, w=220, hgt=70, pad=3;
      const pts=vals.map((v,i)=>{const x=vals.length===1?w/2:pad+i*(w-2*pad)/(vals.length-1);const y=pad+(hgt-pad*2)*(1-v/max);return [x,y];});
      const points=pts.map(p=>p.join(',')).join(' ');
      const line=q('#speed-line');if(line)line.setAttribute('points',points);
      const area=q('#speed-area');if(area)area.setAttribute('d',`M${pts[0][0]} ${hgt} L${pts.map(p=>p.join(' ')).join(' L')} L${pts[-1]?.[0]||pts[pts.length-1][0]} ${hgt} Z`);
      const dots=q('#speed-dots');if(dots)dots.innerHTML=pts.map(([x,y])=>`<circle cx="${x}" cy="${y}" r="2.2" fill="#2DB38D"/>`).join('');
    }
    const bar=q('#tool-healthbar');
    if(bar){bar.classList.remove('good','warn','bad','idle');bar.classList.add(tone);}
    const dot=q('#tool-health-dot');if(dot){dot.className='health-dot '+tone;}
  }
  let lastNoticeKey='';
  function refreshCore(){
    renderStatus();
    let lastDone=0,lastSkipped=0,lastManual=0;
    const timer=setInterval(()=>{
      if(!document.body.contains(q('#ad88-xnk-tool-root'))){clearInterval(timer);return;}
      const st=window.AD88_XNK_BOT?.status?.()||{};
      const doneCount=st.processed?.length||0, skippedCount=st.skipped?.length||0, manualCount=st.manual?.length||0;
      if((doneCount>lastDone||skippedCount>lastSkipped||manualCount>lastManual) && (lastDone||lastSkipped||lastManual)){playNotice();}
      lastDone=doneCount; lastSkipped=skippedCount; lastManual=manualCount;
      renderStatus();
    },1000);
  }
  function getTodayKey(){ return new Date().toLocaleDateString('vi-VN'); }
  function localDateTimeValue(d){
    const x=new Date(d);
    const pad=n=>String(n).padStart(2,'0');
    return `${x.getFullYear()}-${pad(x.getMonth()+1)}-${pad(x.getDate())}T${pad(x.getHours())}:${pad(x.getMinutes())}`;
  }
  function parseLogTimestamp(x){
    const ts=Number(x?.timestamp);
    if(Number.isFinite(ts)&&ts>0) return ts;
    const m=String(x?.date||'').match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
    const t=String(x?.time||'').match(/^(\d{1,2}):(\d{2}):(\d{2})$/);
    if(!m||!t) return 0;
    const d=new Date(Number(m[3]),Number(m[2])-1,Number(m[1]),Number(t[1]),Number(t[2]),Number(t[3]));
    return Number.isFinite(d.getTime())?d.getTime():0;
  }
  function getSavedLogRange(){
    const start=new Date(); start.setHours(0,0,0,0);
    const now=new Date();
    return {
      from:localStorage.getItem('AD88_XNK_LOG_FROM')||localDateTimeValue(start),
      to:localStorage.getItem('AD88_XNK_LOG_TO')||localDateTimeValue(now)
    };
  }
  function saveLogRange(from,to){
    localStorage.setItem('AD88_XNK_LOG_FROM',from);
    localStorage.setItem('AD88_XNK_LOG_TO',to);
  }
  function filterLogsByRange(logs,from,to){
    const fromMs=new Date(from).getTime(), toMs=new Date(to).getTime();
    if(!Number.isFinite(fromMs)||!Number.isFinite(toMs)||fromMs>toMs) return [];
    return (Array.isArray(logs)?logs:[]).filter(x=>{const ts=parseLogTimestamp(x);return ts>=fromMs&&ts<=toMs;});
  }
  function setQuickLogRange(mode){
    const now=new Date();
    if(mode==='yesterday'){
      const start=new Date(now); start.setDate(start.getDate()-1); start.setHours(0,0,0,0);
      const end=new Date(start); end.setHours(23,59,59,999);
      saveLogRange(localDateTimeValue(start),localDateTimeValue(end));
      return;
    }
    const start=new Date(now); start.setHours(0,0,0,0);
    saveLogRange(localDateTimeValue(start),localDateTimeValue(now));
  }
  function money(v,c='VND'){
    const n=Number(v);
    if(!Number.isFinite(n)) return '—';
    return `${n.toLocaleString('vi-VN')} ${c==='USDT'?'USDT':'VND'}`;
  }
  function statsRows(){
    const st=window.AD88_XNK_BOT?.status?.()||{};
    const logs=Array.isArray(st.orderLogs)?st.orderLogs:[];
    const today=getTodayKey();
    const todayLogs=logs.filter(x=>!x.date||x.date===today);
    const done=todayLogs.filter(x=>x.state==='DONE');
    const returned=todayLogs.filter(x=>x.state==='RETURN');
    const sums=arr=>{const v=arr.filter(x=>(x.currency||'VND')!=='USDT').reduce((a,x)=>a+(Number(x.amount)||0),0);const u=arr.filter(x=>x.currency==='USDT').reduce((a,x)=>a+(Number(x.amount)||0),0);return {v,u};};
    return {todayLogs,done,returned,sumDone:sums(done),sumReturned:sums(returned)};
  }
  function statsTable(title,items,type){
    const rows=items.slice().reverse().slice(0,10);
    const timeHead=type==='done'?'Thời gian giao dịch thành công':'Thời gian trả lại đơn';
    const body=rows.length?rows.map(x=>`<tr><td>${esc(x.time||'')}</td><td class="order-cell">${esc(x.order||'—')}</td><td>${money(x.amount,x.currency)}</td><td>${esc(x.provider||'—')}</td><td class="${type==='done'?'ok':'bad'}">${type==='done'?'✓ Thành công':esc(x.reason||x.label||'Đơn trả lại')}</td></tr>`).join(''):`<tr><td colspan="5" class="empty-row">Chưa có dữ liệu</td></tr>`;
    return `<section class="stats-table-card ${type}"><div class="stats-table-head"><b>${title}</b><button type="button" data-stat-all="${type}">Xem tất cả ›</button></div><div class="stats-table-scroll"><table><thead><tr><th>${timeHead}</th><th>Mã đơn</th><th>Số tiền</th><th>Nhà thứ ba</th><th>${type==='done'?'Trạng thái':'Lý do trả lại'}</th></tr></thead><tbody>${body}</tbody></table></div></section>`;
  }

  function renderFilteredLog(el,type){
    const st=window.AD88_XNK_BOT?.status?.()||{};
    const logs=Array.isArray(st.orderLogs)?st.orderLogs:[];
    const today=getTodayKey();
    const items=logs.filter(x=>(!x.date||x.date===today) && x.state===(type==='done'?'DONE':'RETURN'));
    const title=type==='done'?'DANH SÁCH ĐƠN ĐÃ XỬ LÝ':'DANH SÁCH ĐƠN TRẢ LẠI';
    const timeHead=type==='done'?'Thời gian giao dịch thành công':'Thời gian trả lại đơn';
    const rows=items.length?items.map(x=>`<div class="ad88-order-log-item ${type==='done'?'success':'skip'}"><div class="ad88-order-log-top"><span class="ad88-order-log-status">${type==='done'?'✓ THÀNH CÔNG':'↷ ĐƠN TRẢ LẠI'}</span><time>${esc(x.time||'')}</time></div><div class="ad88-order-log-order">Đơn: <b>${esc(x.order||'—')}</b></div><div class="ad88-order-log-meta">Người thao tác: <b>${esc(x.operator||'—')}</b> &nbsp; Số tiền: <b>${esc(money(x.amount,x.currency))}</b> &nbsp; Nhà thứ 3: <b>${esc(x.provider||'—')}</b></div>${type!=='done'&&x.reason?`<div class="ad88-order-log-reason">Lý do: ${esc(x.reason)}</div>`:''}</div>`).join(''):`<div class="ad88-order-log-empty">Chưa có dữ liệu ${type==='done'?'đã xử lý':'trả lại'} trong ngày hôm nay.</div>`;
    el.innerHTML=head(title)+`<div class="ad88-log-live"><div class="ad88-log-live-head"><span>${timeHead.toUpperCase()}</span><div class="ad88-log-actions"><b>${items.length}</b></div></div><div class="ad88-order-log-list">${rows}</div></div>`;
    q('[data-back]',el).onclick=back;
  }
  function renderStats(el){
    const d=statsRows();
    const total=d.done.length+d.returned.length;
    const pct=n=>total?((n/total)*100).toFixed(1):'0.0';
    el.innerHTML=`<div class="stats-page">
      <div class="stats-page-head"><div><span>▥</span><b>THỐNG KÊ XỬ LÝ HÔM NAY</b></div><div class="stats-head-actions"><label>▣ Hôm nay (${new Date().toLocaleDateString('vi-VN')})</label><button type="button" id="stats-refresh">↻ Làm mới</button></div></div>
      <div class="stats-summary">
        <div class="stats-box done"><span>✓</span><small>ĐÃ XỬ LÝ</small><strong>${d.done.length} đơn</strong><em>Tổng: ${d.sumDone.v?money(d.sumDone.v,'VND'):''}${d.sumDone.u?`${d.sumDone.v?' · ':''}${money(d.sumDone.u,'USDT')}`:''}</em><i style="width:${pct(d.done.length)}%"></i></div>
        <div class="stats-box returned"><span>↷</span><small>ĐƠN TRẢ LẠI</small><strong>${d.returned.length} đơn</strong><em>Tổng: ${d.sumReturned.v?money(d.sumReturned.v,'VND'):''}${d.sumReturned.u?`${d.sumReturned.v?' · ':''}${money(d.sumReturned.u,'USDT')}`:''}</em><i style="width:${pct(d.returned.length)}%"></i></div>
      </div>
      <div class="stats-lists">${statsTable('DANH SÁCH ĐƠN ĐÃ XỬ LÝ',d.done,'done')}${statsTable('DANH SÁCH ĐƠN TRẢ LẠI',d.returned,'returned')}</div>
      <div class="stats-home-back"><button type="button" data-act="home">← &nbsp; QUAY LẠI GIAO DIỆN TRANG CHỦ</button></div>
    </div>`;
    q('#stats-refresh',el).onclick=()=>renderStats(el);
    el.querySelectorAll('[data-stat-all]').forEach(b=>b.onclick=()=>openPage(b.dataset.statAll==='done'?'log-done':'log-returned'));
  }
  function toggleStatsView(root){
    const home=q('#ad88-home-content',root), stats=q('#ad88-stats-view',root), main=q('#ad88-tool-main',root);
    if(!home||!stats||!main)return;
    const opening=stats.classList.contains('ad88-hidden');
    if(opening){home.classList.add('ad88-hidden');stats.classList.remove('ad88-hidden');renderStats(stats);main.classList.add('stats-mode');}
    else{stats.classList.add('ad88-hidden');home.classList.remove('ad88-hidden');main.classList.remove('stats-mode');}
    const btn=q('[data-act="stats"]',root);if(btn)btn.classList.toggle('is-active',opening);
    requestAnimationFrame(()=>{updateNewLayout(q('#ad88-tool-panel',root));updateLedFrame(q('#ad88-tool-panel',root));});
  }
  function openPage(page){const main=q('#ad88-tool-main'),sub=q('#ad88-tool-sub');if(!main||!sub)return;main.classList.add('ad88-hidden');sub.classList.remove('ad88-hidden');sub.classList.remove('provider-page-host');if(page==='health')renderHealthPage(sub);else if(page==='providers')renderProviders(sub);else if(page==='provider-amount')renderProviderAmountSettings(sub);else if(page==='settings')renderSettings(sub);else if(page==='license')renderLicenseSettings(sub);else if(page==='apikeys')renderApiKeys(sub);else if(page==='led')renderLedSettings(sub);else if(page==='log')renderLog(sub);else if(page==='log-done')renderFilteredLog(sub,'done');else if(page==='log-returned')renderFilteredLog(sub,'returned');else renderAbout(sub);}
  function back(){q('#ad88-tool-main')?.classList.remove('ad88-hidden');q('#ad88-tool-sub')?.classList.add('ad88-hidden');}
  function head(title){return `<div class="ad88-subhead"><button data-back="1">‹</button><b>${title}</b><button data-back="1">×</button></div>`;}
  window.addEventListener('AD88_ORDER_LOG_CHANGED',()=>{const sub=q('#ad88-tool-sub');if(sub&&!sub.classList.contains('ad88-hidden')&&sub.querySelector('.ad88-log-live'))renderLog(sub);});
  function renderProviders(el){
    el.classList.add('provider-page-host');
    const st=getProviderState();
    el.innerHTML=head('Bật/tắt nhà thứ 3')+`<div class="ad88-provider-list">${PROVIDERS.map(name=>{
      const on=st[name]!==false;
      return `<label class="ad88-provider-row"><span class="provider-dot"></span><b>${name}</b><input class="provider-toggle" data-provider="${name}" type="checkbox" ${on?'checked':''}><i class="provider-switch"><span></span><em>${on?'✓':'×'}</em></i></label>`;
    }).join('')}</div><div class="ad88-balance-foot"><span>Chỉ bật nhà được phép tự động đẩy đơn</span></div>`;
    el.scrollTop=0;
    requestAnimationFrame(()=>{el.scrollTop=0;});
    q('[data-back]',el).onclick=back;
    el.querySelectorAll('.provider-toggle').forEach(inp=>inp.onchange=()=>{const s=getProviderState();s[inp.dataset.provider]=inp.checked;setProviderState(s);inp.closest('.ad88-provider-row')?.classList.toggle('off',!inp.checked);});
  }
  function renderSettings(el){
    const st=getToolSettings();
    el.innerHTML=head('Cài đặt')+`<div class="ad88-settings"><h4>Cài đặt chung</h4>${toggle('auto','Tự động xử lý đơn',st.auto)}${toggle('bank','Tự động kiểm tra Bank',st.bank)}${toggle('unlock','Tự động mở khóa',st.unlock)}<button class="setting-row" id="provider-amount-settings" data-page="provider-amount" type="button">💰 <span>Cài đặt số tiền bên thứ 3</span><i>›</i></button><button class="setting-row provider-toggle-settings" id="provider-toggle-settings">🏦 <span>Bật/tắt nhà thứ 3</span><i>›</i></button><h4>Nhật ký</h4><button class="setting-row" id="return-reason-log-settings" type="button">▤ <span>Log lý do đơn trả lại</span><b>${st.returnReasonLog?'BẬT':'TẮT'}</b><i>›</i></button><h4>Cấu hình LED</h4><button class="setting-row" id="led-settings">💡 <span>Điều chỉnh đèn LED</span><i>›</i></button><h4>Cấu hình xử lý</h4><button class="setting-row" id="process-time">⏱ <span>Thời gian xử lý</span><i>›</i></button><button class="setting-row" id="reset-session">↻ <span>Đặt lại phiên xử lý</span><i>›</i></button><h4>License</h4><button class="setting-row" id="license-settings">🔑 <span>Mở khóa Key</span><i>›</i></button><h4>Bảo mật &amp; cập nhật</h4><button class="setting-row" id="check-update" type="button">↻ <span>Cập nhật Tool</span><b id="update-badge">v${AD88_VERSION}</b><i>›</i></button><h4>Khác</h4><button class="setting-row" id="clear-log">♲ <span>Xóa nhật ký phiên</span><i>›</i></button><div class="setting-row">🌐 <span>Ngôn ngữ</span><b>Tiếng Việt</b></div></div>`;
    q('[data-back]',el).onclick=back;
    ['auto','bank','unlock'].forEach(id=>{
      const input=q('#'+id,el);
      input.onchange=e=>{
        setToolSetting(id,e.target.checked);
        if(id==='auto'){
          if(e.target.checked) window.AD88_XNK_BOT?.start?.(); else window.AD88_XNK_BOT?.stop?.();
          renderStatus();
        }
      };
    });
    q('#provider-amount-settings',el).onclick=e=>{e.preventDefault();e.stopPropagation();openPage('provider-amount');};
    q('#provider-toggle-settings',el).onclick=()=>openPage('providers');
    q('#return-reason-log-settings',el).onclick=()=>renderReturnReasonLogSettings(el);
    q('#license-settings',el).onclick=()=>openPage('license');
    q('#led-settings',el).onclick=()=>openPage('led');
    q('#reset-session',el).onclick=()=>{
      window.AD88_XNK_BOT?.reset?.();
      renderStatus();
      alert('Đã đặt lại phiên xử lý. Lịch sử đơn của phiên hiện tại đã được xóa.');
    };
    q('#clear-log',el).onclick=()=>{
      window.AD88_XNK_BOT?.reset?.();
      renderStatus();
      alert('Đã xóa nhật ký phiên xử lý.');
    };
    q('#process-time',el).onclick=()=>renderProcessTiming(el);
    q('#check-update',el).onclick=async()=>{
      const r=await ad88SendToBackground({type:'AD88_OPEN_UPDATE',auto:true},5000);
      if(!r||!r.ok)alert('Không mở được trang cập nhật: '+((r&&r.message)||'thử F5 trang BO.'));
    };
    ad88SendToBackground({type:'AD88_CHECK_UPDATE'},8000).then(r=>{const b=q('#update-badge',el);if(!b)return;b.textContent=(r&&r.ok&&r.available)?('CÓ BẢN MỚI '+r.version):('v'+AD88_VERSION);if(r&&r.ok&&r.available)b.style.color='#ffb454';});
  }
  // showToast được gọi ở nhiều nơi (tải CSV, kích hoạt…) nhưng trước đây chưa được định nghĩa.
  function showToast(message,error=false){try{showToolToast(q('#ad88-tool-sub')||document.body,message,error);}catch(e){}}
  function renderApiKeys(el){
    el.innerHTML=head('Khóa API Bank Check')+`<div class="ad88-timing ad88-sync-page"><div class="sync-intro"><div class="sync-intro-icon">🔑</div><div><b>Khóa API Bank Check</b><small>Khóa chỉ lưu trong bộ nhớ extension, không nằm trong mã nguồn. Không chia sẻ khóa này cho người khác.</small></div></div><div class="sync-section-title">TRẠNG THÁI</div><div class="setting-row"><span>Khóa hiện tại</span><b id="key-state">…</b></div><div class="sync-section-title">NHẬP KHÓA</div><div class="sync-grid"><label class="sync-field"><span>License Key</span><div><input id="key-license" type="password" autocomplete="off" spellcheck="false" placeholder="ak_…"></div></label><label class="sync-field"><span>Secret Key</span><div><input id="key-secret" type="password" autocomplete="off" spellcheck="false" placeholder="sk_…"></div></label></div><button class="setting-row sync-save" id="key-save">✓ <span>Lưu khóa</span><i>›</i></button><button class="setting-row" id="key-clear">♲ <span>Xóa khóa đã lưu</span><i>›</i></button></div>`;
    q('[data-back]',el).onclick=()=>openPage('settings');
    const refresh=async()=>{const st=await window.AD88_apiKeys.status();const t=q('#key-state',el);if(t)t.textContent=(st.hasLicense&&st.hasSecret)?('ĐÃ NHẬP (…'+esc(st.licenseTail)+')'):'CHƯA NHẬP';};
    refresh();
    q('#key-save',el).onclick=async()=>{
      const l=q('#key-license',el).value.trim(),sk=q('#key-secret',el).value.trim();
      if(!l||!sk||/\s/.test(l+sk)){showToolToast(el,'Cần nhập đủ License Key và Secret Key (không chứa khoảng trắng)',true);return;}
      const ok=await window.AD88_apiKeys.save(l,sk);
      q('#key-license',el).value='';q('#key-secret',el).value='';
      await refresh();
      showToolToast(el,ok?'✓ Đã lưu khóa':'Không lưu được khóa',!ok);
    };
    q('#key-clear',el).onclick=async()=>{
      if(!confirm('Xóa License Key và Secret Key đã lưu? Bank Check sẽ không chạy cho đến khi nhập lại.'))return;
      await window.AD88_apiKeys.clear();
      await refresh();
      showToolToast(el,'Đã xóa khóa');
    };
  }
  async function renderLicenseSettings(el){
    const escLocal=v=>String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
    const icon=(name,cls='')=>{
      const a={
        key:`<svg class="${cls}" viewBox="0 0 48 48" aria-hidden="true"><path d="M19.5 27.5a9.5 9.5 0 1 1 6.1-16.8l5.3 5.3h10.4v6.1h-4v4h-4v4h-5.8l-3.5-3.5a9.5 9.5 0 0 1-4.5.9Z"/><circle cx="19" cy="18" r="3.1" fill="#07191a" stroke="none"/></svg>`,
        shield:`<svg class="${cls}" viewBox="0 0 48 48" aria-hidden="true"><path d="M24 4 40 10v11c0 10.5-6.6 18.7-16 23-9.4-4.3-16-12.5-16-23V10L24 4Z"/><path d="m16.5 24 5 5 10-11" fill="none" stroke="#07191a" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
        database:`<svg class="${cls}" viewBox="0 0 48 48" aria-hidden="true"><ellipse cx="24" cy="9" rx="14" ry="6"/><path d="M10 9v15c0 3.3 6.3 6 14 6s14-2.7 14-6V9" fill="none"/><path d="M10 24v15c0 3.3 6.3 6 14 6s14-2.7 14-6V24" fill="none"/></svg>`,
        gear:`<svg class="${cls}" viewBox="0 0 48 48" aria-hidden="true"><path d="m29.5 5 1.3 5.2a15 15 0 0 1 4.2 2.4l5.1-1.6 3.5 6-4 3.6a15 15 0 0 1 0 4.8l4 3.6-3.5 6-5.1-1.6a15 15 0 0 1-4.2 2.4L29.5 41h-7l-1.3-5.2a15 15 0 0 1-4.2-2.4l-5.1 1.6-3.5-6 4-3.6a15 15 0 0 1 0-4.8l-4-3.6 3.5-6 5.1 1.6a15 15 0 0 1 4.2-2.4L22.5 5h7Z"/><circle cx="26" cy="22" r="6" fill="#07191a" stroke="none"/></svg>`,
        lock:`<svg class="${cls}" viewBox="0 0 48 48" aria-hidden="true"><rect x="9" y="20" width="30" height="22" rx="4"/><path d="M15 20v-6c0-5 4-9 9-9s9 4 9 9v6" fill="none" stroke="currentColor" stroke-width="5"/><circle cx="24" cy="30" r="3" fill="#07191a" stroke="none"/></svg>`,
        check:`<svg class="${cls}" viewBox="0 0 48 48" aria-hidden="true"><circle cx="24" cy="24" r="20"/><path d="m14 24 7 7 14-15" fill="none" stroke="#06201c" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
        copy:`<svg class="${cls}" viewBox="0 0 48 48" aria-hidden="true"><rect x="15" y="13" width="23" height="27" rx="3" fill="none" stroke="currentColor" stroke-width="3"/><path d="M10 33V10c0-2 1.5-3 3-3h18" fill="none" stroke="currentColor" stroke-width="3"/></svg>`,
        trash:`<svg class="${cls}" viewBox="0 0 48 48" aria-hidden="true"><path d="M11 13h26M19 13V8h10v5M15 13l2 29h14l2-29" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M20 19v17M28 19v17" fill="none" stroke="currentColor" stroke-width="3"/></svg>`
      }; return a[name]||'';
    };
    el.innerHTML=head('Mở khóa Key')+`<div class="ad88-license-page christmas-license">
      <div class="ad88-license-card christmas-license-card">
        <div class="ad88-license-icon">${icon('key')}</div>
        <div class="license-card-copy"><h3>LICENSE AD88 XNK TOOL</h3><p>Kích hoạt License Key được cấp riêng cho máy này.</p></div>
        <div class="license-card-brand">AD<span>88</span><i>♛</i></div>
      </div>
      <div class="ad88-license-device christmas-device"><small>MÃ MÁY</small><b id="ad88-license-device">Đang lấy mã máy…</b><button type="button" id="ad88-copy-device">${icon('copy')}<span>Sao chép</span></button></div>
      <label class="ad88-license-label">LICENSE KEY</label>
      <textarea id="ad88-license-input" class="ad88-license-input christmas-license-input" rows="4" placeholder="Dán License Key AD88.… vào đây"></textarea>
      <div class="ad88-license-actions christmas-actions"><button type="button" id="ad88-license-activate">${icon('key')}<span>KÍCH HOẠT</span></button><button type="button" id="ad88-license-clear" class="danger">${icon('trash')} XÓA KEY</button></div>
      <div id="ad88-license-status" class="ad88-license-status christmas-status">Đang kiểm tra…</div>
      <div class="ad88-license-note">License được xác minh bằng chữ ký ECDSA P-256. Tool không chứa private key.</div>

      <section class="ad88-license-info artwork-license-info" aria-label="Thông tin và bản quyền">
        <img src="${chrome.runtime.getURL('assets/ad88-license-info-christmas.png')}" alt="AD88 XNK TOOL - Thông tin và bản quyền" draggable="false">
      </section>
    </div>`;
    q('[data-back]',el).onclick=back;
    const deviceEl=q('#ad88-license-device',el), input=q('#ad88-license-input',el), status=q('#ad88-license-status',el);
    const render=lic=>{
      deviceEl.textContent=lic.device||'—';
      status.textContent=(lic.ok?'✓ ':'✕ ')+(lic.message||'License không hợp lệ');
      status.className='ad88-license-status christmas-status '+(lic.ok?'ok':'bad');
      if(lic.ok && lic.payload) status.textContent='✓ '+lic.message+(lic.payload.n?` · ${lic.payload.n}`:'');
    };
    try{
      const token=await window.AD88_LICENSE.getToken();
      if(token) input.value=token;
      render(await window.AD88_LICENSE.getStatus());
    }catch{ status.textContent='✕ Không thể đọc trạng thái License'; status.className='ad88-license-status christmas-status bad'; }
    q('#ad88-copy-device',el).onclick=async()=>{
      try{await navigator.clipboard.writeText(deviceEl.textContent);showToast('Đã sao chép Mã máy');}
      catch{alert('Mã máy: '+deviceEl.textContent);}
    };
    q('#ad88-license-activate',el).onclick=async()=>{
      const token=input.value.trim();
      if(!token){alert('Vui lòng nhập License Key.');return;}
      const btn=q('#ad88-license-activate',el);btn.disabled=true;btn.textContent='ĐANG KIỂM TRA…';
      try{
        const lic=await window.AD88_LICENSE.activate(token);
        render(lic);
        if(lic.ok){showToast('✓ Kích hoạt License thành công');}
        else{alert('Không thể kích hoạt: '+lic.message);}
      }finally{btn.disabled=false;btn.innerHTML=icon('key')+'<span>KÍCH HOẠT</span>';}
    };
    q('#ad88-license-clear',el).onclick=async()=>{
      if(!confirm('Xóa License Key đang lưu trên máy này?'))return;
      await window.AD88_LICENSE.clearToken(); input.value=''; render(await window.AD88_LICENSE.getStatus());
      try{window.AD88_XNK_BOT?.stop?.();}catch{}
    };
  }

  function renderReturnReasonLogSettings(el){
    const on=!!getToolSettings().returnReasonLog;
    el.innerHTML=head('Log lý do đơn trả lại')+`<div class="ad88-return-reason-settings"><div class="return-reason-intro"><div class="return-reason-icon">▤</div><div><b>CHI TIẾT LÝ DO ĐƠN TRẢ LẠI</b><small>Khi Bank Check kết luận sai thông tin, nhật ký sẽ lưu nguyên nhân cụ thể để dễ đối chiếu.</small></div></div><label class="setting-row"><span>Hiển thị lý do chi tiết trong nhật ký</span><input id="cfg-return-reason-log" type="checkbox" ${on?'checked':''}><i class="switch"></i></label><div class="return-reason-example"><b>Ví dụ log</b><div>HỌ TÊN KHÔNG KHỚP · Tên trên đơn: NGUYEN VAN MINH · Tên từ API: NGUYEN TRAN THU HAI · Chi tiết: Tên chủ tài khoản không khớp...</div></div><div class="return-reason-note">Tắt mục này không xóa nhật ký cũ. Các đơn trả lại mới sẽ chỉ lưu lý do ngắn.</div></div>`;
    q('[data-back]',el).onclick=()=>openPage('settings');
    q('#cfg-return-reason-log',el).onchange=e=>setToolSetting('returnReasonLog',e.target.checked);
  }

  function renderProviderAmountSettings(el){
    const cfg=getProviderConfigState();
    el.innerHTML=head('Cài đặt số tiền bên thứ 3')+`<div class="ad88-provider-config"><div class="provider-config-note">Cài đặt khoảng tiền xử lý cho từng nhà thứ 3. <b>VND: nhập trực tiếp số tiền</b> · <b>USDT: nhập đúng số USDT</b>. Số tiền sẽ tự thêm dấu chấm để dễ đọc, ví dụ <b>5.000.000</b> hoặc <b>10.000.000</b>.</div><div class="provider-config-list">${PROVIDERS.map(key=>{const x=cfg[key];const cur=x.currency||'VND';return `<div class="provider-config-card" data-key="${esc(key)}"><div class="provider-config-title"><span class="provider-dot"></span><b>${esc(x.name)}</b><em class="provider-currency ${cur==='USDT'?'usdt':'vnd'}">${cur}</em></div><div class="provider-config-fields"><label><span>MIN</span><input class="provider-min-input" type="text" inputmode="decimal" autocomplete="off" value="${x.min==null?'':formatAmountInput(x.min,cur)}" placeholder="Không giới hạn"></label><label><span>MAX</span><input class="provider-max-input" type="text" inputmode="decimal" autocomplete="off" value="${x.max==null?'':formatAmountInput(x.max,cur)}" placeholder="Không giới hạn"></label></div><div class="provider-unit-hint">${cur==='USDT'?'Đơn vị: USDT (10 = 10 USDT)':'Đơn vị: VND trực tiếp (100.000 = 100.000 VNĐ)'}</div></div>`}).join('')}<div class="provider-config-save-wrap"><button class="setting-row provider-config-save" id="save-provider-config">✓ <span>Lưu cấu hình</span><i>›</i></button></div></div></div>`;
    el.querySelectorAll('.provider-min-input,.provider-max-input').forEach(input=>{
      input.addEventListener('input',()=>{
        const card=input.closest('.provider-config-card');
        const key=card?.dataset.key;
        const cur=PROVIDER_CONFIG_DEFAULTS[key]?.currency||'VND';
        const before=input.value.slice(0,input.selectionStart??input.value.length);
        const digitsBefore=before.replace(/[^0-9]/g,'').length;
        input.value=formatAmountInput(input.value,cur);
        let pos=0,seen=0;
        while(pos<input.value.length && seen<digitsBefore){if(/[0-9]/.test(input.value[pos]))seen++;pos++;}
        try{input.setSelectionRange(pos,pos)}catch{}
      });
    });
    q('[data-back]',el).onclick=()=>openPage('settings');
    requestAnimationFrame(()=>{
      const panel=q('#ad88-tool-panel');
      const list=q('.provider-config-list',el);
      if(panel&&list){
        const available=Math.max(180,Math.min(window.innerHeight-220,panel.clientHeight-150));
        list.style.maxHeight=available+'px';
      }
    });
    q('#save-provider-config',el).onclick=()=>{
      const out={};
      let invalid='';
      el.querySelectorAll('.provider-config-card').forEach(card=>{
        const key=card.dataset.key;
        const minRaw=card.querySelector('.provider-min-input').value.trim();
        const maxRaw=card.querySelector('.provider-max-input').value.trim();
        const currency=(PROVIDER_CONFIG_DEFAULTS[key]?.currency==='USDT')?'USDT':'VND';
        const min=parseAmountInput(minRaw,currency), max=parseAmountInput(maxRaw,currency);
        const name=PROVIDER_CONFIG_DEFAULTS[key]?.name||key;
        if(min!==null && (!Number.isFinite(min)||min<0)){invalid=`MIN của ${name} không hợp lệ.`;return;}
        if(max!==null && (!Number.isFinite(max)||max<0)){invalid=`MAX của ${name} không hợp lệ.`;return;}
        if(min!==null && max!==null && min>max){invalid=`MIN không được lớn hơn MAX của ${name}.`;return;}
        out[key]={name,currency,min,max};
      });
      if(invalid){showToolToast(el,invalid,true);return;}
      out.__vndDirectUnitMigrated=true;
      setProviderConfigState(out);
      showToolToast(el,'✓ Đã áp dụng');
    };
  }
  function showToolToast(el,message,error=false){
    let toast=q('.ad88-tool-toast',el);
    if(!toast){toast=document.createElement('div');toast.className='ad88-tool-toast';const host=q('#ad88-tool-panel')||el;host.appendChild(toast);}
    toast.textContent=message;
    toast.classList.toggle('error',!!error);
    toast.classList.remove('show');
    requestAnimationFrame(()=>toast.classList.add('show'));
    clearTimeout(toast._timer);
    toast._timer=setTimeout(()=>toast.classList.remove('show'),1600);
  }
  function renderProcessTiming(el){
    const cfg=window.XNK_CONFIG||{},auto=cfg.autoSync!==false,pollMin=Number(cfg.pollMinMs)||100,pollMax=Number(cfg.pollMaxMs)||650,dmin=Number(cfg.nextOrderDelayMinMs)||350,dmax=Number(cfg.nextOrderDelayMaxMs)||3000;
    el.innerHTML=head('Tốc độ & đồng bộ')+`<div class="ad88-timing ad88-sync-page"><div class="sync-intro"><div class="sync-intro-icon">⚡</div><div><b>Tốc độ & đồng bộ</b><small>AUTO SYNC ưu tiên trạng thái DOM/API thực tế, giúp Tool không chạy nhanh hơn khi website chưa cập nhật.</small></div></div><label class="setting-row sync-master"><span>⚡ Đồng bộ tốc độ tự động</span><input id="cfg-auto-sync" type="checkbox" ${auto?'checked':''}><i class="switch"></i></label><div class="sync-section-title">THỜI GIAN CHỜ</div><div class="sync-grid"><label class="sync-field"><span>Chờ thao tác</span><div><input id="cfg-action" type="number" min="1000" max="30000" step="500" value="${Number(cfg.actionTimeoutMs)||8000}"><b>ms</b></div></label><label class="sync-field"><span>Bank Check timeout</span><div><input id="cfg-bank" type="number" min="3000" max="60000" step="500" value="${Number(cfg.bankCheckTimeoutMs)||15000}"><b>ms</b></div></label><label class="sync-field"><span>Cooldown cơ sở</span><div><input id="cfg-delay" type="number" min="100" max="30000" step="100" value="${Number(cfg.nextOrderDelayMs)||2200}"><b>ms</b></div></label></div><div class="sync-section-title">POLLING & COOLDOWN</div><div class="sync-grid"><label class="sync-field"><span>Polling MIN</span><div><input id="cfg-poll-min" type="number" min="50" max="1000" step="10" value="${pollMin}"><b>ms</b></div></label><label class="sync-field"><span>Polling MAX</span><div><input id="cfg-poll-max" type="number" min="100" max="2000" step="10" value="${pollMax}"><b>ms</b></div></label><label class="sync-field"><span>Cooldown MIN</span><div><input id="cfg-delay-min" type="number" min="100" max="10000" step="50" value="${dmin}"><b>ms</b></div></label><label class="sync-field"><span>Cooldown MAX</span><div><input id="cfg-delay-max" type="number" min="200" max="30000" step="100" value="${dmax}"><b>ms</b></div></label></div><button class="setting-row sync-save" id="save-timing">✓ <span>Lưu cấu hình tốc độ & đồng bộ</span><i>›</i></button></div>`;
    q('[data-back]',el).onclick=()=>openPage('settings');
    q('#save-timing',el).onclick=()=>{const a=Math.max(1000,Math.min(30000,Number(q('#cfg-action',el).value)||8000)),b=Math.max(3000,Math.min(60000,Number(q('#cfg-bank',el).value)||15000)),d=Math.max(100,Math.min(30000,Number(q('#cfg-delay',el).value)||2200)),pmin=Math.max(50,Math.min(1000,Number(q('#cfg-poll-min',el).value)||100)),pmax=Math.max(pmin,Math.min(2000,Number(q('#cfg-poll-max',el).value)||650)),dmin2=Math.max(100,Math.min(10000,Number(q('#cfg-delay-min',el).value)||350)),dmax2=Math.max(dmin2,Math.min(30000,Number(q('#cfg-delay-max',el).value)||3000));localStorage.setItem('AD88_XNK_CFG_ACTION_TIMEOUT',String(a));localStorage.setItem('AD88_XNK_CFG_BANK_TIMEOUT',String(b));localStorage.setItem('AD88_XNK_CFG_NEXT_DELAY',String(d));if(window.XNK_CONFIG){window.XNK_CONFIG.actionTimeoutMs=a;window.XNK_CONFIG.bankCheckTimeoutMs=b;window.XNK_CONFIG.nextOrderDelayMs=d;window.XNK_CONFIG.autoSync=!!q('#cfg-auto-sync',el).checked;window.XNK_CONFIG.pollMinMs=pmin;window.XNK_CONFIG.pollMaxMs=pmax;window.XNK_CONFIG.nextOrderDelayMinMs=dmin2;window.XNK_CONFIG.nextOrderDelayMaxMs=dmax2;}localStorage.setItem('AD88_XNK_AUTO_SYNC',String(!!q('#cfg-auto-sync',el).checked));localStorage.setItem('AD88_XNK_POLL_MIN',String(pmin));localStorage.setItem('AD88_XNK_POLL_MAX',String(pmax));localStorage.setItem('AD88_XNK_DELAY_MIN',String(dmin2));localStorage.setItem('AD88_XNK_DELAY_MAX',String(dmax2));showToolToast(el,'✓ Đã lưu cấu hình tốc độ & đồng bộ');};
  }

  function renderLedSettings(el){
    const ls=getLedSettings();
    el.innerHTML=head('Điều chỉnh đèn LED')+`<div class="ad88-led-settings ${ls.enabled?'':'led-off'}"><label class="led-onoff"><input id="led-enabled" type="checkbox" ${ls.enabled?'checked':''}><span class="led-onoff-sw"></span><b id="led-enabled-text">${ls.enabled?'Đèn LED: ĐANG BẬT':'Đèn LED: ĐÃ TẮT'}</b></label><div class="led-setting-title">🎨 Màu LED</div><div class="ad88-led-swatches led-settings-swatches">${LED_COLORS.map(c=>`<button type="button" data-led="${c.value}" title="${c.name}" style="--c:${c.value}"><span></span></button>`).join('')}</div><label class="led-range-row"><span>Độ sáng</span><output id="led-bright-out">${ls.brightness}%</output><input id="led-bright" type="range" min="10" max="300" value="${ls.brightness}"></label><label class="led-range-row"><span>Độ dày</span><output id="led-thick-out">${ls.thick}%</output><input id="led-thick" type="range" min="30" max="200" value="${ls.thick}"></label><label class="led-range-row"><span>Tốc độ</span><output id="led-speed-out">${ls.speed}%</output><input id="led-speed" type="range" min="10" max="100" value="${ls.speed}"></label><div class="led-setting-title">Hiệu ứng</div><div class="led-effects">${[['single','Chạy đơn'],['two','Hai chiều'],['multi','Nhiều điểm'],['comet','Comet Tail'],['pulse','Pulse toàn viền'],['rainbow','Rainbow Flow'],['wave','Wave'],['spark','Spark'],['chase','Đuổi 3 màu'],['dual','Hai màu đối nghịch'],['snake','Rắn dài'],['fire','Lửa'],['marquee','Bóng đèn chạy'],['xmas','Đèn Giáng sinh nhấp nháy'],['heart','Nhịp tim'],['corner','Chớp 4 góc'],['static','Tĩnh']].map(([v,n])=>`<label><input type="radio" name="led-effect" value="${v}" ${ls.effect===v?'checked':''}><span>○</span>${n}</label>`).join('')}</div></div>`;
    q('[data-back]',el).onclick=()=>openPage('settings');
    el.querySelectorAll('[data-led]').forEach(b=>b.onclick=()=>setLedColor(b.dataset.led));
    const br=q('#led-bright',el),bo=q('#led-bright-out',el); br.oninput=()=>{bo.value=br.value+'%';setLedSetting('AD88_XNK_LED_BRIGHTNESS',br.value)};
    const th=q('#led-thick',el),tho=q('#led-thick-out',el); th.oninput=()=>{tho.value=th.value+'%';setLedSetting('AD88_XNK_LED_THICK',th.value)};
    const sp=q('#led-speed',el),so=q('#led-speed-out',el); sp.oninput=()=>{so.value=sp.value+'%';setLedSetting('AD88_XNK_LED_SPEED',sp.value)};
    const en=q('#led-enabled',el);if(en)en.onchange=()=>{setLedSetting('AD88_XNK_LED_ENABLED',en.checked?'1':'0');q('#led-enabled-text',el).textContent=en.checked?'Đèn LED: ĐANG BẬT':'Đèn LED: ĐÃ TẮT';el.querySelector('.ad88-led-settings').classList.toggle('led-off',!en.checked)};
    el.querySelectorAll('input[name=led-effect]').forEach(r=>r.onchange=()=>setLedSetting('AD88_XNK_LED_EFFECT',r.value));
  }
  function toggle(id,label,on){return `<label class="setting-row"><span>⚙ ${label}</span><input id="${id}" type="checkbox" ${on?'checked':''}><i class="switch"></i></label>`;}
  function downloadOrderLogCsv(logs){
    const rows=(Array.isArray(logs)?logs:[]).filter(x=>x.state==='DONE'||x.state==='RETURN');
    if(!rows.length){
      showToast('Chưa có nhật ký để tải');
      return;
    }
    const escCsv=v=>{const s=String(v??'');return /[\",\n]/.test(s)?'\"'+s.replace(/\"/g,'\"\"')+'\"':s};
    const done=rows.filter(x=>x.state==='DONE').length;
    const returned=rows.filter(x=>x.state==='RETURN').length;
    const lines=[];
    lines.push(['BÁO CÁO NHẬT KÝ XỬ LÝ ĐƠN AD88 XNK TOOL']);
    lines.push(['Ngày xuất',new Date().toLocaleDateString('vi-VN')]);
    lines.push(['Tổng số đơn',rows.length]);
    lines.push(['Thành công',done]);
    lines.push(['Đơn trả lại',returned]);
    lines.push([]);
    lines.push(['Ngày','Thời gian','Người thao tác','Mã đơn','Kết quả','Nhà thứ 3','Số tiền VND','USDT','Lý do']);
    rows.slice().reverse().forEach(x=>lines.push([
      x.date||'',x.time||'',x.operator||'',x.order||'',x.label||x.state||'',x.provider||'',
      x.currency==='USDT'?'':(x.amount!=null?Number(x.amount).toLocaleString('vi-VN'):''),
      x.currency==='USDT'?(x.amount!=null?Number(x.amount).toLocaleString('en-US',{maximumFractionDigits:8}):''):'',
      x.reason||''
    ]));
    const csv='\uFEFF'+lines.map(r=>r.map(escCsv).join(',')).join('\r\n');
    const blob=new Blob([csv],{type:'text/csv;charset=utf-8;'});
    const url=URL.createObjectURL(blob);
    const a=document.createElement('a');
    const stamp=new Date().toISOString().slice(0,10);
    a.href=url;a.download=`AD88_XNK_NHAT_KY_${stamp}.csv`;
    document.body.appendChild(a);a.click();a.remove();
    setTimeout(()=>URL.revokeObjectURL(url),1000);
    showToast('Đã tải file nhật ký');
  }
  function renderLog(el){
    const root=q('#ad88-xnk-tool-root');
    if(!root) return;
    const st=window.AD88_XNK_BOT?.status?.()||{};
    const logs=Array.isArray(st.orderLogs)?st.orderLogs:[];
    const range=getSavedLogRange();
    const filtered=filterLogsByRange(logs,range.from,range.to).filter(x=>x.state==='DONE'||x.state==='RETURN').slice().sort((a,b)=>(Number(b.timestamp)||0)-(Number(a.timestamp)||0));
    const fmtDateTime=x=>`${esc(x.date||'—')} ${esc(x.time||'—')}`;
    const amountText=x=>x.amount!=null?`${Number(x.amount).toLocaleString('vi-VN')} ${esc(x.currency||'')}`:'—';
    const statusMeta=x=>{
      if(x.state==='DONE') return ['success','✓','Thành công'];
      if(x.state==='RETURN') return ['return','↶','Trả lại'];
      return ['return','↶','Trả lại'];
    };
    const pageSize=10;
    let page=1;
    const totalPages=Math.max(1,Math.ceil(filtered.length/pageSize));

    el.innerHTML=`<div class="ad88-log-page">
      <div class="ad88-log-page-head"><div class="ad88-log-title"><span>▣</span><div><b>NHẬT KÝ XỬ LÝ ĐƠN</b><small>Theo dõi toàn bộ hoạt động xử lý đơn của tool</small></div></div><button class="ad88-log-home" type="button" data-back="1">← QUAY LẠI GIAO DIỆN TRANG CHỦ</button></div>
      <div class="ad88-log-filter ad88-log-filter-pro"><div class="ad88-log-quick"><button type="button" id="log-today">Hôm nay</button><button type="button" id="log-yesterday">Hôm qua</button><button type="button" id="log-7days">7 ngày</button><button type="button" id="log-30days">30 ngày</button><button type="button" id="log-custom">Chọn thời gian</button></div><div class="ad88-log-date-row"><label><span>TỪ NGÀY</span><input id="log-from" type="datetime-local" value="${esc(range.from)}"></label><label><span>ĐẾN NGÀY</span><input id="log-to" type="datetime-local" value="${esc(range.to)}"></label><button type="button" id="log-apply" class="primary">⌕ ÁP DỤNG</button><button type="button" id="download-order-log" class="excel" ${filtered.length?'':'disabled'}>▣ XUẤT EXCEL</button></div></div>
      <section class="ad88-log-table-card ad88-log-table-card-full"><div class="ad88-log-table-head"><div><b>▣ DANH SÁCH NHẬT KÝ XỬ LÝ ĐƠN</b><span>Hiển thị ${filtered.length.toLocaleString('vi-VN')} dòng</span></div><span>${esc(range.from.replace('T',' '))} → ${esc(range.to.replace('T',' '))}</span></div><div class="ad88-log-table-scroll"><table class="ad88-log-table"><thead><tr><th>STT</th><th>THỜI GIAN</th><th>MÃ ĐƠN</th><th>SỐ TIỀN VND</th><th>USDT</th><th>NHÀ THỨ 3</th><th>NGƯỜI THAO TÁC</th><th>TRẠNG THÁI</th><th>LÝ DO</th></tr></thead><tbody id="ad88-log-tbody"></tbody></table></div><div class="ad88-log-pagination" id="ad88-log-pagination"></div></section>
    </div>`;

    const tbody=q('#ad88-log-tbody',el), pager=q('#ad88-log-pagination',el);
    const renderTable=()=>{
      const start=(page-1)*pageSize, rows=filtered.slice(start,start+pageSize);
      tbody.innerHTML=rows.length?rows.map((x,i)=>{const [tone,icon,label]=statusMeta(x);const isUsdt=x.currency==='USDT';const vndText=!isUsdt&&x.amount!=null?`${Number(x.amount).toLocaleString('vi-VN')} VND`:'—';const usdtText=isUsdt&&x.amount!=null?`${Number(x.amount).toLocaleString('en-US',{maximumFractionDigits:8})} USDT`:'—';return `<tr data-log-index="${start+i}"><td>${start+i+1}</td><td>${fmtDateTime(x)}</td><td class="order-no">${esc(x.order||'—')}</td><td class="amount">${vndText}</td><td class="amount ${isUsdt?'usdt':''}">${usdtText}</td><td>${esc(x.provider||'—')}</td><td>${esc(x.operator||'—')}</td><td><b class="log-status ${tone}">${icon} ${label}</b></td><td class="log-reason-cell">${x.state==='RETURN'?esc(x.reason||'—'):'—'}</td></tr>`}).join(''):`<tr><td colspan="9"><div class="ad88-log-empty">Không có đơn trong khoảng thời gian đã chọn.</div></td></tr>`;
      const nums=Array.from({length:Math.min(totalPages,7)},(_,i)=>i+1).map(p=>`<button type="button" class="${page===p?'active':''}" data-journal-page="${p}">${p}</button>`).join('');
      pager.innerHTML=`<span>Hiển thị <b>${pageSize}</b> dòng/trang</span><div><button type="button" data-journal-page="prev" aria-label="Trang trước">‹</button>${nums}${totalPages>7?`<i>…</i><button type="button" data-journal-page="${totalPages}">${totalPages}</button>`:''}<button type="button" data-journal-page="next" aria-label="Trang sau">›</button></div><span>Trang ${page} / ${totalPages} (Tổng: ${filtered.length.toLocaleString('vi-VN')} dòng)</span>`;
      pager.querySelectorAll('[data-journal-page]').forEach(b=>b.onclick=e=>{
        e.preventDefault();
        e.stopPropagation();
        const action=b.dataset.journalPage;
        const p=action==='next'?Math.min(totalPages,page+1):action==='prev'?Math.max(1,page-1):Number(action);
        if(p>=1&&p<=totalPages&&p!==page){page=p;renderTable();}
      });
    };
    renderTable();
    q('[data-back]',el).onclick=back;
    const from=q('#log-from',el),to=q('#log-to',el);
    const apply=()=>{if(!from?.value||!to?.value)return;const a=new Date(from.value).getTime(),b=new Date(to.value).getTime();if(!Number.isFinite(a)||!Number.isFinite(b)||a>b){showToast('Khoảng thời gian không hợp lệ');return;}saveLogRange(from.value,to.value);renderLog(el);};
    q('#log-apply',el).onclick=apply;
    q('#log-today',el).onclick=()=>{setQuickLogRange('today');renderLog(el);};
    q('#log-yesterday',el).onclick=()=>{setQuickLogRange('yesterday');renderLog(el);};
    q('#log-7days',el).onclick=()=>{const now=new Date(),start=new Date(now);start.setDate(start.getDate()-6);start.setHours(0,0,0,0);saveLogRange(localDateTimeValue(start),localDateTimeValue(now));renderLog(el);};
    q('#log-30days',el).onclick=()=>{const now=new Date(),start=new Date(now);start.setDate(start.getDate()-29);start.setHours(0,0,0,0);saveLogRange(localDateTimeValue(start),localDateTimeValue(now));renderLog(el);};
    q('#log-custom',el).onclick=()=>from?.focus();
    const dl=q('#download-order-log',el);if(dl)dl.onclick=()=>downloadOrderLogCsv(filtered);

    // Journal-only drag: use the desktop mouse events on the actual journal header.
    // This intentionally does NOT touch the global Tool/root drag handlers.
    const logHead=q('.ad88-log-page-head',el);
    if(logHead){
      let drag=null;
      const moveDrag=e=>{
        if(!drag)return;
        const dx=e.clientX-drag.sx,dy=e.clientY-drag.sy;
        if(Math.abs(dx)+Math.abs(dy)>3)drag.moved=true;
        if(!drag.moved)return;
        const r=root.getBoundingClientRect();
        const x=Math.max(4,Math.min(drag.x+dx,window.innerWidth-r.width-4));
        const y=Math.max(4,Math.min(drag.y+dy,window.innerHeight-r.height-4));
        root.style.left=x+'px';root.style.top=y+'px';root.style.right='auto';root.style.bottom='auto';
        e.preventDefault();
      };
      const stopDrag=()=>{
        if(!drag)return;
        if(drag.moved) savePosition(root);
        drag=null;
        document.removeEventListener('mousemove',moveDrag);
        document.removeEventListener('mouseup',stopDrag);
      };
      logHead.addEventListener('mousedown',e=>{
        if(e.button!==0 || e.target.closest('button'))return;
        const r=root.getBoundingClientRect();
        drag={sx:e.clientX,sy:e.clientY,x:r.left,y:r.top,moved:false};
        document.addEventListener('mousemove',moveDrag);
        document.addEventListener('mouseup',stopDrag);
        e.preventDefault();
      });
    }
  }
  function renderAbout(el){el.innerHTML=head('Thông tin Tool')+`<div class="ad88-about"><b>AD88 XNK TOOL</b><p>Phát triển Tool kiểm tra đơn, số tài khoản ngân hàng và xử lý đơn trên bộ WG.</p><p>Phát triển bởi <b>Awei</b> dành riêng cho <b>AD88</b>.</p><p><b>Cấm sao chép, sao lưu, phân phối, chỉnh sửa hoặc sử dụng Tool dưới bất cứ hình thức nào ngoài AD88 khi chưa được Awei cho phép.</b></p><p>Cấu hình nhà thứ 3 cho phép bật/tắt từng cổng tự động. Tắt cổng nào thì Tool không tự chọn cổng đó.</p><small>Version ${AD88_VERSION}</small></div>`;q('[data-back]',el).onclick=back;}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',create);else create();
})();