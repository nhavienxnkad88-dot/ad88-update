// AD88 XNK TOOL 1.4.253 — TỰ TRA TÊN NGƯỜI NHẬN TRÊN WEB VIETINBANK.
//   Ngân hàng khác → màn "Liên ngân hàng" (STK 24/7). Tài khoản VietinBank → màn "Chuyển tiền trong VietinBank".
// Nhận lệnh từ Tool (background) → điền Số tài khoản + chọn Ngân hàng nhận → chờ VietinBank trả tên người nhận → báo lại Tool.
// KHÔNG bao giờ bấm "Tiếp tục" / xác nhận / chuyển tiền; không nhập số tiền. Xong việc thì xoá ô Số tài khoản.
(() => {
  if (window.__ad88BwVtb) return;
  window.__ad88BwVtb = true;
  // Mã ngân hàng (BIN) → tên ngân hàng đúng như danh sách "Chọn ngân hàng nhận" của VietinBank.
  const VTB_BANKS = {"970436": "Vietcombank_Ngân hàng Ngoại thương Việt Nam (VCB)", "970418": "BIDV_Ngân hàng Đầu tư và Phát triển Việt Nam", "970405": "Agribank_Ngân hàng Nông nghiệp và Phát triển nông thôn Việt Nam", "970422": "MB_Ngân hàng Quân đội", "970407": "Techcombank_Ngân hàng Kỹ thương Việt Nam (TCB)", "970416": "ACB_Ngân hàng Á Châu", "970403": "SACOMBANK_Ngân hàng Sài Gòn Tài Lộc", "970432": "VPBank_Ngân hàng Việt Nam Thịnh vượng", "970441": "VIB_Ngân hàng Quốc tế Việt Nam", "970423": "TPBank_Ngân hàng Tiên Phong", "970426": "MSB_Ngân hàng Hàng Hải", "970406": "VikkiBank_Ngân hàng Số Vikki", "970443": "SHB_Ngân hàng Sài Gòn Hà Nội", "970429": "SCB_Ngân hàng Sài Gòn", "970449": "LPBank_Ngân hàng Lộc Phát Việt Nam (LPB)", "970424": "Shinhan_Ngân hàng Shinhan Việt Nam (SHBVN)", "970448": "OCB_Ngân hàng Phương Đông", "970437": "HDBANK_Ngân hàng Phát triển TP HCM", "970440": "SEABANK_Ngân hàng Đông Nam Á", "970425": "ABBANK_Ngân hàng An Bình", "970431": "Eximbank_Ngân hàng xuất nhập khẩu Việt Nam", "970428": "Nam Á_ Ngân hàng Nam Á", "970457": "Wooribank_Ngân hàng Woori Việt Nam", "970412": "PVcomBank_Ngân hàng Đại chúng Việt Nam", "970454": "VietCapitalBank_Ngân hàng Bản Việt", "970452": "Kien Long_Ngân hàng Kiên Long (KLB)", "970419": "NCB_Ngân hàng Quốc Dân", "970430": "PGB_NH TMCP Thinh Vuong Phat Trien", "970433": "VietBank_Ngân hàng Việt Nam Thương Tín", "546034": "CAKE_Ngân hàng số Cake by VPBank", "970438": "BaoVietBank_Ngân hàng Bảo Việt (BVB)", "970410": "StanChart_Ngân hàng Standard Chartered Việt Nam (SCVN)", "970409": "BAB_Ngân hàng Bắc Á", "970427": "VietABank_Ngân hàng Việt Á", "970414": "MBV_NHTNHH MTV VIET NAM HIEN DAI", "970400": "Saigonbank_Ngân hàng Sài Gòn Công Thương (SGB)", "458761": "HSBC_Ngân hàng HSBC Việt Nam", "970434": "Indovina_Ngân hàng Indovina (IVB)", "422589": "CIMB_Ngân hàng CIMB", "970446": "Co-opBank_Ngân hàng Hợp tác xã Việt Nam", "970408": "GPBank_Ngân hàng Kỷ Nguyên Thịnh Vượng", "970421": "VRB_Ngân hàng liên doanh Việt Nga", "970439": "Public Bank_Ngân hàng Public Việt Nam (PBVN)", "970444": "VCBNeo_Ngân hàng Ngoại thương Công nghệ số", "970442": "Hong Leong_Ngân hàng Hong Leong Viet Nam (HLBVN)", "546035": "UBANK_Ngân hàng số UBank by VPBank", "970455": "IBK_Industrial Bank of Korea - CN Hà Nội", "796500": "DBS_Ngân hàng DBS - CN HCM", "970456": "IBK_Industrial Bank of Korea - CN HCM", "970462": "Kookmin_Ngân hàng Kookmin - CN Hà Nội", "970463": "Kookmin_Ngân hàng Kookmin Bank - CN HCM", "801011": "Nonghyup_ Ngân hàng Nonghyup - CN Hà Nội", "668888": "KBank_Ngân hàng Đại chúng Kasikornbank - CN HCM", "970458": "UOB_Ngân hàng United Overseas Bank Việt Nam", "533948": "CitiBank_Ngan hang CitiBank Viet Nam", "168999": "Cathay United Bank - Chi nhánh Hồ Chí Minh", "555666": "BIDC_NH DT va PT Campuchia - CN Ha Noi", "963311": "Vikki by HDBank_Ngân hàng số Vikki by HDBank", "963326": "TNEX_Ngân hàng số TNEX by MSB", "963368": "SVFC_Cty TC TNHH MTV Shinhan VN", "963369": "Liobank_Ngân hàng số Liobank by OCB", "963388": "Timo by BVBank_Ngân hàng số Timo by BVBank", "963399": "UMEE_Ngân hàng số UMEE by KienLongBank", "963601": "DEUTSCHE BANK - CN TP HCM", "963666": "BNP_Ngân hàng BNP Paribas - CN HCM", "963668": "BNP_BNP Paribas - Ha Noi branch", "963669": "ICBC_Industrial and Commercial Bank of China", "963686": "ESUN_NH TM TNHH E.SUN - CN DONG NAI", "963688": "Bank of China (Hongkong) Limited - CN Ho Chi Minh", "970465": "SinoPac_Ngân hàng SinoPac - CN HCM", "970466": "Hana Bank_Ngân hàng KEB Hana - CN HCM", "970467": "Hana Bank_Ngân hàng KEB Hana - CN Hà Nội", "971005": "ViettelMoney_Viettel Money", "971006": "VIETTEL", "971009": "PAYX", "971011": "VNPTMoney_VNPT Money", "971014": "VTC Pay", "971015": "VNPAY", "971025": "MoMo_CTCP Dịch vụ Di động Trực tuyến", "971032": "Mobifone_TCT Viễn thông Mobifone", "971034": "Payoo_CTCP Dịch vụ Trực tuyến Cộng Đồng Việt", "971069": "VNPT FINTECH", "971100": "Napas_CTCP Thanh toán Quốc gia Việt Nam", "971101": "Zalopay", "971122": "PVcomBank Napas_PVcomBank Napas", "971133": "PVcomBank Pay_PVcomBank Pay", "977777": "MAFC_Cty tai chinh TNHH MTV Mirae Asset (Viet Nam)", "999888": "VBSP_Ngân hàng chính sách xã hội Việt Nam"};
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const norm = s => String(s || '').normalize('NFC').replace(/\s+/g, ' ').trim().toUpperCase();
  const events = [];
  window.addEventListener('message', e => {
    const d = e && e.data;
    if (e.source !== window || !d || d.source !== 'ad88-bw') return;
    events.push(d); if (events.length > 30) events.shift();
  });
  function visible(el) { return !!(el && (el.offsetWidth || el.offsetHeight || el.getClientRects().length)); }
  function rowByLabel(text) {
    const want = norm(text);
    const lab = [...document.querySelectorAll('.pl-input-group__col')].find(d => norm(d.textContent) === want);
    return lab ? lab.closest('.pl-input-group__row') : null;
  }
  function form() {
    const acc = document.querySelector('input[name="toAccount"]');
    const bankRow = rowByLabel('Chọn ngân hàng nhận');
    const ctl = bankRow && bankRow.querySelector('.vt-select__control');
    const inp = bankRow && bankRow.querySelector('.vt-select__input input, input[id^="react-select-"]');
    const nameRow = rowByLabel('Tên người nhận');
    if (!acc || !ctl || !inp) return null;
    return { acc, bankRow, ctl, inp, nameRow, mode: 'napas' };
  }
  // Màn "Chuyển tiền trong VietinBank": có ô STK, KHÔNG có ô chọn ngân hàng, có "Thời gian chuyển".
  function formInternal() {
    const acc = document.querySelector('input[name="toAccount"]');
    if (!acc || rowByLabel('Chọn ngân hàng nhận') || !rowByLabel('Thời gian chuyển')) return null;
    return { acc, nameRow: rowByLabel('Tên người nhận'), mode: 'internal' };
  }
  function loggedOut() {
    return !!document.querySelector('input[type="password"]');
  }
  // Chờ theo SỰ KIỆN (trang đổi / có kết quả gửi về), không chờ bằng vòng lặp hẹn giờ: tab chạy nền bị Chrome giãn hẹn giờ ~1 giây/lần.
  function waitFor(fn, ms) {
    return new Promise(resolve => {
      let done = false, mo = null, tm = null;
      const check = () => { if (done) return; let v = null; try { v = fn(); } catch (_) {} if (v) finish(v); };
      const finish = v => { done = true; try { mo && mo.disconnect(); } catch (_) {} window.removeEventListener('message', check); clearTimeout(tm); resolve(v); };
      check(); if (done) return;
      try { mo = new MutationObserver(check); mo.observe(document.documentElement, { subtree: true, childList: true, characterData: true, attributes: true }); } catch (_) {}
      window.addEventListener('message', check);
      tm = setTimeout(() => { if (!done) { let v = null; try { v = fn(); } catch (_) {} finish(v || null); } }, ms);
    });
  }
  // Nhường 1 nhịp cho trang vẽ lại (không bị giãn như setTimeout ở tab nền).
  function tick() { return new Promise(r => { try { const c = new MessageChannel(); c.port1.onmessage = () => r(); c.port2.postMessage(0); } catch (_) { setTimeout(r, 0); } }); }
  async function ticks(n) { for (let i = 0; i < n; i++) await tick(); }
  function setVal(inp, v) {
    const d = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value');
    d.set.call(inp, v);
    inp.dispatchEvent(new Event('input', { bubbles: true }));
    inp.dispatchEvent(new Event('change', { bubbles: true }));
  }
  function focusEl(el) {
    let fired = false; const on = () => { fired = true; };
    el.addEventListener('focus', on, { once: true });
    try { el.focus(); } catch (_) {}
    el.removeEventListener('focus', on);
    if (!fired) { el.dispatchEvent(new FocusEvent('focus')); el.dispatchEvent(new FocusEvent('focusin', { bubbles: true })); }
  }
  function blurEl(el) {
    let fired = false; const on = () => { fired = true; };
    el.addEventListener('blur', on, { once: true });
    try { el.blur(); } catch (_) {}
    el.removeEventListener('blur', on);
    if (!fired) { el.dispatchEvent(new FocusEvent('blur')); el.dispatchEvent(new FocusEvent('focusout', { bubbles: true })); }
  }
  function mouse(el, type) { el.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, button: 0, view: window })); }
  function key(el, k, code) { el.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, cancelable: true, key: k, code: k, keyCode: code, which: code })); }
  function clickText(text) {
    const sq = v => norm(v).replace(/\s+/g, '');   // bỏ khoảng trắng: menu có thể xuống dòng ("Chuyển tiền trong / VietinBank")
    const want = sq(text);
    const el = [...document.querySelectorAll('a, li, span, div, button')].find(x => x.children.length <= 2 && sq(x.textContent) === want);
    if (!el) return false;
    (el.closest('a, button') || el).click();
    return true;
  }
  function selectedBank(f) { const sv = f.bankRow.querySelector('.vt-select__single-value'); return sv ? norm(sv.textContent) : ''; }
  function options(f) {
    let o = [...f.bankRow.querySelectorAll('.vt-select__option')];
    if (!o.length) o = [...document.querySelectorAll('.vt-select__menu .vt-select__option')];
    return o;
  }
  function nameShown(f) { const r = f.nameRow || rowByLabel('Tên người nhận'); const b = r && r.querySelector('.box-view'); return b ? String(b.textContent || '').replace(/\s*\(\s*\d+\s*\)\s*$/, '').trim() : ''; }
  function sq(v) { return norm(v).replace(/\s+/g, ''); }
  // Mở dropdown "Chuyển tiền" trên thanh menu (hover + click) rồi bấm mục con. Trang chủ chưa có sẵn mục con.
  async function openTransferMenu(internal) {
    const sub = internal ? 'Chuyển tiền trong VietinBank' : 'Liên ngân hàng';
    if (clickText(sub)) return true;                       // mục con đã sẵn (đang ở khu chuyển tiền)
    const top = [...document.querySelectorAll('a, button, span, li, div')].find(x => x.children.length <= 2 && sq(x.textContent) === sq('Chuyển tiền') && visible(x));
    if (top) {
      const t = top.closest('a, li, button') || top;
      ['mouseover', 'mouseenter', 'pointerenter', 'pointerover'].forEach(ev => t.dispatchEvent(new MouseEvent(ev, { bubbles: true })));
      await sleep(400);
      if (clickText(sub)) return true;                     // mục con hiện trong dropdown
      try { t.click(); } catch (_) {}                      // hoặc bấm vào "Chuyển tiền" để vào khu chuyển tiền
      await sleep(600);
      if (clickText(sub)) return true;
    }
    return false;
  }
  // Đổi màn trong trang (không tải lại trang, giữ đăng nhập): /transfer/external = "Chuyển tiền liên ngân hàng".
  function spaGo(path) {
    try {
      if (location.pathname === path) return false;
      history.pushState({}, '', path);
      window.dispatchEvent(new PopStateEvent('popstate', { state: {} }));
      return true;
    } catch (_) { return false; }
  }
  async function ensureForm(internal) {
    const get = internal ? formInternal : form;
    let f = get();
    if (f) return f;                                       // GIỮ MÀN: đang ở đúng màn → tra ngay, không điều hướng (nhanh)
    if (loggedOut()) return null;
    if (!internal && spaGo('/transfer/external')) f = await waitFor(get, 8000);
    if (!f && await openTransferMenu(internal)) f = await waitFor(get, 10000);
    if (!f && !internal) { clickText('STK 24/7'); f = await waitFor(form, 3000); }
    return f;
  }
  async function pickBank(f, label) {
    const want = norm(label);
    if (selectedBank(f) === want) return true;
    mouse(f.ctl, 'mousedown');
    await ticks(3);
    focusEl(f.inp);
    setVal(f.inp, label.split('_')[0]);
    let opt = await waitFor(() => options(f).find(o => norm(o.textContent) === want), 3000);
    if (!opt) { key(f.inp, 'Escape', 27); return false; }
    mouse(opt, 'mouseover'); mouse(opt, 'mousemove');
    mouse(opt, 'click');
    if (await waitFor(() => selectedBank(f) === want, 1500)) return true;
    key(f.inp, 'Enter', 13);
    return !!(await waitFor(() => selectedBank(f) === want, 1500));
  }
  function fresh(t0, api = 'napasTransfer') { return events.filter(e => e.at >= t0 && e.api === api); }
  // Câu báo của ngân hàng, bỏ đoạn "thử lại sau / chuyển thường" và mã kỹ thuật trong ngoặc.
  function bankMsg(m) {
    return String(m || '').replace(/\s*\([A-Z0-9]{3,}\)\s*$/, '').replace(/\s*Quý khách vui lòng[^.]*\.?/i, '').trim().slice(0, 160);
  }
  function verdict(e) {
    if (!e) return null;
    if (!e.error && e.name) return { ok: true, found: true, name: e.name };
    const msg = String(e.msg || '');
    if (/phiên|đăng nhập|hết hạn|session/i.test(msg)) return { ok: false, reason: 'LOGGED_OUT' };
    // Ngân hàng KHÔNG CHẮC (vd. PMH_14: "TK không hợp lệ HOẶC hệ thống 24/7 của ngân hàng thụ hưởng đang bị lỗi") → chưa kết luận.
    if (/hệ thống[^.]*(lỗi|gián đoạn|bảo trì)|gián đoạn|bảo trì|tạm ngừng|không thể kết nối/i.test(msg)) return { ok: true, found: false, unsure: true, code: e.code, msg: bankMsg(msg) };
    // Ngân hàng CHẮC CHẮN không có tài khoản (RGW01 liên ngân hàng; "Tài khoản đích không hợp lệ." trong VietinBank).
    if (/không tìm thấy số tài khoản|không tìm thấy tài khoản|tài khoản đích không hợp lệ/i.test(msg)) return { ok: true, found: false, notFound: true, code: e.code, msg: bankMsg(msg) };
    if (msg) return { ok: true, found: false, unsure: true, code: e.code, msg: bankMsg(msg) };
    return { ok: false, reason: 'BANK_ERROR', code: e.code };
  }
  let busy = false;
  const VTB_BIN = '970415';
  async function lookupInternal(account) {
    const f = await ensureForm(true);
    if (!f) return { ok: false, reason: loggedOut() ? 'LOGGED_OUT' : 'NOT_TRANSFER_PAGE' };
    if (String(f.acc.value || '').trim()) { focusEl(f.acc); setVal(f.acc, ''); blurEl(f.acc); await ticks(4); }
    const before = nameShown(f);
    const t0 = Date.now();
    focusEl(f.acc); setVal(f.acc, account); blurEl(f.acc);
    const ev = await waitFor(() => fresh(t0, 'makeInternalTransfer')[0], 6000);
    if (!ev) {
      const nm = nameShown(f);
      if (nm && nm !== before && String(f.acc.value).replace(/\s+/g, '') === account) return { ok: true, found: true, name: nm, fromScreen: true };
      return { ok: false, reason: loggedOut() ? 'LOGGED_OUT' : 'NO_RESPONSE' };
    }
    if (ev.error) await waitFor(() => fresh(t0, 'makeInternalTransfer').find(e => !e.error && e.name), 300);
    const all = fresh(t0, 'makeInternalTransfer');
    return verdict(all.find(e => !e.error && e.name) || all[all.length - 1] || ev);
  }
  async function lookup(req) {
    const account = String(req.account || '').replace(/\s+/g, '');
    const internal = String(req.bin || '') === VTB_BIN;
    const label = VTB_BANKS[String(req.bin || '')];
    if (!account) return { ok: false, reason: 'NO_ACCOUNT' };
    if (!internal && !label) return { ok: false, reason: 'BANK_NOT_IN_LIST' };
    if (busy) return { ok: false, reason: 'BUSY' };
    busy = true;
    try {
      if (loggedOut()) return { ok: false, reason: 'LOGGED_OUT' };
      if (internal) return await lookupInternal(account);
      const f = await ensureForm();
      if (!f) return { ok: false, reason: loggedOut() ? 'LOGGED_OUT' : 'NOT_TRANSFER_PAGE' };
      // 1) xoá STK cũ (để đổi ngân hàng không làm trang tra STK cũ), 2) chọn ngân hàng, 3) nhập STK → trang tự tra tên.
      if (String(f.acc.value || '').trim()) { focusEl(f.acc); setVal(f.acc, ''); blurEl(f.acc); await ticks(4); }
      if (!(await pickBank(f, label))) return { ok: false, reason: 'BANK_PICK_FAILED' };
      await ticks(3);
      const before = nameShown(f);
      let t0 = Date.now();
      focusEl(f.acc); setVal(f.acc, account); blurEl(f.acc);
      let ev = await waitFor(() => fresh(t0)[0], 4500);
      if (!ev) {
        // Trang có thể chỉ tra khi đổi ngân hàng → chọn lại ngân hàng một lần nữa.
        t0 = Date.now();
        mouse(f.ctl, 'mousedown'); await ticks(3); focusEl(f.inp); setVal(f.inp, label.split('_')[0]);
        const opt = await waitFor(() => options(f).find(o => norm(o.textContent) === norm(label)), 3000);
        if (opt) { mouse(opt, 'mouseover'); mouse(opt, 'click'); } else key(f.inp, 'Escape', 27);
        ev = await waitFor(() => fresh(t0)[0], 5000);
      }
      if (!ev) {
        const nm = nameShown(f);
        if (nm && nm !== before && String(f.acc.value).replace(/\s+/g, '') === account) return { ok: true, found: true, name: nm, fromScreen: true };
        return { ok: false, reason: loggedOut() ? 'LOGGED_OUT' : 'NO_RESPONSE' };
      }
      // Lỗi tạm (2 lần gọi liền nhau): ưu tiên kết quả có tên nếu có.
      if (ev.error) await waitFor(() => fresh(t0).find(e => !e.error && e.name), 300);
      const all = fresh(t0);
      const withName = all.find(e => !e.error && e.name);
      return verdict(withName || all[all.length - 1] || ev);
    } catch (e) {
      return { ok: false, reason: 'SCRIPT_ERROR', msg: String(e && e.message || e).slice(0, 120) };
    } finally {
      try { const f = form() || formInternal(); if (f) { setVal(f.acc, ''); } } catch (_) {}
      busy = false;
    }
  }
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg || sender.id !== chrome.runtime.id) return;
    if (msg.type === 'AD88_BW_PING') { sendResponse({ ok: true, ready: !!(form() || formInternal()), loggedOut: loggedOut(), busy }); return; }
    if (msg.type !== 'AD88_BW_LOOKUP') return;
    lookup(msg).then(sendResponse, e => sendResponse({ ok: false, reason: 'SCRIPT_ERROR', msg: String(e && e.message || e) }));
    return true;
  });
})();
