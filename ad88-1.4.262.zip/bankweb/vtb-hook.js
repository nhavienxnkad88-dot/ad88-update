// AD88 XNK TOOL — chạy trong trang VietinBank iPay (world MAIN, trước khi trang tải mã của nó).
// 1) Nghe kết quả tra tên người nhận mà CHÍNH TRANG gọi (liên ngân hàng: napasTransfer; trong VietinBank: makeInternalTransfer).
// 2) 1.4.258: nghe dấu hiệu HẾT PHIÊN (yêu cầu nào của iPay bị 401/403 hoặc báo "phiên/đăng nhập lại") để ghi lý do văng.
// Không đọc gì khác, không gửi đi đâu ngoài chính trang (postMessage cho phần Tool trong cùng trang).
(() => {
  if (window.__ad88BwHook) return;
  window.__ad88BwHook = true;
  const WANT = /\/ipay\/wa\/(napasTransfer|makeInternalTransfer)(?:[?#]|$)/i;
  const API = /\/ipay\/wa\//i;
  const SESS = /phiên|đăng nhập lại|hết hạn|hết phiên|session|unauthor|token.*(hết|hạn|expire)|expired/i;
  function post(o) { try { o.source = 'ad88-bw'; o.at = Date.now(); window.postMessage(o, location.origin); } catch (_) {} }
  function emit(url, status, body) {
    let j = body;
    if (typeof body === 'string') { try { j = JSON.parse(body); } catch (_) { j = null; } }
    if (!j || typeof j !== 'object') j = {};
    const http = Number(status) || 0;
    const errMsg = String(j.errorMessage || j.message || '');
    // Dấu hiệu hết phiên: 401/403, hoặc câu báo nói về phiên/đăng nhập lại.
    if (http === 401 || http === 403 || (errMsg && SESS.test(errMsg))) {
      post({ kind: 'authfail', http, msg: errMsg.slice(0, 200) });
    }
    const m = String(url || '').match(WANT);
    if (!m) return;
    post({
      kind: 'lookup', api: m[1], http,
      error: j.error === true || j.error === 'true' || http >= 400,
      code: String(j.errorCode == null ? '' : j.errorCode).slice(0, 20),
      msg: errMsg.slice(0, 300),
      name: String(j.beneficiaryName || j.receiverAccountName || j.toAccountName || (j.acctRecvObj && j.acctRecvObj.customerName) || '')
        .replace(/\s*\(\s*\d+\s*\)\s*$/, '').trim().slice(0, 120)
    });
  }
  try {
    const XO = XMLHttpRequest.prototype.open, XS = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.open = function (method, url) { try { this.__ad88u = String(url); } catch (_) {} return XO.apply(this, arguments); };
    XMLHttpRequest.prototype.send = function () {
      try {
        if (API.test(this.__ad88u || '')) {
          this.addEventListener('loadend', () => {
            try {
              const want = WANT.test(this.__ad88u || '');
              const rt = this.responseType;
              const body = (want && (rt === '' || rt === 'text')) ? this.responseText : (want && rt === 'json' ? this.response : null);
              emit(this.__ad88u, this.status, body);
            } catch (_) {}
          });
        }
      } catch (_) {}
      return XS.apply(this, arguments);
    };
  } catch (_) {}
  try {
    const F = window.fetch;
    if (typeof F === 'function') {
      window.fetch = function (input) {
        const u = typeof input === 'string' ? input : (input && (input.url || String(input))) || '';
        const p = F.apply(this, arguments);
        if (API.test(u)) p.then(r => { try { WANT.test(u) ? r.clone().text().then(t => emit(u, r.status, t), () => {}) : emit(u, r.status, null); } catch (_) {} }, () => {});
        return p;
      };
    }
  } catch (_) {}
})();
