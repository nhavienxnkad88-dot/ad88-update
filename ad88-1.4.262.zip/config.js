// Phiên bản chỉ lấy từ manifest.json (nguồn duy nhất).
const AD88_VERSION = (() => { try { return chrome.runtime.getManifest().version; } catch (e) { return "dev"; } })();

const XNK_CONFIG = {
  version: AD88_VERSION,
  mode: "LIVE",

  // Không khóa hàng loạt.
  // Một đơn phải hoàn tất rồi mới bắt đầu đơn kế tiếp.
  processOnlyOneAtATime: true,
  nextOrderDelayMs: 2200,
  // Đồng bộ tốc độ: Tool ưu tiên chờ theo trạng thái website thay vì sleep cố định.
  autoSync: true,
  pollMinMs: 100,
  pollMaxMs: 650,
  nextOrderDelayMinMs: 350,
  nextOrderDelayMaxMs: 3000,

  actionTimeoutMs: 8000,
  bankCheckTimeoutMs: 15000,

  // Kiểm tra địa chỉ USDT TRC20 trên TRON Mainnet.
  // Có thể điền API key TronGrid nếu tài khoản của bạn yêu cầu/quản lý quota.
  tron: {
    enabled: true,
    validateUrl: "https://api.trongrid.io/wallet/validateaddress",
    apiKey: ""
  },

  invalidUsdtNote:
    "ĐỊA CHỈ VÍ USDT TRC20 KHÔNG CHÍNH XÁC HOẶC KHÔNG HỢP LỆ. QUÝ KHÁCH VUI LÒNG LIÊN HỆ CSKH 24/7 ĐỂ ĐƯỢC HỖ TRỢ Ạ!!!",

  invalidUsdtErc20Note:
    "ĐỊA CHỈ VÍ USDT ERC20 KHÔNG CHÍNH XÁC HOẶC KHÔNG HỢP LỆ. QUÝ KHÁCH VUI LÒNG LIÊN HỆ CSKH 24/7 ĐỂ ĐƯỢC HỖ TRỢ Ạ!!!",

  invalidBankNote:
    "THÔNG TIN NGÂN HÀNG QUÝ KHÁCH LIÊN KẾT KHÔNG CHÍNH XÁC. QUÝ KHÁCH VUI LÒNG LIÊN HỆ CSKH 24/7 ĐỂ ĐƯỢC HỖ TRỢ Ạ!!!",

  // 1.4.262: note khi trả đơn vì STK là số điện thoại ở VietinBank / BIDV / MSB.
  phoneNote:
    "VIETINBANK BIDV MSB ĐÃ NGỪNG SỬ DỤNG SỐ ĐIỆN THOẠI LÀM TÀI KHOẢN NHẰM TĂNG CƯỜNG BẢO MẬT. QUÝ KHÁCH VUI LÒNG LIÊN HỆ CSKH 24/7 ĐỂ ĐƯỢC HỖ TRỢ",

  // 1.4.230: note khi bật "Bảo trì ngân hàng" (buộc hủy mọi đơn).
  maintenanceNote:
    "NGÂN HÀNG THỤ HƯỞNG CỦA QUÝ KHÁCH ĐANG BẢO TRÌ XIN QUÝ KHÁCH VUI LÒNG QUAY LẠI SAU Ạ.",

  // 1.4.232: DỪNG QUA NGÀY — giờ Việt Nam CHUẨN (lấy từ máy chủ BO, không theo đồng hồ máy tính).
  // Từ dayPauseStart tới dayPauseEnd: không nhận đơn mới, không bấm Xác nhận thanh toán; hết giờ tự đẩy lại.
  dayPauseStart: "23:58:00",
  dayPauseEnd: "00:00:05",

  // Khoảng tiền mặc định của các cổng. VND dùng số tiền thực tế; USDT dùng đúng số USDT.
  // 888Pay có trong Registry để hiển thị ở Bật/tắt, Thống kê và Nhật ký; mặc định BẬT (từ 1.4.129).
  providerFallback: AD88_providerFallback(),

  allowPaymentConfirm: true
};
