// Khóa API Bank Check dựng sẵn. TỆP NÀY KHÔNG BAO GIỜ ĐƯỢC ĐƯA LÊN GITHUB (đã đóng băng: bản cập nhật không ghi đè/không chứa tệp này).
self.AD88_BUILTIN_API_KEYS = { license: "ak_cxsiCgOe1sP2RvQ5axwCbn2EHOWtb61R", secret: "sk_2e5edfe57a61fc15865cd3cd18bcc5b3c96809d1de2fd1a4" };
