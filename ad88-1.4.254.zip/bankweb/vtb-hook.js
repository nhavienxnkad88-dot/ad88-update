// AD88 XNK TOOL 1.4.253 — chạy trong trang VietinBank iPay (world MAIN, trước khi trang tải mã của nó).
// Chỉ nghe kết quả tra tên người nhận mà CHÍNH TRANG gọi (liên ngân hàng: napasTransfer; trong VietinBank: makeInternalTransfer), rút ra: có lỗi không, mã lỗi, câu báo, tên người nhận.
// Không đọc gì khác, không gửi đi đâu ngoài chính trang (postMessage cho phần Tool trong cùng trang).
(() => {
  if (window.__ad88BwHook) return;
  window.__ad88BwHook = true;
  const WANT = /\/ipay\/wa\/(napasTransfer|makeInternalTransfer)(?:[?#]|$)/i;
  function emit(url, status, body) {
    const m = String(url || '').match(WANT);
    if (!m) return;
    let j = body;
    if (typeof body === 'string') { try { j = JSON.parse(body); } catch (_) { j = null; } }
    if (!j || typeof j !== 'object') { j = {}; }
    const out = {
      source: 'ad88-bw', api: m[1], http: Number(status) || 0,
      error: j.error === true || j.error === 'true' || (Number(status) >= 400),
      code: String(j.errorCode == null ? '' : j.errorCode).slice(0, 20),
      msg: String(j.errorMessage || '').slice(0, 300),
      name: String(j.beneficiaryName || j.receiverAccountName || j.toAccountName || (j.acctRecvObj && j.acctRecvObj.customerName) || '')
        .replace(/\s*\(\s*\d+\s*\)\s*$/, '').trim().slice(0, 120),
      at: Date.now()
    };
    try { window.postMessage(out, location.origin); } catch (_) {}
  }
  try {
    const XO = XMLHttpRequest.prototype.open, XS = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.open = function (method, url) { try { this.__ad88u = String(url); } catch (_) {} return XO.apply(this, arguments); };
    XMLHttpRequest.prototype.send = function () {
      try {
        if (WANT.test(this.__ad88u || '')) {
          this.addEventListener('loadend', () => {
            try {
              const rt = this.responseType;
              const body = (rt === '' || rt === 'text') ? this.responseText : (rt === 'json' ? this.response : null);
              emit(this.__ad88u, this.status, body);
            } catch (_) {}
          });
        }
      } catch (_) {}
      return XS.apply(this, arguments);
    };
  } catch (_) {}
  try {
    const F = window.fetch;
    if (typeof F === 'function') {
      window.fetch = function (input, init) {
        const u = typeof input === 'string' ? input : (input && (input.url || String(input))) || '';
        const p = F.apply(this, arguments);
        if (WANT.test(u)) p.then(r => { try { r.clone().text().then(t => emit(u, r.status, t), () => {}); } catch (_) {} }, () => {});
        return p;
      };
    }
  } catch (_) {}
})();
